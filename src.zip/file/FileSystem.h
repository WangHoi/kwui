#ifndef FILE_SYSTEM_H
#define FILE_SYSTEM_H

#include "pattern/singleton.h"
#include "string/String.h"

SMART_REF(IFile);
class FileSystem {
public:
    FileSystem();
    ~FileSystem();

    IFileHandle OpenRead(const String& filename) { return Open(filename, "rb"); }
	IFileHandle OpenReadText(const String& filename) { return Open(filename, "r"); }
    IFileHandle OpenWrite(const String& filename) { return Open(filename, "wb"); }
	IFileHandle OpenWriteText(const String& filename) { return Open(filename, "w"); }
    void Close(IFile* f);
    bool Exists(const String& filename) const;
    vector<String> GetFileList(const String& dir, bool recursive = true);

private:
    void Init();
    IFileHandle Open(const String& filename, const char* mode);
    pointer _idx_data;
    vector<const char*> _string_table;
    SUPPORT_SINGLETON(FileSystem);
};

#endif // FILE_SYSTEM_H