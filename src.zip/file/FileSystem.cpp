#include "FileSystem.h"
#include "File.h"
#include "data/data_type.h"
#include "text/EncodingManager.h"
#include <stdio.h>

DEFINE_SINGLETON_INSTANCE(FileSystem);

#ifdef c2_log
#undef c2_log
#define c2_log(...) printf(__VA_ARGS__)
#endif

FileSystem::FileSystem() {
    Init();
}

FileSystem::~FileSystem() {
}

IFileHandle FileSystem::Open(const String& filename, const char* mode) {
    IFile* f = new CrtFile(filename, mode);
    if (f && !f->IsValid()) safe_delete(f);
    return IFileHandle(f);
}

void FileSystem::Close(IFile* f) {
    if (f) {
        f->Close();
        delete f;
    }
}

bool FileSystem::Exists(const String& filename) const {
    if (g_platform_data.use_archive) {
        for (const char* s : _string_table) {
            if (strcmp(filename.GetCString(), s) == 0) return true;
        }
    } else {
        FILE* f = nullptr;
        auto platform_filename = EncodingManager::Instance()->UTF8ToSystem(filename);
        f = fopen(platform_filename.GetCString(), "r");
        if (f) {
            fclose(f);
            return true;
        }
    }
    return false;
}

vector<String> FileSystem::GetFileList(const String& dir_, bool recursive) {
    auto dir = dir_.CanonicalPath();
    if (g_platform_data.use_archive) {
        vector<String> l;
        for (const char* s : _string_table) {
            auto len = dir.GetLength();
            if (strncmp(dir.GetCString(), s, len) == 0 && s[len] == '/') {
                if (recursive || !strchr(s + len + 1, '/')) l.push_back(s + len + 1);
            }
        }
        return l;
    } else {
        return platform_get_file_list(dir, recursive);
    }
}

static inline const char* next_string(const char* p) {
    return p + strlen(p) + 1;
}

void FileSystem::Init() {
    /*
    if (g_platform_data.use_archive) {
        FILE* f = nullptr;
        f = fopen("resource.idx", "rb");
        if (!f) {
            c2_log("[C2] Failed to load resource.idx.\n");
            abort();
        }
        fseek(f, 0, SEEK_END);
        uint32 size = (uint32)ftell(f);
        fseek(f, 0, SEEK_SET);
        _idx_data = (pointer)C2_ALLOC(g_allocator, size);
        fread(_idx_data, size, 1, f);
        fclose(f);
        ManifestDescRecord* manifest = (ManifestDescRecord*)_idx_data;
        _archives.reserve(manifest->_num_archives);
        _filename_map.reserve(manifest->_num_files);
        _string_table.reserve(manifest->_num_archives + manifest->_num_files);
        ArchiveDescRecord* archive = (ArchiveDescRecord*)&manifest[1];
        const char* p = (const char*)_idx_data + manifest->_stab_offset;
        char archive_path[256];
        for (uint32 i = 0; i < manifest->_num_archives; ++i, ++archive) {
            ArchiveDesc ar;
            ar._name = p;
            _string_table.push_back(p);
            p = next_string(p);
            ar._name_id = archive->_name_id;
            ar._size = archive->_size;
            snprintf(archive_path, sizeof(archive_path), "%s", ar._name);
            ar._fd = platform_fopen_read(archive_path);
            if (ar._fd < 0) {
                c2_log("[C2] open %s failed, error: %d.\n", ar._name, ar._fd);
                abort();
            }
            _archives.push_back(ar);
        }
        FileDescRecord* frec = (FileDescRecord*)archive;
        for (uint32 i = 0; i < manifest->_num_files; ++i, ++frec) {
            FileDesc& desc = _filename_map[frec->_name_id];
            desc._name = p;
            _string_table.push_back(p);
            p = next_string(p);
            desc._name_id = frec->_name_id;
            desc._c_size = frec->_c_size;
            desc._d_size = frec->_d_size;
            desc._file_type = frec->_file_type;
            desc._file_flags = frec->_file_flags;
            desc._archive_fd = -1;
            desc._archive_offset = 0;
            for (auto& ar : _archives) {
                if (ar._name_id == frec->_archive_name_id) {
                    desc._archive_fd = ar._fd;
                    desc._archive_offset = frec->_offset;
                    break;
                }
            }
            if (desc._archive_fd == -1) {
                c2_log("[C2] Failed to lookup '%s' in archive.\n", desc._name);
                abort();
            }
        }
    }
    */
}
