#ifndef FILE_H
#define FILE_H

#include "data/data_type.h"
#include "data/data_helpers.h"
#include "memory/MemoryRegion.h"

SMART_REF(IFile);
class IFile {
public:
    virtual ~IFile() {}
    operator bool() const { return IsValid(); }
    virtual bool IsValid() const { return false; }
    virtual void Close() {}
    virtual int ReadBytes(pointer p, int length) { return 0; }
    virtual bool GetLine(pointer p, int max_size) { return 0; }
    virtual int WriteBytes(const_pointer p, int length) { return 0; }
    virtual void Flush() {}
    virtual size_t GetSize() const { return 0; }
    virtual void Seek(int64 offset) {}
    virtual size_t GetOffset() const { return 0; }
    const MemoryRegion* ReadAll() {
        auto mem = mem_alloc(GetSize());
        if (mem) ReadBytes((pointer)mem->data, mem->size);
        return mem;
    }
};

class CrtFile : public IFile {
public:
    CrtFile(const String& fname, const char* mode);

    bool IsValid() const override { return _file != nullptr; }
    int ReadBytes(pointer p, int length) override;
    bool GetLine(pointer p, int max_size) override;
    int WriteBytes(const_pointer p, int length) override;
    void Flush() override;
    size_t GetSize() const override;
    void Seek(int64 offset) override;
    size_t GetOffset() const override;
    void Close() override;
private:
    FILE* _file;
    size_t _file_size;
    friend class FileSystem;
};

inline bool is_utf8_bom(uint8 c0, uint8 c1, uint8 c2) {
    return (c0 == 0xef) && (c1 == 0xbb) && (c2 == 0xbf);
}

#include "platform/platform_config.h"

#if ON_WINDOWS
#pragma warning(disable:4996) // for Visual Studio
#endif

#endif // FILE_H
