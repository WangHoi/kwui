#pragma once
#include <string>

class AdminAuthorization
{
public:
    static bool HasAdminRights();
    static bool ExecuteElevated(const std::string& arguments);
	static bool ExecuteDirectly(const std::string& arguments);
};
