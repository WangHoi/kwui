#ifndef INSTALL_PROGRESS_SMOOTHER_H
#define INSTALL_PROGRESS_SMOOTHER_H
#include "ui/Node2D.h"
#include "ui/ProgressBarNode.h"

SMART_REF(InstallProgressSmoother)
class InstallProgressSmoother : public Node2D {
public:
    struct Config {
        bool remove_exist_install;
        bool install_vcredist;
    };
    InstallProgressSmoother();
    void SetConfig(const Config& config);
    inline double GetDisplayProgress() const { return _display_progress; }
    void Start(EventContext& ctx);
    void StartChengxunInstall();
    void SetChengxunProgress(double progress);
    void OnAnimationFrame(double timestamp, EventContext& ctx) override;
    void Pause();
    void Resume();
    using ProgressCallback = function<void(double)>;
    inline void SetProgressCallback(ProgressCallback&& callback) { _progress_callback = callback; }
private:
    Config _config;
    double _chengxun_progress;
    double _full_time;
    double _start_ts;
    optional<double> _remove_exist_done_ts;
    optional<double> _vcredist_finish_ts;
    optional<double> _chengxun_start_ts;
    optional<double> _chengxun_start_display_progress;
    optional<double> _animation_start_ts;
    struct CatchupState {
        double start_display_progress;
        double step;
    };
    optional<CatchupState> _catchup_state;
    double _display_progress;
    ProgressCallback _progress_callback;
    optional<double> _pause_start_ts;
    double _total_paused_time;
    int _pause_counter;
};

#endif // INSTALL_PROGRESS_SMOOTHER_H