#ifndef UNINSTALL_PROGRESS_SMOOTHER_H
#define UNINSTALL_PROGRESS_SMOOTHER_H
#include "ui/Node2D.h"
#include "ui/ProgressBarNode.h"

SMART_REF(UninstallProgressSmoother)
class UninstallProgressSmoother : public Node2D {
public:
    UninstallProgressSmoother();
    inline double GetDisplayProgress() const { return _display_progress; }
    void Start(EventContext& ctx);
    void Done();
    void OnAnimationFrame(double timestamp, EventContext& ctx) override;
    void Pause();
    void Resume();
    using ProgressCallback = function<void(double)>;
    inline void SetProgressCallback(ProgressCallback&& callback) { _progress_callback = callback; }
private:
    bool _done;
    double _full_time;
    double _start_ts;
    optional<double> _animation_start_ts;
    struct CatchupState {
        double start_display_progress;
        double step;
    };
    optional<CatchupState> _catchup_state;
    double _display_progress;
    ProgressCallback _progress_callback;
    optional<double> _pause_start_ts;
    double _total_paused_time;
    int _pause_counter;
};

#endif // UNINSTALL_PROGRESS_SMOOTHER_H