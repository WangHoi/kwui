#pragma once
#include "memory/memory_helpers.h"
// #include "utils/MPSCQueue.h"
#include "debug/log.h"
#include "JobQueueInterface.h"
#include <uv.h>
#include <deque>

SMART_REF(UvJobQueue)
class UvJobQueue : public JobQueueInterface
{
public:
	void Submit(JobQueueInterface::Functor&& f) override;
	static UvJobQueueRef Create(uv_loop_t* loop);
	UvJobQueue(uv_loop_t* loop);
	~UvJobQueue();

private:
	void ProcessJobs();

	uv_mutex_t _mutex;
	uv_async_t* _async;
	std::deque<Functor> _queue;
};
