#ifndef MAIN_DIALOG_H
#define MAIN_DIALOG_H

#include "Dialog.h"
#include "ui/ImageNode.h"
#include "ui/LabelNode.h"
#include "ui/ButtonNode.h"
#include "ui/TextEditNode.h"
#include "ui/ProgressBarNode.h"
#include "InstallConfig.h"

SMART_REF(MainDialog);
class MainDialog : public Dialog {
public:
	MainDialog();
	void SetConfig(const InstallConfig& config);
	void SetupUi();
	void OnDestroy() override;

	void SetProgress(float progress);
	void SetTargetDir(const String& target_dir);
	String GetTargetDir() const;

	inline void SetStartInstallCallback(ClickedCallback&& callback) {
		_start_install_callback = callback;
	}
	inline void SetInstallDoneCallback(ClickedCallback&& callback) {
		_install_done_callback = callback;
	}
	inline void SetCloseRequestedCallback(ClickedCallback&& callback) {
		_close_requested_callback = callback;
	}
	void StartInstallButtonClicked(EventContext& ctx);
	void InstallDoneButtonClicked(EventContext& ctx);
	void ToggleExpand(EventContext& ctx);
	void BrowseButtonClicked(EventContext& ctx);
    enum Page {
        INVALID_PAGE = -1,
        MAIN_PAGE,
        PROGRESS_PAGE,
        DONE_PAGE,
    };
    inline Page GetPage() const { return _current_page; }
	void SetPage(Page page);
	void OnCloseButtonClicked(EventContext& ctx) override;
    void OnEnterKeyDown(EventContext& ctx) override;
    void PathTextChangedCallback(const wstring& text);

private:
	ButtonNodeRef MakePrimaryButton(const String& text, 
                                    float padding_x,
                                    float padding_y);
	Node2DRef MakeSecondaryButton(const String& text);
	ButtonNodeRef MakeExpandButton();
	ProgressBarNodeRef MakeProgressBar();
	void UpdateAvailSpaceLabel(const String& target_dir);

	String _product_name;
	String _display_name;
	String _version;
	Page _current_page;
    ButtonNodeRef _start_install_btn;
    Node2DRef _main_page;
	ImageNodeRef _expand_image;
	Node2DRef _main_page_expanded;
	TextEditNodeRef _path_edit;
	LabelNodeRef _avail_space_label;
	Node2DRef _progress_page;
	ProgressBarNodeRef _progress_bar;
	LabelNodeRef _progress_label;
	Node2DRef _done_page;
	bool _expanded;
	size_t _estimated_size_kb;
	ClickedCallback _start_install_callback;
	ClickedCallback _install_done_callback;
	ClickedCallback _close_requested_callback;
    bool _target_dir_valid;
};

#endif // MAIN_DIALOG_H