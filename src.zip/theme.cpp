#include "theme.h"

namespace theme {
	const Color BACKGROUND_COLOR = Color::FromString("#F8F8F8");
	const Color ACTION_COLOR = Color::FromString("#FF6500");
	const Color ACTION_HOVERED_COLOR = Color::FromString("#ED6207");
    const Color ACTION_DISABLED_COLOR = Color::FromString("#CCCCCC");
	const Color ACTION_TEXT_COLOR = Color::FromString("#F3F3F3");
	const Color H1_TEXT_COLOR = Color::FromString("#000000");
	const Color H2_TEXT_COLOR = Color::FromString("#333333");
	const Color H3_TEXT_COLOR = Color::FromString("#777777");
    const Color PROGRESS_TEXT_COLOR = Color::FromString("#909090");
	const float H1_FONT_SIZE = 44.0f;
	const float H2_FONT_SIZE = 24.0f;
	const float H3_FONT_SIZE = 14.0f;
    const float PROGRESS_FONT_SIZE = 40.0f;
	const Color BORDER_COLOR = Color::FromString("#E5E5E5");
	const Color CLOSE_BUTTON_HOVER_COLOR = Color::FromString("#F45454");

	const float DIALOG_BORDER_RADIUS = 4.0f;
	const float DIALOG_SHADOW_MARGIN_PIXELS = 24.0f;

	const float TITLE_BAR_HEIGHT = 32.0f;
	const float TITLE_BUTTON_WIDTH = 40.0f;

	const float MAIN_DIALOG_WIDTH = 552.0f;
	const float MAIN_DIALOG_HEIGHT = 408.0f;

	const String CLOSE_BUTTON_PNG = "close_button.png";
	const String CLOSE_BUTTON_HOVER_PNG = "close_button_hover.png";
	const String LOGO_PNG = "logo.png";
	const Vector2 LOGO_SIZE = { 80, 80 };
	const Vector2 LOGO_POSITION = { 236, 108 };
	const String DIALOG_SHADOW_PNG = "dialog-shadow.png";

	const float MAIN_LABEL_Y = 196;
	const Vector2 MAIN_VERSION_POSITION = { 6, 198 };

	const float PRIMARY_BORDER_RADIUS = 8.0f;
	const float SECONDARY_BORDER_RADIUS = 4.0f;
	const String EXPAND_PNG = "expand.png";
	const String COLLAPSE_PNG = "collapse.png";
	const Vector2 EXPAND_PNG_SIZE = { 24, 24 };
	const Vector2 EXPAND_PNG_POSITION = { 106, 12 };
	const float EXPAND_DIALOG_HEIGHT = 480;

	const Color TEXT_EDIT_BACKGROUND_COLOR = Color::FromString("#ffffff");
	const Color TEXT_EDIT_SELECTION_COLOR = Color::FromString("#FF6500").MakeAlpha(0.25);
	const Color TEXT_EDIT_CARET_COLOR = Color::FromString("#000000");
	const Vector2 TEXT_EDIT_SIZE = { 442, 32 };
	const Vector2 TEXT_EDIT_POSITION = { 16, 396 };
	const float TEXT_EDIT_BORDER_RADIUS = 4.0f;
	const float TEXT_EDIT_PADDING = 7.0f;

	const float CONFIRM_DIALOG_WIDTH = 360;
	const float CONFIRM_DIALOG_HEIGHT = 220;
}
