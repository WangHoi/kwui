#ifndef STRINGID_H
#define STRINGID_H

#include "data/data_type.h"
#include "data/data_helpers.h"

typedef uint32 stringid;

#ifdef _DEBUG
#define StringId String
#else
#define StringId stringid
#endif

extern stringid compute_stringid(const char* s);

extern stringid intern_string(const char* s);
class String;
stringid intern_string(const String& s);

extern const char* retrive_string(stringid id);

#endif // STRINGID_H