//
//  UTF8String.cpp
//  C2Engine
//
//  Created by mike luo on 2014-4-10.
//
//
#include "stdafx.h"
#include "UTF8String.h"

#include "text/encoding_helpers.h"
#include "math/math_templates.h"

UTF8String::UTF8String() : _char_index(1, 0) {}
UTF8String::UTF8String(const char* raw_string) : _raw_string(raw_string) { _Init(); }
UTF8String::UTF8String(const String& raw_string) : _raw_string(raw_string) { _Init(); }

UTF8String& UTF8String::operator=(const char* raw_string) {
  if (_raw_string == raw_string) return *this;
  _raw_string = raw_string;
  _Init();
  return *this;
}
UTF8String& UTF8String::operator=(const String& raw_string) {
  if (_raw_string == raw_string) return *this;
  _raw_string = raw_string;
  _Init();
  return *this;
}

void UTF8String::Insert(int index, const String& str) {
  Insert(index, UTF8String(str));
}

void UTF8String::Insert(int index, const UTF8String& str) {
  if (str.IsEmpty()) return;
  int start_pos = _char_index[index], l1 = GetLength(), l2 = str.GetLength(), l2_raw = str.GetRawString().GetLength();
  _raw_string.Insert(start_pos, str.GetRawString());
  _unicode_string.insert(_unicode_string.begin() + index, str._unicode_string.begin(), str._unicode_string.end());
  _char_index.insert(_char_index.begin() + index, str._char_index.begin(), str._char_index.end() - 1);
  for (int i = index; i < index + l2; i++) _char_index[i] += start_pos;
  for (int i = index + l2; i <= l1 + l2; i++) _char_index[i] += l2_raw;
}

void UTF8String::Erase(int start_index, int count) {
  upper_clamp(count, (int)_unicode_string.size() - start_index);
  if (count <= 0) return;
  // scope in raw string : [start_pos, end_pos)
  int start_pos = _char_index[start_index];
  int end_pos =  _char_index[start_index + count];
  int gap_size = end_pos - start_pos;
  _raw_string.Erase(start_pos, gap_size);
  _unicode_string.erase(_unicode_string.begin() + start_index, _unicode_string.begin() + start_index + count);
  _char_index.erase(_char_index.begin() + start_index, _char_index.begin() + start_index + count);
  for (int i = start_index; i < (int)_char_index.size(); i++) {
    _char_index[i] -= gap_size;
  }
}

void UTF8String::Append(const String& str) {
  Insert((int)_unicode_string.size(), str);
}

void UTF8String::PopBack(int count) {
  int start_index = (int)_unicode_string.size() - count;
  lower_clamp(start_index, 0);
  Erase(start_index, count);
}

void UTF8String::_Init() {
  auto start = (const char8*) _raw_string.GetCString(), p = start;
  _unicode_string.clear();
  _char_index.assign(1, 0);
  while (*p) {
    _unicode_string.push_back(fetch_unicode_utf8(p));
    _char_index.push_back(p - start);
  }
}