#include "StringManager.h"

#include "debug/debug_helpers.h"

DEFINE_SINGLETON_INSTANCE(StringManager);

const char* StringManager::Get(stringid id) const {
    lock_guard<mutex> lock(_mutex);
    auto iter = _string_table.find(id);
    if (iter == _string_table.end()) return nullptr;
    else return iter->second.c_str();
}

stringid StringManager::Add(const char* s) {
    stringid id = compute_stringid(s);
    lock_guard<mutex> lock(_mutex);
    auto result = _string_table.emplace(id, s);
    if (!result.second) assert(strcmp(result.first->second.c_str(), s) == 0);
    return id;
}