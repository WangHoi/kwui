#ifndef STRING_MANAGER_H
#define STRING_MANAGER_H

#include "stringid.h"
#include "pattern/singleton.h"
#include "data/data_helpers.h"
#include "thread/thread_helpers.h"

class StringManager {
public:
    const char* Get(stringid id) const;
    stringid Add(const char* s);
private:
    unordered_map<stringid, string> _string_table;
    mutable mutex _mutex;
    SUPPORT_SINGLETON(StringManager);
};

#endif // STRING_MANAGER_H