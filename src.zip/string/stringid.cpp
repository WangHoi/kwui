#include "stringid.h"
#include "String.h"
#include "algorithm/crc32.h"
#include "algorithm/hash_functions.h"
#include "data/data_helpers.h"
#include "StringManager.h"

stringid compute_stringid(const char* s) {
    return hash_string(s);
}

stringid intern_string(const char* s) {
    auto SM = StringManager::Instance();
    if (SM) return SM->Add(s);
    else return compute_stringid(s);
}

stringid intern_string(const String& s) {
    return intern_string(s.GetCString());
}

static const char* FAILURE_STRING = "???";

const char* retrive_string(stringid id) {
    const char* s = nullptr;
    auto SM = StringManager::Instance();
    if (SM) s = SM->Get(id);
    if (!s) s = FAILURE_STRING;
    return s;
}