//
//  UTF8String.h
//  C2Engine
//
//  Created by mike luo on 2014-4-10.
//
//
#ifndef UTF8_STRING_H
#define UTF8_STRING_H

#include "data/data_helpers.h"
#include "data/data_type.h"

class UTF8String {
public:
  UTF8String();
  explicit UTF8String(const char* raw_string);
  explicit UTF8String(const string& raw_string): UTF8String(raw_string.c_str()) {};
  explicit UTF8String(const String& raw_string);

  UTF8String& operator=(const char* raw_string);
  UTF8String& operator=(const String& raw_string);
  UTF8String& operator=(const string& raw_string) { return operator=(raw_string.c_str()); }

  const char* GetCString() const { return _raw_string.GetCString(); }
  const String& GetRawString() const { return _raw_string; }
  bool IsEmpty() const { return _unicode_string.empty(); }
  int GetLength() const { return _unicode_string.size(); }
  char32 GetUnicode(int index) const { return _unicode_string[index]; }
  int GetCharIndex(int index) const { return _char_index[index]; }

  bool operator==(const UTF8String& rop) const { return _raw_string == rop._raw_string; }
  bool operator!=(const UTF8String& rop) const { return _raw_string != rop._raw_string; }

  void Insert(int index, const String& str);
  void Insert(int index, const UTF8String& str);
  void Erase(int start_index, int count);
  void Append(const String& str);
  void PopBack(int count = 1);

private:
  void _Init();

  String _raw_string;
  vector<char32> _unicode_string;
  vector<int> _char_index;
};

#endif // UTF8_STRING_H