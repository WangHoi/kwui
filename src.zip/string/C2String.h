//
//  C2String.h
//  C2Engine
//
//  Created by mike luo on 2014-2-11.
//
//
#ifndef C2_STRING_H
#define C2_STRING_H

#include "stringid.h"
#include "StringManager.h"
#include "String.h"

#include "UTF8String.h"

#endif // C2_STRING_H