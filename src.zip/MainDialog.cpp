#include "MainDialog.h"
#include "theme.h"
#include "ui/ButtonNode.h"
#include "ui/ImageButtonNode.h"
#include "ui/ImageNode.h"
#include "ui/LabelNode.h"
#include "ui/TextEditNode.h"
#include "pattern/callback.h"
#include "platform/platform_helpers.h"
#include "InstallServiceProxy.h"
#include "../installer_resource.h"
#include "PopupShadow.h"
#include "text/EncodingManager.h"

MainDialog::MainDialog()
    : Dialog(theme::MAIN_DIALOG_WIDTH, theme::MAIN_DIALOG_HEIGHT,
             L"MainDialog",
             LoadIconW(GetModuleHandle(NULL), MAKEINTRESOURCEW(IDI_INSTALL_ICON)),
             DIALOG_FLAG_MAIN,
             PopupShadowData{
                 theme::DIALOG_SHADOW_PNG,
                 (int)theme::DIALOG_SHADOW_MARGIN_PIXELS,
             },
             nullopt)
    , _expanded(false)
    , _current_page(INVALID_PAGE)
    , _estimated_size_kb(0)
    , _target_dir_valid(false) {}
void MainDialog::SetConfig(const InstallConfig & config) {
	_product_name = config.product_name;
	_display_name = config.display_name;
	_version = config.version;
	_estimated_size_kb = config.estimated_size_kb;
}
void MainDialog::SetupUi() {
	//Dialog::OnCreate();

	SetTitle(_display_name + u8"��װ��");

	Node2D* root = GetRoot();
	// shared
	{
		auto logo = make_shared<ImageNode>();
		logo->SetImageName(theme::LOGO_PNG);
		logo->SetSize(theme::LOGO_SIZE);
		logo->SetOrigin(theme::LOGO_POSITION);
		root->AddChild(logo);

		auto text = make_shared<LabelNode>();
		String main_label_text;
		int pos = _display_name.Find('(');
		if (pos != -1) {
			main_label_text = _display_name.Left(pos);
		} else {
			main_label_text = _display_name;
		}
		text->SetText(main_label_text);
		text->SetFontSize(theme::H2_FONT_SIZE);
        text->SetFontWeight(FontWeight::SEMI_LIGHT);
		text->SetColor(theme::H1_TEXT_COLOR);
		text->UpdateTextLayout();
		auto text_size = text->GetSize();
		text->SetOrigin({
			roundf((theme::MAIN_DIALOG_WIDTH - text_size.x) * 0.5f),
			theme::MAIN_LABEL_Y
			});
		root->AddChild(text);

		auto version = make_shared<LabelNode>();
		version->SetText(_version);
		version->SetFontSize(theme::H3_FONT_SIZE);
		version->SetColor(theme::H3_TEXT_COLOR);
		version->SetOrigin({
			text->GetX() + roundf(text_size.x) + theme::MAIN_VERSION_POSITION.x,
			theme::MAIN_VERSION_POSITION.y
			});
		root->AddChild(version);
	}
	// ������
	{
		_main_page = make_shared<Node2D>();

		_start_install_btn = MakePrimaryButton(u8"��װ", 56, 8);
        _start_install_btn->SetBackgroundColor(theme::ACTION_DISABLED_COLOR);
		_start_install_btn->SetOrigin({ 196, 270 });
		_start_install_btn->SetClickedCallback(MakeCallback(this, &MainDialog::StartInstallButtonClicked));
		_main_page->AddChild(_start_install_btn);

		auto expand_btn = MakeExpandButton();
		expand_btn->SetOrigin({ 196, 332 });
		expand_btn->SetClickedCallback(MakeCallback(this, &MainDialog::ToggleExpand));
		_main_page->AddChild(expand_btn);

		_expand_image = make_shared<ImageNode>();
		_expand_image->SetImageName(theme::EXPAND_PNG);
		_expand_image->SetSize(theme::EXPAND_PNG_SIZE);
		_expand_image->SetOrigin(theme::EXPAND_PNG_POSITION);
        expand_btn->AddChild(_expand_image);

		root->AddChild(_main_page);
	}
	{
		_main_page_expanded = make_shared<Node2D>();

		_path_edit = make_shared<TextEditNode>();
		_path_edit->SetBackgroundColor(theme::TEXT_EDIT_BACKGROUND_COLOR);
		_path_edit->SetColor(theme::H3_TEXT_COLOR);
		_path_edit->SetFontSize(theme::H3_FONT_SIZE);
		_path_edit->SetSelectionColor(theme::TEXT_EDIT_SELECTION_COLOR,
									  theme::H3_TEXT_COLOR);
		_path_edit->SetCaretColor(theme::TEXT_EDIT_CARET_COLOR);
		_path_edit->SetBackgroundPadding(theme::TEXT_EDIT_PADDING);
		_path_edit->SetBorderRadius(theme::TEXT_EDIT_BORDER_RADIUS);
		_path_edit->SetSize(theme::TEXT_EDIT_SIZE);
		_path_edit->SetOrigin(theme::TEXT_EDIT_POSITION);
		_main_page_expanded->AddChild(_path_edit);

		auto browse_btn = MakeSecondaryButton(u8"���");
		browse_btn->SetOrigin({ 474, 396 });
		browse_btn->SetClickedCallback(MakeCallback(this, &MainDialog::BrowseButtonClicked));
		_main_page_expanded->AddChild(browse_btn);

		_avail_space_label = make_shared<LabelNode>();
		_avail_space_label->SetFontSize(theme::H3_FONT_SIZE);
		_avail_space_label->SetColor(theme::H3_TEXT_COLOR);
		_avail_space_label->SetOrigin({ 169, 434 });
		//_avail_space_label->SetText(u8"����ռ�: 120MB ���ÿռ�: 29GB");
		_main_page_expanded->AddChild(_avail_space_label);

		root->AddChild(_main_page_expanded);
		_main_page_expanded->SetVisible(false);
	}
	{
		_progress_page = make_shared<Node2D>();

		_progress_bar = MakeProgressBar();
		_progress_bar->SetSize({ 360, 4 });
		_progress_bar->SetOrigin({ 96, 268 });
		_progress_bar->SetProgress(0.0f);
		_progress_page->AddChild(_progress_bar);

		_progress_label = make_shared<LabelNode>();
		_progress_label->SetFontSize(theme::PROGRESS_FONT_SIZE);
		_progress_label->SetColor(theme::PROGRESS_TEXT_COLOR);
        _progress_label->SetOrigin({ 8, 278 });
        _progress_label->SetSize({ 536, 60 });
        _progress_label->SetAutoSize(false);
        _progress_label->SetAlignment(TextAlignment::TEXT_ALIGN_CENTER);
        _progress_label->SetText(u8"0%");
		_progress_page->AddChild(_progress_label);

		root->AddChild(_progress_page);
	}
	{
		_done_page = make_shared<Node2D>();

		auto label = make_shared<LabelNode>();
		label->SetFontSize(theme::H3_FONT_SIZE);
		label->SetColor(theme::H3_TEXT_COLOR);
		label->SetOrigin({ 248, 250 });
		label->SetText(u8"��װ���");
		_done_page->AddChild(label);

		auto start_btn = MakePrimaryButton(u8"��ʼʹ��", 32, 8);
		start_btn->SetOrigin({ 196, 290 });
		start_btn->SetClickedCallback(MakeCallback(this, &MainDialog::InstallDoneButtonClicked));
		_done_page->AddChild(start_btn);

		root->AddChild(_done_page);
	}
    _path_edit->SetTextChangedCallback(MakeCallback(this, &MainDialog::PathTextChangedCallback));
    SetTargetDir(InstallServiceProxy::Instance()->GetProgramFilesDir());
	SetPage(MAIN_PAGE);
}
void MainDialog::OnDestroy() {
    _start_install_btn = nullptr;
	_main_page = nullptr;
	_expand_image = nullptr;
	_main_page_expanded = nullptr;
	_path_edit = nullptr;
	_progress_page = nullptr;
	_done_page = nullptr;
	Dialog::OnDestroy();
}
void MainDialog::SetProgress(float progress) {
	_progress_bar->SetProgress(progress);
	char text[8] = {};
	snprintf(text, sizeof(text) - 1, "%.0f%%", progress * 100.0f);
	_progress_label->SetText(text);
	RequestPaint();
}
void MainDialog::StartInstallButtonClicked(EventContext& ctx) {
    if (!_target_dir_valid)
        return;
	SetPage(PROGRESS_PAGE);
	if (_start_install_callback)
		_start_install_callback(ctx);
}
void MainDialog::InstallDoneButtonClicked(EventContext& ctx) {
	if (_install_done_callback)
		_install_done_callback(ctx);
}
void MainDialog::ToggleExpand(EventContext& ctx) {
	_expanded = !_expanded;
	if (_expanded) {
		_expand_image->SetImageName(theme::COLLAPSE_PNG);
		Resize(GetSize().x, theme::EXPAND_DIALOG_HEIGHT);
		_main_page_expanded->SetVisible(true);
	} else {
		_expand_image->SetImageName(theme::EXPAND_PNG);
		Resize(GetSize().x, theme::MAIN_DIALOG_HEIGHT);
		_main_page_expanded->SetVisible(false);
	}
	ctx.RequestPaint();
}
void MainDialog::BrowseButtonClicked(EventContext& ctx) {
	String dir = platform_choose_folder(GetHwnd(), u8"��ѡ��װĿ¼");
	if (!dir.IsEmpty())
		SetTargetDir(dir);
	ctx.RequestPaint();
}
void MainDialog::SetPage(MainDialog::Page page) {
	if (_current_page == page)
		return;
	_current_page = page;
	switch (page) {
	case MAIN_PAGE:
		_main_page->SetVisible(true);
		_progress_page->SetVisible(false);
		_done_page->SetVisible(false);
		break;
	case PROGRESS_PAGE:
		if (_expanded)
			ToggleExpand(*this);
		_main_page->SetVisible(false);
		_progress_page->SetVisible(true);
		_done_page->SetVisible(false);
		break;
	case DONE_PAGE:
		if (_expanded)
			ToggleExpand(*this);
		_main_page->SetVisible(false);
		_progress_page->SetVisible(false);
		_done_page->SetVisible(true);
		break;
	default:
		c2_log("unable to switch to page %d\n", page);
	}
	RequestUpdate();
	RequestPaint();
}
ButtonNodeRef MainDialog::MakePrimaryButton(const String& text, float padding_x, float padding_y) {
	auto btn = make_shared<ButtonNode>();
	btn->SetBackgroundColor(theme::ACTION_COLOR,
							theme::ACTION_HOVERED_COLOR);
	btn->SetColor(theme::ACTION_TEXT_COLOR);
	btn->SetBackgroundPadding(padding_x, padding_y, padding_x, padding_y);
	btn->SetBorderRadius(theme::PRIMARY_BORDER_RADIUS);
	btn->SetFontSize(theme::H2_FONT_SIZE);
	btn->SetText(text);
	return btn;
}
Node2DRef MainDialog::MakeSecondaryButton(const String& text) {
	auto btn = make_shared<ButtonNode>();
	btn->SetBackgroundColor(theme::ACTION_COLOR,
							theme::ACTION_HOVERED_COLOR);
	btn->SetColor(theme::ACTION_TEXT_COLOR);
	btn->SetBackgroundPadding(16, 7, 16, 7);
	btn->SetBorderRadius(theme::SECONDARY_BORDER_RADIUS);
	btn->SetFontSize(theme::H3_FONT_SIZE);
	btn->SetText(text);
	return btn;
}
ButtonNodeRef MainDialog::MakeExpandButton() {
	auto btn = make_shared<ButtonNode>();
    btn->SetCursorType(CURSOR_HAND);
    btn->SetAutoSize(false);
    btn->SetSize({ 160, 48 });
    btn->SetColor(theme::H3_TEXT_COLOR);
	btn->SetFontSize(theme::H3_FONT_SIZE);
	btn->SetText(u8"����ѡ��");
	return btn;
}
ProgressBarNodeRef MainDialog::MakeProgressBar() {
	auto bar = make_shared<ProgressBarNode>();
	bar->SetBackgroundColor(theme::BORDER_COLOR);
	bar->SetColor(theme::ACTION_HOVERED_COLOR);
	return bar;
}
static String may_add_suffix(const String& dir, const String& product_name) {
    String suffix = u8"\\" + product_name;
    if (dir.EndsWith(suffix)) {
        return dir;
    } else {
        if (dir.EndsWith("\\")) {
            // ѡ����̸�Ŀ¼ʱ���磺"C:\\" 
            return dir + product_name;
        } else {
            return dir + suffix;
        }
    }
}
void MainDialog::SetTargetDir(const String& dir) {
	if (dir.IsEmpty())
		return;
    _path_edit->SetText(may_add_suffix(dir, _product_name));
}
static String cleanup_path(const String& text) {
    auto EM = EncodingManager::Instance();
    wstring utf16_text = EM->UTF8ToWide(text);
    if (utf16_text.length() <= 2)
        return text;
    wstring part = utf16_text.substr(2);
    wstring clean_part;
    clean_part.reserve(part.length() + 1);
    for (auto& ch : part) {
        switch (ch) {
        case L'/':
        case L':':
        case L'*':
        case L'?':
        case L'"':
        case L'<':
        case L'>':
        case L'|':
            break;
        default:
            clean_part.push_back(ch);
        }
    }
    wstring utf16_path = utf16_text.substr(0, 2);
    if (!clean_part.empty()) {
        if (clean_part[0] != L'\\')
            utf16_path += L'\\';
        utf16_path += clean_part;
    }
    return EM->WideToUTF8(utf16_path)
        .CanonicalPath();
}
String MainDialog::GetTargetDir() const {
    String dir = cleanup_path(_path_edit->GetText());
    dir = may_add_suffix(dir, _product_name);
    return dir;
}
inline static String GetDriveLetter(const String& dir) {
    return dir.Left(2);
}
void MainDialog::UpdateAvailSpaceLabel(const String& dir) {
	wstring drive_letter = EncodingManager::Instance()
		->UTF8ToWide(GetDriveLetter(dir));
	size_t estimated_size_mb = _estimated_size_kb >> 10;
	ULARGE_INTEGER free_space;
	char text[1024] = {};
	if (GetDiskFreeSpaceExW(drive_letter.c_str(), &free_space, NULL, NULL)) {
		auto free_space_mb = (unsigned long long)(free_space.QuadPart >> 20);
		if (free_space_mb >= 2048) {
			auto free_space_gb = free_space_mb >> 10;
			snprintf(text, sizeof(text),
					 u8"����ռ�: %zdMB ���ÿռ�: %lluGB",
					 estimated_size_mb,
					 free_space_gb);
			_avail_space_label->SetText(text);
		} else {
			_avail_space_label->SetText(text);
		}
        _target_dir_valid = true;
	} else {
		snprintf(text, sizeof(text),
				 u8"����ռ�: %zdMB Ŀ����̲�����",
				 estimated_size_mb);
		_avail_space_label->SetText(text);
        _target_dir_valid = false;
	}
    if (_target_dir_valid) {
        _start_install_btn->SetBackgroundColor(theme::ACTION_COLOR, theme::ACTION_HOVERED_COLOR);
    } else {
        _start_install_btn->SetBackgroundColor(theme::ACTION_DISABLED_COLOR);
    }
}
void MainDialog::OnCloseButtonClicked(EventContext& ctx) {
	if (_close_requested_callback)
		_close_requested_callback(ctx);
}
void MainDialog::OnEnterKeyDown(EventContext& ctx) {
    if (_current_page == MAIN_PAGE) {
        StartInstallButtonClicked(ctx);
    } else if (_current_page == DONE_PAGE) {
        InstallDoneButtonClicked(ctx);
    }
}
void MainDialog::PathTextChangedCallback(const wstring& text) {
    String dir = EncodingManager::Instance()->WideToUTF8(text);
    c2_log("path text changed to [%s]\n", dir.GetCString());
    UpdateAvailSpaceLabel(dir);
    //if (text.length() > = )
    //text.replace()
}
