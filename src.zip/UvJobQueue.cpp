#include "UvJobQueue.h"

void UvJobQueue::Submit(JobQueueInterface::Functor&& f)
{
	uv_mutex_lock(&_mutex);
	_queue.push_back(f);
	uv_mutex_unlock(&_mutex);
	uv_async_send(_async);
}

UvJobQueueRef UvJobQueue::Create(uv_loop_t* loop)
{
	return make_shared<UvJobQueue>(loop);
}

void UvJobQueue::ProcessJobs()
{
	std::deque<Functor> q;
	uv_mutex_lock(&_mutex);
	q = std::move(_queue);
	uv_mutex_unlock(&_mutex);
	for (auto& f : q) {
		f();
	}
}

UvJobQueue::UvJobQueue(uv_loop_t* loop)
{
	uv_mutex_init(&_mutex);

	_async = (uv_async_t*)malloc(sizeof(uv_async_t));
	_async->data = this;
	uv_async_init(loop, _async, [](uv_async_t* async) {
		((UvJobQueue*)async->data)->ProcessJobs();
		});

}

UvJobQueue::~UvJobQueue()
{
	ProcessJobs();
	uv_close((uv_handle_t*)_async, [](uv_handle_t* h) {
		free(h);
		});
	uv_mutex_destroy(&_mutex);
}
