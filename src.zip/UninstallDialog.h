#ifndef UNINSTALL_DIALOG_H
#define UNINSTALL_DIALOG_H

#include "Dialog.h"
#include "ui/ImageNode.h"
#include "ui/LabelNode.h"
#include "ui/ButtonNode.h"
#include "ui/TextEditNode.h"
#include "ui/ProgressBarNode.h"
#include "InstallConfig.h"

SMART_REF(UninstallDialog);
class UninstallDialog : public Dialog {
public:
	UninstallDialog();
	void SetConfig(const InstallConfig& config);
	void SetupUi();
	void OnDestroy() override;

	void SetProgress(float progress);

	inline void SetStartUninstallCallback(ClickedCallback&& callback) {
		_start_uninstall_callback = callback;
	}
	inline void SetUninstallDoneCallback(ClickedCallback&& callback) {
		_uninstall_done_callback = callback;
	}
	inline void SetCloseRequestedCallback(ClickedCallback&& callback) {
		_close_requested_callback = callback;
	}
	void StartUninstallButtonClicked(EventContext& ctx);
	void UninstallDoneButtonClicked(EventContext& ctx);
	enum Page {
		INVALID_PAGE = -1,
		MAIN_PAGE,
		PROGRESS_PAGE,
		DONE_PAGE,
	};
    inline Page GetPage() const { return _current_page; }
    void SetPage(Page page);
    void OnCloseButtonClicked(EventContext& ctx) override;

private:
	Node2DRef MakePrimaryButton(const String& text);
	ProgressBarNodeRef MakeProgressBar();

	String _product_name;
	String _display_name;
	String _version;
	Page _current_page;
	Node2DRef _main_page;
	Node2DRef _progress_page;
	ProgressBarNodeRef _progress_bar;
	LabelNodeRef _progress_label;
	Node2DRef _done_page;
	ClickedCallback _start_uninstall_callback;
	ClickedCallback _uninstall_done_callback;
	ClickedCallback _close_requested_callback;
};

#endif // UNINSTALL_DIALOG_H