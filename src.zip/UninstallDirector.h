#ifndef UNINSTALL_DIRECTOR_H
#define UNINSTALL_DIRECTOR_H

#include "pattern/singleton.h"
#include "install/InstallMessage.h"
#include "install/LocalInstallService.h"
#include "install/InstallTimer.h"
#include "memory/ResourceManager.h"
#include "UninstallDialog.h"
#include "ConfirmDialog.h"
#include "InstallConfig.h"
#include "UnInstallProgressSmoother.h"
#include "HiddenMsgWindow.h"

class UninstallDirector : public WindowMsgListener {
public:
	UninstallDirector();
	~UninstallDirector();
	void SetConfig(const InstallConfig& config);
	void Start();
	void OnInstallMessage(InstallMessageBase* msg);
	void KillProcessConfirmed(EventContext& ctx);
	void UninstallCancelled(EventContext& ctx);
	void StartUninstallConfirmed(EventContext& ctx);
	void UninstallDoneClicked(EventContext& ctx);

	// �˳�ж�ضԻ���
	void CloseRequested(EventContext& ctx);
	void CloseCancelled(EventContext& ctx);

    void SmoothProgressCallback(double progress);

	// implements WindowMsgListener
	void OnAppMessage(WPARAM wParam, LPARAM lParam) override;

private:
	void SetupUi();
	enum State : int;
	void SetState(State state);
	void CheckToKillProcess();
	void EnterStart();         // ����������
	void Ui_EnterProgress();
	void EnterDone();
	void RemoveShortcut();
	void RemoveDir();
	void FinishUninstall();
    void CalmDown();

	ConfirmDialogRef MakeConfirmDialog_Quit();
	ConfirmDialogRef MakeConfirmDialog_KillProcess();
	enum State {
		STATE_INIT,
		STATE_KILL_PROCESS,
		STATE_START,
		STATE_REMOVE_DIR,
		STATE_REMOVE_SHORTCUT,
        STATE_CALM, // �ȴ� UninstallProgressSmoother
		STATE_DONE,
		NUM_STATES,
	};
	static const char* STATE_NAMES[NUM_STATES];
	State _state;
	InstallConfig _config;
	UninstallDialogRef _uninstall_dialog;
	ConfirmDialogRef _config_dialog;
	ConfirmDialogRef _quit_confirm_dialog;
	vector<DWORD> _pids; // �������еĽ���
    InstallTimer _timer;
    UninstallProgressSmootherRef _progress_smoother;

	SUPPORT_SINGLETON(UninstallDirector)
};

#endif // UNINSTALL_DIRECTOR_H
