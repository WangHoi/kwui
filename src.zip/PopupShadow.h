#ifndef POPUP_SHADOW_H
#define POPUP_SHADOW_H

#include "platform/platform_config.h"
#include "platform/windows/windows_header.h"
#include "memory/memory_helpers.h"
#include "math/Vector2.h"
#include "ui/Node2D.h"
#include "ui/LabelNode.h"
#include "ui/ImageButtonNode.h"
#include "string/String.h"
#include "pattern/callback.h"
#include "graphics/GraphicDevice.h"

struct PopupShadowData {
	String image_name;
	int padding; // in DIP
    HMONITOR monitor;
    float dpi_scale;
};

class Dialog;
SMART_REF(PopupShadow)
class PopupShadow {
public:
	PopupShadow(float width, float height, HWND owner,
				const WCHAR* wnd_class_name,
				const PopupShadowData& data);
	virtual ~PopupShadow();

	inline void Show() {
		SetVisible(true);
	}
	inline void Hide() {
		SetVisible(false);
	}
	void SetVisible(bool visible);
	inline bool IsVisible() const {
		return _visible;
	}
	HWND GetHwnd() const { return _hwnd; }
	void Close();

	virtual void OnDestroy();

private:
	void InitWindow(HINSTANCE hInstance, const WCHAR* wnd_class_name, HICON icon);
	static LRESULT CALLBACK WndProcMain(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);
	LRESULT WindowProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);

	void OnCreate();
	void OnPaint();
	void OnResize();
	void RecreateRenderTarget();
	void DiscardDeviceResources();

	HWND _owner_hwnd;
	HWND _hwnd;
	bool _visible;
	bool _first_show_window;
	Vector2 _pixel_size;
	WicBitmapRenderTarget _rt;
	PopupShadowData _data;
	ComPtr<ID2D1Bitmap> _bitmap;
	float _render_dpi_scale;
	friend class Dialog;
};

#endif // POPUP_SHADOW_H