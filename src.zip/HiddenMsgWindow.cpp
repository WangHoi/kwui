#include "HiddenMsgWindow.h"
#include "text/EncodingManager.h"
#include "debug/C2Debug.h"

typedef LRESULT(CALLBACK *WndProc)(HWND, UINT, WPARAM, LPARAM);
static ATOM RegisterWindowClass(HINSTANCE hInstance, const wchar_t* class_name, WndProc wnd_proc);

HiddenMsgWindow::HiddenMsgWindow()
	: _listener(NULL), _hwnd(NULL)
{
	InitWindow(GetModuleHandle(NULL), L"HiddenMsgWindow");
}

void HiddenMsgWindow::InitWindow(HINSTANCE hInstance, const WCHAR* wnd_class_name) {
	RegisterWindowClass(hInstance, wnd_class_name, &HiddenMsgWindow::WndProcMain);
	CreateWindowExW(0, wnd_class_name, L"", 0,
		0, 0,
		0, 0,
		HWND_MESSAGE, NULL, hInstance, this);
}

ATOM RegisterWindowClass(HINSTANCE hInstance, const wchar_t* class_name, WndProc wnd_proc) {
	WNDCLASSEX wcex = {};

	wcex.cbSize = sizeof(WNDCLASSEX);

	wcex.style = CS_DBLCLKS;
	wcex.lpfnWndProc = wnd_proc;
	wcex.cbClsExtra = 0;
	wcex.cbWndExtra = 0;
	wcex.hInstance = hInstance;
	wcex.lpszClassName = class_name;

	return RegisterClassEx(&wcex);
}
LRESULT HiddenMsgWindow::WindowProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam) {
	if (message == WM_APP) {
		if (_listener) {
			_listener->OnAppMessage(wParam, lParam);
		} else {
			c2_log("HiddenMsgWindow::WindowProc(): ignore WM_APP message\n");
		}
	}

	return 0;
}
LRESULT CALLBACK HiddenMsgWindow::WndProcMain(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam) {
	HiddenMsgWindow *me;
	if (message == WM_CREATE) {
		me = reinterpret_cast<HiddenMsgWindow*>(((LPCREATESTRUCTW)lParam)->lpCreateParams);
		me->_hwnd = hWnd;
		SetWindowLongPtrW(hWnd, GWLP_USERDATA, (LONG)me);
	} else {
		me = reinterpret_cast<HiddenMsgWindow*>(GetWindowLongPtrW(hWnd, GWLP_USERDATA));
	}
	if (me)
		return me->WindowProc(hWnd, message, wParam, lParam);
	else
		return DefWindowProc(hWnd, message, wParam, lParam);
}
