#ifndef CONFIRM_DIALOG_H
#define CONFIRM_DIALOG_H

#include "Dialog.h"
#include "ui/ImageNode.h"
#include "ui/LabelNode.h"
#include "ui/ButtonNode.h"
#include "ui/TextEditNode.h"
#include "ui/ProgressBarNode.h"

struct ConfirmDialogUiConfig {
	String title_text;
	String label_text;
	optional<String> action_btn_text; 
	optional<String> cancel_btn_text;
	optional<String> skip_btn_text;
};
SMART_REF(ConfirmDialog);
class ConfirmDialog : public Dialog {
public:
    ConfirmDialog(optional<CreateData> create_data = nullopt);
	void SetupUi(const ConfirmDialogUiConfig& data);
	void OnDestroy() override;

	inline void SetActionButtonClickedCallback(ClickedCallback&& callback) {
		_action_clicked_callback = callback;
	}
	inline void SetCancelButtonClickedCallback(ClickedCallback&& callback) {
		_cancel_clicked_callback = callback;
	}
	inline void SetSkipButtonClickedCallback(ClickedCallback&& callback) {
		_skip_clicked_callback = callback;
	}

	void ActionButtonClicked(EventContext& ctx);
	void CancelButtonClicked(EventContext& ctx);
	void SkipButtonClicked(EventContext& ctx);
	void OnCloseButtonClicked(EventContext& ctx) override;
    void OnEnterKeyDown(EventContext& ctx) override;
    void OnEscapeKeyDown(EventContext& ctx) override;

private:
	ButtonNodeRef MakeActionButton(const String& text);
	ButtonNodeRef MakeBorderButton(const String& text);

	ClickedCallback _action_clicked_callback;
	ClickedCallback _cancel_clicked_callback;
	ClickedCallback _skip_clicked_callback;
	ConfirmDialogUiConfig _config;
};

#endif // CONFIRM_DIALOG_H