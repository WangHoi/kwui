#ifndef INSTALL_CONFIG_H
#define INSTALL_CONFIG_H

#include "string/String.h"

struct InstallConfig {
	String publisher;
	String product_name;
	String version;
    String vcredist_version;
	String display_name;
	String exe_filename;
	String uninstaller_filename;
	size_t estimated_size_kb;
	String temp_log_filename;

	static InstallConfig MakePublishConfig();
};

#endif
