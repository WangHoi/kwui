#include "stdafx.h"
#include "MemoryCache.h"

MemoryCache::MemoryCache(uint32 capacity, IAllocator* allocator)
: _allocator(allocator), _capacity(capacity), _size(0) {}

MemoryCache::~MemoryCache() {
  for (auto& p : _cache) mem_free(p.second);
}

uint32 MemoryCache::GetSize(uint64 id) const {
  auto it = _cache.find(id);
  if (it == _cache.end()) return 0;
  return it->second->size;
}

bool MemoryCache::Read(uint64 id, void* data, uint32 size) {
  auto it = _cache.find(id);
  if (it == _cache.end()) return false;
  memcpy(data, it->second->data, min(size, it->second->size));
  return true;
}

void MemoryCache::Write(uint64 id, const void* data, uint32_t size) {
  auto it = _cache.find(id);
  if (it != _cache.end()) {
    if (it->second->size == size) {
      memcpy(it->second->data, data, size);
    } else {
      mem_free(it->second);
      it->second = mem_copy((const_pointer)data, size);
    }
  } else {
    _cache.insert(make_pair(id, mem_copy((const_pointer)data, size)));
  }
}
