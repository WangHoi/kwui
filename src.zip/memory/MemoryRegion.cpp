#include "stdafx.h"
#include "MemoryRegion.h"
#if ON_PS4
#include "platform/ps4/ps4_allocators.h"
#endif

void mem_init() {
#if ON_PS4
  ps4_mem_init();
#else
  static CrtAllocator s_allocator;
  g_allocator = &s_allocator;
#endif
}
