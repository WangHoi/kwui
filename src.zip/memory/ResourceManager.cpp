#include "ResourceManager.h"

DEFINE_SINGLETON_INSTANCE(ResourceManager);

Resource ResourceManager::LoadResource(int id) {
    HRSRC info = FindResourceW(_hmodule, MAKEINTRESOURCEW(id), L"MYFILE");
    if (!info) return Resource();
    HGLOBAL res = ::LoadResource(_hmodule, info);
    
    if (res) {
        LPVOID data = LockResource(res);
        DWORD size = SizeofResource(_hmodule, info);
        return Resource(id, (const byte*)data, size);
    } else {
        return Resource();
    }
}
