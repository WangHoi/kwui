#include "stdafx.h"
#include "Allocator.h"

Allocator* g_allocator = nullptr;


