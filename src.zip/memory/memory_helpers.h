#ifndef MEMORY_HELPERS_H
#define MEMORY_HELPERS_H

#include <memory>
#include <memory.h>

using std::unique_ptr;
using std::shared_ptr;
using std::weak_ptr;

using std::make_shared;
using std::make_unique;

using std::static_pointer_cast;

template <typename T>
inline void safe_delete(T& p) {
    if (p) {
        delete p;
        p = nullptr;
    }
}

#define SMART_REF(Class)  \
    class Class; \
    typedef shared_ptr<Class> Class##Ref; \
    typedef shared_ptr<const Class> Class##RefConst; \
    typedef unique_ptr<Class> Class##Handle; \
    typedef unique_ptr<const Class> Class##HandleConst; \
    typedef weak_ptr<Class> Class##Link; \
    typedef weak_ptr<const Class> Class##LinkConst;

#endif // MEMORY_HELPERS_H
