#include "stdafx.h"
#include "MemoryArena.h"

MemoryArena::MemoryArena(int size, int alignment /*= 16*/) {
  this->size = size;
  base = (pointer)malloc(size);
  used = 0;
  temp_count = 0;
}

MemoryArena::MemoryArena(MemoryArena* parent, int size, int alignment /*= 16*/) {
  this->size = size;
  base = (pointer)parent->Alloc(size, alignment);
  used = 0;
  temp_count = 0;
}

MemoryArena::~MemoryArena() {
  c2_assert(temp_count == 0);
  free(base);
}

void* MemoryArena::Alloc(size_t len, size_t alignment /*= sizeof(ptrdiff_t)*/) {
  size_t ret = (used + (alignment - 1)) & ~(alignment - 1);
  used = ret + len;
  c2_assert(used <= size);
  return base + ret;
}

TemporaryMemory MemoryArena::BeginTemporaryMemory(int alignment /*= 16*/) {
  ++temp_count;
  used = (used + (alignment - 1)) & ~(alignment - 1);
  c2_assert(used <= size);
  return TemporaryMemory{this, used};
}

void MemoryArena::EndTemporaryMemory(const TemporaryMemory& temp) {
  c2_assert(temp_count > 0);
  --temp_count;
  used = temp.used;
}
