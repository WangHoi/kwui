#ifndef RESOURCE_MANAGER_H
#define RESOURCE_MANAGER_H

#include "pattern/singleton.h"
#include "platform/platform_config.h"
#include "platform/windows/windows_header.h"

struct Resource {
    int id;
    const byte* data;
    size_t size;

    Resource() : id(0), data(NULL), size(0) {}
    Resource(int id_, const byte* d, size_t s)
        : id(id_), data(d), size(s) {}
    inline bool IsValid() const { return id > 0; }
};

class ResourceManager {
public:
    ResourceManager(HMODULE hModule) : _hmodule(hModule) {}
    Resource LoadResource(int id);

private:
    HMODULE _hmodule;
    SUPPORT_SINGLETON_WITH_ONE_ARG_CREATOR(ResourceManager, HMODULE)
};

#endif // RESOURCE_MANAGER_H