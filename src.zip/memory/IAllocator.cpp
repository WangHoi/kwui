#include "stdafx.h"
#include "IAllocator.h"

IAllocator* g_allocator = nullptr;


