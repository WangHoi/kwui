//
//  Memory.h
//  C2
//
//  Created by hoi wang on 09-24-15
//
//
#ifndef MEMORY_H
#define MEMORY_H

#include "data/C2Data.h"
#include "IAllocator.h"
#include <memory.h>

struct MemoryRegion {
  void* data;
  uint32 size;

  MemoryRegion(): data(nullptr), size(0) {}
  MemoryRegion(const void* d, uint32 s): data((void*)d), size(s) {}
  virtual ~MemoryRegion() = 0;
};
inline MemoryRegion::~MemoryRegion() {}

typedef void(*ReleaseFn)(void* ptr, uint32 size, void* user_data);

struct MemoryRef : public MemoryRegion {
  ReleaseFn release_fn;
  void* user_data;
  MemoryRef()
	: release_fn(nullptr), user_data(nullptr) {}
  ~MemoryRef() {
    if (release_fn) release_fn(data, size, user_data);
  }
};

struct ResizableMemoryRegion : public MemoryRegion {
  virtual void Resize(uint32 new_size) = 0;
};
inline void ResizableMemoryRegion::Resize(uint32 new_size) {}

struct AllocatedMemory : public ResizableMemoryRegion {
  IAllocator* allocator;

  AllocatedMemory(IAllocator* a, uint32 s): allocator(a) {
    size = s;
    data = C2_ALLOC(a, s);
  }
  ~AllocatedMemory() {
    C2_FREE(allocator, data);
  }
  void Resize(uint32 new_size) override {
    data = C2_REALLOC(allocator, data, new_size);
    size = data ? new_size : 0;
  }
};

inline AllocatedMemory* mem_alloc(uint32 size) {
  auto mem = ::new AllocatedMemory(g_allocator, size);
  return mem;
}
inline AllocatedMemory* mem_copy(const void* data, uint32 size) {
  auto mem = mem_alloc(size);
  ::memcpy(mem->data, data, size);
  return mem;
}
inline AllocatedMemory* mem_clone(const MemoryRegion* mem) {
  return mem_copy(mem->data, mem->size);
}
inline void mem_free(const MemoryRegion* mem) {
  if (mem) delete mem;
}

inline MemoryRef* mem_ref(const void* data, uint32 size, ReleaseFn release_fn = nullptr, void* user_data = nullptr) {
  auto ref = ::new MemoryRef;
  ref->data = (void*)data;
  ref->size = size;
  ref->release_fn = release_fn;
  ref->user_data = user_data;
  return ref;
}

void mem_init();

#endif // MEMORY_H