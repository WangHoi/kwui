#ifndef ALLOCATOR_H
#define ALLOCATOR_H

#include "data/C2Data.h"
#include "platform/C2Platform.h"
#include <memory.h>

#define ALIGN_MASK(value, mask) (((value) + (mask)) & ((~0) & (~(mask))))
#define ALIGN_16(value) ALIGN_MASK(value, 0xf)
#define ALIGN_256(value) ALIGN_MASK(value, 0xff)
#define ALIGN_4096(value) ALIGN_MASK(value, 0xfff)

#ifdef C2_MEMORY_DEBUG
#define C2_ALLOC(allocator, size)  c2_alloc(allocator, size, sizeof(ptrdiff_t), __FILE__, __LINE__)
#define C2_FREE(allocator, ptr)  c2_free(allocator, ptr, sizeof(ptrdiff_t), __FILE__, __LINE__)
#define C2_REALLOC(allocator, ptr, size)  c2_realloc(allocator, ptr, size, sizeof(ptrdiff_t), __FILE__, __LINE__)
#define C2_ALIGNED_ALLOC(allocator, size, align)  c2_alloc(allocator, size, align, __FILE__, __LINE__)
#define C2_ALIGNED_REALLOC(allocator, ptr, size, align) c2_realloc(allocator, ptr, size, align, __FILE__, __LINE__)
#define C2_ALIGNED_FREE(allocator, ptr, align)  c2_free(allocator, ptr, align, __FILE__, __LINE__)
#define C2_NEW(allocator, type) ::new(C2_ALLOC(allocator, sizeof(type))) type
#define C2_DELETE(allocator, ptr) c2_delete_object(allocator, ptr, sizeof(ptrdiff_t), __FILE__, __LINE__)
#define C2_ALIGNED_NEW(allocator, type, align) ::new(C2_ALIGNED_ALLOC(allocator, sizeof(type), align)) type
#define C2_ALIGNED_DELETE(allocator, ptr, align) c2_delete_object(allocator, ptr, align, __FILE__, __LINE__)
#else
#define C2_ALLOC(allocator, size)  c2_alloc(allocator, size, sizeof(ptrdiff_t))
#define C2_FREE(allocator, ptr)  c2_free(allocator, ptr, sizeof(ptrdiff_t))
#define C2_REALLOC(allocator, ptr, size)  c2_realloc(allocator, ptr, size, sizeof(ptrdiff_t))
#define C2_ALIGNED_ALLOC(allocator, size, align)  c2_alloc(allocator, size, align)
#define C2_ALIGNED_REALLOC(allocator, ptr, size, align) c2_realloc(allocator, ptr, size, align)
#define C2_ALIGNED_FREE(allocator, ptr, align)  c2_free(allocator, ptr, align)
#define C2_NEW(allocator, type) ::new(C2_ALLOC(allocator, sizeof(type))) type
#define C2_DELETE(allocator, ptr) c2_delete_object(allocator, ptr, sizeof(ptrdiff_t))
#define C2_ALIGNED_NEW(allocator, type, align) ::new(C2_ALIGNED_ALLOC(allocator, sizeof(type), align)) type
#define C2_ALIGNED_DELETE(allocator, ptr, align) c2_delete_object(allocator, ptr, align)
#endif

struct NO_VTABLE Allocator {
  virtual ~Allocator() = 0;
  virtual void* Alloc(size_t size, size_t align, const char* file, uint32 line) = 0;
  virtual void Free(const void* ptr, size_t align, const char* file, uint32 line) = 0;
  virtual void* Realloc(const void* ptr, size_t size, size_t align, const char* file, uint32 line) = 0;
};
inline Allocator::~Allocator() {}

extern Allocator* g_allocator;

inline void* align_ptr(void* ptr, size_t extra, size_t align = sizeof(ptrdiff_t)) {
	union { void* ptr; size_t addr; } un;
	un.ptr = ptr;
	size_t unaligned = un.addr + extra; // space for header
	size_t mask = align - 1;
	size_t aligned = ALIGN_MASK(unaligned, mask);
	un.addr = aligned;
	return un.ptr;
}

inline void* c2_alloc(Allocator* allocator, size_t size, size_t align = 0, const char* file = nullptr, uint32 line = 0) {
	return allocator->Alloc(size, align, file, line);
}

inline void c2_free(Allocator* allocator, const void* ptr, size_t align = 0, const char* file = nullptr, uint32 line = 0) {
	allocator->Free(ptr, align, file, line);
}

inline void* c2_realloc(Allocator* allocator, const void* ptr, size_t size, size_t align = 0, const char* file = nullptr, uint32 line = 0) {
	return allocator->Realloc(ptr, size, align, file, line);
}

/*
static inline void* c2_aligned_alloc(Allocator* allocator, size_t size, size_t align, const char* file = nullptr, uint32 line = 0) {
	size_t total = size + align;
	uint8* ptr = (uint8*)c2_alloc(allocator, total, align, file, line);
	uint8* aligned = (uint8*)align_ptr(ptr, sizeof(uint32), align);
	uint32* header = (uint32*)aligned - 1;
	*header = uint32(aligned - ptr);
	return aligned;
}

static inline void c2_aligned_free(Allocator* allocator, const void* ptr_, size_t align, const char* file = nullptr, uint32 line = 0) {
	uint8* aligned = (uint8*)ptr_;
	uint32* header = (uint32*)aligned - 1;
	uint8* ptr = aligned - *header;
	c2_free(allocator, ptr, 0, file, line);
}

static inline void* c2_aligned_realloc(Allocator* allocator, const void* ptr_, size_t size, size_t align, const char* file = nullptr, uint32 line = 0) {
	if (!ptr_) return c2_aligned_alloc(allocator, size, align, file, line);

	uint8* aligned = (uint8*)ptr_;
	uint32 offset = *( (uint32*)aligned - 1);
	uint8* ptr = aligned - offset;
	size_t total = size + align;
	ptr = (uint8*)c2_realloc(allocator, ptr, total, 0, file, line);
	uint8* new_aligned = (uint8*)align_ptr(ptr, sizeof(uint32), align);

	if (new_aligned == aligned) return aligned;

	aligned = ptr + offset;
	::memmove(new_aligned, aligned, size);
	uint32* header = (uint32*)new_aligned - 1;
	*header = uint32(new_aligned - ptr);
	return new_aligned;
}
*/

template <typename T>
inline void c2_delete_object(Allocator* allocator, T* object, size_t align = 0, const char* file = nullptr, uint32 line = 0) {
	if (object) {
		object->~T();
		c2_free(allocator, object, align, file, line);
	}
}

struct CrtAllocator: public Allocator {
  ~CrtAllocator() {}
  void* Alloc(size_t size, size_t align, const char* file, uint32 line) override {
    if (align <= sizeof(ptrdiff_t)) return ::malloc(size);
    else {
#if ON_WINDOWS
      return _aligned_malloc(size, align);
#else
      return nullptr;
#endif
    }
  }
  void Free(const void* ptr, size_t align, const char* file, uint32 line) override {
    if (align <= sizeof(ptrdiff_t)) return ::free((void*)ptr);
    else {
#if ON_WINDOWS
      return _aligned_free((void*)ptr);
#else
      return;
#endif
    }
  }
  void* Realloc(const void* ptr, size_t size, size_t align, const char* file, uint32 line) override {
    if (align <= sizeof(ptrdiff_t)) return ::realloc((void*)ptr, size);
    else {
#if ON_WINDOWS
      return _aligned_realloc((void*)ptr, size, align);
#else
      return nullptr;
#endif
    }
  }
};

#endif