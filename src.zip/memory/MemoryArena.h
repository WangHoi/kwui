//
//  MemoryArena.h
//  ShadowPlay
//
//  Created by hoi wang on 09-18-15
//
//
#ifndef MEMORY_ARENA_H
#define MEMORY_ARENA_H

#include "data/C2Data.h"
#include "debug/C2Debug.h"
#include "platform/C2Platform.h"

struct MemoryArena;
struct TemporaryMemory {
  MemoryArena* arena;
  size_t used;
};

struct MemoryArena {
  size_t size;
  pointer base;
  size_t used;
  int32 temp_count;

  MemoryArena(int size, int alignment = 16);
  MemoryArena(MemoryArena* parent, int size, int alignment = 16);
  ~MemoryArena();
  void* Alloc(size_t len, size_t alignment = sizeof(ptrdiff_t));
  void Reset() { used = 0; }
  MemoryArena MakeSubArena(int size, int alignment = 16) { return MemoryArena(size, alignment); }
  TemporaryMemory BeginTemporaryMemory(int alignment = 16);
  void EndTemporaryMemory(const TemporaryMemory& temp);
};

#endif // MEMORY_ARENA_H