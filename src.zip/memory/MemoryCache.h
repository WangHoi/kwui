//
//  MemoryCache.h
//  C2
//
//  Created by hoi wang on 09-29-15
//
//
#ifndef MEMORY_CACHE_H
#define MEMORY_CACHE_H

#include "platform/C2Platform.h"
#include "data/C2Data.h"
#include "IAllocator.h"

struct MemoryCache {
public:
  MemoryCache(uint32 capacity = 16 * MEGABYTE, IAllocator* allocator = g_allocator);
  ~MemoryCache();
  uint32 GetSize(uint64 id) const;
  bool Read(uint64 id, void* data, uint32 size);
  void Write(uint64 id, const void* data, uint32_t size);
private:
  IAllocator* _allocator;
  uint32 _capacity;
  uint32 _size;
  unordered_map<uint64, const MemoryRegion*> _cache;
};

#endif // MEMORY_CACHE_H