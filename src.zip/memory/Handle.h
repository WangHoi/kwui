//
//  Handle.h
//  C2
//
//  Created by hoi wang on 09-24-15
//
//
#ifndef C2_HANDLE_H
#define C2_HANDLE_H
#include "Platform/Thread.h"

#define DECL_HANDLE(name) \
  struct name##_HANDLE {\
    uint32 idx;\
    name##_HANDLE(): idx(UINT32_MAX) {} \
    bool operator ==(const name##_HANDLE& o) const { return idx == o.idx; } \
    bool operator !=(const name##_HANDLE& o) const { return idx != o.idx; } \
    operator bool() const { return idx != UINT32_MAX; } \
        };

template <typename HANDLE_TYPE, uint32 COUNT>
class HandleAlloc {
public:
  HandleAlloc(): _used(0) {
    for (uint32 i = 0; i < COUNT; ++i) {
      auto& h = _handles[i];
      h.idx = i;
      _indices[i] = i;
    }
  }
  void Clear() { _used = 0; }
  HANDLE_TYPE Alloc() {
    _spin_lock.Lock();
    c2_assert_return_x(_used < COUNT, HANDLE_TYPE());
    ++_used;
    _spin_lock.Unlock();
    return _handles[_used - 1];
  }
  void Free(HANDLE_TYPE h) {
    //c2_assert(h.idx < COUNT);
    //c2_assert(_indices[h.idx] < _used);
    //c2_assert(_handles[h.idx].age == h.age);
    _spin_lock.Lock();
    if (_indices[h.idx] != _used - 1) {
      uint32 old_index = _indices[h.idx];
      swap(_indices[h.idx], _indices[_handles[_used - 1].idx]);
      swap(_handles[old_index], _handles[_used - 1]);
    }
    --_used;
    _spin_lock.Unlock();
  }
  uint32 GetUsed() const { return _used; }
  bool IsValid(HANDLE_TYPE h) const {
    return ((h.idx < COUNT) && (_indices[h.idx] < _used));
  }
  HANDLE_TYPE GetHandleAt(uint32 i) const { return _handles[i]; }
  const HANDLE_TYPE* GetPointer() const { return _handles; }

private:
  HANDLE_TYPE _handles[COUNT];
  uint32 _indices[COUNT];
  uint32 _used;
  SpinLock _spin_lock;
};

#endif // C2_HANDLE_H