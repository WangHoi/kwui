#include "InstallServiceProxy.h"
#include "debug/log.h"
#include "debug/debug_helpers.h"
#include "text/EncodingManager.h"
#include "platform/platform_helpers.h"
#include "memory/pack_utils.h"
#include <assert.h>
#include <stdlib.h>
#include <io.h>
#include <WinReg.hpp>
#include <msi.h>
#include <psapi.h>

#define MAX_ARG_LEN 8192
#pragma warning(disable:4996)

static const size_t MAX_MSG_SIZE = 65536;

extern const char* INSTALL_SERVICE_PIPE_NAME;

struct InstallServiceProxy::WriteRequestContext {
	uv_write_t req;
	std::vector<uint8_t> buf;
};

DEFINE_SINGLETON_INSTANCE(InstallServiceProxy);

static const char* DEFAULT_PRODUCT_NAME = "TestProduct";
static const char* DEFAULT_PRODUCT_VERSION = "1.0.0";
static const char* DEFAULT_UNINSTALLER_NAME = "Uninstall.exe";
static const WCHAR* REG_SHELL_FOLDERS_KEY = L"Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Shell Folders";
static const WCHAR* REG_UNINSTALL_KEY = L"Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall";

static const WCHAR* VCREDIST_2019_X86_PROVIDER_KEY = L"SOFTWARE\\Classes\\Installer\\Dependencies\\Microsoft.VS.VC_RuntimeMinimumVSU_x86,v14";

// Qt install related config key
static const String SC_PRODUCT_NAME = "ProductName";
static const String SC_PRODUCT_VERSION = "ProductVersion";
static const String SC_PRODUCT_UUID = "ProductUUID";
static const String SC_USER_START_MENU_DIR = "StartMenuDir";
static const String SC_DESKTOP_DIR = "DesktopDir";

static InstallErrorAction ErrorUserConfirm(DWORD ui_thread_id, HWND hwnd,
	InstallMessageType orig_request_type,
	const String& data);
static bool post_thread_message(DWORD idThread, HWND hwnd, UINT Msg, WPARAM wParam, InstallMessageBase *lParam);

static void on_alloc(uv_handle_t* handle, size_t suggested_size, uv_buf_t* buf)
{
	buf->base = (char*)malloc(suggested_size);
	buf->len = suggested_size;
}

void InstallServiceProxy::Quit()
{
	_job_queue->Submit([=]() {
		this->DoQuit();
		});
	if (_thread_handle) {
		WaitForSingleObject(_thread_handle, 200);
	}
}

void InstallServiceProxy::SetTargetDir(const String& dir) {
	c2_log("Set target dir to [%s]\n", dir.GetCString());
	_target_dir = dir;
}
void InstallServiceProxy::RunExe(const String& exe_filename,
	const vector<String>& args) {
	RunExe(exe_filename, Resource(), args);
}

void InstallServiceProxy::RunExe(const String& exe_filename,
	const Resource& exe,
	const vector<String>& args) {

	RunExeRequest* req = new RunExeRequest;
	req->src_hwnd = GetMsgHwnd();
	req->resource = exe.id;
	req->target_dir = _target_dir;
	req->exe_filename = exe_filename;
	auto EM = EncodingManager::Instance();
	for (auto& arg : args) {
		req->arguments.push_back(EM->UTF8ToWide(arg));
	}
	_job_queue->Submit([=] {
		this->DoRunExe(*req);
		delete req;
		});
}
void InstallServiceProxy::UnpackArchive(const Resource& data) {
	UnpackArchiveRequest* req = new UnpackArchiveRequest;
	req->src_hwnd = GetMsgHwnd();
	req->resource = data.id;
	req->target_dir = _target_dir;
	_job_queue->Submit([=] {
		this->DoUnpackArchive(*req);
		delete req;
		});
}
void InstallServiceProxy::UnpackResource(const String& filename, const Resource& data) {
	auto req = new UnpackResourceRequest;
	req->src_hwnd = GetMsgHwnd();
	req->resource = data.id;
	req->target_dir = _target_dir;
	req->filename = filename;
	_job_queue->Submit([=] {
		this->DoUnpackResource(*req);
		delete req;
		});
}
void InstallServiceProxy::RemoveTargetDir() {
	RemoveDirRequest* req = new RemoveDirRequest;
	req->src_hwnd = GetMsgHwnd();
	req->target_dir = _target_dir;
	_job_queue->Submit([=] {
		this->DoRemoveDir(*req);
		delete req;
		});
}
void InstallServiceProxy::CreateShortcut() {
	CreateShortcutRequest* req = new CreateShortcutRequest;
	req->src_hwnd = GetMsgHwnd();
	req->product_name = _product_name;
	req->target_dir = _target_dir;
	req->display_name = _display_name;
	req->product_version = _product_version;
	req->exe_filename = _exe_filename;
	req->uninstaller_filename = _uninstaller_filename;
	req->publisher = _publisher;
	req->estimated_size = _estimated_size_kb;
	_job_queue->Submit([=] {
		this->DoCreateShortcut(*req);
		delete req;
		});
}
void InstallServiceProxy::RemoveShortcut() {
	RemoveShortcutRequest* req = new RemoveShortcutRequest;
	req->src_hwnd = GetMsgHwnd();
	req->product_name = _product_name;
	req->display_name = _display_name;
	_job_queue->Submit([=] {
		this->DoRemoveShortcut(*req);
		delete req;
		});
}
DWORD WINAPI InstallServiceProxy::WorkerThreadFunc(LPVOID lpParam) {
	auto me = (InstallServiceProxy*)lpParam;
	int ret;

	me->_loop = uv_loop_new();
	me->_job_queue = UvJobQueue::Create(me->_loop);
	
	me->_server = (uv_pipe_t*)malloc(sizeof(uv_pipe_t));
	me->_server->data = me;
	ret = uv_pipe_init(me->_loop, me->_server, 0);
	assert(ret == 0);
	ret = uv_pipe_bind(me->_server, INSTALL_SERVICE_PIPE_NAME);
	if (ret) {
		c2_log("bind pipe [%s] error: %s\n", INSTALL_SERVICE_PIPE_NAME, uv_strerror(ret));
	}
	ret = uv_listen((uv_stream_t*)me->_server, 32, &InstallServiceProxy::OnNewConnection);

	// notify thread creator
	uv_barrier_wait(&me->_thread_start_barrier);
	
	uv_run(me->_loop, UV_RUN_DEFAULT);

	return 0;
}
void InstallServiceProxy::DoRunExe(RunExeRequest& request) {
	c2_log("Start RunExe [%s].\n", request.exe_filename.GetCString());
	json arguments = json::array();
	for (auto& a : request.arguments)
		arguments.push_back(String(a).GetCString());
	SendMsg(GetFirstContext(), {
		{ "cmd", "run_exe" },
		{ "data", {
			{ "resource", request.resource },
			{ "exe_filename", request.exe_filename.GetCString() },
			{ "target_dir", request.target_dir.GetCString() },
			{ "arguments", arguments }
		}}
		});
}
InstallErrorAction ErrorUserConfirm(DWORD ui_thread_id, HWND hwnd,
	InstallMessageType orig_request_type,
	const String& data) {
	MSG msg;
	BOOL success;
	InstallErrorAction action;

	PeekMessageW(&msg, NULL, 0, 0, PM_NOREMOVE);

	auto request = new ErrorUserCallback(orig_request_type, data);
	request->src_thread_id = GetCurrentThreadId();
	success = post_thread_message(ui_thread_id, hwnd, WM_APP, 0, request);
	if (!success) {
		delete request;
		return INSTALL_ERR_ABORT;
	}

	success = GetMessageW(&msg, NULL, 0, 0);
	if (msg.message != WM_APP) {
		c2_log("ErrorUserConfirm() recv unexpect window msg 0x%04X\n", msg.message);
		return INSTALL_ERR_ABORT;
	}
	auto reply_base = (InstallMessageBase*)msg.lParam;
	if (reply_base->GetType() != INSTALL_MSG_ERROR_USER_ACTION) {
		c2_log("ErrorUserConfirm() recv unexpect InstallMessageType %d\n", reply_base->GetType());
		delete reply_base;
		return INSTALL_ERR_ABORT;
	}
	auto reply = (ErrorUserAction*)reply_base;
	reply_base = nullptr;
	if (reply->request_msg_type != orig_request_type) {
		c2_log("ErrorUserConfirm() recv unexpect original request InstallMessageType %d\n",
			reply->request_msg_type);
		delete reply;
		return INSTALL_ERR_ABORT;
	}
	action = reply->action;
	delete reply;
	if (action == INSTALL_ERR_RETRY || action == INSTALL_ERR_CONTINUE) {
		::Sleep(50);
	}
	return action;
}
void InstallServiceProxy::DoUnpackArchive(UnpackArchiveRequest& request) {
	c2_log("DoUnpackArchive target_dir=[%s].\n", request.target_dir.GetCString());

	SendMsg(GetFirstContext(), {
	{ "cmd", "unpack_archive" },
	{ "data", {
		{ "resource", request.resource },
		{ "target_dir", request.target_dir.GetCString() },
	}}
	});
}
void InstallServiceProxy::DoCreateShortcut(CreateShortcutRequest& request) {
	c2_log("DoCreateShortcut product name=[%s].\n", request.product_name.GetCString());

	SendMsg(GetFirstContext(), {
	{ "cmd", "create_shortcut" },
	{ "data", {
		{ "target_dir", request.target_dir.GetCString() },
		{ "product_name", request.product_name.GetCString() },
		{ "display_name", request.display_name.GetCString() },
		{ "product_version", request.product_version.GetCString() },
		{ "exe_filename", request.exe_filename.GetCString() },
		{ "uninstaller_filename", request.uninstaller_filename.GetCString() },
		{ "publisher", request.publisher.GetCString() },
		{ "estimated_size", request.estimated_size.value_or(0) },
	}}
	});
}
void InstallServiceProxy::DoRemoveShortcut(RemoveShortcutRequest& request) {
	c2_log("DoRemoveShortcut product name=[%s].\n", request.product_name.GetCString());

	SendMsg(GetFirstContext(), {
	{ "cmd", "remove_shortcut" },
	{ "data", {
		{ "product_name", request.product_name.GetCString() },
		{ "display_name", request.display_name.GetCString() },
	}}
	});
}
void InstallServiceProxy::DoRemoveDir(RemoveDirRequest& request) {
	c2_log("DoRemoveDir target_dir=[%s].\n", request.target_dir.GetCString());

	SendMsg(GetFirstContext(), {
	{ "cmd", "remove_dir" },
	{ "data", {
		{ "target_dir", request.target_dir.GetCString() },
	}}
	});
}
void InstallServiceProxy::DoKillProcess(KillProcessRequest& request) {
	c2_log("DoKillProcess.\n");

	json process_ids = json::array();
	for (auto id : request.process_ids)
		process_ids.push_back(id);

	SendMsg(GetFirstContext(), {
	{ "cmd", "kill_process" },
	{ "data", {
		{ "process_ids", process_ids },
	}}
	});
}
void InstallServiceProxy::GetRunningProcessNew() {
	GetRunningProcessRequest* req = new GetRunningProcessRequest;
	req->src_hwnd = GetMsgHwnd();
	req->product_name = _product_name;
	req->exe_filenames.push_back(_exe_filename);
	req->exe_filenames.push_back(_product_name + "\\workbench.exe");
	req->exe_filenames.push_back(_product_name + "\\QtWebEngineProcess.exe");
	req->exe_filenames.push_back(_product_name + "\\dirmigrate.exe");
	_job_queue->Submit([=] {
		this->DoGetRunningProcess(*req);
		delete req;
		});
}
void InstallServiceProxy::DoGetRunningProcess(GetRunningProcessRequest& request) {
	c2_log("DoGetRunningProcess.\n");
	
	json exe_filenames = json::array();
	for (auto exe_filename : request.exe_filenames)
		exe_filenames.push_back(exe_filename.GetCString());

	SendMsg(GetFirstContext(), {
		{ "cmd", "get_running_process" },
		{ "data", {
			{ "product_name", request.product_name.GetCString() },
			{ "exe_filenames", exe_filenames }
		}}
		});
}
void InstallServiceProxy::DoQuit()
{
	uv_stop(_loop);
}
void InstallServiceProxy::KillProcess(const vector<DWORD>& pid) {
	KillProcessRequest* req = new KillProcessRequest;
	req->src_hwnd = GetMsgHwnd();
	req->process_ids = pid;
	_job_queue->Submit([=] {
		this->DoKillProcess(*req);
		delete req;
		});
}
void InstallServiceProxy::LaunchTargetExe() {
	String exe_path = "\"" + _target_dir + "\\" + _exe_filename + "\"";
	wstring utf16_exe_path = EncodingManager::Instance()
		->UTF8ToWide(exe_path);
	bool success;
	PROCESS_INFORMATION pi = {};
	STARTUPINFOW si = {};
	si.cb = sizeof(si);
	success = CreateProcessW(NULL,
		&utf16_exe_path[0],
		NULL,
		NULL,
		FALSE,
		DETACHED_PROCESS,
		NULL,
		NULL,
		&si,
		&pi);
	if (success) {
		CloseHandle(pi.hProcess);
	}
}

void InstallServiceProxy::DetectExistInstall() {
	auto req = new DetectExistInstallRequest;
	req->src_hwnd = GetMsgHwnd();
	req->program_files_dir_hint = _program_files_dir;
	req->product_name = _product_name;
	req->display_name = _display_name;
	req->current_vcredist_version = _vcredist_version;
	_job_queue->Submit([=] {
		this->DoDetectExistInstall(*req);
		delete req;
		});
}
void InstallServiceProxy::RemoveExistInstall(const ExistInstallData& data) {
	auto req = new RemoveExistInstallRequest;
	req->src_hwnd = GetMsgHwnd();
	req->data = data;
	_job_queue->Submit([=] {
		this->DoRemoveExistInstall(*req);
		delete req;
		});
}

void InstallServiceProxy::DeleteUninstallerSelf() {
	InstallTimer timer;
	auto EM = EncodingManager::Instance();
	WCHAR temp_path[MAX_PATH + 1] = {};
	WCHAR filename[MAX_PATH + 1] = {};
	DWORD ret;
	ret = GetTempPathW(MAX_PATH, temp_path);
	ret = GetTempFileNameW(temp_path, L"chengxun_uninstall_", 1, filename);
	wstring script_filename = wstring(filename) + L".vbs";
	FILE* f = _wfopen(script_filename.c_str(), L"w");
	if (!f) {
		c2_log("Open [%s] failed.\n", EM->WideToUTF8(script_filename).GetCString());
		return;
	}
	fputs("Set fso = WScript.CreateObject(\"Scripting.FileSystemObject\")\n", f);
	fputs("file = WScript.Arguments.Item(0)\n", f);
	fputs("folderpath = WScript.Arguments.Item(1)\n", f);
	fputs("Set folder = fso.GetFolder(folderpath)\n", f);
	fputs("on error resume next\n", f);
	fputs("fso.DeleteFile(file)\n", f);
	fputs("for i = 1 to 5\n", f);
	fputs("  if NOT fso.FileExists(file) then\n", f);
	fputs("    exit for\n", f);
	fputs("  end if\n", f);
	fputs("  WScript.Sleep(1000)\n", f);
	fputs("  fso.DeleteFile(file)\n", f);
	fputs("next\n", f);
	//    fputs("if folder.SubFolders.Count = 0 and folder.Files.Count = 0 then\n", f);
	fputs("Set folder = Nothing\n", f);
	fputs("fso.DeleteFolder folderpath, true\n", f);
	//    fputs("end if\n", f);
	fputs("fso.DeleteFile(WScript.ScriptFullName)\n", f);
	fclose(f);

	BOOL success;
	PROCESS_INFORMATION pi = {};
	wstring cmdline;
	STARTUPINFOW si = {};
	si.cb = sizeof(si);

	cmdline = L"cscript \"" + script_filename + L"\"";
	//cmdline += L" //B";
	cmdline += L" //Nologo";
	wstring target_dir = EM->UTF8ToWide(_target_dir);
	wstring exe_filename = EM->UTF8ToWide(_uninstaller_filename);
	cmdline += L" \"" + target_dir + L"\\" + exe_filename + L"\"";
	cmdline += L" \"" + target_dir + L"\"";

	//c2_log("RemoveSelf: %.03lf create process cmdline [%s]...\n",
	//       timer.GetElapsed(),
	//       EM->WideToUTF8(cmdline).GetCString());
	success = CreateProcessW(NULL,
		&cmdline[0],
		NULL,
		NULL,
		FALSE,
		DETACHED_PROCESS | CREATE_NO_WINDOW,
		NULL,
		temp_path,
		&si,
		&pi);
	if (!success) {
		c2_log("RunExe: create process cmdline [%s] failed, GetLastError()=0x%08X.\n",
			EM->WideToUTF8(cmdline).GetCString(), GetLastError());
		return;
	}
	CloseHandle(pi.hProcess);
	c2_log("RemoveSelf: %.03lf Done\n", timer.GetElapsed());
}

void InstallServiceProxy::ErrorUserAction(InstallMessageType orig_msg_type,
	DWORD worker_thread_id, InstallErrorAction action)
{
	auto req = new ::ErrorUserAction(orig_msg_type, action);
	req->src_thread_id = worker_thread_id;
	req->src_hwnd = GetMsgHwnd();
	_job_queue->Submit([=] {
		this->DoErrorUserAction(*req);
		delete req;
		});
}

static BOOL Is64BitWindows()
{
#if defined(_WIN64)
	return TRUE;  // 64-bit programs run only on Win64
#elif defined(_WIN32)
	// 32-bit programs run on both 32-bit and 64-bit Windows
	// so must sniff
	BOOL f64 = FALSE;
	return IsWow64Process(GetCurrentProcess(), &f64) && f64;
#else
	return FALSE; // Win64 does not support Win16
#endif
}
InstallServiceProxy::InstallServiceProxy()
	: _product_name(DEFAULT_PRODUCT_NAME)
	, _display_name(DEFAULT_PRODUCT_NAME)
	, _product_version(DEFAULT_PRODUCT_VERSION) {

	WCHAR path[MAX_PATH + 1] = {};
	if (SHGetSpecialFolderPathW(NULL, path, CSIDL_PROGRAM_FILESX86, FALSE)) {
		_program_files_dir = EncodingManager::Instance()->WideToUTF8(path);
	}
	else {
		if (Is64BitWindows()) {
			_program_files_dir = "C:\\Program Files (x86)";
		} else {
			_program_files_dir = "C:\\Program Files";
		}
	}

	uv_barrier_init(&_thread_start_barrier, 2);

	HANDLE h;
	int tries = 0;
	while (tries < 2) {
		h = CreateThread(NULL, 0, &InstallServiceProxy::WorkerThreadFunc, this, 0, NULL);
		if (h == INVALID_HANDLE_VALUE || h == NULL) {
			c2_log("create worker thread failed, GetLastError()=0x%08X\n", GetLastError());
			++tries;
			continue;
		}
		break;
	}
	if (h != INVALID_HANDLE_VALUE && h != NULL) {
		_thread_handle = h;
		uv_barrier_wait(&_thread_start_barrier);
	}
}

void InstallServiceProxy::DoDetectExistInstall(DetectExistInstallRequest& req) {
	c2_log("DoDetectExistInstall product_name=[%s].\n", req.product_name.GetCString());

	SendMsg(GetFirstContext(), {
		{ "cmd", "detect_exist_install" },
		{ "data", {
			{ "program_files_dir_hint", req.program_files_dir_hint.GetCString() },
			{ "product_name", req.product_name.GetCString() },
			{ "display_name", req.display_name.GetCString() },
			{ "current_vcredist_version", req.current_vcredist_version.GetCString() },
		}}
		});
}

void InstallServiceProxy::DoRemoveExistInstall(RemoveExistInstallRequest& req) {
	c2_log("DoRemoveExistInstall.\n");

	json jdata = json::object();
	ExistInstallData &data = req.data;
	jdata = json::object({
		{ "type", "my" },
		{ "product_name", data.product_name.GetCString() },
		{ "display_name", data.display_name.GetCString() },
		{ "target_dir", data.target_dir.GetCString() },
		{ "version", data.version.GetCString() },
		});

	SendMsg(GetFirstContext(), {
		{ "cmd", "remove_exist_install" },
		{ "data", jdata }});
}
void InstallServiceProxy::DoUnpackResource(UnpackResourceRequest& req) {
	c2_log("DoUnpackResource filename=[%s].\n", req.filename.GetCString());

	SendMsg(GetFirstContext(), {
		{ "cmd", "unpack_resource" },
		{ "data", {
			{ "resource", req.resource },
			{ "filename", req.filename.GetCString() },
			{ "target_dir", req.target_dir.GetCString() },
		}}
		});
}

void InstallServiceProxy::DoErrorUserAction(::ErrorUserAction& req) {
	c2_log("DoErrorUserAction orig_msg_type=%d, action=%d.\n", req.request_msg_type, req.action);

	SendMsg(GetFirstContext(), {
		{ "cmd", "error_user_action" },
		{ "data", {
			{ "worker_thread_id", req.src_thread_id },
			{ "request_msg_type", req.request_msg_type },
			{ "action", req.action },
		}}
		});
}
bool post_thread_message(DWORD idThread, HWND hwnd, UINT Msg, WPARAM wParam, InstallMessageBase *lParam) {
	BOOL success;
	DWORD last_error;
	c2_log("post_thread_message idThread=%08X hwnd=%08X InstallMessage type %d\n",
		idThread, hwnd, lParam->GetType());
	if (idThread) {
	retry:
		success = PostThreadMessageW(idThread, Msg, wParam, (LPARAM)lParam);
		if (!success) {
			last_error = GetLastError();
			c2_log("notify ui thread failed, GetLastError()=0x%08X\n", last_error);
			if (last_error == ERROR_NOT_ENOUGH_QUOTA) {
				::Sleep(1000);
				goto retry;
			}
		}
	} else if (hwnd) {
	retry2:
		success = PostMessage(hwnd, Msg, wParam, (LPARAM)lParam);
		if (!success) {
			last_error = GetLastError();
			c2_log("notify ui hwnd failed, GetLastError()=0x%08X\n", last_error);
			if (last_error == ERROR_NOT_ENOUGH_QUOTA) {
				::Sleep(1000);
				goto retry2;
			}
		}
	} else {
		c2_log("notify ui failed, src thread and hwnd is invalid.\n");
		success = false;
	}
	return success;
}

bool InstallServiceProxy::ParseReadedData(PeerContext* ctx)
{
	std::vector<uint8_t>& buf = ctx->read_buf;
	if (buf.size() < 4)
		return false;
	uint32_t size = unpack_be32(&buf[0]);
	if (size > MAX_MSG_SIZE) {
		buf.clear();
		return false;
	}
	if (4 + size > buf.size())
		return false;
	try {
		json j = json::from_bson(buf.begin() + 4, buf.begin() + 4 + size);
		buf.erase(buf.begin(), buf.begin() + 4 + size);

		c2_log("recv [%s]\n", j.dump().c_str());

		std::string cmd = j["cmd"].get<std::string>();
		if (cmd == "connect") {
			auto reply = new ConnectNotify;
			post_thread_message(0, _msg_window.GetHwnd(), WM_APP, 0, reply);
		} else if (cmd == "run_exe_reply") {
			auto reply = new RunExeReply;
			reply->resource = j["data"]["resource"].get<UINT>();
			reply->status = j["data"]["status"].get<int>();
			reply->exit_code = j["data"]["exit_code"].get<int>();
			post_thread_message(0, _msg_window.GetHwnd(), WM_APP, 0, reply);
		} else if (cmd == "unpack_archive_reply") {
			auto reply = new UnpackArchiveReply;
			reply->resource = j["data"]["resource"].get<UINT>();
			reply->status = j["data"]["status"].get<int>();
			post_thread_message(0, _msg_window.GetHwnd(), WM_APP, 0, reply);
		} else if (cmd == "unpack_archive_progress") {
			auto reply = new UnpackArchiveProgress;
			reply->resource = j["data"]["resource"].get<UINT>();
			reply->progress = j["data"]["progress"].get<double>();
			post_thread_message(0, _msg_window.GetHwnd(), WM_APP, 0, reply);
		} else if (cmd == "create_shortcut_reply") {
			auto reply = new CreateShortcutReply;
			reply->resource = j["data"]["resource"].get<UINT>();
			reply->status = j["data"]["status"].get<int>();
			post_thread_message(0, _msg_window.GetHwnd(), WM_APP, 0, reply);
		} else if (cmd == "remove_shortcut_reply") {
			auto reply = new RemoveShortcutReply;
			reply->resource = j["data"]["resource"].get<UINT>();
			reply->status = j["data"]["status"].get<int>();
			post_thread_message(0, _msg_window.GetHwnd(), WM_APP, 0, reply);
		} else if (cmd == "remove_dir_reply") {
			auto reply = new RemoveDirReply;
			reply->resource = j["data"]["resource"].get<UINT>();
			reply->status = j["data"]["status"].get<int>();
			post_thread_message(0, _msg_window.GetHwnd(), WM_APP, 0, reply);
		} else if (cmd == "kill_process_reply") {
			auto reply = new KillProcessReply;
			reply->resource = j["data"]["resource"].get<UINT>();
			reply->status = j["data"]["status"].get<int>();
			post_thread_message(0, _msg_window.GetHwnd(), WM_APP, 0, reply);
		} else if (cmd == "detect_exist_install_reply") {
			auto reply = new DetectExistInstallReply;
			reply->resource = j["data"]["resource"].get<UINT>();
			reply->vcredist_installed = j["data"]["vcredist_installed"].get<bool>();
			json chengxun_result = j["data"]["chengxun_result"];
			if (chengxun_result.is_object() && chengxun_result["type"].is_string()) {
				std::string result_type = chengxun_result["type"].get<std::string>();
				ExistInstallData data;
				data.product_name = chengxun_result["product_name"].get<std::string>();
				data.display_name = chengxun_result["display_name"].get<std::string>();
				data.version = chengxun_result["version"].get<std::string>();
				data.target_dir = chengxun_result["target_dir"].get<std::string>();
				reply->chengxun_result.emplace(data);
			}
			post_thread_message(0, _msg_window.GetHwnd(), WM_APP, 0, reply);
		} else if (cmd == "remove_exist_install_reply") {
			auto reply = new RemoveExistInstallReply;
			reply->resource = j["data"]["resource"].get<UINT>();
			reply->status = j["data"]["status"].get<int>();
			post_thread_message(0, _msg_window.GetHwnd(), WM_APP, 0, reply);
		} else if (cmd == "unpack_resource_reply") {
			auto reply = new UnpackResourceReply;
			reply->resource = j["data"]["resource"].get<UINT>();
			reply->status = j["data"]["status"].get<int>();
			post_thread_message(0, _msg_window.GetHwnd(), WM_APP, 0, reply);
		} else if (cmd == "error_user_callback") {
			auto request_msg_type = (InstallMessageType)j["data"]["request_msg_type"].get<int>();
			auto detail = j["data"]["detail"].get<std::string>();
			auto reply = new ErrorUserCallback(request_msg_type, detail);
			reply->src_thread_id = j["data"]["src_thread_id"].get<DWORD>();
			post_thread_message(0, _msg_window.GetHwnd(), WM_APP, 0, reply);
		} else if (cmd == "get_running_process_reply") {
			auto reply = new GetRunningProcessReply;
			json process_ids = j["data"]["process_ids"];
			for (auto& id : process_ids)
				reply->process_ids.push_back(id.get<DWORD>());
			post_thread_message(0, _msg_window.GetHwnd(), WM_APP, 0, reply);
		} else {
			c2_log("ParseReadedData: unhandled msg type [%s]\n", cmd.c_str());
		}

		return true;
	}
	catch (...) {
		buf.clear();
		return false;
	}
}

void InstallServiceProxy::SendMsg(PeerContext* dst, json&& j)
{
	c2_log("send [%s]\n", j.dump().c_str());

	if (!dst || !dst->pipe) {
		c2_log("main service: send msg error: no peer pipe.\n");
		return;
	}

	WriteRequestContext* ctx = new WriteRequestContext;
	ctx->buf.resize(4);
	json::to_bson(j, ctx->buf);
	uint32_t size = (uint32_t)(ctx->buf.size() - 4);
	pack_be32(&ctx->buf[0], size);

	uv_buf_t uv_buf = uv_buf_init((char*)ctx->buf.data(), ctx->buf.size());
	ctx->req.data = ctx;
	int ret = uv_write(&ctx->req, (uv_stream_t*)dst->pipe, &uv_buf, 1, &InstallServiceProxy::OnWritten);
	if (ret < 0) {
		c2_log("send error: %s\n", uv_strerror(ret));
		uv_close((uv_handle_t*)dst->pipe, [](uv_handle_t* h) { free(h); });
		dst->pipe = nullptr;
	}
}

void InstallServiceProxy::OnWritten(uv_write_t* req, int status)
{
	WriteRequestContext* ctx = (WriteRequestContext*)req->data;
	delete ctx;
}

void InstallServiceProxy::OnReaded(uv_stream_t* stream, ssize_t nread, const uv_buf_t* buf)
{
	auto me = (InstallServiceProxy*)stream->data;
	if (nread < 0) {
		c2_log("read error %s, exit.\n", uv_strerror(nread));
		uv_close((uv_handle_t*)stream, [](uv_handle_t* h) { free(h); });
		me->_peer_map.erase((uv_pipe_t*)stream);
		return;
	}
	if (nread == 0)
		return;

	PeerContext* ctx = me->FindContext((uv_pipe_t*)stream);
	if (ctx) {
		std::copy(buf->base, buf->base + nread, std::back_inserter(ctx->read_buf));
		while (me->ParseReadedData(ctx)) {}
	}
	free(buf->base);
}
void InstallServiceProxy::OnNewConnection(uv_stream_t* server, int status)
{
	c2_log("main service: new connection, status %d\n", status);
	if (status < 0) {
		c2_log("main service: on new connection error: %s\n", uv_strerror(status));
		return;
	}

	auto me = (InstallServiceProxy*)server->data;
	if (!me) {
		c2_log("main service: null InstallService object pointer.\n");
		return;
	}

	c2_log("main service: got new connection.\n");

	int ret;
	uv_pipe_t* new_peer = (uv_pipe_t*)malloc(sizeof(uv_pipe_t));
	ret = uv_pipe_init(me->_loop, new_peer, 0);
	assert(ret == 0);
	ret = uv_accept(server, (uv_stream_t*)new_peer);
	if (ret < 0) {
		c2_log("main service: accept new connection error: %s\n", uv_strerror(ret));
		uv_close((uv_handle_t*)new_peer, [](uv_handle_t* h) { free(h); });
		return;
	}

	new_peer->data = me;
	PeerContext ctx;
	ctx.pipe = new_peer;

	me->_peer_map.emplace(new_peer, ctx);
	uv_read_start((uv_stream_t*)new_peer, on_alloc, &InstallServiceProxy::OnReaded);
}
InstallServiceProxy::PeerContext* InstallServiceProxy::FindContext(uv_pipe_t* pipe)
{
	auto it = _peer_map.find(pipe);
	if (it == _peer_map.end())
		return nullptr;
	return &it->second;
}

InstallServiceProxy::PeerContext* InstallServiceProxy::GetFirstContext()
{
	if (_peer_map.empty())
		return nullptr;
	return &_peer_map.begin()->second;
}
