#include "stdafx.h"
#include "ps4_allocators.h"

#define ONION_MIN_SIZE 64
#define GARLIC_MIN_SIZE_SHIFT 6
#define GARLIC_MIN_SIZE (1 << GARLIC_MIN_SIZE_SHIFT)

#define G_ALLOCATOR_SIZE (1024u * MEGABYTE)
static const size_t GARLIC_ALLOCATOR_SIZE = 2560u * MEGABYTE;
static const size_t ONION_ALLOCATOR_SIZE = 8u * MEGABYTE;

static OnionAllocator s_g_allocator;

IAllocator* g_onion_allocator = nullptr;
IAllocator* g_garlic_allocator = nullptr;

extern "C" SceLibcMspace get_g_allocator_handle() {
  return s_g_allocator.GetHandle();
}

OnionAllocator::OnionAllocator(size_t size, bool gpu_writable) {
  _size = size;
  auto ret = sceKernelAllocateDirectMemory(0, SCE_KERNEL_MAIN_DMEM_SIZE, size, 64 * KILOBYTE,
                                           SCE_KERNEL_WB_ONION, &_dmem_offset);
  if (ret != SCE_OK) {
    c2_log("[C2] Failed to allocate onion direct memory.\n");
    abort();
  }
  int prot = SCE_KERNEL_PROT_CPU_RW;
  if (gpu_writable) prot |= SCE_KERNEL_PROT_GPU_ALL;
  ret = sceKernelMapDirectMemory(&_addr, size, prot, 0, _dmem_offset, 64 * KILOBYTE);
  if (ret != SCE_OK) {
    c2_log("[C2] Failed to map onion memory.\n");
    abort();
  }
  _mspace = sceLibcMspaceCreate("onion heap", _addr, _size, 0);
}

OnionAllocator::~OnionAllocator() {
  if (this == g_allocator) return;
  Finalize();
}

void* OnionAllocator::Alloc(size_t size, size_t align, const char* file, uint32 line) {
  return sceLibcMspaceMemalign(_mspace, align, size);
}

void OnionAllocator::Free(const void* ptr, size_t align, const char* file, uint32 line) {
  if (!ptr) return;
  sceLibcMspaceFree(_mspace, (void*)ptr);
}

void* OnionAllocator::Realloc(const void* ptr, size_t size, size_t align, const char* file, uint32 line) {
  return sceLibcMspaceReallocalign(_mspace, (void*)ptr, align, size);
}

void OnionAllocator::GetStats(AllocatorStat* stats) {
  SceLibcMallocManagedSize mmsize;
  SCE_LIBC_INIT_MALLOC_MANAGED_SIZE(mmsize);
  sceLibcMspaceMallocStatsFast(_mspace, &mmsize);
  stats->total_size = _size;
  stats->used = mmsize.currentInuseSize;
  stats->peak_used = mmsize.maxInuseSize;
}

void OnionAllocator::Finalize() {
  sceLibcMspaceDestroy(_mspace);
  sceKernelMunmap(_addr, _size);
  sceKernelReleaseDirectMemory(_dmem_offset, _size);
}

/////////////////////////////////////////////////////////////////////////////
static void compute_fli_sli(size_t size, int& fli, int& sli) {
  size >>= GARLIC_MIN_SIZE_SHIFT;
  c2_assert(size > 0);
  fli = last_bit_position(size);
  sli = (size - (1ul << fli)) >> (fli - GARLIC_SLI);
  c2_assert(sli < (1 << GARLIC_SLI));
}

GarlicAllocator::GarlicAllocator(size_t size) {
  _size = size;
  _used = _peak_used = 0;
  auto ret = sceKernelAllocateDirectMemory(0, SCE_KERNEL_MAIN_DMEM_SIZE, size, 64 * KILOBYTE,
                                           SCE_KERNEL_WC_GARLIC, &_dmem_offset);
  if (ret != SCE_OK) {
    c2_log("[C2] Failed to allocate garlic direct memory.\n");
    abort();
  }
  ret = sceKernelMapDirectMemory(&_addr, size, SCE_KERNEL_PROT_CPU_WRITE | SCE_KERNEL_PROT_GPU_ALL, 0, _dmem_offset, 64 * KILOBYTE);
  if (ret != SCE_OK) {
    c2_log("[C2] Failed to map garlic memory.\n");
    abort();
  }
  _block_allocator.Init(sizeof(BlockHeader), ALIGNOF(BlockHeader), 4096);
  _fli_mask = 0;
  memset(&_sli_mask, 0, sizeof(_sli_mask));
  memset(_headers, 0, sizeof(_headers));
  auto block = AllocBlock();
  block->ptr = (intptr_t)_addr;
  block->size = _size;
  block->next = nullptr;
  block->prev = nullptr;
  block->next_free = nullptr;
  block->prev_free = nullptr;
  InsertFreeBlock(block);
  _used_map.reserve(4096);
}

GarlicAllocator::~GarlicAllocator() {
  sceKernelMunmap(_addr, _size);
  sceKernelReleaseDirectMemory(_dmem_offset, _size);
}

void* GarlicAllocator::Alloc(size_t size, size_t align, const char* file, uint32 line) {
  SpinLockGuard lock_holder(&_lock);
  size = max<size_t>(size + align - 1, GARLIC_MIN_SIZE);
  int fli, sli;
  compute_fli_sli(size, fli, sli);
  auto block = FindFreeBlock(size, &fli, &sli);
  if (block) {
    RemoveFreeBlock(block, fli, sli);
    intptr_t aligned_ptr = ALIGN_MASK(block->ptr, align - 1);
    long left = block->size - size - (aligned_ptr - block->ptr);
    if (left >= GARLIC_MIN_SIZE) {
      block->size -= left;
      auto new_block = AllocBlock();
      new_block->ptr = block->ptr + block->size;
      new_block->size = left;
      new_block->next = block->next;
      new_block->prev = block;
      if (block->next) block->next->prev = new_block;
      block->next = new_block;
      InsertFreeBlock(new_block);
    }
    _used_map[aligned_ptr] = block;
    _used += block->size;
    _peak_used = max(_used, _peak_used);
    return (void*)aligned_ptr;
  }
  c2_log("[C2] garlic allocate fail, size %d, align %d.\n", size, align);
  return nullptr;
}

void GarlicAllocator::Free(const void* ptr, size_t align, const char* file, uint32 line) {
  if (!ptr) return;
  SpinLockGuard lock_holder(&_lock);
  auto it = _used_map.find((intptr_t)ptr);
  if (it == _used_map.end()) {
    c2_log("[C2] Garlic free failed, not valid pointer.\n");
    return;
  }
  auto block = it->second;
  _used -= block->size;
  block = MergeFreeBlockAfter(block);
  block = MergeFreeBlockBefore(block);
  InsertFreeBlock(block);
  _used_map.erase(it);
}

void* GarlicAllocator::Realloc(const void* ptr, size_t size, size_t align, const char* file, uint32 line) {
  c2_log("[C2] Garlic realloc not supported.\n");
  return nullptr;
}

void GarlicAllocator::GetStats(AllocatorStat* stats) {
  stats->total_size = _size;
  stats->used = _used;
  stats->peak_used = _peak_used;
}

GarlicAllocator::BlockHeader* GarlicAllocator::AllocBlock() {
  return (BlockHeader*)C2_ALLOC(&_block_allocator, sizeof(BlockHeader));
}

void GarlicAllocator::FreeBlock(BlockHeader* block) {
  C2_FREE(&_block_allocator, block);
}

void GarlicAllocator::InsertFreeBlock(BlockHeader* block) {
  int fli, sli;
  compute_fli_sli(block->size, fli, sli);
  auto head = _headers[fli][sli];
  if (head) head->prev_free = block;
  block->next_free = head;
  block->prev_free = nullptr;
  _headers[fli][sli] = block;
  block->is_free = true;
  set_bit(_sli_mask[fli], sli);
  set_bit(_fli_mask, fli);
}

GarlicAllocator::BlockHeader* GarlicAllocator::FindFreeBlock(size_t size, int* out_fli, int* out_sli) {
  int fli = *out_fli;
  int sli = *out_sli;
  uint32 sli_map = _sli_mask[fli] & (~0 << (sli + 1));
  if (!sli_map) {
    const uint32 fli_map = _fli_mask & (~0 << (fli + 1));
    if (!fli_map) return nullptr;
    *out_fli = fli = first_bit_position(fli_map);
    sli_map = _sli_mask[fli];
  }
  c2_assert(sli_map != 0);
  *out_sli = sli = first_bit_position(sli_map);
  return _headers[fli][sli];
}

void GarlicAllocator::RemoveFreeBlock(BlockHeader* block, int fli, int sli) {
  auto prev_block = block->prev_free;
  auto next_block = block->next_free;
  if (prev_block) prev_block->next_free = next_block;
  if (next_block) next_block->prev_free = prev_block;
  if (!prev_block) {
    c2_assert(_headers[fli][sli] == block);
    _headers[fli][sli] = next_block;
    if (!next_block) {
      clear_bit(_sli_mask[fli], sli);
      if (!_sli_mask[fli]) clear_bit(_fli_mask, fli);
    }
  }
  block->next_free = nullptr;
  block->prev_free = nullptr;
  block->is_free = false;
}

void GarlicAllocator::RemoveFreeBlock(BlockHeader* block) {
  int fli, sli;
  compute_fli_sli(block->size, fli, sli);
  RemoveFreeBlock(block, fli, sli);
}

void GarlicAllocator::RemoveBlock(BlockHeader* block) {
  auto prev_block = block->prev;
  auto next_block = block->next;
  if (prev_block) prev_block->next = next_block;
  if (next_block) next_block->prev = prev_block;
  FreeBlock(block);
}

GarlicAllocator::BlockHeader* GarlicAllocator::MergeFreeBlockAfter(BlockHeader* block) {
  auto next_block = block->next;
  if (next_block && next_block->is_free) {
    block->size += next_block->size;
    RemoveFreeBlock(next_block);
    RemoveBlock(next_block);
  }
  return block;
}

GarlicAllocator::BlockHeader* GarlicAllocator::MergeFreeBlockBefore(BlockHeader* block) {
  auto prev_block = block->prev;
  if (prev_block && prev_block->is_free) {
    block->ptr = prev_block->ptr;
    block->size += prev_block->size;
    RemoveFreeBlock(prev_block);
    RemoveBlock(prev_block);
  }
  return block;
}

extern "C" void ps4_mem_early_init() {
  if (!g_allocator) {
    new (&s_g_allocator) OnionAllocator(G_ALLOCATOR_SIZE, false);
    g_allocator = &s_g_allocator;
  }
}

extern "C" void ps4_mem_early_fini() {
  if (g_allocator) {
    g_allocator = nullptr;
    s_g_allocator.Finalize();
  }
}

void ps4_mem_init() {
  g_onion_allocator = new OnionAllocator(ONION_ALLOCATOR_SIZE, true);
  g_garlic_allocator = new GarlicAllocator(GARLIC_ALLOCATOR_SIZE);
}
