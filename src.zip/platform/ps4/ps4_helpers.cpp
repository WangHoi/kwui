#include "stdafx.h"
#include <stdio.h>
#include <kernel.h>
#include <sys/dirent.h>

void set_cursor_position(const Vector2& pos) {}
int64 get_frequency() {
  return (int64)sceKernelGetProcessTimeCounterFrequency();
}

int64 get_cycle_counter() {
  return (int64)sceKernelGetProcessTimeCounter();
}

double get_timestamp() {
  static double counter_time = 1.0 / get_frequency();
  return sceKernelGetProcessTimeCounter() * counter_time;
}

RtcTime get_rtc_time() {
  RtcTime t;
  SceRtcDateTime date_time;
  sceRtcGetCurrentClockLocalTime(&date_time);
  t.year = date_time.year;
  t.month = date_time.month;
  t.day = date_time.day;
  t.hour = date_time.hour;
  t.minute = date_time.minute;
  t.second = date_time.second;
  t.millisecond = date_time.microsecond / 1000;
  return t;
}

vector<String> platform_get_file_list(const String& path, bool recursive) {
  c2_log("[C2] WARN: get_file_list not implmented.\n");
  return vector<String>();
}

String get_clipboard_text() { return EMPTY_STRING; }
bool set_clipboard_text(const String&) { return false; }

extern "C" {
  char *getenv(const char *) { return nullptr; }
  char* tmpnam(char*) { return nullptr; }
  void unlink(const char*) {}
  FILE* tmpfile(const char*) { return nullptr; }
  int system(const char *) { return 0; }
  char *mktemp(char *) { return nullptr; }
}

void* platform_mmap(const char* fname, size_t size) {
  int fd = sceKernelOpen(fname, SCE_KERNEL_O_RDONLY, SCE_KERNEL_S_IRUSR);
  if (fd < 0) {
    c2_log("[C2] Unabled to open %s, error: %08x\n", fname, fd);
    return nullptr;
  }
  void* ptr = nullptr;
  int ret = sceKernelMmap(nullptr, size, SCE_KERNEL_PROT_CPU_READ,
                          SCE_KERNEL_MAP_PRIVATE, fd, 0, &ptr);
  if (ret != SCE_OK) {
    c2_log("[C2] mmap %s failed, error: %08x\n", fname, ret);
    return nullptr;
  }
  return ptr;
}

void platform_munmap(void* ptr) {}

int platform_fopen_read(const char* fname) {
  return sceKernelOpen(fname, SCE_KERNEL_O_RDONLY, SCE_KERNEL_S_IRUSR);
}
int platform_fclose(int fd) {
  return sceKernelClose(fd);
}
int platform_pread(int fd, void* buf, size_t size, off_t offset) {
  return sceKernelPread(fd, buf, size, offset);
}

int platform_mkdir(const char* dir) {
  return sceKernelMkdir(dir, SCE_KERNEL_S_IRWU);
}
