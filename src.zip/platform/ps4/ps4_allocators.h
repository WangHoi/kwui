//
//  Allocators.h
//  ShadowPlay
//
//  Created by hoi wang on 02-23-16
//
//
#ifndef PS4_ALLOCATORS_H
#define PS4_ALLOCATORS_H

#include "sce_headers.h"
#include "memory/IAllocator.h"
#include "memory/PoolAllocator.h"

class OnionAllocator : public IAllocator {
public:
  OnionAllocator() {}
  OnionAllocator(size_t size, bool gpu_writable);
  ~OnionAllocator();
  void* Alloc(size_t size, size_t align, const char* file, uint32 line) override;
  void Free(const void* ptr, size_t align, const char* file, uint32 line) override;
  void* Realloc(const void* ptr, size_t size, size_t align, const char* file, uint32 line) override;
  void GetStats(AllocatorStat* stats) override;
  SceLibcMspace GetHandle() const { return _mspace; }
  void Finalize();
private:
  size_t _size;
  off_t _dmem_offset;
  void* _addr;
  SceLibcMspace _mspace;
};

#define GARLIC_SLI 2
class GarlicAllocator : public IAllocator {
public:
  GarlicAllocator(size_t size);
  ~GarlicAllocator();
  void* Alloc(size_t size, size_t align, const char* file, uint32 line) override;
  void Free(const void* ptr, size_t align, const char* file, uint32 line) override;
  void* Realloc(const void* ptr, size_t size, size_t align, const char* file, uint32 line) override;
  void GetStats(AllocatorStat* stats) override;
private:
  struct BlockHeader;
  BlockHeader* AllocBlock();
  void FreeBlock(BlockHeader* block);
  void RemoveBlock(BlockHeader* block);

  void InsertFreeBlock(BlockHeader* block);
  BlockHeader* FindFreeBlock(size_t size, int* out_fli, int* out_sli);
  void RemoveFreeBlock(BlockHeader* block, int fli, int sli);
  void RemoveFreeBlock(BlockHeader* block);
  BlockHeader* MergeFreeBlockAfter(BlockHeader* block);
  BlockHeader* MergeFreeBlockBefore(BlockHeader* block);

  SpinLock _lock;
  size_t _size;
  size_t _used;
  size_t _peak_used;
  off_t _dmem_offset;
  void* _addr;
  struct BlockHeader {
    intptr_t ptr;
    size_t size;
    bool is_free;
    BlockHeader* prev;
    BlockHeader* next;
    BlockHeader* prev_free;
    BlockHeader* next_free;
  };
  unordered_map<intptr_t, BlockHeader*> _used_map;
  PoolAllocator _block_allocator;
  uint32 _fli_mask;
  uint32 _sli_mask[32];
  BlockHeader* _headers[32][(1 << GARLIC_SLI)];
};

extern "C" void ps4_mem_early_init();
extern "C" void ps4_mem_early_fini();
extern "C" SceLibcMspace get_g_allocator_handle();

void ps4_mem_init();

extern IAllocator* g_onion_allocator;
extern IAllocator* g_garlic_allocator;

#endif // PS4_ALLOCATORS_H
