#ifndef THREAD_H
#define THREAD_H

#include "platform_config.h"
#include "debug/C2Debug.h"
#include "data/C2Data.h"
#include "Semaphore.h"
#if ON_PS4
#include "ps4/sce_headers.h"
#endif
#include <atomic>

#ifndef _MANAGED
#include <thread>
using std::thread;
#endif

typedef std::atomic_int32_t atomic_int32;
typedef std::atomic_uint32_t atomic_uint32;
typedef std::atomic_int64_t atomic_int64;
typedef std::atomic_uint64_t atomic_uint64;
using std::atomic;
using std::atomic_size_t;
using std::atomic_bool;
using std::atomic_int;
using std::atomic_uint;
using std::atomic_long;
using std::atomic_ulong;
using std::atomic_flag;
using std::atomic_exchange;
using std::atomic_compare_exchange_strong;
using std::memory_order_relaxed;
using std::memory_order_consume;
using std::memory_order_acquire;
using std::memory_order_release;
using std::memory_order_acq_rel;
using std::memory_order_seq_cst;
using std::atomic_thread_fence;

typedef int32(*ThreadFn)(void* user_data);

class Thread {
public:
  Thread()
#if ON_WINDOWS
  : _handle(INVALID_HANDLE_VALUE), _thread_id(UINT32_MAX)
#elif ON_PS4
  : _handle(0), _thread_id(0)
#endif
  , _fn(NULL), _user_data(NULL), _stack_size(0), _exit_code(0), _running(false) {}
  virtual ~Thread() { if (_running) Shutdown(); }

  void Init(ThreadFn fn, void* user_data = NULL, uint32 stack_size = 0, const char* name = NULL, int core = -1) {
    c2_assert_return(!_running && "Already running!");

    _fn = fn;
    _user_data = user_data;
    _stack_size = stack_size;
    _running = true;

#if ON_WINDOWS
    _handle = CreateThread(NULL, _stack_size, threadFunc, this, 0, NULL);
#elif ON_PS4
    int ret = 0;
    ScePthreadAttr attr;
    scePthreadAttrInit(&attr);
    if (_stack_size > 0) {
      ret = scePthreadAttrSetstacksize(&attr, _stack_size);
      c2_assert(ret == SCE_OK);
    }
    ret = scePthreadCreate(&_handle, &attr, threadFunc, this, name);
    c2_assert(ret == SCE_OK);
    
    ret = scePthreadAttrDestroy(&attr);
    c2_assert(ret == SCE_OK);
#endif

    _sem.Wait();

    if (name) SetThreadName(name);
    if (core != -1) SetThreadCore(core);
  }

  void Shutdown() {
    c2_assert_return(_running && "Not running!");
#if ON_WINDOWS
    WaitForSingleObject(_handle, INFINITE);
    GetExitCodeThread(_handle, (DWORD*)&_exit_code);
    CloseHandle(_handle);
    _handle = INVALID_HANDLE_VALUE;
    _running = false;
#elif ON_PS4
    auto ret = scePthreadJoin(_handle, NULL);
    c2_assert(ret == SCE_OK);
#endif
  }
  bool IsRunning() const { return _running; }
  int32 GetExitCode() const { return _exit_code; }
  void SetThreadName(const char* _name) {
#if ON_WINDOWS
#  pragma pack(push, 8)
    struct ThreadName {
      DWORD  type;
      LPCSTR name;
      DWORD  id;
      DWORD  flags;
    };
#  pragma pack(pop)
    ThreadName tn;
    tn.type  = 0x1000;
    tn.name  = _name;
    tn.id    = _thread_id;
    tn.flags = 0;

    __try {
      RaiseException(0x406d1388, 0, sizeof(tn)/4, (ULONG_PTR*)&tn);
    } __except(EXCEPTION_EXECUTE_HANDLER) {
    }
#elif ON_PS4
#endif
  }
  void SetThreadCore(int core) {
#if ON_WINDOWS
    SetThreadIdealProcessor(_handle, core);
#endif
  }

private:
  Thread(const Thread&);
  Thread& operator =(const Thread&);

  int32 Entry() {
#if ON_WINDOWS
    _thread_id = ::GetCurrentThreadId();
#elif ON_PS4
    _thread_id = scePthreadGetthreadid();
#endif
    _sem.Post();
    return _fn(_user_data);
  }

#if ON_WINDOWS
  static DWORD WINAPI threadFunc(LPVOID arg) {
    Thread* thread = (Thread*)arg;
    int32 result = thread->Entry();
    return result;
  }
  HANDLE _handle;
  DWORD  _thread_id;

#elif ON_PS4
  static void* threadFunc(void* arg) {
    Thread* thread = (Thread*)arg;
    int32 result = thread->Entry();
    return (void*)ptrdiff_t(result);
  }
  ScePthread _handle;
  int _thread_id;
#endif

  ThreadFn _fn;
  void* _user_data;
  Semaphore _sem;
  uint32 _stack_size;
  int32 _exit_code;
  bool _running;
};

class TlsData {
public:
  TlsData() {
#if ON_WINDOWS
    _id = TlsAlloc();
    c2_assert_return(TLS_OUT_OF_INDEXES != _id && "Failed to allocated TLS index.");
#endif
  }

  ~TlsData() {
#if ON_WINDOWS
    BOOL result = TlsFree(_id);
    c2_assert_return(result && "Failed to free TLS index.");
#endif
  }

  void* Get() const {
#if ON_WINDOWS
    return TlsGetValue(_id);
#endif
    return nullptr;
  }
  void Set(void* ptr) {
#if ON_WINDOWS
    TlsSetValue(_id, ptr);
#endif
  }

private:
  uint32 _id;
};

class SpinLock {
public:
  SpinLock() {
#if ON_WINDOWS
    _flag.clear();
#endif
  }
  void Lock() { while (_flag.test_and_set(memory_order_acquire)); }
  void Unlock() { _flag.clear(memory_order_release); }
  bool TryLock() { return !_flag.test_and_set(memory_order_acquire); }
private:
  SpinLock(const SpinLock&) = delete;
#if ON_WINDOWS
  atomic_flag _flag;
#else
  atomic_flag _flag = ATOMIC_FLAG_INIT;
#endif
};

class SpinLockGuard {
public:
  SpinLockGuard(SpinLock* lock): _lock(lock) {
    _lock->Lock();
  }
  ~SpinLockGuard() {
    _lock->Unlock();
  }
private:
  SpinLock* _lock;
};
#endif
