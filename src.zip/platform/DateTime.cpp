#include "stdafx.h"
#include "DateTime.h"

#ifdef _MSC_VER
#pragma warning(disable:4996)
#endif

DateTime DateTime::Now() {
  std::time_t time = std::time(nullptr);
  DateTime date;
  memcpy(&date._tm, std::localtime(&time), sizeof(std::tm));
  return date;
}

String DateTime::ToString(StringFormat format) const {
  char buf[256];
  if (format == DateTime::DATE_STRING) snprintf(buf, sizeof(buf), "%04d-%02d-%02d", _tm.tm_year + 1900, _tm.tm_mon + 1, _tm.tm_mday);
  else if (format == DateTime::TIME_STRING) snprintf(buf, sizeof(buf), "%02d:%02d:%02d", _tm.tm_hour, _tm.tm_min, _tm.tm_sec);
  else snprintf(buf, sizeof(buf), "%04d-%02d-%02d %02d:%02d:%02d",
                _tm.tm_year + 1900, _tm.tm_mon + 1, _tm.tm_mday,
                _tm.tm_hour, _tm.tm_min, _tm.tm_sec);
  return String(buf);
}

int DateTime::GetYear() const {
  return _tm.tm_year + 1900;
}

int DateTime::GetMonth() const {
  return _tm.tm_mon;
}

int DateTime::GetDay() const {
  return _tm.tm_mday + 1;
}

int DateTime::GetHour() const {
  return _tm.tm_hour;
}

int DateTime::GetMinute() const {
  return _tm.tm_min;
}

int DateTime::GetSecond() const {
  return _tm.tm_sec;
}

DateTime::DateTime() {}
