//
//  C2Platform.h
//  C2Engine
//
//  Created by mike luo on 13-1-25.
//
//

#ifndef C2_PLATFORM_H
#define C2_PLATFORM_H

#include "platform/platform_config.h"
#include "platform/platform_helpers.h"
#include "platform/platform_data.h"
#include "platform/Semaphore.h"
#include "platform/Thread.h"
#include "platform/DateTime.h"

#endif // C2_PLATFORM_H
