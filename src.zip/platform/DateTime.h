//
//  DateTime.h
//  C2Engine
//
//  Created by hoi wang on 03-21-16
//
//
#ifndef DATE_TIME_H
#define DATE_TIME_H

#include "string/String.h"
#include <ctime>

class DateTime {
public:
  enum StringFormat {
    DATE_TIME_STRING,
    DATE_STRING,
    TIME_STRING,
  };
  static DateTime Now();
  String ToString(StringFormat format = DATE_TIME_STRING) const;
  int GetYear() const;
  int GetMonth() const;
  int GetDay() const;
  int GetHour() const;
  int GetMinute() const;
  int GetSecond() const;
private:
  DateTime();
  std::tm _tm;
};

#endif // DATE_TIME_H