#ifndef PLATFORM_HELPERS_H
#define PLATFORM_HELPERS_H

#include "data/data_type.h"
#include "data/data_helpers.h"
#include "string/String.h"
#include "platform_config.h"
#if ON_WINDOWS
#include <intrin.h>
#include "windows/windows_header.h"
#endif

#define KILOBYTE (1 << 10)
#define MEGABYTE (1 << 20)
#define GIGABYTE (1 << 30)

#ifndef CACHE_LINE_SIZE
#define CACHE_LINE_SIZE 64
#endif
#define DECLARE_ALIGN(_align) __declspec(align(_align))

struct RtcTime {
    int year;
    int month;
    int day;
    int hour;
    int minute;
    int second;
    int millisecond;
};

extern double get_timestamp();
extern int64 get_cycle_counter();
extern int64 get_frequency();
extern RtcTime get_rtc_time();

extern vector<String> platform_get_file_list(const String& path, bool recursive = false);

extern optional<String> get_clipboard_text();
extern bool set_clipboard_text(const String& text);

//extern void set_cursor_position(const Vector2& pos);
extern int platform_fopen_read(const char* fname);
extern int platform_fclose(int fd);
extern int platform_pread(int fd, void* buf, size_t size, off_t offset);
extern int platform_mkdir(const char* dir_path);

#if ON_WINDOWS

#define ALIGNOF(type) __alignof(type)

#define force_inline __forceinline
#define no_inline __declspec(noinline)
#define NO_VTABLE  __declspec(novtable)
/*
force_inline uint64 atomic_add_u64(volatile uint64 *value, uint64 to_add)
{
  // returns the original value _prior_ to adding
  return _InterlockedExchangeAdd64((__int64 *)value, to_add);
}

force_inline uint64 atomic_exchange_u64(volatile uint64 *target, uint64 value) {
  // returns the original value _prior_ to adding
  return _InterlockedExchange64((__int64 *)target, value);
}
*/
force_inline uint32 atomic_compare_exchange_u32(volatile uint32* value, uint32 new_value, uint32 expected_value) {
    return _InterlockedCompareExchange((long *)value, new_value, expected_value);
}

force_inline uint32 atomic_exchange_u32(volatile uint32* value, uint32 new_value) {
    return _InterlockedExchange((long *)value, new_value);
}

force_inline uint32 get_thread_id() {
    //return (uint32)__readfsdword(0x24);
    return GetCurrentThreadId();
}

void* platform_mmap(const char* fname, size_t size);
void platform_munmap(void* ptr);
String platform_choose_folder(HWND parent, const String &title);

#define platform_alloc(size) VirtualAlloc(0, size, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE)
#define platform_free(ptr) VirtualFree(ptr, 0, MEM_RELEASE)
//#define snprintf sprintf_s
#define sscanf sscanf_s
#define swprintf swprintf_s

#endif

// platform common macros
#define DECLARE_ALIGN_16 DECLARE_ALIGN(16)
#define DECLARE_ALIGN_CACHE_LINE DECLARE_ALIGN(CACHE_LINE_SIZE)

#endif // PLATFORM_HELPERS_H