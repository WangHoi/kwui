//
//  Semaphore.h
//  C2
//
//  Created by hoi wang on 09-29-15
//
//
#ifndef SEMAPHORE_H
#define SEMAPHORE_H

#include "platform_config.h"
#include "data/C2Data.h"

#if ON_WINDOWS
#define WIN32_LEAN_AND_MEAN
#include "Windows.h"
#elif ON_PS4
#include "ps4/sce_headers.h"
#endif

class Semaphore {
public:
  Semaphore() {
#if ON_WINDOWS
    _handle = CreateSemaphore(NULL, 0, LONG_MAX, NULL);
#elif ON_PS4
    auto ret = sceKernelCreateSema(&_handle, "sem", 0, 0, 65535, nullptr);
    c2_assert(ret == SCE_OK);
#endif
  }
  ~Semaphore() {
#if ON_WINDOWS
    CloseHandle(_handle);
#elif ON_PS4
    sceKernelDeleteSema(_handle);
#endif
  }
  void Post(uint32 count = 1) const {
#if ON_WINDOWS
    ReleaseSemaphore(_handle, count, NULL);
#elif ON_PS4
    sceKernelSignalSema(_handle, (int)count);
#endif
  }
  bool Wait(int32 msecs = -1) const {
#if ON_WINDOWS
    DWORD milliseconds = (0 > msecs) ? INFINITE : msecs;
    return WAIT_OBJECT_0 == WaitForSingleObject(_handle, milliseconds);
#elif ON_PS4
    if (msecs == -1) return sceKernelWaitSema(_handle, 1, nullptr) == SCE_OK; 
    else {
      SceKernelUseconds usecs = msecs * 1000;
      return sceKernelWaitSema(_handle, 1, &usecs) == SCE_OK;
    }
#else
    return false;
#endif
  }

private:
  Semaphore(const Semaphore&);
  Semaphore& operator =(const Semaphore&);
#if ON_WINDOWS
  HANDLE _handle;
#elif ON_PS4
  SceKernelSema _handle;
#endif
};

#endif // SEMAPHORE_H