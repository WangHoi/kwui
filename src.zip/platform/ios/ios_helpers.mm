//
//  ios_helpers.cpp
//  C2Engine
//
//  Created by mike luo on 13-1-25.
//
//

#include "platform/platform_helpers.h"

#import <Foundation/Foundation.h>
#import <mach/mach_time.h>

static double get_frequency() {
  mach_timebase_info_data_t timebase;
  mach_timebase_info(&timebase);
  return 1e9 * timebase.denom / timebase.numer;
}

double get_timestamp() {
  static double counter_time = 1.0 / get_frequency();
  uint64_t counter = mach_absolute_time();
  return counter * counter_time;
}

vector<Name> get_file_list(const Name& path, bool recursive) {
  // TODO
  return {};
}

Name get_resource_path() {
  return Name{[[[NSBundle mainBundle] resourcePath] UTF8String]};
}

Name get_archive_path() {
  NSArray* paths = NSSearchPathForDirectoriesInDomains(NSLibraryDirectory, NSUserDomainMask, YES);
  return Name{[[paths objectAtIndex:0] UTF8String]};
}

Name get_document_path() {
  NSArray* paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
  return Name{[[paths objectAtIndex:0] UTF8String]};
}