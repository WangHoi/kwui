#include "platform/platform_config.h"
#include "debug/log.h"

#if ON_WINDOWS

#include "platform/windows/windows_header.h"
#include "platform/platform_helpers.h"
#include "data/data_type.h"
#include "text/EncodingManager.h"
#include <io.h>
#include <stdio.h>
#include <fcntl.h>
#include <direct.h>
#include <sys/types.h>
#include <sys/stat.h>

int64 get_frequency() {
    LARGE_INTEGER frequency;
    QueryPerformanceFrequency(&frequency);
    return frequency.QuadPart;
}

int64 get_cycle_counter() {
    LARGE_INTEGER counter;
    QueryPerformanceCounter(&counter);
    return counter.QuadPart;
}

double get_timestamp() {
    static double counter_time = 1.0 / get_frequency();
    LARGE_INTEGER counter;
    QueryPerformanceCounter(&counter);
    return counter.QuadPart * counter_time;
}

RtcTime get_rtc_time() {
    SYSTEMTIME t;
    GetLocalTime(&t);
    return RtcTime{ t.wYear, t.wMonth, t.wDay, t.wHour, t.wMinute, t.wSecond, t.wMilliseconds };
}

static void s_get_file_list_append(const string& path_system, const string& prefix_system, bool recursive, vector<String>* list_out) {
    auto EM = EncodingManager::Instance();
    WIN32_FIND_DATAA find_data;
    HANDLE handle = FindFirstFileA((path_system + "*").c_str(), &find_data);
    if (handle == INVALID_HANDLE_VALUE) return;
    do {
        if (!(find_data.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)) {
            list_out->emplace_back(EM->SystemToUTF8(prefix_system + find_data.cFileName));
        } else if (recursive) {
            auto dir_name = find_data.cFileName;
            if (strcmp(dir_name, ".") && strcmp(dir_name, "..")) {
                s_get_file_list_append(path_system + dir_name + "/", prefix_system + dir_name + "/", true, list_out);
            }
        }
    } while (FindNextFileA(handle, &find_data));
}

vector<String> platform_get_file_list(const String& path, bool recursive) {
    vector<String> list;
    s_get_file_list_append(EncodingManager::Instance()->UTF8ToSystem(path + "/").GetString(), string(), recursive, &list);
    return list;
}

optional<String> get_clipboard_text() {
    if (!OpenClipboard(nullptr)) return nullopt;

    // Get handle of clipboard object for ANSI text
    HANDLE hData = GetClipboardData(CF_UNICODETEXT);
    if (hData == nullptr) return nullopt;

    // Lock the handle to get the actual text pointer
    wchar_t* pszText = static_cast<wchar_t*>(GlobalLock(hData));
    if (pszText == nullptr) {
        CloseClipboard();
        return nullopt;
    }

    // Save text in a string class instance
    String text = EncodingManager::Instance()->WideToUTF8(pszText);

    // Release the lock
    GlobalUnlock(hData);

    // Release the clipboard
    CloseClipboard();

    return text;
}

bool set_clipboard_text(const String& text) {
    wstring text_system = EncodingManager::Instance()->UTF8ToWide(text);
    size_t text_length = text_system.length();
    HGLOBAL global_memory = GlobalAlloc(GMEM_MOVEABLE, (text_length + 1) * sizeof(wchar_t));
    if (!global_memory) return false;

    char* global_data = (char*)GlobalLock(global_memory);
    memcpy(global_data, text_system.data(), (text_length + 1) * sizeof(wchar_t));
    GlobalUnlock(global_memory);

    OpenClipboard(nullptr);
    EmptyClipboard();
    SetClipboardData(CF_UNICODETEXT, global_memory);
    CloseClipboard();

    return true;
}
/*
void set_cursor_position(const Vector2& pos) {
    auto MM = CursorManager::Instance();
    if (!MM->IsActive()) return;
    auto HWND = GetActiveWindow();
    RECT rect;
    GetClientRect(HWND, &rect);
    auto win_pos = Vector2(float(rect.right), float(rect.bottom)) * Vector2(clamp(pos.x, 0.f, 1.f), clamp(1 - pos.y, 0.f, 1.f));
    POINT p{ (int)win_pos.x, (int)win_pos.y };
    ClientToScreen(HWND, &p);
    SetCursorPos(p.x, p.y);
}
*/
void* platform_mmap(const char* fname, size_t size) {
    HANDLE hMapFile;      // handle for the file's memory-mapped region
    HANDLE hFile;         // the file handle
    DWORD dwFileMapSize;  // size of the file mapping
    DWORD dwMapViewSize;  // the size of the view
    DWORD dwFileMapStart; // where to start the file map view
    DWORD dwSysGran;      // system allocation granularity
    SYSTEM_INFO SysInfo;  // system information; used to get granularity
    LPVOID lpMapAddress;  // pointer to the base address of the
    //shows up

    // Create the test file. Open it "Create Always" to overwrite any
    // existing file. The data is re-created below
    hFile = CreateFileA(fname,
                       GENERIC_READ,
                       0,
                       NULL,
                       OPEN_EXISTING,
                       FILE_ATTRIBUTE_NORMAL,
                       NULL);

    if (hFile == INVALID_HANDLE_VALUE) {
        c2_log("Target file is null: %s\n", fname);
        return nullptr;
    }

    // Get the system allocation granularity.
    GetSystemInfo(&SysInfo);
    dwSysGran = SysInfo.dwAllocationGranularity;

    // Now calculate a few variables. Calculate the file offsets as
    // 64-bit values, and then get the low-order 32 bits for the
    // function calls.

    // To calculate where to start the file mapping, round down the
    // offset of the data into the file to the nearest multiple of the
    // system allocation granularity.
    dwFileMapStart = 0;

    // Calculate the size of the file mapping view.
    dwMapViewSize = size;

    // How large will the file mapping object be?
    dwFileMapSize = size;

    // Create a file mapping object for the file
    // Note that it is a good idea to ensure the file size is not zero
    hMapFile = CreateFileMapping(hFile,          // current file handle
                                 NULL,           // default security
                                 PAGE_READONLY,  // read permission
                                 0,              // size of mapping object, high
                                 dwFileMapSize,  // size of mapping object, low
                                 NULL);          // name of mapping object

    if (hMapFile == NULL) {
        c2_log("hMapFile is NULL: last error: %d\n", GetLastError());
        return nullptr;
    }

    // Map the view and test the results.

    lpMapAddress = MapViewOfFile(hMapFile,            // handle to
                                 // mapping object
                                 FILE_MAP_READ, // read/write
                                 0,                   // high-order 32
                                 // bits of file
                                 // offset
                                 dwFileMapStart,      // low-order 32
                                 // bits of file
                                 // offset
                                 dwMapViewSize);      // number of bytes
    // to map
    if (lpMapAddress == NULL) {
        c2_log("lpMapAddress is NULL: last error: %d\n", GetLastError());
        return nullptr;
    }

    return lpMapAddress;
}

void platform_munmap(void* ptr) {
#if 0
    BOOL bFlag;
    bFlag = UnmapViewOfFile(lpMapAddress);
    bFlag = CloseHandle(hMapFile); // close the file mapping object

    if (!bFlag) {
        _tprintf(TEXT("\nError %ld occurred closing the mapping object!"),
                 GetLastError());
    }

    bFlag = CloseHandle(hFile);   // close the file itself

    if (!bFlag) {
        _tprintf(TEXT("\nError %ld occurred closing the file!"),
                 GetLastError());
    }

    return 0;
#endif
}

int platform_fopen_read(const char* fname) {
    int fd = -1;
    _sopen_s(&fd, fname, _O_RDONLY | _O_BINARY, _SH_DENYRD, _S_IREAD);
    return fd;
}

int platform_fclose(int fd) {
    return _close(fd);
}

int platform_mkdir(const char* dir) {
    return _mkdir(dir);
}

struct CriticalSectionBlock {
    CRITICAL_SECTION _cs;

    CriticalSectionBlock() {
        InitializeCriticalSection(&_cs);
        EnterCriticalSection(&_cs);
    }
    ~CriticalSectionBlock() {
        LeaveCriticalSection(&_cs);
        DeleteCriticalSection(&_cs);
    }
};

int platform_pread(int fd, void* buf, size_t size, off_t offset) {
    CriticalSectionBlock block;
    _lseek(fd, offset, SEEK_SET);
    return _read(fd, buf, size);
}

String platform_choose_folder(HWND parent, const String& title) {
    auto EM = EncodingManager::Instance();
    wstring utf16_title = EM->UTF8ToWide(title);
    PIDLIST_ABSOLUTE pid_list;
    BROWSEINFOW info = {};
    WCHAR path[MAX_PATH + 1] = {};
    info.hwndOwner = parent;
    info.lpszTitle = utf16_title.c_str();
    //info.ulFlags = BIF_RETURNONLYFSDIRS | BIF_DONTGOBELOWDOMAIN;
    pid_list = SHBrowseForFolderW(&info);
    if (SHGetPathFromIDListW(pid_list, path)) {
        return EM->WideToUTF8(path);
    } else {
        return String();
    }
}

#endif // ON_WINDOWS