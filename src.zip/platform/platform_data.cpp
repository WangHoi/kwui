#include "platform_data.h"

PlatformData g_platform_data = {};
