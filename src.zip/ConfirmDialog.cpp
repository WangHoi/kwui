#include "ConfirmDialog.h"
#include "theme.h"
#include "ui/ButtonNode.h"
#include "ui/ImageButtonNode.h"
#include "ui/ImageNode.h"
#include "ui/LabelNode.h"
#include "ui/TextEditNode.h"
#include "pattern/callback.h"
#include "platform/platform_helpers.h"

ConfirmDialog::ConfirmDialog(optional<CreateData> create_data)
	: Dialog(theme::CONFIRM_DIALOG_WIDTH, theme::CONFIRM_DIALOG_HEIGHT,
			 L"ConfirmDialog", NULL, DIALOG_FLAG_POPUP,
			 PopupShadowData{
				 theme::DIALOG_SHADOW_PNG,
				 (int)theme::DIALOG_SHADOW_MARGIN_PIXELS,
			 },
             create_data) {}

void ConfirmDialog::SetupUi(const ConfirmDialogUiConfig& data) {
	_config = data;
	SetTitle(data.title_text);

	Node2D* root = GetRoot();

	auto label = make_shared<LabelNode>();
	label->SetText(data.label_text);
	label->SetFontSize(theme::H3_FONT_SIZE);
	label->SetColor(theme::H2_TEXT_COLOR);
	label->SetAutoSize(false);
	label->SetAlignment(TEXT_ALIGN_CENTER);
	label->SetOrigin({ 36, 80 });
	label->SetSize({ 288, 48 });
	root->AddChild(label);

	if (data.action_btn_text.has_value()) {
		auto action_btn = MakeActionButton(*data.action_btn_text);
		action_btn->SetOrigin({ 180, 172 });
		action_btn->SetSize({ 76, 32 });
		action_btn->SetClickedCallback(MakeCallback(this, &ConfirmDialog::ActionButtonClicked));
		root->AddChild(action_btn);
	}

	if (data.cancel_btn_text.has_value()) {
		if (data.action_btn_text.has_value()) {
			auto cancel_btn = MakeBorderButton(*data.cancel_btn_text);
			cancel_btn->SetSize({ 76, 32 });
			cancel_btn->SetClickedCallback(MakeCallback(this, &ConfirmDialog::CancelButtonClicked));
			cancel_btn->SetOrigin({ 270, 172 });
			root->AddChild(cancel_btn);
		} else {
			auto action_btn = MakeActionButton(*data.cancel_btn_text);
			action_btn->SetOrigin({ 142, 172 });
			action_btn->SetSize({ 76, 32 });
			action_btn->SetClickedCallback(MakeCallback(this, &ConfirmDialog::CancelButtonClicked));
			root->AddChild(action_btn);
		}
	}

	if (data.skip_btn_text.has_value()) {
		auto skip_btn = MakeBorderButton(*data.skip_btn_text);
		skip_btn->SetOrigin({ 18, 172 });
		skip_btn->SetSize({ 76, 32 });
		skip_btn->SetClickedCallback(MakeCallback(this, &ConfirmDialog::SkipButtonClicked));
		root->AddChild(skip_btn);
	}
}
void ConfirmDialog::OnDestroy() {
	Dialog::OnDestroy();
}
void ConfirmDialog::ActionButtonClicked(EventContext& ctx) {
	Close();
	if (_action_clicked_callback)
		_action_clicked_callback(ctx);
}
void ConfirmDialog::CancelButtonClicked(EventContext& ctx) {
	Dialog::OnCloseButtonClicked(ctx);
	if (_cancel_clicked_callback)
		_cancel_clicked_callback(ctx);
}
void ConfirmDialog::SkipButtonClicked(EventContext& ctx) {
	Close();
	if (_skip_clicked_callback)
		_skip_clicked_callback(ctx);
}
ButtonNodeRef ConfirmDialog::MakeActionButton(const String& text) {
	auto btn = make_shared<ButtonNode>();
	btn->SetBackgroundColor(theme::ACTION_COLOR,
							theme::ACTION_HOVERED_COLOR);
	btn->SetColor(theme::ACTION_TEXT_COLOR);
	btn->SetAutoSize(false);
	btn->SetBorderRadius(theme::SECONDARY_BORDER_RADIUS);
	btn->SetFontSize(theme::H3_FONT_SIZE);
	btn->SetText(text);
	return btn;
}
ButtonNodeRef ConfirmDialog::MakeBorderButton(const String& text) {
	auto btn = make_shared<ButtonNode>();
	btn->SetBackgroundColor(NO_COLOR,
							theme::BORDER_COLOR);
	btn->SetColor(theme::H3_TEXT_COLOR);
	btn->SetAutoSize(false);
	btn->SetBorderStyle(theme::BORDER_COLOR, 2);
	btn->SetBorderRadius(theme::SECONDARY_BORDER_RADIUS);
	btn->SetFontSize(theme::H3_FONT_SIZE);
	btn->SetText(text);
	return btn;
}
void ConfirmDialog::OnCloseButtonClicked(EventContext& ctx) {
    CancelButtonClicked(ctx);
}
void ConfirmDialog::OnEnterKeyDown(EventContext& ctx) {
	if (_config.action_btn_text.has_value())
		ActionButtonClicked(ctx);
	else
		CancelButtonClicked(ctx);
}
void ConfirmDialog::OnEscapeKeyDown(EventContext& ctx) {
    CancelButtonClicked(ctx);
}
