#ifndef DIALOG_H
#define DIALOG_H

#include "platform/platform_config.h"
#include "platform/windows/windows_header.h"
#include "memory/memory_helpers.h"
#include "math/Vector2.h"
#include "ui/Node2D.h"
#include "ui/LabelNode.h"
#include "ui/ImageButtonNode.h"
#include "string/String.h"
#include "pattern/callback.h"
#include "PopupShadow.h"

enum DialogFlag {
	DIALOG_FLAG_MAIN = 1,
	DIALOG_FLAG_POPUP = 2,
};

SMART_REF(Dialog)
class Dialog : public EventContext {
public:
    struct CreateData {
        float dpi_scale;
        HMONITOR monitor;
    };
    Dialog(float width, float height,
		   const WCHAR* wnd_class_name, HICON icon, int flags,
		   optional<PopupShadowData> popup_shadow,
           optional<CreateData> create_data);
    virtual ~Dialog();

	inline void SetParent(HWND parent) { _hwnd_parent = parent; }
	inline void SetParent(Dialog* parent) { SetParent(parent->_hwnd); }
	inline void Show() {
        SetVisible(true);
    }
    inline void Hide() {
        SetVisible(false);
    }
    void SetVisible(bool visible);
    inline bool IsVisible() const {
        return _visible;
    }
    void Resize(float width, float height);
	void SetTitle(const String& text);
	Node2D* GetRoot() const { return _root.get(); }
	const Vector2& GetSize() const { return _size; }
    inline float GetDpiScale() const { return _dpi_scale; }
	HWND GetHwnd() const { return _hwnd; }
	void Close();

    // implements EventContext
    Vector2 GetMousePosition() const override { return _mouse_position; }
    void RequestPaint() override;
	void RequestUpdate() override;
    void RequestAnimationFrame(Node2D* node) override;

	virtual void OnCloseButtonClicked(EventContext& ctx);
	virtual void OnDestroy();
	virtual void OnActivate(bool active);
	virtual void OnWindowPosChanged(WINDOWPOS* wnd_pos);
	virtual void DiscardDeviceResources();
    virtual void OnEnterKeyDown(EventContext& ctx) {}
    virtual void OnEnterKeyUp(EventContext& ctx) {}
    virtual void OnEscapeKeyDown(EventContext& ctx) {}
    virtual void OnEscapeKeyUp(EventContext& ctx) {}

private:
    void InitWindow(HINSTANCE hInstance, const WCHAR* wnd_class_name, HICON icon);
    static LRESULT CALLBACK WndProcMain(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);
    LRESULT WindowProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);

	void OnCreate();
    void OnPaint();
    void OnResize();
    void OnKeyDown(int key, int modifiers, bool prev_down = true);
    void OnKeyUp(int key, int modifiers);
    void OnCharacter(wchar_t ch);
	void OnImeCommit(const wstring& text);
	void OnImeStartComposition();
	void OnImeComposition(const wstring& text, optional<int> caret_pos);
	void OnImeEndComposition();
	void UpdateCaretRect(const Vector2& origin, const Vector2& size);
    void OnMouseDown(ButtonState button, int buttons, int modifiers);
    void OnMouseUp(ButtonState button, int buttons, int modifiers);
    void OnMouseMove(int buttons, int modifiers);
    void PaintNode(Painter& p, Node2D* node);
    void UpdateHoveredNode();
    void UpdateFocusedNode();
	void UpdateMouseTracking();
	void RecreateRenderTarget();
	void OnDpiChanged(UINT dpi, const RECT* rect);
    Node2D* PickNode(Node2D* node, const Vector2& pos, int flag_mask, Vector2* out_local_pos = nullptr);
    Node2D* PickSelf(Node2D* node, const Vector2& pos, int flag_mask, Vector2* out_local_pos);
	void DiscardNodeDeviceResources(Node2D* node);
	void UpdateBorderAndRenderTarget();
    void OnAnimationTimerEvent();

    HWND _hwnd_parent;
    HWND _hwnd;
	int _flags;
    optional<CreateData> _create_data;
    bool _visible;
    bool _first_show_window;
    Vector2 _size;
	Vector2 _pixel_size;
    Vector2 _mouse_position;
    ComPtr<ID2D1HwndRenderTarget> _rt;
    Node2DRef _root;
	LabelNodeRef _title_label;
	ImageButtonNodeRef _close_button;
    Node2DLink _hovered_node;   // under mouse node
    Node2DLink _focused_node;
	bool _mouse_event_tracking;
	bool _mouse_capture;
	optional<PopupShadowData> _popup_shadow_data;
	PopupShadowRef _popup_shadow;
	bool _on_window_pos_changed;
	float _dpi_scale;
	HIMC _himc;
    vector<Node2DLink>  _animating_nodes;
    UINT_PTR _animation_timer_id;
};

#endif // DIALOG_H