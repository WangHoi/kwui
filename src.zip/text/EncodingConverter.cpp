#include "EncodingConverter.h"

#if !ON_WINDOWS
const int EncodingConverter::BLOCK_SIZE = 128;

EncodingConverter::EncodingConverter(Encoding from, Encoding to)
    : _from(from), _to(to), _block(BLOCK_SIZE) {
#if !ON_WINDOWS
    _descriptor = iconv_open(ENCODING_NAMES[to], ENCODING_NAMES[from]);
#endif
}

EncodingConverter::~EncodingConverter() {
#if !ON_WINDOWS
    if (_descriptor) {
        iconv_close(_descriptor);
        _descriptor = nullptr;
    }
#endif
}

String EncodingConverter::Convert(const String& text) const {
#if ON_WINDOWS
    return text;
#else
    String result;
    const char* in = text.GetCString();
    size_t in_remains = text.GetLength();

    lock_guard<mutex> lock(_mutex);

    do {
        char* out = _block.data();
        size_t out_remains = BLOCK_SIZE;
        int r = iconv(_descriptor, &in, &in_remains, &out, &out_remains);
        if (out_remains == BLOCK_SIZE) break;
        result.Append(_block.data(), BLOCK_SIZE - out_remains);
        if (r == 0) break;
    } while (true);

    return result;
#endif
}
#endif