//
//  string_io.h
//  C2Engine
//
//  Created by mike luo on 13-1-25.
//
//

#ifndef STRING_IO_H
#define STRING_IO_H

#include "data/data_helpers.h"

class Matrix4;

bool fetch_string(const char*& buf, string& s);
bool fetch_float(const char*& buf, float& x);
bool fetch_integer(const char*& buf, int& x);
bool fetch_matrix(const char*& buf, Matrix4& matrix);

#endif // STRING_IO_H
