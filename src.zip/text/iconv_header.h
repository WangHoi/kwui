//
//  iconv_header.h
//  C2Engine
//
//  Created by mike luo on 13-10-17.
//
//

#ifndef ICONV_HEADER_H
#define ICONV_HEADER_H

#if ON_WINDOWS
#include <iconv.h>
#endif
#include "platform/platform_config.h"

#if ON_IOS
inline size_t iconv(iconv_t cd, const char** inbuf,  size_t* inbytesleft, char** outbuf, size_t* outbytesleft) {
  return iconv(cd, (char**) inbuf, inbytesleft, outbuf, outbytesleft);
}
#endif

#endif // ICONV_HEADER_H
