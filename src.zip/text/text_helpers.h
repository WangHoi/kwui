//
//  text_helpers.h
//  C2Engine
//
//  Created by mike luo on 13-1-25.
//
//
#ifndef TEXT_HELPERS_H
#define TEXT_HELPERS_H

#include <string>
#include <string.h>
#include <stdio.h>

#include "platform/platform_config.h"

using std::string;
using std::to_string;

inline bool string_equal(const char* s1, const char* s2) {
#if ON_WINDOWS
  return _stricmp(s1, s2) == 0;
#else
  return strcasecmp(s1, s2) == 0;
#endif
}

inline bool string_start_with(const string& s1, const string& s2) {
  return s1.compare(0, s2.length(), s2) == 0;
}

#if ON_WINDOWS
#pragma warning(disable:4996) // for Visual Studio
#endif

#endif // TEXT_HELPERS_H