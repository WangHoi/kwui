#ifndef ENCODING_HELPERS_H
#define ENCODING_HELPERS_H

#include "data/data_helpers.h"
#include "data/data_type.h"
#include "math/bit_arithmetics.h"

char32 fetch_unicode_utf8(const char8*& s);
int get_code_width_utf8(const char8* s);
int string_length_utf8(const char8* s);
int put_unicode(char8* s, char32 code);
int put_unicode(char16* s, char32 code);

bool is_surrogate(char16 ch);
bool is_high_surrogate(char16 ch);
bool is_low_surrogate(char16 ch);

#endif // ENCODING_HELPERS_H