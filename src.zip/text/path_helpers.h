//
//  path_helpers.h
//  C2Engine
//
//  Created by mike luo on 2013-9-17.
//
//

#ifndef PATH_HELPERS_H
#define PATH_HELPERS_H

#include "data/data_helpers.h"

String get_basename(const String& path);

#endif // PATH_HELPERS_H