//
//  string_io.cpp
//  C2Engine
//
//  Created by mike luo on 13-1-25.
//
//
#include "stdafx.h"
#include "text/string_io.h"

#include "math/Matrix4.h"
#include "data/data_type.h"
#include <ctype.h>

bool fetch_string(const char*& buf_, string& s) {
  auto buf = (const uchar*) buf_;
  while ((uint8)isspace((uint8)*buf)) buf++;
  if (!*buf) return false;
  auto start = buf;
  while (*buf && !isspace((uint8)*buf)) buf++;
  s.assign(start, buf);
  buf_ = (const char*) buf;
  return true;
}

bool fetch_float(const char*& buf_, float& x) {
  auto buf = (const uchar*) buf_;
  while (isspace((uint8)*buf)) buf++;
  bool negative = false;
  if (*buf == '-') {
    negative = true;
    buf++;
  }
  if (!isdigit((uint8)*buf)) return false;
  x = (float) (*buf - '0');
  buf++;
  while (isdigit((uint8)*buf)) {
    x = x * 10 + (*buf - '0');
    buf++;
  }
  if (*buf == '.') {
    buf++;
    float base = 1.0f;
    while (isdigit((uint8)*buf)) {
      base *= 0.1f;
      x += base * (*buf - '0');
      buf++;
    }
  }
  if (*buf == 'e' || *buf == 'E') {
    buf++;
    int exp;
    if (!fetch_integer((const char*&) buf, exp)) return false;
    x *= powf(10.0f, (float) exp);
  }
  if (negative) x = -x;
  buf_ = (const char*) buf;
  return true;
}

bool fetch_integer(const char*& buf_, int& x) {
  auto buf = (const uchar*) buf_;
  while (isspace((uint8)*buf)) buf++;
  bool negative = false;
  if (*buf == '-') {
    negative = true;
    buf++;
  }
  if (!isdigit((uint8)*buf)) return false;
  x = *buf - '0';
  buf++;
  while (isdigit((uint8)*buf)) {
    x = x * 10 + (*buf - '0');
    buf++;
  }
  if (negative) x = -x;
  buf_ = (const char*) buf;
  return true;
}

bool fetch_matrix(const char*& buf_, Matrix4& matrix) {
  auto buf = buf_;
  auto b = matrix.GetBuffer();
  for (int i = 0; i < 16; i++) {
    if (!fetch_float(buf, b[i])) return false;
  }
  buf_ = buf;
  return true;
}

/***** test *****/
#include "debug/debug_print.h"

class StringIOUnitTest {
public:
  StringIOUnitTest() {
    const char* content = "  -1  8 9   100 1289234   7277  -82  -191    \n-23 0.200976 9.8 -10.7 -0.00001 -";
    const char* buf = content;
    int i;
    while (fetch_integer(buf, i)) debug_print("%d ", i);
    debug_print("\n");
    float f;
    buf = content;
    while (fetch_float(buf, f)) debug_print("%g ", f);
    debug_print("\n");
    buf = content;
    string s;
    while (fetch_string(buf, s)) debug_print("%s ", s.c_str());
    debug_print("\n");
  }
};

// static StringIOUnitTest test;