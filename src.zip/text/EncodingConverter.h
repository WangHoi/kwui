#ifndef ENCODING_CONVERTER_H
#define ENCODING_CONVERTER_H

#include "platform/platform_config.h"
#if !ON_WINDOWS
#include "iconv_header.h"

#include "EncodingName.h"
#include "data/data_helpers.h"
#include "data/data_type.h"
#include "thread/thread_helpers.h"
#include "memory/memory_helpers.h"
#include "string/String.h"

SMART_REF(EncodingConverter);

class EncodingConverter {
public:
    EncodingConverter(Encoding from, Encoding to);
    ~EncodingConverter();
    String Convert(const String& text) const;
private:
    static const int BLOCK_SIZE;
    const Encoding _from, _to;
    mutable vector<char> _block;
    mutable mutex _mutex;
#if !ON_WINDOWS
    iconv_t _descriptor;
#endif
};
#endif

#endif // ENCODING_CONVERTER_H