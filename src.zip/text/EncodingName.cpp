//
//  EncodingName.cpp
//  C2Engine
//
//  Created by mike luo on 2013-9-27.
//
//

#include "stdafx.h"
#include "EncodingName.h"

const char* ENCODING_NAMES[ENCODING_COUNT] = {
  "GBK", "UTF-8"
};