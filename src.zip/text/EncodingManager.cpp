#include "EncodingManager.h"
#include "platform/windows/windows_header.h"

DEFINE_SINGLETON_INSTANCE(EncodingManager);

#if ON_WINDOWS
static String WideToCodePage(const wstring& text, UINT cp) {
	int utf8_size = ::WideCharToMultiByte(cp, 0,
										  text.data(), (int)text.length(),
										  NULL, 0, NULL, NULL);
	if (utf8_size <= 0)
		return String();
	String str;
	str.Resize(utf8_size);
	::WideCharToMultiByte(cp, 0,
						  text.data(), (int)text.length(),
						  &str[0], str.GetLength(), NULL, NULL);
	return str;
}
static wstring CodePageToWide(const String& text, UINT cp) {
	int wchar_size = ::MultiByteToWideChar(
		cp, 0, text.GetCString(), (int)text.GetLength(), NULL, 0);
	if (wchar_size <= 0)
		return wstring();
	wstring wstr;
	wstr.resize(wchar_size);
	::MultiByteToWideChar(cp,
						  0,
						  text.GetCString(),
						  (int)text.GetLength(),
						  &wstr[0],
						  wchar_size);
	return wstr;
}
#else
String EncodingManager::Convert(const String& text, Encoding from, Encoding to) {
    if (from == to) return text;

    const EncodingConverter* converter = nullptr;
    {
        FromTo from_to = { from, to };
        lock_guard<mutex> lock(_mutex);
        auto iter = _converters.find(from_to);
        if (iter == _converters.end()) {
            EncodingConverterHandleConst c(new EncodingConverter(from, to));
            converter = c.get();
            _converters.emplace(move(from_to), move(c));
        } else {
            converter = iter->second.get();
        }
    }

    return converter->Convert(text);
}
#endif
String EncodingManager::UTF8ToSystem(const String& text) {
#if ON_WINDOWS
	UINT code_page = GetACP();
	if (code_page == CP_UTF8)
		return text;
	return WideToCodePage(UTF8ToWide(text), code_page);
#else
	return Convert(text, UTF_8, SYSTEM_ENCODING);
#endif
}
String EncodingManager::SystemToUTF8(const String& text) {
#if ON_WINDOWS
	UINT code_page = GetACP();
	if (code_page == CP_UTF8)
		return text;
	return WideToUTF8(CodePageToWide(text, code_page));
#else
	return Convert(text, SYSTEM_ENCODING, UTF_8);
#endif
}
#if ON_WINDOWS
wstring EncodingManager::UTF8ToWide(const String& text) {
	return CodePageToWide(text, CP_UTF8);
}
String EncodingManager::WideToUTF8(const wstring& text) {
    return WideToCodePage(text, CP_UTF8);
}
#endif
