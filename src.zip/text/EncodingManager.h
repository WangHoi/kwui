﻿//
//  EncodingManager.h
//  C2Engine
//
//  Created by mike luo on 2013-9-27.
//
//
#ifndef ENCODING_MANAGER_H
#define ENCODING_MANAGER_H

#include "EncodingConverter.h"
#include "data/data_helpers.h"
#include "thread/thread_helpers.h"
#include "pattern/singleton.h"
#include "platform/platform_config.h"
#include "string/String.h"

class EncodingManager {
public:
	String UTF8ToSystem(const String& text);
	String SystemToUTF8(const String& text);
#if ON_WINDOWS
    wstring UTF8ToWide(const String& text);
    String WideToUTF8(const wstring& text);
#else
	String Convert(const String& text, Encoding from, Encoding to);
	struct FromTo {
        Encoding from, to;
        bool operator==(const FromTo& p) const { return from == p.from && to == p.to; }
        struct Hash {
            inline size_t operator ()(const FromTo& p) const {
                return p.from + p.to * ENCODING_COUNT;
            }
        };
    };
private:
    unordered_map<FromTo, EncodingConverterHandleConst, FromTo::Hash> _converters;

    mutex _mutex;
#endif
    SUPPORT_SINGLETON(EncodingManager);
};

#endif // ENCODING_MANAGER_H