//
//  path_helpers.cpp
//  C2Engine
//
//  Created by mike luo on 2013-9-17.
//
//

#include "stdafx.h"
#include "path_helpers.h"

String get_basename(const String& path) {
  const char* s = path.GetCString();
  for (int i = path.GetLength() - 1; i >= 0; i--) {
    if (s[i] == '\\' || s[i] == '/') return String(s + i + 1);
  }
  return path;
}
