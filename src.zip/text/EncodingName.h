//
//  EncodingName.h
//  C2Engine
//
//  Created by mike luo on 2013-9-27.
//
//

#ifndef ENCODING_NAME_H
#define ENCODING_NAME_H

enum Encoding {
    GBK,
    UTF_8,
    ENCODING_COUNT
};

extern const char* ENCODING_NAMES[ENCODING_COUNT];

#endif // ENCODING_NAME_H