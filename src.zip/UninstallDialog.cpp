#include "UninstallDialog.h"
#include "theme.h"
#include "ui/ButtonNode.h"
#include "ui/ImageButtonNode.h"
#include "ui/ImageNode.h"
#include "ui/LabelNode.h"
#include "ui/TextEditNode.h"
#include "pattern/callback.h"
#include "platform/platform_helpers.h"
#include "install/LocalInstallService.h"
#include "../uninstaller_resource.h"

UninstallDialog::UninstallDialog()
	: Dialog(552.0f, 384.0f,
			 L"UninstallDialog",
			 LoadIconW(GetModuleHandle(NULL), MAKEINTRESOURCEW(IDI_UNINSTALL_ICON)),
			 DIALOG_FLAG_MAIN,
			 PopupShadowData{
				 theme::DIALOG_SHADOW_PNG,
				 (int)theme::DIALOG_SHADOW_MARGIN_PIXELS,
			 },
             nullopt)
	, _current_page(INVALID_PAGE) {}
void UninstallDialog::SetConfig(const InstallConfig & config) {
	_product_name = config.product_name;
	_display_name = config.display_name;
	_version = config.version;
}
void UninstallDialog::SetupUi() {
	//Dialog::OnCreate();

	SetTitle(_display_name + u8"ж����");

	Node2D* root = GetRoot();
	String main_label_text;
	// shared
	{
		auto logo = make_shared<ImageNode>();
		logo->SetImageName(theme::LOGO_PNG);
		logo->SetSize(theme::LOGO_SIZE);
		logo->SetOrigin(theme::LOGO_POSITION);
		root->AddChild(logo);

		auto text = make_shared<LabelNode>();
		int pos = _display_name.Find('(');
		if (pos != -1) {
			main_label_text = _display_name.Left(pos);
		} else {
			main_label_text = _display_name;
		}
		text->SetText(main_label_text);
		text->SetFontSize(theme::H2_FONT_SIZE);
		text->SetFontWeight(FontWeight::SEMI_LIGHT);
		text->SetColor(theme::H1_TEXT_COLOR);
		text->UpdateTextLayout();
		auto text_size = text->GetSize();
		text->SetOrigin({
			roundf((theme::MAIN_DIALOG_WIDTH - text_size.x) * 0.5f),
			theme::MAIN_LABEL_Y
			});
		root->AddChild(text);

		auto version = make_shared<LabelNode>();
		version->SetText(_version);
		version->SetFontSize(theme::H3_FONT_SIZE);
		version->SetColor(theme::H3_TEXT_COLOR);
		version->SetOrigin({
			text->GetX() + roundf(text_size.x) + theme::MAIN_VERSION_POSITION.x,
			theme::MAIN_VERSION_POSITION.y
			});
		root->AddChild(version);
	}
	// ������
	{
		_main_page = make_shared<Node2D>();
		
		auto start_btn = MakePrimaryButton(u8"ж��");
		start_btn->SetOrigin({ 196, 270 });
		start_btn->SetSize({ 160, 48 });
		start_btn->SetClickedCallback(MakeCallback(this, &UninstallDialog::StartUninstallButtonClicked));
		_main_page->AddChild(start_btn);

		root->AddChild(_main_page);
	}
	{
		_progress_page = make_shared<Node2D>();

		_progress_bar = MakeProgressBar();
		_progress_bar->SetSize({ 360, 4 });
		_progress_bar->SetOrigin({ 96, 268 });
		_progress_bar->SetProgress(0.0f);
		_progress_page->AddChild(_progress_bar);

		_progress_label = make_shared<LabelNode>();
		_progress_label->SetFontSize(theme::PROGRESS_FONT_SIZE);
		_progress_label->SetColor(theme::PROGRESS_TEXT_COLOR);
		_progress_label->SetOrigin({ 8, 278 });
        _progress_label->SetSize({ 536, 60 });
        _progress_label->SetAutoSize(false);
        _progress_label->SetAlignment(TextAlignment::TEXT_ALIGN_CENTER);
		_progress_label->SetText(u8"0%");
		_progress_page->AddChild(_progress_label);

		root->AddChild(_progress_page);
	}
	{
		_done_page = make_shared<Node2D>();

		auto label = make_shared<LabelNode>();
		label->SetFontSize(theme::H3_FONT_SIZE);
		label->SetColor(theme::H3_TEXT_COLOR);
		label->SetAutoSize(false);
		label->SetAlignment(TEXT_ALIGN_CENTER);
		label->SetOrigin({ 8, 238 });
		label->SetSize({ 536, 24 });
		label->SetText(String(u8"��ж��") + main_label_text);
		_done_page->AddChild(label);

		auto start_btn = MakePrimaryButton(u8"���");
		start_btn->SetOrigin({ 196, 270 });
		start_btn->SetSize({ 160, 48 });
		start_btn->SetClickedCallback(MakeCallback(this, &UninstallDialog::UninstallDoneButtonClicked));
		_done_page->AddChild(start_btn);

		root->AddChild(_done_page);
	}
	SetPage(MAIN_PAGE);
}
void UninstallDialog::OnDestroy() {
	_main_page = nullptr;
	_progress_page = nullptr;
	_progress_bar = nullptr;
	_progress_label = nullptr;
	_done_page = nullptr;

	Dialog::OnDestroy();
}
void UninstallDialog::SetProgress(float progress) {
	_progress_bar->SetProgress(progress);
	char text[8] = {};
	snprintf(text, sizeof(text) - 1, "%.0f%%", progress * 100.0f);
	_progress_label->SetText(text);
	RequestPaint();
}
void UninstallDialog::StartUninstallButtonClicked(EventContext& ctx) {
	SetPage(PROGRESS_PAGE);
	if (_start_uninstall_callback)
		_start_uninstall_callback(ctx);
}
void UninstallDialog::UninstallDoneButtonClicked(EventContext& ctx) {
	SetPage(MAIN_PAGE);
	if (_uninstall_done_callback)
		_uninstall_done_callback(ctx);
}
void UninstallDialog::SetPage(UninstallDialog::Page page) {
	if (_current_page == page)
		return;
	_current_page = page;
	switch (page) {
	case MAIN_PAGE:
		_main_page->SetVisible(true);
		_progress_page->SetVisible(false);
		_done_page->SetVisible(false);
		break;
	case PROGRESS_PAGE:
		_main_page->SetVisible(false);
		_progress_page->SetVisible(true);
		_done_page->SetVisible(false);
		break;
	case DONE_PAGE:
		_main_page->SetVisible(false);
		_progress_page->SetVisible(false);
		_done_page->SetVisible(true);
		break;
	default:
		c2_log("unable to switch to page %d\n", page);
	}
	RequestUpdate();
	RequestPaint();
}
Node2DRef UninstallDialog::MakePrimaryButton(const String& text) {
	auto btn = make_shared<ButtonNode>();
	btn->SetBackgroundColor(theme::ACTION_COLOR,
							theme::ACTION_HOVERED_COLOR);
	btn->SetColor(theme::ACTION_TEXT_COLOR);
	btn->SetAutoSize(false);
	btn->SetBorderRadius(theme::PRIMARY_BORDER_RADIUS);
	btn->SetFontSize(theme::H2_FONT_SIZE);
	btn->SetText(text);
	return btn;
}
ProgressBarNodeRef UninstallDialog::MakeProgressBar() {
	auto bar = make_shared<ProgressBarNode>();
	bar->SetBackgroundColor(theme::BORDER_COLOR);
	bar->SetColor(theme::ACTION_HOVERED_COLOR);
	return bar;
}
void UninstallDialog::OnCloseButtonClicked(EventContext& ctx) {
	if (_close_requested_callback)
		_close_requested_callback(ctx);
}