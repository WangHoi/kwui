#include "InstallProgressSmoother.h"
#include "platform/platform_helpers.h"
#include "MainDialog.h"

static constexpr double REMOVE_EXIST_TIME_ESTIMATE = .5;
static constexpr double VCREDIST_TIME_ESTIMATE = 4.0;
#ifndef NDEBUG
static constexpr double CHENGXUN_TIME_ESTIMATE = 10.5;
#else
static constexpr double CHENGXUN_TIME_ESTIMATE = 5.5;
#endif

InstallProgressSmoother::InstallProgressSmoother()
    : _chengxun_progress(0.0)
    , _start_ts(0.0)
    , _display_progress(0.0)
    , _total_paused_time(0.0)
    , _pause_counter(0) {}

void InstallProgressSmoother::SetConfig(const Config & config) {
    _config = config;
    _full_time = 0.0;
    if (_config.remove_exist_install)
        _full_time += REMOVE_EXIST_TIME_ESTIMATE;
    if (_config.install_vcredist)
        _full_time += VCREDIST_TIME_ESTIMATE;
    _full_time += CHENGXUN_TIME_ESTIMATE;
    int j = 1;
}

void InstallProgressSmoother::Start(EventContext& ctx) {
    _start_ts = get_timestamp();
    ctx.RequestAnimationFrame(this);
}

void InstallProgressSmoother::SetChengxunProgress(double progress) {
    _chengxun_progress = progress;
}

void InstallProgressSmoother::OnAnimationFrame(double timestamp, EventContext& ctx) {
    if (!_animation_start_ts.has_value())
        _animation_start_ts.emplace(timestamp);

    if (_pause_start_ts.has_value()) {
        ctx.RequestAnimationFrame(this);
        return;
    }

    if (!_chengxun_start_ts.has_value()) {
        double time = timestamp - _animation_start_ts.value() - _total_paused_time;
        _display_progress = clamp(time, 0.0, _full_time - CHENGXUN_TIME_ESTIMATE) / _full_time;
        //c2_log("!!! #%.03lf progress=%.02lf%%\n", time, _display_progress * 100.0);
    } else {
        double time = timestamp - _chengxun_start_ts.value() - _total_paused_time;
        auto real_progress = linear_interpolate(
            _chengxun_start_display_progress.value(),
            1.0,
            _chengxun_progress);
        auto fake_progress = linear_interpolate(
            _chengxun_start_display_progress.value(),
            1.0,
            clamp(time, 0.0, CHENGXUN_TIME_ESTIMATE) / CHENGXUN_TIME_ESTIMATE);
        if (real_progress < 0.999999) {
            _display_progress = sqrt(real_progress * fake_progress);
        } else {
            const double T = 0.02;
            if (!_catchup_state.has_value()) {
                double step = _display_progress / time * T;
                _catchup_state.emplace(CatchupState{ _display_progress, step });
            }
            _display_progress = min(1.0, _display_progress + _catchup_state->step);
            const double A = 0.0015;
            _catchup_state->step += A;
            //c2_log("real=%.0lf%%, fake=%.0lf%% display=%.0lf%%\n",
            //       real_progress * 100.0,
            //       fake_progress * 100.0,
            //       _display_progress * 100.0);
        }
    }
    if (_display_progress < 1.0)
        ctx.RequestAnimationFrame(this);
    if (_progress_callback)
        _progress_callback(_display_progress);
}
void InstallProgressSmoother::Pause() {
    ++_pause_counter;
    if (_pause_counter == 1)
        _pause_start_ts.emplace(get_timestamp());
}
void InstallProgressSmoother::Resume() {
    if (_pause_counter <= 0)
        return;
    --_pause_counter;
    if (_pause_counter == 0) {
        _total_paused_time += get_timestamp() - _pause_start_ts.value_or(0);
        _pause_start_ts = nullopt;
    }
}
void InstallProgressSmoother::StartChengxunInstall() {
    _chengxun_start_ts.emplace(get_timestamp());
    _chengxun_start_display_progress.emplace(_display_progress);
}
