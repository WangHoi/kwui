﻿#include "platform/platform_config.h"
#include "platform/windows/windows_header.h"
#include "graphics/GraphicDevice.h"
#include "debug/LogManager.h"
#include "debug/Logger.h"
#include "install/LocalInstallService.h"
#include "install/SingleInstanceApplication.h"
#include "memory/ResourceManager.h"
#include "text/EncodingManager.h"
#include "UninstallDialog.h"
#include "ConfirmDialog.h"
#include "theme.h"
#include "UninstallDirector.h"
#include "../uninstaller_resource.h"
#include <stdlib.h>
#include <shellapi.h>

#pragma comment(lib, "d2d1.lib")
#pragma comment(lib, "dwrite.lib")
#pragma comment(lib, "c2.lib")
#pragma comment(lib, "Windowscodecs.lib")
#pragma comment(lib, "Imm32.lib")
#pragma comment(lib, "msi.lib")

static void LoadResourceBitmaps();
static void CreateLogManager(InstallConfig& cfg);

int WINAPI wWinMain(HINSTANCE hInstance,
					HINSTANCE hPrevInstance,
					PWSTR pCmdLine,
					int nCmdShow) {
    auto install_cfg = InstallConfig::MakePublishConfig();

    SingleInstanceApplication app("uninstall_" + install_cfg.product_name);
    if (app.IsLate())
        return 0;

	CoInitializeEx(NULL, COINIT_MULTITHREADED);
	EncodingManager::CreateInstance();
	CreateLogManager(install_cfg);
	ResourceManager::Instance()->CreateInstance(hInstance);
	LocalInstallService::Instance()->CreateInstance();
	GraphicDevice::CreateInstance()->Init();

	LoadResourceBitmaps();

	int exit_code = 0;
	MSG msg;
	PeekMessageW(&msg, NULL, 0, 0, PM_NOREMOVE);
	auto UD = UninstallDirector::CreateInstance();
	UD->SetConfig(install_cfg);
	UD->Start();

	while (GetMessageW(&msg, NULL, 0, 0)) {
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}

	UninstallDirector::ReleaseInstance();
	GraphicDevice::ReleaseInstance();
	LogManager::ReleaseInstance();
	EncodingManager::ReleaseInstance();

	CoUninitialize();
	return exit_code;
}

void LoadResourceBitmaps() {
	auto GD = GraphicDevice::Instance();
	{
		auto x1_res = ResourceManager::Instance()->LoadResource(IDR_LOGO_X1);
		auto x1_5_res = ResourceManager::Instance()->LoadResource(IDR_LOGO_X1_5);
		auto x2_res = ResourceManager::Instance()->LoadResource(IDR_LOGO_X2);
		GD->LoadBitmapToCache(theme::LOGO_PNG, x1_res, x1_5_res, x2_res);
	}
	{
		auto x1_res = ResourceManager::Instance()->LoadResource(IDR_CLOSE_BUTTON_X1);
		auto x1_5_res = ResourceManager::Instance()->LoadResource(IDR_CLOSE_BUTTON_X1_5);
		auto x2_res = ResourceManager::Instance()->LoadResource(IDR_CLOSE_BUTTON_X2);
		GD->LoadBitmapToCache(theme::CLOSE_BUTTON_PNG, x1_res, x1_5_res, x2_res);
	}
	{
		auto x1_res = ResourceManager::Instance()->LoadResource(IDR_CLOSE_BUTTON_HOVER_X1);
		auto x1_5_res = ResourceManager::Instance()->LoadResource(IDR_CLOSE_BUTTON_HOVER_X1_5);
		auto x2_res = ResourceManager::Instance()->LoadResource(IDR_CLOSE_BUTTON_HOVER_X2);
		GD->LoadBitmapToCache(theme::CLOSE_BUTTON_HOVER_PNG, x1_res, x1_5_res, x2_res);
	}
	{
		auto x1_res = ResourceManager::Instance()->LoadResource(IDR_EXPAND_X1);
		auto x1_5_res = ResourceManager::Instance()->LoadResource(IDR_EXPAND_X1_5);
		auto x2_res = ResourceManager::Instance()->LoadResource(IDR_EXPAND_X2);
		GD->LoadBitmapToCache(theme::EXPAND_PNG, x1_res, x1_5_res, x2_res);
	}
	{
		auto x1_res = ResourceManager::Instance()->LoadResource(IDR_COLLAPSE_X1);
		auto x1_5_res = ResourceManager::Instance()->LoadResource(IDR_COLLAPSE_X1_5);
		auto x2_res = ResourceManager::Instance()->LoadResource(IDR_COLLAPSE_X2);
		GD->LoadBitmapToCache(theme::COLLAPSE_PNG, x1_res, x1_5_res, x2_res);
	}
	{
        auto x1_res = ResourceManager::Instance()->LoadResource(IDR_DIALOG_SHADOW_X1);
        auto x1_5_res = ResourceManager::Instance()->LoadResource(IDR_DIALOG_SHADOW_X1_5);
        auto x2_res = ResourceManager::Instance()->LoadResource(IDR_DIALOG_SHADOW_X2);
        GD->LoadBitmapToCache(theme::DIALOG_SHADOW_PNG, x1_res, x1_5_res, x2_res);
	}
}
void CreateLogManager(InstallConfig& cfg) {
	auto EM = EncodingManager::Instance();
	auto LM = LogManager::CreateInstance();
	LM->AddLogger(make_shared<VSDebugLogger>());
	WCHAR temp_dir[MAX_PATH + 1] = {};
	DWORD temp_dir_len = GetTempPathW(MAX_PATH, temp_dir);
	if (temp_dir_len > 0 && temp_dir_len <= MAX_PATH) {
		wstring utf16_logger_path = temp_dir;
		if (*utf16_logger_path.rbegin() != L'\\')
			utf16_logger_path += L'\\';
		utf16_logger_path += EM->UTF8ToWide(cfg.product_name);
		utf16_logger_path += L"_uninstall.log";
		cfg.temp_log_filename = EM->WideToUTF8(utf16_logger_path);
		LM->AddLogger(make_shared<FileLogger>(cfg.temp_log_filename));
	}
}
