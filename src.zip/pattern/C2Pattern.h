//
//  C2Pattern.h
//  C2Engine
//
//  Created by mike luo on 13-1-9.
//
//

#ifndef C2_PATTERN_H
#define C2_PATTERN_H

#include "singleton.h"
#include "observer.h"
#include "OkMixin.h"
#include "Manager.h"
#include "SharedManager.h"
#include "self_link.h"

#endif // C2_PATTERN_H