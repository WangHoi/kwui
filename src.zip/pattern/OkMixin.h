//
//  OkMixin.h
//  C2Engine
//
//  Created by mike luo on 13-5-16.
//
//

#ifndef OK_MIXIN_H
#define OK_MIXIN_H

class OkMixin {
public:
  OkMixin() : _ok(false) {}
  void Done() { _ok = true; }
  bool Ok() const { return _ok; }
private:
  bool _ok;
};

#endif // OK_MIXIN_H
