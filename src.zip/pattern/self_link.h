//
//  self_link.h
//  C2Engine
//
//  Created by mike luo on 14-1-27.
//
//
#ifndef SELF_LINK_H
#define SELF_LINK_H

#include "memory/memory_helpers.h"

#define SUPPORT_SELF_LINK(ClassName) \
  public: \
    void SetSelfLink(const ClassName##Ref& ref) { _self_link = ref; } \
    const ClassName##Link& GetSelfLink() const { return _self_link; } \
    ClassName##Ref GetSelfRef() const { return _self_link.lock(); } \
  private: \
    ClassName##Link _self_link;

#endif // SELF_LINK_H