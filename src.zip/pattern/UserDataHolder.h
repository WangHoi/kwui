//
//  UserDataHolder.h
//  C2Engine
//
//  Created by mike luo on 2013-11-18.
//
//
#ifndef USER_DATA_HOLDER_H
#define USER_DATA_HOLDER_H

#include "memory/memory_helpers.h"

SMART_REF(UserData);
class UserData {
public:
  virtual ~UserData() {}
};

class UserDataRefHolder {
public:
  virtual ~UserDataRefHolder() {}
  UserData* GetUserData() const { return _user_data.get(); }
  const UserDataRef& GetUserDataRef() const { return _user_data; }
  void SetUserData(const UserDataRef& user_data) { _user_data = user_data; }
protected:
  UserDataRef _user_data;
};

class UserDataHolder {
public:
  virtual ~UserDataHolder() {}
  UserData* GetUserData() const { return _user_data; }
  void SetUserData(UserData* user_data) { _user_data = user_data; }
protected:
  UserData* _user_data;
};

#endif // USER_DATA_HOLDER_H