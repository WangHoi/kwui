//
//  SharedManager.h
//  C2Engine
//
//  Created by mike luo on 2014-11-20.
//
//
#ifndef SHARED_MANAGER_H
#define SHARED_MANAGER_H

#include "memory/memory_helpers.h"
#include "data/data_helpers.h"
#include "thread/thread_helpers.h"
#include "debug/log.h"

template <class T>
class SharedManager {
protected:
  typedef shared_ptr<T> ObjRef;
  typedef function<ObjRef(const String&)> LoadFunction;
  typedef function<void(const String&, const ObjRef&)> CleanupCallback;

  ObjRef Load(const String& name, const LoadFunction& load_function) {
    unique_lock<mutex> lock(_mutex);
    auto iter = _table.find(name);
    if (iter == _table.end()) return _Load(name, load_function, move(lock));
    if (iter->second.is_loading) {
      auto future_ref = iter->second.future_ref;
      lock.unlock();
      return future_ref.get();
    }
    return iter->second.ref;
  }

  void Cleanup(const CleanupCallback& cleanup_callback) {
    lock_guard<mutex> lock(_mutex);
    Table new_table;
    for (auto& pair : _table) {
      auto& item = pair.second;
      if (item.is_loading || !item.ref || item.ref.use_count() > 1) {
        new_table.emplace(pair.first, pair.second);
      } else if (cleanup_callback) {
        cleanup_callback(pair.first, item.ref);
      }
    }
    _table.swap(new_table);
  }

private:
  ObjRef _Load(const String& name, const LoadFunction& load_function, unique_lock<mutex> lock) {
    packaged_task<ObjRef(const String&)> loading_task{load_function};

    auto item = &_table[name];
    item->is_loading = true;
    item->future_ref = loading_task.get_future();
    lock.unlock();

    loading_task(name);

    lock.lock();
    item = &_table[name];
    item->is_loading = false;
    item->ref = item->future_ref.get();
    item->future_ref = shared_future<ObjRef>{};
    return item->ref;
  }

  struct TableItem {
    bool is_loading;
    shared_future<ObjRef> future_ref;
    ObjRef ref;
  };

  typedef unordered_map<String, TableItem> Table;
  Table _table;
  mutable mutex _mutex;
};

#endif // SHARED_MANAGER_H