//
//  Manager.h
//  C2Engine
//
//  Created by mike luo on 13-8-27.
//
//
#ifndef MANAGER_H
#define MANAGER_H

#include "memory/memory_helpers.h"
#include "data/data_helpers.h"

template <class T>
class Manager {
public:
  typedef shared_ptr<T> ObjRef;
  typedef function<ObjRef()> LoadFunction;
  typedef function<void(const String&, const ObjRef&)> ResourceCallback;

  T* Find(const String& name) const {
    auto ref_ptr = _Find(name);
    if (ref_ptr) return ref_ptr->get();
    else return nullptr;
  }

  ObjRef FindRef(const String& name) const {
    auto ref_ptr = _Find(name);
    if (ref_ptr) return *ref_ptr;
    else return nullptr;
  }

  void Add(const String& name, const ObjRef& ref) { _table.emplace(name, ref); }
  void Remove(const String& name) { _table.erase(name); }

  const ObjRef& Load(const String& name, const LoadFunction& load_function) {
    auto ref_ptr = _Find(name);
    if (ref_ptr) return *ref_ptr;
    auto ref = load_function();
    return _Add(name, ref);
  }

  void ForEach(const ResourceCallback& callback) const {
    for (auto& pair : _table) callback(pair.first, pair.second);
  }

  int Count() const {
    return _table.size();
  }

private:
  typedef unordered_map<String, ObjRef> Table;

  const ObjRef* _Find(const String& name) const {
    auto iter = _table.find(name);
    if (iter != _table.end()) return &iter->second; 
    else return nullptr;
  }

  const ObjRef& _Add(const String& name, const ObjRef& ref) {
    return _table.emplace(name, ref).first->second;
  }

  Table _table;
};
#endif // MANAGER_H