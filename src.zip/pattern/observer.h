//
//  observer.h
//  C2Engine
//
//  Created by mike luo on 13-1-9.
//
//

#ifndef OBSERVER_H
#define OBSERVER_H

#include "data/data_helpers.h"

#define SUPPORT_OBSERVER \
public: \
  void AddObserver(Observer& observer) const { _observer_list.push_back(&observer); } \
  void RemoveObserver(Observer& observer) const { _observer_list.remove(&observer); } \
private: \
  typedef list<Observer*> ObserverList; \
  mutable ObserverList _observer_list;

#define NOTIFY_ALL(Event) \
  for (auto observer : _observer_list) { observer->Event; }

#endif // OBSERVER_H
