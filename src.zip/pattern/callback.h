#ifndef PATTERN_CALLBACK_H
#define PATTERN_CALLBACK_H

#include "data/data_helpers.h"

template <typename Class, typename... MemFnArg>
inline function<void(MemFnArg...)> MakeCallback(Class* me,
												void (Class::*mem_fn)(MemFnArg...)) {
	return [=](MemFnArg...args) {
		(me->*mem_fn)(std::forward<MemFnArg...>(args)...);
	};
}
template <typename Class, typename... MemFnArg, typename UpArg1>
inline function<void(MemFnArg...)> MakeCallback(Class* me,
												void (Class::*mem_fn)(UpArg1, MemFnArg...),
												UpArg1 up_arg1) {
	return [=](MemFnArg...args) {
		(me->*mem_fn)(up_arg1,
					  std::forward<MemFnArg...>(args)...);
	};
}
template <typename Class, typename... MemFnArg, typename UpArg1, typename UpArg2>
inline function<void(MemFnArg...)> MakeCallback(Class* me,
												void (Class::*mem_fn)(UpArg1, UpArg2, MemFnArg...),
												UpArg1 up_arg1,
												UpArg2 up_arg2) {
	return [=](MemFnArg...args) {
		(me->*mem_fn)(up_arg1,
					  up_arg2,
					  std::forward<MemFnArg...>(args)...);
	};
}
#endif // PATTERN_CALLBACK_H