#ifndef INSTALL_DIRECTOR_H
#define INSTALL_DIRECTOR_H

#include "pattern/singleton.h"
#include "install/InstallMessage.h"
#include "install/InstallTimer.h"
#include "memory/ResourceManager.h"
#include "MainDialog.h"
#include "ConfirmDialog.h"
#include "InstallConfig.h"
#include "InstallProgressSmoother.h"
#include "HiddenMsgWindow.h"

class InstallDirector : public WindowMsgListener {
public:
	InstallDirector();
	~InstallDirector();
	void SetConfig(const InstallConfig& config);
	void Start();
	void OnInstallMessage(InstallMessageBase* msg);
	void KillProcessConfirmed(EventContext& ctx);
	void RemoveExistProductConfirmed(EventContext& ctx);
	void InstallCancelled(EventContext& ctx);
	void StartInstallConfirmed(EventContext& ctx);
	void InstallDoneClicked(EventContext& ctx);

	// ���Թ���Ա��ʽ������װ�������
	void RetryStartServiceRequested(EventContext& ctx);
	// �˳���װ�Ի���
	void CloseRequested(EventContext& ctx);
	void CloseCancelled(EventContext& ctx);

	// д���ļ�ʧ�ܣ��Ի����û�����
	void CallbackError_Retry(InstallMessageType orig_msg_type,
								  DWORD worker_thread_id,
								  EventContext& ctx);
	void CallbackError_Cancel(InstallMessageType orig_msg_type,
								   DWORD worker_thread_id,
								   EventContext& ctx);
	void CallbackError_Skip(InstallMessageType orig_msg_type,
								 DWORD worker_thread_id,
								 EventContext& ctx);
    
    void SmoothProgressCallback(double progress);

	// implements WindowMsgListener
	void OnAppMessage(WPARAM wParam, LPARAM lParam) override;

private:
	void SetupUi();
	void LoadResources();
	enum State : int;
	void SetState(State state);
	void CheckToKillProcess();
	void CheckToRemoveInstalledProduct();
	void EnterStart();         // ����������
	void Ui_EnterProgress();
	void EnterDone();
	void InstallVCRedist();    // ��װVC���п�
	void InstallChengxun();    // ��װ��Ѷ
	void CreateShortcut();
	void FinishInstall();
	void RemoveExistInstall(); // �Ƴ��Ѱ�װ
	void UnpackUninstaller();
	void CloseConfirmDialog();
    void CalmDown();           // ��Ϣ�£��ȴ�����������
	void StartService();
	ConfirmDialogRef MakeConfirmDialog_KillProcess();
	ConfirmDialogRef MakeConfirmDialog_RemoveExistProduct();
	ConfirmDialogRef MakeConfirmDialog_CallbackError(ErrorUserCallback* msg);
	ConfirmDialogRef MakeConfirmDialog_Quit();
	ConfirmDialogRef MakeConfirmDialog_ElevateError();
	ConfirmDialogRef MakeConfirmDialog_UnpackArchiveOrResourceError();

	enum State {
		STATE_INIT,
		STATE_START_SERVICE,
		STATE_GET_RUNNING_PROCESS,
		STATE_KILL_PROCESS,
		STATE_CONFIRM_REMOVE_EXIST_PRODUCT,
		STATE_REMOVE_EXIST_INSTALL,
		STATE_START,
		STATE_INSTALL_VCREDIST,
		STATE_INSTALL_CHENGXUN,
		STATE_CREATE_SHORTCUT,
		STATE_UNPACK_UNINSTALLER,
        STATE_CALM, // �ȴ� InstallProgressSmoother
		STATE_DONE,
		NUM_STATES,
	};
	static const char* STATE_NAMES[NUM_STATES];
	State _state;
	InstallConfig _config;
	MainDialogRef _main_dialog;
	ConfirmDialogRef _confirm_dialog;
	ConfirmDialogRef _quit_confirm_dialog;
	vector<DWORD> _pids; // �������еĽ���
	Resource _res_vcredist;
	Resource _res_chengxun;
    bool _vcredist_installed;
	optional<ExistInstallData> _exist_chengxun_install;
    InstallTimer _timer;
    InstallProgressSmootherRef _progress_smoother;

	SUPPORT_SINGLETON(InstallDirector)
};

#endif // INSTALL_DIRECTOR_H
