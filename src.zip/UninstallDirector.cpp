#include "UninstallDirector.h"
#include "install/LocalInstallService.h"
#include "debug/log.h"
#include "text/EncodingManager.h"
#include "../uninstaller_resource.h"
#include <assert.h>

DEFINE_SINGLETON_INSTANCE(UninstallDirector);

const char* UninstallDirector::STATE_NAMES[UninstallDirector::NUM_STATES] = {
	"INIT",
	"KILL_PROCESS",
	"START",
	"REMOVE_DIR",
	"REMOVE_SHORTCUT",
    "CALM",
	"DONE",
};

UninstallDirector::UninstallDirector()
	: _state(STATE_INIT) {
	LocalInstallService::Instance()->SetListener(this);
    _progress_smoother = make_shared<UninstallProgressSmoother>();
}
UninstallDirector::~UninstallDirector()
{
	LocalInstallService::Instance()->SetListener(nullptr);
}
void UninstallDirector::SetConfig(const InstallConfig& config) {
	_config = config;
	auto IS = LocalInstallService::Instance();
	IS->SetPublisher(_config.publisher);
	IS->SetProductName(_config.product_name, _config.display_name);
	IS->SetProductVersion(_config.version);
	IS->SetExeFilename(_config.exe_filename);
	IS->SetUninstallerFilename(_config.uninstaller_filename);
	// detect target dir
	WCHAR path[MAX_PATH + 1] = {};
	if (GetModuleFileNameW(NULL, path, MAX_PATH) > 0) {
		String target_dir = EncodingManager::Instance()
			->WideToUTF8(path);
		target_dir.RemoveLastSection('\\');
		c2_log("Set target dir to [%s]\n", target_dir.GetCString());
		IS->SetTargetDir(target_dir);
	} else {
		c2_log("Get target dir failed, may have problem to uninstall\n");
		IS->SetTargetDir("C:\\Program Files (x86)\\chengxun");
	}
}
void UninstallDirector::Start() {
	SetupUi();
	CheckToKillProcess();
}
void UninstallDirector::OnInstallMessage(InstallMessageBase* msg) {
	if (!_uninstall_dialog)
		return;
	InstallMessageType msg_type = msg->GetType();
	if (msg_type == INSTALL_MSG_KILL_PROCESS_REPLY) {
		EnterStart();
	} else if (msg_type == INSTALL_MSG_REMOVE_DIR_REPLY) {
		RemoveShortcut();
	} else if (msg_type == INSTALL_MSG_REMOVE_SHORTCUT_REPLY) {
        CalmDown();
	} else {
		c2_log("unhandled InstallMessageType %d\n", msg_type);
	}
}
void UninstallDirector::SetupUi() {
	_uninstall_dialog = make_shared<UninstallDialog>();
	_uninstall_dialog->SetConfig(_config);
	_uninstall_dialog->SetupUi();
	_uninstall_dialog->SetStartUninstallCallback(MakeCallback(this, &UninstallDirector::StartUninstallConfirmed));
	_uninstall_dialog->SetUninstallDoneCallback(MakeCallback(this, &UninstallDirector::UninstallDoneClicked));
	_uninstall_dialog->SetCloseRequestedCallback(MakeCallback(this, &UninstallDirector::CloseRequested));
    _progress_smoother->SetProgressCallback(MakeCallback(this, &UninstallDirector::SmoothProgressCallback));
}
void UninstallDirector::SetState(UninstallDirector::State state) {
	if (_state != state) {
		c2_log("uninstall state changed from [%s] to [%s]\n",
			   STATE_NAMES[_state], STATE_NAMES[state]);
		_state = state;
	}
}
void UninstallDirector::CheckToKillProcess() {
	auto IS = LocalInstallService::Instance();
	_pids = IS->GetRunningProcess();
	if (!_pids.empty()) {
		_config_dialog = MakeConfirmDialog_KillProcess();
		_config_dialog->Show();
		SetState(STATE_KILL_PROCESS);
	} else {
		EnterStart();
	}
}
ConfirmDialogRef UninstallDirector::MakeConfirmDialog_KillProcess() {
	ConfirmDialogUiConfig data;
	data.title_text = _config.display_name + u8"ж����";
	data.label_text = _config.display_name + u8"�������У��Ƿ�ر�"
		+ _config.display_name + u8"����ж�أ�";
	data.action_btn_text = u8"����ж��";
	data.cancel_btn_text = u8"�Ժ���˵";
	auto dlg = make_shared<ConfirmDialog>();
	dlg->SetupUi(data);
	dlg->SetActionButtonClickedCallback(MakeCallback(this, &UninstallDirector::KillProcessConfirmed));
	dlg->SetCancelButtonClickedCallback(MakeCallback(this, &UninstallDirector::UninstallCancelled));
	return dlg;
}
void UninstallDirector::KillProcessConfirmed(EventContext& ctx) {
	if (!_pids.empty()) {
		LocalInstallService::Instance()->KillProcess(_pids);
		_pids.clear();
	}
}
void UninstallDirector::UninstallCancelled(EventContext& ctx) {
	if (_config_dialog) {
		_config_dialog->Close();
		_config_dialog = nullptr;
	}
	if (_uninstall_dialog) {
		_uninstall_dialog->Close();
		_uninstall_dialog = NULL;
	}
}
void UninstallDirector::StartUninstallConfirmed(EventContext & ctx) {
	Ui_EnterProgress();
	RemoveDir();
}
void UninstallDirector::UninstallDoneClicked(EventContext & ctx) {
	FinishUninstall();
}
void UninstallDirector::EnterStart() {
	_uninstall_dialog->Show();
	_uninstall_dialog->SetPage(UninstallDialog::MAIN_PAGE);
	SetState(STATE_START);
}
void UninstallDirector::Ui_EnterProgress() {
    _timer.Restart();
    _progress_smoother->Start(*_uninstall_dialog);
	_uninstall_dialog->SetPage(UninstallDialog::PROGRESS_PAGE);
}
void UninstallDirector::EnterDone() {
    double time = _timer.GetElapsed();
	_uninstall_dialog->SetPage(UninstallDialog::DONE_PAGE);
	SetState(STATE_DONE);
    c2_log("Uninstall done, time cost %.03lf s\n", time);
}
void UninstallDirector::RemoveShortcut() {
	LocalInstallService::Instance()->RemoveShortcut();
	SetState(STATE_REMOVE_SHORTCUT);
}
void UninstallDirector::RemoveDir() {
	LocalInstallService::Instance()->RemoveTargetDir();
	SetState(STATE_REMOVE_DIR);
}
void UninstallDirector::FinishUninstall() {
    _uninstall_dialog->Hide();
	LocalInstallService::Instance()->DeleteUninstallerSelf();
	_uninstall_dialog->Close();
}
ConfirmDialogRef UninstallDirector::MakeConfirmDialog_Quit() {
	ConfirmDialogUiConfig data;
	data.title_text = _config.display_name + u8"ж����";
	data.label_text = u8"ȷ��Ҫֹͣ" + _config.display_name + u8"ж�أ�";
	data.action_btn_text = u8"����ж��";
	data.cancel_btn_text = u8"ֹͣ";
	auto dlg = make_shared<ConfirmDialog>();
	dlg->SetupUi(data);
	dlg->SetActionButtonClickedCallback(MakeCallback(this, &UninstallDirector::CloseCancelled));
	dlg->SetCancelButtonClickedCallback(MakeCallback(this, &UninstallDirector::UninstallCancelled));
	return dlg;
}
void UninstallDirector::CloseRequested(EventContext& ctx) {
    if (_uninstall_dialog->GetPage() == UninstallDialog::DONE_PAGE)
        return UninstallDoneClicked(ctx);
    
    if (_quit_confirm_dialog)
		return;
	_quit_confirm_dialog = MakeConfirmDialog_Quit();
	_quit_confirm_dialog->Show();
}
void UninstallDirector::CloseCancelled(EventContext& ctx) {
	if (_quit_confirm_dialog) {
		_quit_confirm_dialog->Close();
		_quit_confirm_dialog = nullptr;
		return;
	}
}
void UninstallDirector::SmoothProgressCallback(double progress) {
    _uninstall_dialog->SetProgress((float)progress);
    if (progress >= 1.0) {
        EnterDone();
    }
}
void UninstallDirector::CalmDown() {
    c2_log("Work done, time cost %.03lf s, smooth_progress=%.03lf%%.\n",
           _timer.GetElapsed(), _progress_smoother->GetDisplayProgress() * 100.0);
    _progress_smoother->Done();
    SetState(STATE_CALM);
}
void UninstallDirector::OnAppMessage(WPARAM wParam, LPARAM lParam) {
	auto install_msg = (InstallMessageBase*)lParam;
	OnInstallMessage(install_msg);
	delete install_msg;
}
