#ifndef HIDDEN_MSG_WINDOW_H
#define HIDDEN_MSG_WINDOW_H

#include "platform/platform_config.h"
#include "platform/windows/windows_header.h"

class WindowMsgListener
{
public:
	virtual void OnAppMessage(WPARAM wParam, LPARAM lParam) = 0;
};
class HiddenMsgWindow
{
public:
	HiddenMsgWindow();
	~HiddenMsgWindow() = default;

	inline HWND GetHwnd() const { return _hwnd; }
	inline void SetListener(WindowMsgListener *l) { _listener = l; }

private:
	void InitWindow(HINSTANCE hInstance, const WCHAR* wnd_class_name);
	static LRESULT CALLBACK WndProcMain(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);
	LRESULT WindowProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);

	WindowMsgListener *_listener;
	HWND _hwnd;
};

#endif // HIDDEN_MSG_WINDOW_H
