#ifndef THEME_H
#define THEME_H

#include "graphics/Color.h"
#include "string/String.h"
#include "math/Vector2.h"

namespace theme {
	extern const Color BACKGROUND_COLOR;
	extern const Color ACTION_COLOR;
	extern const Color ACTION_HOVERED_COLOR;
    extern const Color ACTION_DISABLED_COLOR;
	extern const Color ACTION_TEXT_COLOR;
	extern const Color H1_TEXT_COLOR;
	extern const Color H2_TEXT_COLOR;
	extern const Color H3_TEXT_COLOR;
    extern const Color PROGRESS_TEXT_COLOR;
	extern const float H1_FONT_SIZE;
	extern const float H2_FONT_SIZE;
	extern const float H3_FONT_SIZE;
    extern const float PROGRESS_FONT_SIZE;
	extern const Color BORDER_COLOR;
	extern const Color CLOSE_BUTTON_HOVER_COLOR;
	
	extern const float DIALOG_BORDER_RADIUS;
	extern const float DIALOG_SHADOW_MARGIN_PIXELS;

	extern const float TITLE_BAR_HEIGHT;
	extern const float TITLE_BUTTON_WIDTH;
	extern const float MAIN_DIALOG_WIDTH;
	extern const float MAIN_DIALOG_HEIGHT;

	extern const String CLOSE_BUTTON_PNG;
	extern const String CLOSE_BUTTON_HOVER_PNG;
	extern const String LOGO_PNG;
	extern const Vector2 LOGO_SIZE;
	extern const Vector2 LOGO_POSITION;
	extern const String DIALOG_SHADOW_PNG;

	extern const float MAIN_LABEL_Y;
	extern const Vector2 MAIN_VERSION_POSITION;
	
	extern const float PRIMARY_BORDER_RADIUS;
	extern const float SECONDARY_BORDER_RADIUS;
	extern const String EXPAND_PNG;
	extern const String COLLAPSE_PNG;
	extern const Vector2 EXPAND_PNG_SIZE;
	extern const Vector2 EXPAND_PNG_POSITION;
	extern const float EXPAND_DIALOG_HEIGHT;

	extern const Color TEXT_EDIT_BACKGROUND_COLOR;
	extern const Color TEXT_EDIT_SELECTION_COLOR;
	extern const Color TEXT_EDIT_CARET_COLOR;
	extern const Vector2 TEXT_EDIT_SIZE;
	extern const Vector2 TEXT_EDIT_POSITION;
	extern const float TEXT_EDIT_BORDER_RADIUS;
	extern const float TEXT_EDIT_PADDING;

	extern const float CONFIRM_DIALOG_WIDTH;
	extern const float CONFIRM_DIALOG_HEIGHT;
}
#endif // THEME_H