#include "ImageButtonNode.h"
#include "graphics/Painter.h"

ImageButtonNode::ImageButtonNode()
	: _bg_color(NO_COLOR), _bg_hover_color(NO_COLOR) {
    _flags = NODE_FLAG_CLICKABLE | NODE_FLAG_HOVERABLE | NODE_FLAG_FOCUSABLE;
    _image = make_shared<ImageNode>();
    AddChild(_image);
	_hover_image = make_shared<ImageNode>();
	AddChild(_hover_image);
	_hover_image->SetVisible(false);
}
void ImageButtonNode::PaintNode(Painter& p) {
	p.SetColor(UnderMouse() ? _bg_hover_color : _bg_color);
	p.DrawRect(ZERO_VECTOR2, _size);
}
inline void ImageButtonNode::OnHoverEnter(EventContext & ctx) {
	_image->SetVisible(false);
	_hover_image->SetVisible(true);
	ctx.RequestPaint();
}
inline void ImageButtonNode::OnHoverLeave(EventContext & ctx) { 
	_image->SetVisible(true);
	_hover_image->SetVisible(false);
	ctx.RequestPaint();
}
void ImageButtonNode::OnSizeChanged() {
	_image->SetSize(_size);
	_hover_image->SetSize(_size);
}
void ImageButtonNode::SetImageName(const String& name, const String& hover_name) {
	_image->SetImageName(name);
	_hover_image->SetImageName(hover_name);
}
