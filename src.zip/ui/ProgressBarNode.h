#ifndef PROGRESS_BAR_NODE_H
#define PROGRESS_BAR_NODE_H

#include "LabelNode.h"
#include "string/String.h"
#include "graphics/TextLayout.h"
#include "graphics/Color.h"

SMART_REF(ProgressBarNode)
class ProgressBarNode : public Node2D {
public:
    ProgressBarNode();
    void PaintNode(Painter& p) override;

	inline float GetProgress() const { return _progress; }
	void SetProgress(float value);
    inline void SetColor(const Color& c) { _color = c; }
    inline void SetBackgroundColor(const Color& c) { _bg_color = c; }
    void SetBorderRadius(float r) { _border_radius = r; }

private:
	float _progress;
    Color _bg_color;
    Color _color;
    float _border_radius;
};

#endif // PROGRESS_BAR_NODE_H
