#include "LabelNode.h"
#include "graphics/Painter.h"

LabelNode::LabelNode()
	: _align(TEXT_ALIGN_TOP_LEFT)
	, _font_size(DEFAULT_FONT_SIZE)
	, _color(BLACK)
	, _auto_size(true)
	, _content_rect(ZERO_VECTOR4)
	, _layout_dirty(false) {}

void LabelNode::PaintNode(Painter& p) {
	UpdateTextLayout();
    
	if (_layout) {
        p.SetColor(_color);
		Vector2 offset = ComputeDrawOffset();
        p.DrawTextLayout(offset, *_layout);
    }
}
void LabelNode::SetText(const String& text) {
    if (_text != text) {
        _text = text;
		_layout_dirty = true;
    }
}
void LabelNode::SetAlignment(TextAlignment align) {
	if (_align != align) {
		_align = align;
		_layout_dirty = true;
	}
}
void LabelNode::SetFontSize(float font_size) {
    if (_font_size != font_size) {
        _font_size = font_size;
		_layout_dirty = true;
    }
}
void LabelNode::SetFontWeight(FontWeight weight) {
    if (_font_weight.GetRaw() != weight.GetRaw()) {
        _font_weight = weight;
        _layout_dirty = true;
    }
}
void LabelNode::SetAutoSize(bool auto_size) {
	if (auto_size != _auto_size) {
		_auto_size = auto_size;
		_layout_dirty = true;
	}
}
void LabelNode::UpdateTextLayout() {
	if (!_layout_dirty)
		return;

	auto builder = TextLayoutBuilder(_text)
		.FontSize(_font_size)
        .FontWeight(_font_weight)
		.Align(_align);
	if (!_auto_size) 
		builder.MaxWidth(_size.x);
    _layout = builder.Build();
    _content_rect = _layout->GetRect();
	if (_auto_size) {
		_size.Set(_content_rect.x + _content_rect.z,
				  _content_rect.y + _content_rect.w);
	}
	_layout_dirty = false;
}
Vector2 LabelNode::ComputeDrawOffset() const {
	Vector2 offset = ZERO_VECTOR2;
	if (_align & TEXT_ALIGN_VCENTER) {
		offset.y = 0.5f * (_size.y - _content_rect.w);
	} else if (_align & TEXT_ALIGN_BOTTOM) {
		offset.y = _size.y - _content_rect.w;
	}
	return offset;

	return offset;
}
void LabelNode::DiscardDeviceResources() {
	_layout_dirty = true;
}
