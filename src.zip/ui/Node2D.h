#ifndef NODE_2D_H
#define NODE_2D_H

#include "math/Vector2.h"
#include "memory/memory_helpers.h"

enum NodeFlag {
    NODE_FLAG_FOCUSABLE = 1,
    NODE_FLAG_HOVERABLE = 2,
    NODE_FLAG_CLICKABLE = 4,
};

struct Padding {
    float left, top, right, bottom;
    Padding() : left(0), top(0), right(0), bottom(0) {}
    Padding(float p) : left(p), top(p), right(p), bottom(p) {}
    Padding(float l, float t, float r, float b) : left(l), top(t), right(r), bottom(b) {}
};

enum CursorType {
    CURSOR_ARROW,
    CURSOR_CROSS,
    CURSOR_HAND,
    CURSOR_IBEAM,
    CURSOR_WAIT,
    NUM_CURSOR_TYPES,
};

class Node2D;
class EventContext {
public:
    virtual Vector2 GetMousePosition() const = 0;

    virtual void RequestPaint() = 0;
    virtual void RequestUpdate() = 0;
    virtual void RequestAnimationFrame(Node2D* node) = 0;
};
enum ModifierState {
    NO_MODIFILER = 0,
    LCTRL_MODIFIER = 1,
    RCTRL_MODIFIER = 2,
    CTRL_MODIFIER = LCTRL_MODIFIER | RCTRL_MODIFIER,
    LSHIFT_MODIFIER = 4,
    RSHIFT_MODIFIER = 8,
    SHIFT_MODIFIER = LSHIFT_MODIFIER | RSHIFT_MODIFIER,
    LALT_MODIFIER = 16,
    RALT_MODIFIER = 32,
    ALT_MODIFIER = LALT_MODIFIER | RALT_MODIFIER,
};
enum ButtonState {
    LEFT_BUTTON,
    MIDDLE_BUTTON,
    RIGHT_BUTTON,
    BUTTON_COUNT
};

using ClickedCallback = function<void(EventContext&)>;

class Dialog;
class PopupShadow;
class Painter;
SMART_REF(Node2D)
class Node2D : public enabled_shared_from_this<Node2D> {
public:
    Node2D();

    virtual void PaintNode(Painter &p) {}
    // position in parent coordinates
    virtual bool HitTestNode(const Vector2& p);

    virtual void OnHoverEnter(EventContext& ctx) {}
    virtual void OnHoverLeave(EventContext& ctx) {}
    virtual void OnMouseDown(const Vector2& pos, EventContext& ctx) {}
    virtual void OnClick(EventContext& ctx);
    virtual void OnFocusIn(EventContext& ctx) {}
    virtual void OnFocusOut(EventContext& ctx) {}
    virtual void OnImeStartComposition(EventContext& ctx) {}
    virtual void OnImeComposition(const wstring& text,
                                  optional<int> caret_pos,
                                  EventContext& ctx) {}
    virtual void OnImeEndComposition(EventContext& ctx) {}
    virtual void OnImeCommit(const wstring& text, EventContext& ctx) {
        for (auto ch : text)
            OnCharacter(ch, ctx);
    }
    virtual bool QueryImeCaretRect(Vector2& origin, Vector2& size) { return false; }
    virtual void OnCharacter(wchar_t ch, EventContext& ctx) {}
    virtual void OnKeyDown(int key, int modifiers, EventContext& ctx) {}
    virtual void OnKeyUp(int key, int modifiers, EventContext& ctx) {}
    virtual void OnSizeChanged() {}

    virtual void DiscardDeviceResources() {}

    virtual void OnAnimationFrame(double timestamp, EventContext& ctx) {}

    virtual optional<CursorType> GetCursorType() const { return nullopt; }

    bool IsVisible() const { return _visible; }
    void SetVisible(bool visible) { _visible = visible; }
    // Check visible along hierarchy, exclude |ancestor|,
    //  IsVisibleTo(nullptr) will check full hierarchy.
    bool IsVisibleTo(Node2D* ancestor) const;
    inline bool IsVisibleInHierarchy() const {
        return IsVisibleTo(nullptr);
    }

    inline bool IsFocusable() const { return _flags & NODE_FLAG_FOCUSABLE; }
    inline bool IsHoverable() const { return _flags & NODE_FLAG_HOVERABLE; }
    inline bool IsClickable() const { return _flags & NODE_FLAG_CLICKABLE; }
    inline int GetFlags() const { return _flags; }

    void AddChild(const Node2DRef& child);
    void RemoveChild(const Node2DRef& child);
    inline const vector<Node2DRef>& GetChildren() const { return _children; }

    inline const Vector2& GetOrigin() const { return _origin; }
    inline const Vector2& GetSize() const { return _size; }
    inline float GetX() const { return _origin.x; }
    inline float GetY() const { return _origin.y; }
    inline float GetWidth() const { return _size.x; }
    inline float GetHeight() const { return _size.y; }
    inline void SetOrigin(const Vector2& origin) { _origin = origin; }
    void SetSize(const Vector2& size) {
        if (_size != size) {
            _size = size;
            OnSizeChanged();
        }
    }
    Vector2 MapPointToRoot(const Vector2& p) const;

    inline bool UnderMouse() const { return _under_mouse; }
    inline void SetClickedCallback(ClickedCallback&& callback) { _clicked_callback = callback; }

protected:
    Vector2 _origin;
    Vector2 _size;
    int _flags;
    bool _visible;
    Node2DLink _parent;
    vector<Node2DRef> _children;
    ClickedCallback _clicked_callback;

    bool _under_mouse;
    friend class Dialog;
    friend class PopupShadow;
};

#endif // NODE_2D_H
