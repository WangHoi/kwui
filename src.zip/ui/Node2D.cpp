#include "Node2D.h"
#include <assert.h>
#include <algorithm>

Node2D::Node2D()
    : _origin(ZERO_VECTOR2), _size(ZERO_VECTOR2)
    , _flags(0), _visible(true), _under_mouse(false) {}

bool Node2D::HitTestNode(const Vector2& p) {
    return _origin <= p && p < (_origin + _size);
}
bool Node2D::IsVisibleTo(Node2D* ancestor) const {
    const Node2D* p = this;
    do {
        if (!p->IsVisible())
            return false;
        p = p->_parent.lock().get();
    } while (p && p != ancestor);
    return true;
}
void Node2D::AddChild(const Node2DRef& child) {
    assert(child->_parent.lock() == nullptr);
    child->_parent = weak_from_this();
    _children.push_back(child);
}
void Node2D::RemoveChild(const Node2DRef& child) {
    auto it = std::find(_children.begin(), _children.end(), child);
    if (it != _children.end()) {
        (*it)->_parent.reset();
        _children.erase(it);
    }
}
Vector2 Node2D::MapPointToRoot(const Vector2& p) const {
    const Node2D* node = this;
    Vector2 v = p;
    while (node) {
        v += node->_origin;
        node = node->_parent.lock().get();
    }
    return v;
}
void Node2D::OnClick(EventContext& ctx) {
    if (_clicked_callback)
        _clicked_callback(ctx);
}
