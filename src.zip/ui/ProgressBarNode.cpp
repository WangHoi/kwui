#include "ProgressBarNode.h"
#include "graphics/Painter.h"

ProgressBarNode::ProgressBarNode()
    : _bg_color(WHITE)
    , _color(BLUE)
    , _border_radius(0) {}
void ProgressBarNode::PaintNode(Painter& p) {
	p.SetColor(_bg_color);
    p.DrawRoundedRect(ZERO_VECTOR2, _size, _border_radius);
	
	Vector2 bar_size = { _size.x * _progress, _size.y };
	p.SetColor(_color);
	p.DrawRoundedRect(ZERO_VECTOR2, bar_size, _border_radius);
}
void ProgressBarNode::SetProgress(float value) {
	_progress = clamp(value, 0.0f, 1.0f);
}
