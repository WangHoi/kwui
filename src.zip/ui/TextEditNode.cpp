#include "TextEditNode.h"
#include "graphics/Painter.h"
#include "text/EncodingManager.h"
#include "text/encoding_helpers.h"
#include "debug/log.h"
#include "debug/debug_helpers.h"
#include "platform/platform_helpers.h"

static constexpr size_t MAX_UNDO_HISTORY = 20;

class ReplaceSelectionCommand : public TextEditModel::Command {
public:
    ReplaceSelectionCommand(int caret_pos, const wstring& text)
        : _sel_active(caret_pos), _text(text) {}
    ReplaceSelectionCommand(int caret_anchor, int caret_pos, const wstring& text)
        : _sel_anchor(caret_anchor), _sel_active(caret_pos), _text(text) {}
    inline bool HasSelection() const {
        return _sel_anchor.has_value();
    }
    void Apply(TextEditModel::State& state) override {
        state.sel_anchor = nullopt;
        if (_sel_anchor.has_value()) {
            int sel_start = _sel_anchor.value();
            int sel_end = _sel_active;
            if (sel_start > sel_end)
                swap(sel_start, sel_end);
            _deleted_text = state.text.substr(sel_start, sel_end - sel_start);
            state.text.erase(sel_start, sel_end - sel_start);
            state.sel_active = sel_start + (int)_text.length();
            state.text.insert(sel_start, _text);
        } else {
            state.sel_active = _sel_active + (int)_text.length();
            state.text.insert(_sel_active, _text);
        }
    }
    void Rollback(TextEditModel::State& state) override {
        state.sel_anchor = _sel_anchor;
        state.sel_active = _sel_active;
        if (_sel_anchor.has_value()) {
            int sel_start = _sel_anchor.value();
            int sel_end = _sel_active;
            if (sel_start > sel_end)
                swap(sel_start, sel_end);
            state.text.erase(sel_start, _text.length());
            state.text.insert(sel_start, _deleted_text);
        } else {
            state.text.erase(_sel_active, _text.length());
        }
    }
    bool Merge(const Command& cmd_) {
        if (HasSelection())
            return false;
        auto cmd = dynamic_cast<const ReplaceSelectionCommand*>(&cmd_);
        if (cmd) {
            if (cmd->HasSelection())
                return false;
            if (_sel_active + _text.length() == cmd->_sel_active) {
                _text += cmd->_text;
                return true;
            }
        }
        return false;
    }
private:
    optional<int> _sel_anchor;
    int _sel_active;
    wstring _text;
    wstring _deleted_text; // HasSelection() ʱ����Ч
};
class DeleteTextCommand : public TextEditModel::Command {
public:
    // ��ǰɾ��ʱ��n Ϊ����
    DeleteTextCommand(int caret_pos, int n)
        : _sel_active(caret_pos), _n(n) {}
    void Apply(TextEditModel::State& state) override {
        if (_n >= 0) {
            _deleted_text = state.text.substr(_sel_active, _n);
            c2_assert(_deleted_text.length() == _n);
            state.sel_anchor = nullopt;
            state.sel_active = _sel_active;
            state.text.erase(_sel_active, _n);
        } else {
            _deleted_text = state.text.substr(_sel_active + _n, -_n);
            c2_assert(_deleted_text.length() == -_n);
            state.sel_anchor = nullopt;
            state.sel_active = _sel_active + _n; // ��Ҫ�ƶ����
            state.text.erase(_sel_active + _n, -_n);
        }
    }
    void Rollback(TextEditModel::State& state) override {
        if (_n >= 0) {
            state.sel_anchor = nullopt;
            state.sel_active = _sel_active;
            state.text.insert(_sel_active, _deleted_text);
        } else {
            state.sel_anchor = nullopt;
            state.sel_active = _sel_active;
            state.text.insert(_sel_active + _n, _deleted_text);
        }
        _deleted_text.clear();
    }
    bool Merge(const Command& cmd_) {
        auto cmd = dynamic_cast<const DeleteTextCommand*>(&cmd_);
        if (cmd && _n * cmd->_n > 0) {
            if (_n >= 0 && _sel_active == cmd->_sel_active) {
                // Delete
                _n += cmd->_n;
                _deleted_text += cmd->_deleted_text;
                return true;
            } else if (_n < 0 && _sel_active + _n == cmd->_sel_active) {
                // Backspace
                _n += cmd->_n;
                _deleted_text = cmd->_deleted_text + _deleted_text;
                return true;
            }
        }
        return false;
    }
private:
    int _sel_active;
    int _n;
    wstring _deleted_text;
};

class TextEditNode::CaretBlinkHelper {
public:
    CaretBlinkHelper() {
        _blink_time_ms = GetCaretBlinkTime();
        Reset();
    }
    void Reset() {
        _reset_time = get_timestamp();
        _visible = nullopt;
    }
    // true is state changed
    bool Update(double timestamp) {
        if (_blink_time_ms == INFINITY)
            return false;
        UINT i = static_cast<UINT>((timestamp - _reset_time) * 1000.0)
            / _blink_time_ms;
        bool new_visible = (i % 2 == 0);
        if (_visible.has_value() && _visible.value() == new_visible)
            return false;
        _visible.emplace(new_visible);
        return true;
    }
    bool IsCaretVisible() const {
        return _visible.value_or(false);
    }

private:
    // The time required to invert the caret's pixels.
    // INFINITE indicates that the caret does not blink.
    UINT _blink_time_ms;
    double _reset_time;
    optional<bool> _visible;
};
static wstring char32_to_wstring(char32 ch) {
    static_assert(sizeof(wchar_t) == sizeof(char16));

    char16 c16[3] = {};
    int len = put_unicode(c16, ch);
    return wstring((wchar_t*)c16);
}

void TextEditModel::ResetWithText(const wstring& text) {
    _cmds.clear();
    _cmd_top = 0;
    _state.sel_anchor = nullopt;
    _state.sel_active = text.length();
    _state.text = text;
}
/*
void TextEditModel::InsertChar(int pos, char32 ch) {
    AddCommand(make_unique<ReplaceSelectionCommand>(
        pos, char32_to_wstring(ch)));
}
*/
void TextEditModel::InsertText(int pos, const wstring& text, bool from_ime) {
    AddCommand(make_unique<ReplaceSelectionCommand>(
        pos, text), !from_ime);
}
void TextEditModel::DeleteText(int pos, int n) {
    AddCommand(make_unique<DeleteTextCommand>(
        pos, n));
}
void TextEditModel::DeleteSelection(int sel_anchor, int sel_active) {
    AddCommand(make_unique<ReplaceSelectionCommand>(
        sel_anchor, sel_active, wstring()));
}
void TextEditModel::ReplaceSelection(int sel_anchor,
                                     int sel_active,
                                     const wstring& text) {
    AddCommand(make_unique<ReplaceSelectionCommand>(
        sel_anchor, sel_active, text));
}
bool TextEditModel::Undo() {
    if (_cmds.empty())
        return false;
    if (_cmd_top == 0)
        return false;
    if (_cmd_top > _cmds.size()) {
        c2_log("TextEditModel::Undo(): Invalid cmd top %zd\n", _cmd_top);
        ClearUndoHistory();
        return false;
    }
    --_cmd_top;
    _cmds[_cmd_top]->Rollback(_state);
    return true;
}
bool TextEditModel::Redo() {
    if (_cmds.empty())
        return false;
    if (_cmd_top == _cmds.size())
        return false;
    if (_cmd_top > _cmds.size()) {
        c2_log("TextEditModel::Redo(): Invalid cmd top %zd\n", _cmd_top);
        ClearUndoHistory();
        return false;
    }
    _cmds[_cmd_top]->Apply(_state);
    ++_cmd_top;
    return true;
}
void TextEditModel::ClearUndoHistory() {
    _cmds.clear();
    _cmd_top = 0;
}
void TextEditModel::AddCommand(TextEditModel::CommandHandle&& cmd, bool try_merge) {
    cmd->Apply(_state);
    if (try_merge && _cmd_top > 0 && _cmd_top <= (int)_cmds.size()) {
        if (_cmds[_cmd_top - 1]->Merge(*cmd)) {
            _cmds.resize(_cmd_top);
            return;
        }
    }
    _cmds.resize(_cmd_top);
    _cmds.push_back(move(cmd));
    ++_cmd_top;
    if (_cmds.size() > MAX_UNDO_HISTORY) {
        _cmds.pop_front();
        --_cmd_top;
    }
}
TextEditNode::TextEditNode()
    : _font_size(DEFAULT_FONT_SIZE)
    , _color(BLACK), _bg_color(WHITE)
    , _selection_bg_color(BLUE), _selection_text_color(WHITE)
    , _caret_color(BLACK), _is_focused(false), _caret_pos(-1)
    , _scroll_offset(ZERO_VECTOR2)
    , _padding(0)
    , _border_radius(0)
    , _sel_anchor(0) {
    _flags = NODE_FLAG_CLICKABLE | NODE_FLAG_FOCUSABLE;
    _caret_blink_helper = make_unique<CaretBlinkHelper>();
    UpdateTextLayout();
    MoveCaret(0, false, false);
}
TextEditNode::~TextEditNode() = default;
void TextEditNode::PaintNode(Painter& p) {
    p.SetColor(_bg_color);
    p.DrawRoundedRect(ZERO_VECTOR2, _size, _border_radius);

    Vector2 clip_origin = Vector2(_padding, 0);
    Vector2 clip_size = _size - Vector2(2 * _padding, 0);
    p.PushClipRect(clip_origin, clip_size);
    {
        // Draw selection
        if (HasSelection() && !_composing.has_value()) {
            p.SetColor(_selection_bg_color);
            Vector4 rect = _layout->GetRangeRect(_sel_anchor.value(),
                                                 _caret_pos);
            p.DrawRect(_scroll_offset.x + _padding + rect.x,
                       _scroll_offset.y + _padding + rect.y,
                       rect.z,
                       rect.w);
        }

        // Draw text
        p.SetColor(_color);
        p.DrawTextLayout(_scroll_offset + _padding, *_layout);
    }
    p.PopClipRect();

    if (_composing.has_value()) {
        // Draw underline
        float baseline = _layout->GetBaseline();
        auto pos = HasSelection()
            ? min(_sel_anchor.value(), _caret_pos)
            : _caret_pos;
        Vector4 rect = _layout->GetRangeRect(pos,
                                             pos + _composing->text.length());
        p.SetColor(_caret_color);
        p.DrawRect(_scroll_offset.x + _padding + rect.x,
                   _scroll_offset.y + _padding + baseline - 0.5f,
                   rect.z,
                   1.0f);
    }
    if (_is_focused && _caret_blink_helper->IsCaretVisible()) {
        p.SetColor(_caret_color);
        p.DrawRect(_scroll_offset + _padding + _caret_rect.XY(), _caret_rect.ZW());
    }
}
void TextEditNode::UpdateTextLayout() {
    wstring disp_text = GetDisplayText();
    _layout = TextLayoutBuilder(disp_text)
        .FontSize(_font_size)
        .Build();
}
void TextEditNode::OnFocusIn(EventContext& ctx) {
    _is_focused = true;
    ResetCaretBlink();
    ctx.RequestAnimationFrame(this);
    ctx.RequestPaint();
}
void TextEditNode::OnFocusOut(EventContext& ctx) {
    _is_focused = false;
    ctx.RequestPaint();
}
void TextEditNode::OnCharacter(wchar_t ch, EventContext& ctx) {
    InsertText(wstring{ ch }, false);
    ctx.RequestPaint();
}
void TextEditNode::OnImeComposition(const wstring& text,
                                    optional<int> caret_pos,
                                    EventContext& ctx) {
    if (_composing.has_value()) {
        _composing->text = text;
        _composing->caret_pos = caret_pos.value_or(_composing->caret_pos);
    } else {
        ComposeState e;
        e.text = text;
        e.caret_pos = caret_pos.value_or((int)text.length());
        _composing.emplace(e);
    }

    UpdateTextLayout();
    ResetCaretBlink();
    UpdateCaretAndScroll();
    ctx.RequestPaint();
}
void TextEditNode::OnImeEndComposition(EventContext &ctx) {
    _composing = nullopt;
    UpdateTextLayout();
    ResetCaretBlink();
    UpdateCaretAndScroll();
    ctx.RequestPaint();
}
void TextEditNode::OnImeCommit(const wstring& text, EventContext& ctx) {
    InsertText(text, true);
    ctx.RequestPaint();
}
bool TextEditNode::QueryImeCaretRect(Vector2 &origin, Vector2 &size) {
    //UpdateTextLayout();
    //UpdateScrollOffset();
    origin = _scroll_offset + _padding + _caret_rect.XY();
    size = _caret_rect.ZW();
    return true;
}
void TextEditNode::OnKeyDown(int key, int modifiers, EventContext& ctx) {
    switch (key) {
    case VK_LEFT:
        if (modifiers) {
            if ((modifiers & SHIFT_MODIFIER) == modifiers) {
                MoveCaretLeft(true);
            }
        } else {
            MoveCaretLeft(false);
        }
        break;
    case VK_RIGHT:
        if (modifiers) {
            if ((modifiers & SHIFT_MODIFIER) == modifiers) {
                MoveCaretRight(true);
            }
        } else {
            MoveCaretRight(false);
        }
        break;
    case VK_HOME:
        if (modifiers) {
            if ((modifiers & SHIFT_MODIFIER) == modifiers) {
                MoveCaretToStart(true);
            }
        } else {
            MoveCaretToStart(false);
        }
        break;
    case VK_END:
        if (modifiers) {
            if ((modifiers & SHIFT_MODIFIER) == modifiers) {
                MoveCaretToEnd(true);
            }
        } else {
            MoveCaretToEnd(false);
        }
        break;
    case VK_BACK:
        DeleteLeftChar();
        break;
    case VK_DELETE:
        DeleteRightChar();
        break;
    case 'C':
        ClipboardCopy();
        break;
    case 'X':
        ClipboardCut();
        break;
    case 'V':
        ClipboardPaste();
        break;
    case 'A':
        if (modifiers) {
            if ((modifiers & CTRL_MODIFIER) == modifiers) {
                SelectAll();
            }
        }
        break;
    case 'Z':
        if (modifiers) {
            if ((modifiers & CTRL_MODIFIER) == modifiers) {
                // Ctrl-Z
                Undo();
            } else if ((modifiers & CTRL_MODIFIER) && (modifiers & SHIFT_MODIFIER)
                       && (modifiers & (CTRL_MODIFIER | SHIFT_MODIFIER)) == modifiers) {
                // Ctrl-Shift-Z
                Redo();
            }
        }
        break;
    case 'Y':
        if (modifiers) {
            if ((modifiers & CTRL_MODIFIER) == modifiers) {
                // Ctrl-Y
                Redo();
            }
        }
        break;
    }
    ResetCaretBlink();
    ctx.RequestPaint();
}
void TextEditNode::InsertText(const wstring& text, bool from_ime) {
    ClearComposingText();
    if (HasSelection()) {
        _model.ReplaceSelection(_sel_anchor.value(),
                                _caret_pos,
                                text);
    } else {
        _model.InsertText(_caret_pos, text, from_ime);
    }
    SyncStateFromModel();
    UpdateTextLayout();
    UpdateCaretAndScroll();
}
void TextEditNode::DeleteLeftChar() {
    if (HasSelection()) {
        _model.DeleteSelection(_sel_anchor.value(), _caret_pos);
        SyncStateFromModel();
    } else {
        if (_caret_pos > 0) {
            int n = 1;
            if (_caret_pos > 1) {
                wchar_t char_back_one = _text[_caret_pos - 1];
                wchar_t char_back_two = _text[_caret_pos - 2];
                if ((is_low_surrogate(char_back_one) && is_high_surrogate(char_back_two))
                    || (char_back_one == '\n' && char_back_two == '\r')) {
                    n = 2;
                }
            }
            _model.DeleteText(_caret_pos, -n);
            SyncStateFromModel();
        }
    }
    UpdateTextLayout();
    UpdateCaretAndScroll();
}
void TextEditNode::DeleteRightChar() {
    if (HasSelection()) {
        _model.DeleteSelection(_sel_anchor.value(), _caret_pos);
        SyncStateFromModel();
    } else {
        if (_caret_pos < (int)_text.length()) {
            int n = 1;
            if (_caret_pos + 1 < (int)_text.length()) {
                wchar_t char_after_one = _text[_caret_pos];
                wchar_t char_after_two = _text[_caret_pos + 1];
                if ((is_high_surrogate(char_after_one) && is_low_surrogate(char_after_two))
                    || (char_after_one == '\r' && char_after_two == '\n')) {
                    n = 2;
                }
            }
            _model.DeleteText(_caret_pos, n);
            SyncStateFromModel();
        }
    }
    UpdateTextLayout();
    UpdateCaretAndScroll();
}
void TextEditNode::MoveCaretLeft(bool make_selection) {
    int n = 1;
    if (_caret_pos > 1) {
        wchar_t char_back_one = _text[_caret_pos - 1];
        wchar_t char_back_two = _text[_caret_pos - 2];
        if ((is_low_surrogate(char_back_one) && is_high_surrogate(char_back_two))
            || (char_back_one == '\n' && char_back_two == '\r')) {
            n = 2;
        }
    }
    if (make_selection && !HasSelection()) {
        if (_caret_pos > 0) {
            _sel_anchor.emplace(_caret_pos);
        }
    }
    MoveCaret(_caret_pos - n, false, make_selection);
}
void TextEditNode::MoveCaretRight(bool make_selection) {
    int n = 1;
    if (_caret_pos + 1 < (int)_text.length()) {
        wchar_t char_after_one = _text[_caret_pos];
        wchar_t char_after_two = _text[_caret_pos + 1];
        if ((is_high_surrogate(char_after_one) && is_low_surrogate(char_after_two))
            || (char_after_one == '\r' && char_after_two == '\n')) {
            n = 2;
        }
    }
    if (make_selection && !HasSelection()) {
        if (_caret_pos < (int)_text.length()) {
            _sel_anchor.emplace(_caret_pos);
        }
    }
    MoveCaret(_caret_pos + n, false, make_selection);
}
void TextEditNode::MoveCaret(int pos, bool force, bool keep_selection) {
    if (!keep_selection)
        _sel_anchor = nullopt;

    pos = clamp(pos, 0, (int)_text.length());
    if (pos != _caret_pos || force) {
        _caret_pos = pos;
        UpdateCaretAndScroll();
    }
}
void TextEditNode::MoveCaretToStart(bool make_selection) {
    if (make_selection && !HasSelection()) {
        if (_caret_pos != 0)
            _sel_anchor.emplace(_caret_pos);
    }
    MoveCaret(0, false, make_selection);
}
void TextEditNode::MoveCaretToEnd(bool make_selection) {
    if (make_selection && !HasSelection()) {
        if (_caret_pos != _text.length())
            _sel_anchor.emplace(_caret_pos);
    }
    MoveCaret((int)_text.length(), false, make_selection);
}
void TextEditNode::UpdateCaretAndScroll() {
    int disp_caret_pos = GetDisplayCaretPos();
    _caret_rect = _layout->GetCaretRect(disp_caret_pos);
    Vector4 content_rect = _layout->GetRect();
    float avail_width = _size.x - _padding * 2;

    float caret_x = _caret_rect.x + 0.5f * _caret_rect.z + _scroll_offset.x;
    if (caret_x < 0) {
        _scroll_offset.x += -caret_x;
        if (_scroll_offset.x > 0)
            _scroll_offset.x = 0;
    } else {
        if (caret_x > avail_width) {
            _scroll_offset.x -= caret_x - avail_width;
        }
    }

    if (avail_width >= content_rect.z && _scroll_offset.x < 0) {
        _scroll_offset.x = 0;
        return;
    }
    if (avail_width < content_rect.z && _scroll_offset.x < avail_width - content_rect.z) {
        _scroll_offset.x = avail_width - content_rect.z;
        return;
    }
}
void TextEditNode::OnMouseDown(const Vector2& local_pos, EventContext& ctx) {
    int pos = _layout->HitTest(local_pos - _scroll_offset - _padding);
    if (pos != -1)
        MoveCaret(pos, false, false);
    ResetCaretBlink();
    ctx.RequestPaint();
}
void TextEditNode::OnSizeChanged() {
    MoveCaret(_caret_pos, true, true);
}
void TextEditNode::OnAnimationFrame(double timestamp, EventContext& ctx) {
    if (!_is_focused)
        return;
    if (_caret_blink_helper->Update(timestamp))
        ctx.RequestPaint();
    ctx.RequestAnimationFrame(this);
}
String TextEditNode::GetText() const {
    return EncodingManager::Instance()->WideToUTF8(_text);
}
void TextEditNode::SetText(const String& text) {
    wstring utf16_text = EncodingManager::Instance()->UTF8ToWide(text);
    if (utf16_text != _text) {
        _model.ResetWithText(utf16_text);
        SyncStateFromModel();
        UpdateTextLayout();
        MoveCaret(_text.length(), true, true);
    }
}
void TextEditNode::SetFontSize(float font_size) {
    if (_font_size != font_size) {
        _font_size = font_size;
        UpdateTextLayout();
        MoveCaret(_text.length(), true, true);
    }
}
wstring TextEditNode::GetDisplayText() const {
    wstring display_text = _text;
    if (HasSelection()) {
        if (_composing.has_value()) {
            auto pos = min(_sel_anchor.value(), _caret_pos);
            auto sel_len = max(_sel_anchor.value(), _caret_pos) - pos;
            if (pos >= 0 && pos <= (int)display_text.length()) {
                display_text.erase(pos, sel_len);
                display_text.insert(pos, _composing->text);
            }
        }
    } else {
        if (_composing.has_value()) {
            if (_caret_pos >= 0 && _caret_pos <= (int)display_text.length())
                display_text.insert(_caret_pos, _composing->text);
        }
    }
    return display_text;
}
int TextEditNode::GetDisplayCaretPos() const {
    if (HasSelection()) {
        if (_composing.has_value()) {
            return min(_sel_anchor.value(), _caret_pos)
                + _composing->caret_pos;
        } else {
            return _caret_pos;
        }
    } else {
        return _composing.has_value()
            ? _caret_pos + _composing->caret_pos
            : _caret_pos;
    }
}
void TextEditNode::ClearComposingText() {
    _composing = nullopt;
}
void TextEditNode::SyncStateFromModel() {
    auto& state = _model.GetState();
    bool changed = _text != state.text;
    _text = state.text;
    _sel_anchor = state.sel_anchor;
    _caret_pos = state.sel_active;
    if (changed && _text_changed_callback)
        _text_changed_callback(_text);
}
void TextEditNode::Undo() {
    if (_model.Undo()) {
        SyncStateFromModel();
        UpdateTextLayout();
        UpdateCaretAndScroll();
    }
}
void TextEditNode::Redo() {
    if (_model.Redo()) {
        SyncStateFromModel();
        UpdateTextLayout();
        UpdateCaretAndScroll();
    }
}
void TextEditNode::SelectAll() {
    if (!_text.empty()) {
        _sel_anchor.emplace(0);
        MoveCaret(_text.length(), false, true);
    }
}
void TextEditNode::ClipboardCopy() {
    if (HasSelection()) {
        auto text = EncodingManager::Instance()
            ->WideToUTF8(GetSelectionText());
        set_clipboard_text(text);
    }
}
void TextEditNode::ClipboardCut() {
    if (HasSelection()) {
        auto text = EncodingManager::Instance()
            ->WideToUTF8(GetSelectionText());
        set_clipboard_text(text);

        _model.DeleteSelection(_sel_anchor.value(), _caret_pos);
        SyncStateFromModel();
        UpdateTextLayout();
        UpdateCaretAndScroll();
    }
}
void TextEditNode::ClipboardPaste() {
    optional<String> text = get_clipboard_text();
    if (text.has_value()) {
        wstring utf16_text = EncodingManager::Instance()->UTF8ToWide(text.value());
        InsertText(utf16_text, true/*from_ime*/); // from_ime=true ��ʶ�����ܵ�������
    }
}

wstring TextEditNode::GetSelectionText() const {
    if (!_sel_anchor.has_value())
        return wstring();
    int sel_start = min(_sel_anchor.value(), _caret_pos);
    int sel_end = max(_sel_anchor.value(), _caret_pos);
    return _text.substr(sel_start, sel_end - sel_start);
}
void TextEditNode::ResetCaretBlink() {
    _caret_blink_helper->Reset();
}
