#ifndef LABEL_NODE_H
#define LABEL_NODE_H

#include "Node2D.h"
#include "string/String.h"
#include "graphics/TextLayout.h"
#include "graphics/Color.h"

SMART_REF(LabelNode)
class LabelNode : public Node2D {
public:
	LabelNode();
    void PaintNode(Painter& p) override;
	void DiscardDeviceResources() override;
    void SetText(const String& text);
	void SetAlignment(TextAlignment align);
    void SetFontSize(float font_size);
    void SetFontWeight(FontWeight weight);
    void SetColor(const Color& c) { _color = c; }
	void SetAutoSize(bool auto_size);
    void UpdateTextLayout();

private:
	Vector2 ComputeDrawOffset() const;
    String _text;
	TextAlignment _align;
    float _font_size;
    FontWeight _font_weight;
    TextLayoutHandle _layout;
    Color _color;
	bool _auto_size;
	Vector4 _content_rect;
	bool _layout_dirty;
};

#endif // LABEL_NODE_H
