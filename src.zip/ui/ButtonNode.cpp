#include "ButtonNode.h"
#include "graphics/Painter.h"

ButtonNode::ButtonNode()
    : _bg_color(NO_COLOR)
    , _bg_hover_color(NO_COLOR)
    , _border_radius(0)
	, _auto_size(true)
	, _layout_dirty(true) {
    _flags = NODE_FLAG_CLICKABLE | NODE_FLAG_HOVERABLE | NODE_FLAG_FOCUSABLE;
    _label = make_shared<LabelNode>();
    AddChild(_label);
}
bool ButtonNode::HitTestNode(const Vector2& p) {
	UpdateGeometry();
	return Node2D::HitTestNode(p);
}
void ButtonNode::SetText(const String& text) {
    _label->SetText(text);
	_layout_dirty = true;
}
void ButtonNode::SetBackgroundPadding(float padding) {
    _padding = Padding(padding);
	_layout_dirty = true;
}
void ButtonNode::SetBackgroundPadding(float left, float top, float right, float bottom) {
    _padding = Padding(left, top, right, bottom);
	_layout_dirty = true;
}
void ButtonNode::UpdateGeometry() {
	if (!_layout_dirty)
		return;
	if (_auto_size) {
		_label->SetAutoSize(true);
		_label->SetAlignment(TEXT_ALIGN_TOP_LEFT);
		_label->UpdateTextLayout();
		_label->SetOrigin(Vector2(_padding.left, _padding.top));
		_size.Set(_padding.left + _padding.right + _label->GetWidth(),
				  _padding.top + _padding.bottom + _label->GetHeight());
	} else {
		_label->SetAutoSize(false);
		_label->SetAlignment(TEXT_ALIGN_CENTER);
		_label->SetSize(_size);
		_label->UpdateTextLayout();
	}
	_layout_dirty = false;
}
void ButtonNode::PaintNode(Painter& p) {
	UpdateGeometry();

	Vector2 origin = ZERO_VECTOR2;
	Vector2 size = _size;
	if (_border_style.has_value()) {
		p.SetStrokeColor(_border_style->color);
		p.SetStrokeWidth(_border_style->width);
		// Convert <inside> border to <center> border.
		origin += _border_style->width * 0.5f;
		size -= _border_style->width;
	}
    p.SetColor(UnderMouse() ? _bg_hover_color : _bg_color);
    p.DrawRoundedRect(origin, size, _border_radius);
}
void ButtonNode::SetAutoSize(bool auto_size) {
	if (_auto_size != auto_size) {
		_auto_size = auto_size;
		_layout_dirty = true;
	}
}
void ButtonNode::SetBorderStyle(const Color& border_color, float border_width) {
	_border_style.emplace(BorderStyle { border_color, border_width });
}
