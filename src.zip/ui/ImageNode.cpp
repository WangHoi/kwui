#include "ImageNode.h"
#include "graphics/Painter.h"
#include "graphics/GraphicDevice.h"

void ImageNode::PaintNode(Painter& p) {
	if (!_bitmap) {
		BitmapSubItem item = GraphicDevice::Instance()
			->GetBitmap(_image_name, p.GetDpiScale());
		if (item)
			_bitmap = p.CreateBitmap(item);
	}
    if (_bitmap) {
		p.DrawBitmap(_bitmap.Get(), ZERO_VECTOR2, _size);
    }
}
void ImageNode::DiscardDeviceResources() {
	_bitmap = nullptr;
}
void ImageNode::SetImageName(const String& name) {
	_image_name = name;
	_bitmap = nullptr;
}
