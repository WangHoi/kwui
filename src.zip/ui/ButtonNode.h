#ifndef BUTTON_NODE_H
#define BUTTON_NODE_H

#include "LabelNode.h"
#include "string/String.h"
#include "graphics/TextLayout.h"
#include "graphics/Color.h"

struct BorderStyle {
	Color color;
	float width;
};

SMART_REF(ButtonNode)
class ButtonNode : public Node2D {
public:
    ButtonNode();
    void PaintNode(Painter& p) override;
    void OnHoverEnter(EventContext& ctx) override { ctx.RequestPaint(); }
    void OnHoverLeave(EventContext& ctx) override { ctx.RequestPaint(); }
	bool HitTestNode(const Vector2& p) override;
    optional<CursorType> GetCursorType() const override { return _cursor; }

    inline void SetCursorType(CursorType c) { _cursor.emplace(c); }
    void SetText(const String& text);
    inline void SetFontSize(float font_size) { _label->SetFontSize(font_size); }
    inline void SetColor(const Color& c) { _label->SetColor(c); }
    inline void SetBackgroundColor(const Color& color) { SetBackgroundColor(color, color); }
    inline void SetBackgroundColor(const Color& color, const Color& hover_color) {
        _bg_color = color;
        _bg_hover_color = hover_color;
    }
    void SetBorderRadius(float r) { _border_radius = r; }
	void SetAutoSize(bool auto_size);
	void SetBorderStyle(const Color& border_color, float border_width);

	// only available in AutoSize mode
	void SetBackgroundPadding(float padding);
	void SetBackgroundPadding(float left, float top, float right, float bottom);

	void UpdateGeometry();
private:
    LabelNodeRef _label;
    Color _bg_color;
    Color _bg_hover_color;
    Padding _padding;
    float _border_radius;
	optional<BorderStyle> _border_style;
	bool _auto_size;
	bool _layout_dirty;
    optional<CursorType> _cursor;
};

#endif // LABEL_NODE_H
