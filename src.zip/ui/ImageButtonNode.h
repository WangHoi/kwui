#ifndef IMAGE_BUTTON_NODE_H
#define IMAGE_BUTTON_NODE_H

#include "ImageNode.h"
#include "string/String.h"
#include "graphics/TextLayout.h"
#include "graphics/Color.h"

SMART_REF(ImageButtonNode)
class ImageButtonNode : public Node2D {
public:
    ImageButtonNode();
    void PaintNode(Painter& p) override;
	void OnHoverEnter(EventContext& ctx) override;
	void OnHoverLeave(EventContext& ctx) override;
	void OnSizeChanged() override;

	inline void SetImageName(const String& name) { SetImageName(name, name); }
	void SetImageName(const String& name, const String& hover_name);
	inline void SetBackgroundColor(const Color& color) { SetBackgroundColor(color, color); }
	inline void SetBackgroundColor(const Color& color, const Color& hover_color) {
		_bg_color = color;
		_bg_hover_color = hover_color;
	}

private:
    ImageNodeRef _image;
	ImageNodeRef _hover_image;
	Color _bg_color;
	Color _bg_hover_color;
};

#endif // IMAGE_LABEL_NODE_H
