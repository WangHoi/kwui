#ifndef IMAGE_NODE_H
#define IMAGE_NODE_H

#include "Node2D.h"
#include "string/String.h"
#include "graphics/TextLayout.h"
#include "graphics/Color.h"

SMART_REF(ImageNode)
class ImageNode : public Node2D {
public:
    ImageNode() {}
    void PaintNode(Painter& p) override;
	void DiscardDeviceResources() override;
    void SetImageName(const String& name);

private:
	String _image_name;
	ComPtr<ID2D1Bitmap> _bitmap;
};

#endif // IMAGE_NODE_H
