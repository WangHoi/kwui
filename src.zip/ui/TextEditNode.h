#ifndef TEXT_EDIT_NODE_H
#define TEXT_EDIT_NODE_H

#include "Node2D.h"
#include "string/String.h"
#include "graphics/TextLayout.h"
#include "graphics/Color.h"
#include "memory/memory_helpers.h"

class TextEditModel {
public:
    struct State {
        optional<int> sel_anchor;
        int sel_active;
        wstring text;
        State() : sel_anchor(nullopt), sel_active(0) {}
        inline bool HasSelection() const { return sel_anchor.has_value(); }
    };
    class Command {
    public:
        virtual ~Command() {}
        virtual void Apply(State& state) = 0;
        virtual void Rollback(State& state) = 0;
        virtual bool Merge(const Command& cmd) { return false; }
    };
    void ResetWithText(const wstring& text);
    //void InsertChar(int pos, char32 ch);
    void InsertText(int pos, const wstring& text, bool from_ime);
    // n ����Ϊ����
    void DeleteText(int pos, int n);
    void DeleteSelection(int sel_anchor, int sel_active);
    void ReplaceSelection(int sel_anchor, int sel_active,
                          const wstring& text);
    bool Undo();
    bool Redo();
    void ClearUndoHistory();
    inline const State& GetState() const { return _state; }

private:
    SMART_REF(Command);
    void AddCommand(CommandHandle&& cmd, bool try_merge = true);

    State _state;
    deque<CommandHandle> _cmds;
    size_t _cmd_top = 0;
};
SMART_REF(TextEditNode)
class TextEditNode : public Node2D {
public:
    TextEditNode();
    ~TextEditNode();
    void PaintNode(Painter& p) override;
    void OnFocusIn(EventContext& ctx) override;
    void OnFocusOut(EventContext& ctx) override;
    void OnCharacter(wchar_t ch, EventContext& ctx) override;
    void OnImeComposition(const wstring& text,
                          optional<int> caret_pos,
                          EventContext& ctx) override;
    void OnImeEndComposition(EventContext& ctx) override;
    void OnImeCommit(const wstring& text, EventContext& ctx) override;
    bool QueryImeCaretRect(Vector2& origin, Vector2& size) override;

    void OnKeyDown(int key, int modifiers, EventContext& ctx) override;
    void OnKeyUp(int key, int modifiers, EventContext& ctx) override {}
    void OnMouseDown(const Vector2& local_pos, EventContext& ctx) override;
    void OnSizeChanged() override;
    void OnAnimationFrame(double timestamp, EventContext& ctx) override;

    void SetColor(const Color& c) { _color = c; }
    void SetBackgroundColor(const Color& c) { _bg_color = c; }
    void SetBackgroundPadding(float padding) { _padding = padding; }
    void SetBorderRadius(float radius) { _border_radius = radius; }
    inline void SetSelectionColor(const Color& bg_color, const Color& text_color) {
        _selection_bg_color = bg_color;
        _selection_text_color = text_color;
    }
    inline void SetCaretColor(const Color& color) { _caret_color = color; }
    String GetText() const;
    void SetText(const String& text);
    void SetFontSize(float font_size);
    using TextChangedCallback = function<void(const wstring&)>;
    inline void SetTextChangedCallback(TextChangedCallback&& callback) {
        _text_changed_callback = callback;
    }

private:
    void UpdateTextLayout();
    // �����ı�ƫ�ƣ��������֡�����ƶ����������뷨Composing�ı�
    void UpdateCaretAndScroll();
    void InsertText(const wstring& text, bool ime_commit);
    void DeleteLeftChar();
    void DeleteRightChar();
    // TODO: �ع����� MoveCaret() ��ΪMoveCaretTo(make_selection) �� DoMoveCaret(pos, force, selection)
    void MoveCaret(int pos, bool force, bool keep_selection);
    void MoveCaretLeft(bool make_selection);
    void MoveCaretRight(bool make_selection);
    void MoveCaretToStart(bool make_selection);
    void MoveCaretToEnd(bool make_selection);
    wstring GetDisplayText() const;
    int GetDisplayCaretPos() const;
    void ClearComposingText();
    void SyncStateFromModel();
    void Undo();
    void Redo();
    void SelectAll();
    void ClipboardCopy();
    void ClipboardCut();
    void ClipboardPaste();
    inline bool HasSelection() const { return _sel_anchor.has_value(); }
    wstring GetSelectionText() const;
    void ResetCaretBlink();

    wstring _text;
    float _font_size;
    TextLayoutHandle _layout;
    Color _color;
    Color _bg_color;
    Color _selection_bg_color;
    Color _selection_text_color;
    Color _caret_color;
    bool _is_focused;
    int _caret_pos;
    Vector4 _caret_rect; // ����������������Ͻǣ�������scroll_offset
    Vector2 _scroll_offset;
    float _padding;
    float _border_radius;
    // ���뷨����ʱ�ı�����ƴ��
    struct ComposeState {
        wstring text;
        int caret_pos;	// �ڲ����λ��
    };
    optional<ComposeState> _composing;
    optional<int> _sel_anchor;	// ѡ���������һ��λ��
    TextEditModel _model;
    SMART_REF(CaretBlinkHelper);
    CaretBlinkHelperHandle _caret_blink_helper;
    TextChangedCallback _text_changed_callback;
};

#endif // TEXT_EDIT_NODE_H
