#pragma once
#include "pattern/singleton.h"
#include "data/data_helpers.h"
#include "string/String.h"
#include "memory/ResourceManager.h"
#include "install/InstallMessage.h"
#include "install/InstallTimer.h"
#include "HiddenMsgWindow.h"
#include "UvJobQueue.h"
#include <array>
#include <json.hpp>
using json = nlohmann::json;

class InstallServiceProxy {
public:
	void Quit();
	const String& GetTargetDir() const { return _target_dir; }
	void SetTargetDir(const String& dir);
	inline void SetProductName(const String& name) { SetProductName(name, name); }
	inline void SetProductName(const String& name, const String& display_name) {
		_product_name = name;
		_display_name = display_name;
	}
	inline void SetProductVersion(const String& version) { _product_version = version; }
	inline void SetVCRedistVersion(const String& version) { _vcredist_version = version; }
	// filename without directory
	inline void SetExeFilename(const String& filename) { _exe_filename = filename; }
	// filename without directory
	inline void SetUninstallerFilename(const String& filename) { _uninstaller_filename = filename; }
	inline void SetPublisher(const String& publisher) { _publisher = publisher; }
	inline void SetEstimatedSize(size_t size_kb) { _estimated_size_kb.emplace(size_kb); }

	void RunExe(const String& exe_filename,
		const Resource& exe,
		const vector<String>& args);
	void RunExe(const String& exe_filename,
		const vector<String>& args);
	void UnpackArchive(const Resource& data);
	// ����Դд�뵽��װĿ��Ŀ¼
	void UnpackResource(const String& filename, const Resource& data);
	void RemoveTargetDir();
	void CreateShortcut();
	void RemoveShortcut();
	void GetRunningProcessNew();
	void KillProcess(const vector<DWORD>& pid);
	void LaunchTargetExe();
	inline String GetProgramFilesDir() const { return _program_files_dir; }
	void DetectExistInstall();
	void RemoveExistInstall(const ExistInstallData& data);
	void DeleteUninstallerSelf();
	void ErrorUserAction(InstallMessageType orig_msg_type,
		DWORD worker_thread_id, InstallErrorAction action);

	inline void SetListener(WindowMsgListener *listener) { _msg_window.SetListener(listener); }
	inline HWND GetMsgHwnd() const { return _msg_window.GetHwnd(); }

private:
	struct WriteRequestContext;
	enum ConnectionState {
		CONN_STATE_INIT,
		CONN_STATE_CONNECTING,
		CONN_STATE_READY,
		NUM_CONN_STATES,
	};
	static constexpr std::array<const char*, NUM_CONN_STATES> CONN_STATE_NAMES = {
		"INIT",
		"CONNECTING",
		"READY",
	};

	InstallServiceProxy();
	void DoRunExe(RunExeRequest& exe);
	void DoUnpackArchive(UnpackArchiveRequest& req);
	void DoCreateShortcut(CreateShortcutRequest& req);
	void DoRemoveShortcut(RemoveShortcutRequest& req);
	void DoRemoveDir(RemoveDirRequest& req);
	void DoKillProcess(KillProcessRequest& req);
	void DoDetectExistInstall(DetectExistInstallRequest& req);
	void DoRemoveExistInstall(RemoveExistInstallRequest& req);
	void DoUnpackResource(UnpackResourceRequest& req);
	void DoErrorUserAction(::ErrorUserAction& req);
	void DoGetRunningProcess(GetRunningProcessRequest& req);
	void DoQuit();
	static DWORD WINAPI WorkerThreadFunc(LPVOID lpParam);

	struct PeerContext;
	struct WriteRequestContext;
	void SendMsg(PeerContext* dst, json&& j);
	bool ParseReadedData(PeerContext* ctx);
	PeerContext* FindContext(uv_pipe_t* pipe);
	PeerContext* GetFirstContext();
	static void OnNewConnection(uv_stream_t* server, int status);
	static void OnWritten(uv_write_t* req, int status);
	static void OnReaded(uv_stream_t* stream, ssize_t nread, const uv_buf_t* buf);

	struct PeerContext {
		uv_pipe_t* pipe;
		std::vector<uint8_t> read_buf;
	};

	String _target_dir;
	String _product_name;
	String _display_name;
	String _product_version;
	String _vcredist_version;
	String _exe_filename;
	String _uninstaller_filename;
	String _publisher;
	String _program_files_dir;
	optional<size_t> _estimated_size_kb;
	HiddenMsgWindow _msg_window;
	
	uv_loop_t* _loop = nullptr;
	uv_pipe_t* _server = nullptr;
	unordered_map<uv_pipe_t*, PeerContext> _peer_map;
	UvJobQueueRef _job_queue;
	uv_barrier_t _thread_start_barrier;
	HANDLE _thread_handle = NULL;

	SUPPORT_SINGLETON(InstallServiceProxy)
};
