#include "InstallDirector.h"
#include "InstallServiceProxy.h"
#include "debug/log.h"
#include "../installer_resource.h"
#include "AdminAuthorization.h"
#include <assert.h>
#include <WinReg.hpp>

DEFINE_SINGLETON_INSTANCE(InstallDirector);

const char* InstallDirector::STATE_NAMES[InstallDirector::NUM_STATES] = {
    "INIT",
	"START_SERVICE",
	"GET_RUNNING_PROCESS",
    "KILL_PROCESS",
    "CONFIRM_REMOVE_EXIST_PRODUCT",
    "REMOVE_EXIST_INSTALL",
    "START",
    "INSTALL_VCREDIST",
    "INSTALL_CHENGXUN",
    "CREATE_SHORTCUT",
    "UNPACK_UNINSTALLER",
    "CALM",
    "DONE",
};

InstallDirector::InstallDirector()
    : _state(STATE_INIT), _vcredist_installed(false)
{
	InstallServiceProxy::Instance()->SetListener(this);
    _progress_smoother = make_shared<InstallProgressSmoother>();
}
InstallDirector::~InstallDirector()
{
	InstallServiceProxy::Instance()->SetListener(nullptr);
}
void InstallDirector::SetConfig(const InstallConfig& config) {
    _config = config;
    auto IS = InstallServiceProxy::Instance();
    IS->SetPublisher(_config.publisher);
    IS->SetProductName(_config.product_name, _config.display_name);
    IS->SetProductVersion(_config.version);
    IS->SetVCRedistVersion(_config.vcredist_version);
    IS->SetExeFilename(_config.exe_filename);
    IS->SetUninstallerFilename(_config.uninstaller_filename);
    IS->SetEstimatedSize(_config.estimated_size_kb);

	c2_log("install config vcredist_version=\"%s\", product_name=\"%s\", version=\"%s\"\n",
		_config.vcredist_version.GetCString(),
		_config.display_name.GetCString(),
		_config.version.GetCString());
}
void InstallDirector::Start() {
    LoadResources();
    SetupUi();
	StartService();
    // CheckToKillProcess();
}
void InstallDirector::OnInstallMessage(InstallMessageBase* msg) {
	c2_log("got InstallMessage type %d in state %s.\n",
		msg->GetType(), STATE_NAMES[_state]);
	if (!_main_dialog) {
		c2_log("ignore InstallMessage, no main dialog.\n");
		return;
	}
	InstallMessageType msg_type = msg->GetType();
	if (msg_type == INSTALL_MSG_CONNECT_NOTIFY) {
		CheckToKillProcess();
	} else if (msg_type == INSTALL_MSG_KILL_PROCESS_REPLY) {
        CheckToRemoveInstalledProduct();
    } else if (msg_type == INSTALL_MSG_DETECT_EXIST_INSTALL_REPLY) {
        auto detect_msg = static_cast<DetectExistInstallReply*>(msg);
        _vcredist_installed = detect_msg->vcredist_installed;
        _exist_chengxun_install = detect_msg->chengxun_result;

        InstallProgressSmoother::Config cfg;
        cfg.remove_exist_install = _exist_chengxun_install.has_value();
        cfg.install_vcredist = !_vcredist_installed;
        _progress_smoother->SetConfig(cfg);

        if (_exist_chengxun_install.has_value()) {
            String target_dir;
			String version;
            const auto& d = *_exist_chengxun_install;
			target_dir = d.target_dir;
			version = d.version;
            _main_dialog->SetTargetDir(target_dir);

			optional<int> cmp = version.VersionCompare(_config.version);
			if (cmp.has_value() && *cmp == 1) {
				CloseConfirmDialog();
				_confirm_dialog = MakeConfirmDialog_RemoveExistProduct();
				_confirm_dialog->Show();
				SetState(STATE_CONFIRM_REMOVE_EXIST_PRODUCT);
			} else {
				EnterStart();
			}
        } else {
            EnterStart();
        }
    } else if (msg_type == INSTALL_MSG_REMOVE_EXIST_INSTALL_REPLY) {
        if (!_vcredist_installed)
            InstallVCRedist();
        else
            InstallChengxun();
    } else if (msg_type == INSTALL_MSG_RUN_EXE_REPLY) {
        if (_state == STATE_INSTALL_VCREDIST) {
            InstallChengxun();
        } else {
            c2_log("recv INSTALL_MSG_RUN_EXE_REPLY in wrong state %d.\n", _state);
        }
    } else if (msg_type == INSTALL_MSG_UNPACK_ARCHIVE_PROGRESS) {
        auto progress_msg = static_cast<UnpackArchiveProgress*>(msg);
        _progress_smoother->SetChengxunProgress(progress_msg->progress);
        //_main_dialog->SetProgress((float)(0.2 + 0.78 * (float)progress_msg->progress));
    } else if (msg_type == INSTALL_MSG_UNPACK_ARCHIVE_REPLY) {
        CreateShortcut();
    } else if (msg_type == INSTALL_MSG_CREATE_SHORTCUT_REPLY) {
        UnpackUninstaller();
    } else if (msg_type == INSTALL_MSG_UNPACK_RESOURCE_REPLY) {
        CalmDown();
    } else if (msg_type == INSTALL_MSG_ERROR_USER_CALLBACK) {
        auto callback_msg = static_cast<ErrorUserCallback*>(msg);
        if (callback_msg->request_msg_type == INSTALL_MSG_RUN_EXE_REQUEST) {
            if (_state == STATE_INSTALL_VCREDIST) {
                _progress_smoother->Pause();
                CloseConfirmDialog();
                _confirm_dialog = MakeConfirmDialog_CallbackError(callback_msg);
                _confirm_dialog->Show();
            } else {
                c2_log("ignore INSTALL_MSG_RUN_EXE_REQUEST ErrorUserCallback in state [%s]\n",
                       STATE_NAMES[_state]);
            }
        } else if (callback_msg->request_msg_type == INSTALL_MSG_UNPACK_ARCHIVE_REQUEST) {
            if (_state == STATE_INSTALL_CHENGXUN) {
                _progress_smoother->Pause();
                CloseConfirmDialog();
                _confirm_dialog = MakeConfirmDialog_CallbackError(callback_msg);
                _confirm_dialog->Show();
            } else {
                c2_log("ignore INSTALL_MSG_UNPACK_ARCHIVE_REQUEST ErrorUserCallback in state [%s]\n",
                       STATE_NAMES[_state]);
            }
        } else if (callback_msg->request_msg_type == INSTALL_MSG_UNPACK_RESOURCE_REQUEST) {
            if (_state == STATE_UNPACK_UNINSTALLER) {
                _progress_smoother->Pause();
                CloseConfirmDialog();
                _confirm_dialog = MakeConfirmDialog_CallbackError(callback_msg);
                _confirm_dialog->Show();
            } else {
                c2_log("ignore INSTALL_MSG_RUN_EXE_REQUEST ErrorUserCallback in state [%s]\n",
                       STATE_NAMES[_state]);
            }
        } else {
            c2_log("unhandled ErrorUserCallback original InstallMessageType %d\n",
                   callback_msg->request_msg_type);
        }
	} else if (msg_type == INSTALL_MSG_GET_RUNNING_PROCESS_REPLY) {
		auto reply_msg = static_cast<GetRunningProcessReply*>(msg);
		_pids = reply_msg->process_ids;
		if (!_pids.empty()) {
			CloseConfirmDialog();
			_confirm_dialog = MakeConfirmDialog_KillProcess();
			_confirm_dialog->Show();
			SetState(STATE_KILL_PROCESS);
		} else {
			CheckToRemoveInstalledProduct();
		}
	} else {
        c2_log("unhandled InstallMessageType %d\n", msg_type);
    }
}
void InstallDirector::SetupUi() {
    _main_dialog = make_shared<MainDialog>();
    _main_dialog->SetConfig(_config);
    _main_dialog->SetupUi();
    _main_dialog->SetStartInstallCallback(MakeCallback(this, &InstallDirector::StartInstallConfirmed));
    _main_dialog->SetInstallDoneCallback(MakeCallback(this, &InstallDirector::InstallDoneClicked));
    _main_dialog->SetCloseRequestedCallback(MakeCallback(this, &InstallDirector::CloseRequested));
    _progress_smoother->SetProgressCallback(MakeCallback(this, &InstallDirector::SmoothProgressCallback));
}
void InstallDirector::SetState(InstallDirector::State state) {
    if (_state != state) {
        c2_log("install state changed from [%s] to [%s]\n",
               STATE_NAMES[_state], STATE_NAMES[state]);
        _state = state;
    }
}
void InstallDirector::CheckToKillProcess() {
    auto IS = InstallServiceProxy::Instance();
    IS->GetRunningProcessNew();
	SetState(STATE_GET_RUNNING_PROCESS);
}
void InstallDirector::CheckToRemoveInstalledProduct() {
    InstallServiceProxy::Instance()->DetectExistInstall();
}
ConfirmDialogRef InstallDirector::MakeConfirmDialog_Quit() {
    ConfirmDialogUiConfig data;
    data.title_text = _config.display_name + u8"��װ��";
    data.label_text = u8"ȷ��Ҫֹͣ" + _config.display_name + u8"��װ��";
    data.action_btn_text = u8"������װ";
    data.cancel_btn_text = u8"ֹͣ";
    
    optional<ConfirmDialog::CreateData> create_data;
    HMONITOR monitor = MonitorFromWindow(_main_dialog->GetHwnd(), MONITOR_DEFAULTTOPRIMARY);
    create_data.emplace(Dialog::CreateData{
                            _main_dialog->GetDpiScale(),
                            monitor,
                        });

    auto dlg = make_shared<ConfirmDialog>(create_data);
    dlg->SetupUi(data);
    dlg->SetActionButtonClickedCallback(MakeCallback(this, &InstallDirector::CloseCancelled));
    dlg->SetCancelButtonClickedCallback(MakeCallback(this, &InstallDirector::InstallCancelled));
    return dlg;
}
ConfirmDialogRef InstallDirector::MakeConfirmDialog_ElevateError() {
	ConfirmDialogUiConfig data;
	data.title_text = _config.display_name + u8"��װ��";
	data.label_text = u8"��ȡ����ԱȨ��ʧ�ܣ�ȷ��Ҫֹͣ" + _config.display_name + u8"��װ��";
	data.action_btn_text = u8"����";
	data.cancel_btn_text = u8"ֹͣ��װ";

	optional<ConfirmDialog::CreateData> create_data;
	HMONITOR monitor = MonitorFromWindow(_main_dialog->GetHwnd(), MONITOR_DEFAULTTOPRIMARY);
	create_data.emplace(Dialog::CreateData{
							_main_dialog->GetDpiScale(),
							monitor,
		});

	auto dlg = make_shared<ConfirmDialog>(create_data);
	dlg->SetupUi(data);
	dlg->SetActionButtonClickedCallback(MakeCallback(this, &InstallDirector::RetryStartServiceRequested));
	dlg->SetCancelButtonClickedCallback(MakeCallback(this, &InstallDirector::InstallCancelled));
	return dlg;
}
ConfirmDialogRef InstallDirector::MakeConfirmDialog_KillProcess() {
    ConfirmDialogUiConfig data;
    data.title_text = _config.display_name + u8"��װ��";
    data.label_text = _config.display_name + u8"�������У��Ƿ�ر�"
        + _config.display_name + u8"������װ��";
    data.action_btn_text = u8"������װ";
    data.cancel_btn_text = u8"�Ժ���˵";
    auto dlg = make_shared<ConfirmDialog>();
    dlg->SetupUi(data);
    dlg->SetActionButtonClickedCallback(MakeCallback(this, &InstallDirector::KillProcessConfirmed));
    dlg->SetCancelButtonClickedCallback(MakeCallback(this, &InstallDirector::InstallCancelled));
    return dlg;
}
ConfirmDialogRef InstallDirector::MakeConfirmDialog_RemoveExistProduct() {
    ConfirmDialogUiConfig data;
    data.title_text = _config.display_name + u8"��װ��";
	data.label_text = u8"ϵͳ�Ѵ��ڽϸ߰汾���˰�װ�޷�����";
    data.cancel_btn_text = u8"֪����";
    auto dlg = make_shared<ConfirmDialog>();
    dlg->SetupUi(data);
    dlg->SetCancelButtonClickedCallback(MakeCallback(this, &InstallDirector::InstallCancelled));
    return dlg;
}
ConfirmDialogRef InstallDirector::MakeConfirmDialog_UnpackArchiveOrResourceError() {
    ConfirmDialogUiConfig data;
    data.title_text = _config.display_name + u8"��װ��";
    data.label_text = u8"��ѹ�ļ�ʧ�ܣ��˰�װ�޷�����";
    data.cancel_btn_text = u8"֪����";
    auto dlg = make_shared<ConfirmDialog>();
    dlg->SetupUi(data);
    dlg->SetCancelButtonClickedCallback(MakeCallback(this, &InstallDirector::InstallCancelled));
    return dlg;
}
void InstallDirector::KillProcessConfirmed(EventContext& ctx) {
    if (!_pids.empty()) {
        InstallServiceProxy::Instance()->KillProcess(_pids);
        _pids.clear();
    }
}
void InstallDirector::RemoveExistProductConfirmed(EventContext& ctx) {
    EnterStart();
}
void InstallDirector::InstallCancelled(EventContext& ctx) {
    CloseConfirmDialog();
    if (_main_dialog) {
        _main_dialog->Close();
        _main_dialog = NULL;
    }
}
void InstallDirector::StartInstallConfirmed(EventContext & ctx) {
    InstallServiceProxy::Instance()
        ->SetTargetDir(_main_dialog->GetTargetDir());
    Ui_EnterProgress();
    if (_exist_chengxun_install.has_value()) {
        RemoveExistInstall();
    } else {
        if (!_vcredist_installed)
            InstallVCRedist();
        else
            InstallChengxun();
    }
}
void InstallDirector::InstallDoneClicked(EventContext & ctx) {
    FinishInstall();
}
void InstallDirector::RetryStartServiceRequested(EventContext & ctx)
{
	StartService();
}
void InstallDirector::CloseRequested(EventContext& ctx) {
    if (_main_dialog->GetPage() == MainDialog::DONE_PAGE)
        return InstallCancelled(ctx);

    if (_quit_confirm_dialog)
        return;
    _quit_confirm_dialog = MakeConfirmDialog_Quit();
    _quit_confirm_dialog->Show();
}
void InstallDirector::CloseCancelled(EventContext& ctx) {
    if (_quit_confirm_dialog) {
        _quit_confirm_dialog->Close();
        _quit_confirm_dialog = nullptr;
        return;
    }
}
void InstallDirector::EnterStart() {
    _main_dialog->Show();
    _main_dialog->SetPage(MainDialog::MAIN_PAGE);
    SetState(STATE_START);
}
void InstallDirector::Ui_EnterProgress() {
    _timer.Restart();
    _progress_smoother->Start(*_main_dialog);
    _main_dialog->SetPage(MainDialog::PROGRESS_PAGE);
}
void InstallDirector::EnterDone() {
    _main_dialog->SetPage(MainDialog::DONE_PAGE);
    SetState(STATE_DONE);
    c2_log("Install done, time cost %.03lf s\n", _timer.GetElapsed());
}
void InstallDirector::InstallVCRedist() {
	c2_log(">>> %s\n", __func__);
    vector<String> args;
    args.push_back("/install");
    args.push_back("/quiet");
    args.push_back("/norestart");
    args.push_back("/log");
    args.push_back("vcredist_msvc2019_x86_install.log");
    InstallServiceProxy::Instance()->RunExe("vcredist_msvc2019_x86.exe", _res_vcredist, args);
    SetState(STATE_INSTALL_VCREDIST);
}
void InstallDirector::InstallChengxun() {
	c2_log(">>> %s\n", __func__);
    _progress_smoother->StartChengxunInstall();
    InstallServiceProxy::Instance()->UnpackArchive(_res_chengxun);
    SetState(STATE_INSTALL_CHENGXUN);
}
void InstallDirector::CreateShortcut() {
    //_main_dialog->SetProgress(0.98f);
    InstallServiceProxy::Instance()->CreateShortcut();
    SetState(STATE_CREATE_SHORTCUT);
}
void InstallDirector::FinishInstall() {
    _main_dialog->Hide();
    InstallServiceProxy::Instance()->LaunchTargetExe();
    _main_dialog->Close();
}
void InstallDirector::LoadResources() {
    auto RM = ResourceManager::Instance();
    _res_vcredist = RM->LoadResource(IDR_VCREDIST);
    _res_chengxun = RM->LoadResource(IDR_CHENGXUN_ARCHIVE);
}
void InstallDirector::RemoveExistInstall() {
    assert(_exist_chengxun_install.has_value());
    InstallServiceProxy::Instance()->RemoveExistInstall(*_exist_chengxun_install);
    SetState(STATE_REMOVE_EXIST_INSTALL);
}
void InstallDirector::UnpackUninstaller() {
    //_main_dialog->SetProgress(0.99f);
#if 0
    InstallServiceProxy::Instance()
        ->UnpackResource(_config.uninstaller_filename, _res_uninstaller);
    SetState(STATE_UNPACK_UNINSTALLER);
#endif
    CalmDown();
}
void InstallDirector::CloseConfirmDialog() {
    if (_confirm_dialog) {
        _confirm_dialog->Close();
        _confirm_dialog = nullptr;
    }
}
void InstallDirector::CalmDown() {
    c2_log("Work done, time cost %.03lf s, smooth_progress=%.03lf%%.\n",
           _timer.GetElapsed(), _progress_smoother->GetDisplayProgress() * 100.0);
    SetState(STATE_CALM);
}
void InstallDirector::StartService()
{
	SetState(STATE_START_SERVICE);
	bool succeeds;
	const std::string arguments = "--service";
	if (AdminAuthorization::HasAdminRights()) {
		succeeds = AdminAuthorization::ExecuteDirectly(arguments);
	} else {
		succeeds = AdminAuthorization::ExecuteElevated(arguments);
	}
	if (!succeeds) {
		_confirm_dialog = MakeConfirmDialog_ElevateError();
		_confirm_dialog->Show();
	}
}
ConfirmDialogRef InstallDirector::MakeConfirmDialog_CallbackError(ErrorUserCallback* msg) {
    ConfirmDialogUiConfig data;
    data.title_text = _config.display_name + u8"��װ��";
    data.label_text = u8"���ܴ�Ҫд����ļ���\n" + msg->detail;
    data.action_btn_text = u8"���³���";
    data.cancel_btn_text = u8"ֹͣ��װ";
    data.skip_btn_text = make_optional(u8"����");
    
    optional<ConfirmDialog::CreateData> create_data;
    HMONITOR monitor = MonitorFromWindow(_main_dialog->GetHwnd(), MONITOR_DEFAULTTOPRIMARY);
    create_data.emplace(Dialog::CreateData{
                            _main_dialog->GetDpiScale(),
                            monitor,
                        });

    auto dlg = make_shared<ConfirmDialog>(create_data);
    dlg->SetupUi(data);
    dlg->SetActionButtonClickedCallback(
        MakeCallback(this,
                     &InstallDirector::CallbackError_Retry,
                     msg->request_msg_type,
                     msg->src_thread_id
        ));
    dlg->SetCancelButtonClickedCallback(
        MakeCallback(this,
                     &InstallDirector::CallbackError_Cancel,
                     msg->request_msg_type,
                     msg->src_thread_id));
    dlg->SetSkipButtonClickedCallback(
        MakeCallback(this,
                     &InstallDirector::CallbackError_Skip,
                     msg->request_msg_type,
                     msg->src_thread_id));
    return dlg;
}
void InstallDirector::CallbackError_Retry(InstallMessageType orig_msg_type,
                                          DWORD worker_thread_id,
                                          EventContext& ctx) {
	InstallServiceProxy::Instance()
		->ErrorUserAction(orig_msg_type, worker_thread_id, INSTALL_ERR_RETRY);
    _progress_smoother->Resume();
}
void InstallDirector::CallbackError_Cancel(InstallMessageType orig_msg_type,
                                           DWORD worker_thread_id,
                                           EventContext& ctx) {
	InstallServiceProxy::Instance()
		->ErrorUserAction(orig_msg_type, worker_thread_id, INSTALL_ERR_ABORT);
	InstallCancelled(ctx);
}
void InstallDirector::CallbackError_Skip(InstallMessageType orig_msg_type,
                                         DWORD worker_thread_id,
                                         EventContext& ctx) {
	InstallServiceProxy::Instance()
		->ErrorUserAction(orig_msg_type, worker_thread_id, INSTALL_ERR_CONTINUE);
	_progress_smoother->Resume();
}
void InstallDirector::SmoothProgressCallback(double progress) {
    _main_dialog->SetProgress((float)progress);
    if (progress >= 1.0) {
        EnterDone();
    }
}
void InstallDirector::OnAppMessage(WPARAM wParam, LPARAM lParam) {
	auto install_msg = (InstallMessageBase*)lParam;
	OnInstallMessage(install_msg);
	delete install_msg;
}
