#ifndef LOGO_NODE_H
#define LOGO_NODE_H

#include "ui/Node2D.h"
#include "string/String.h"
#include "graphics/TextLayout.h"
#include "graphics/Color.h"

SMART_REF(LogoNode)
class LogoNode : public Node2D {
public:
    LogoNode();
    void SetImageName(const String& name);
    void StartAnimate(EventContext& ctx);
    void StopAnimate(EventContext& ctx);

    void PaintNode(Painter& p) override;
	void DiscardDeviceResources() override;
    void OnAnimationFrame(double timestamp, EventContext& ctx) override;

private:
	String _image_name;
	ComPtr<ID2D1Bitmap> _bitmap;
    ComPtr<ID2D1LinearGradientBrush> _brush;
    optional<double> _start_ts;
    optional<double> _stop_ts;
    optional<double> _stop_brush_yoffset;
    double _time;
};

#endif // LOGO_NODE_H
