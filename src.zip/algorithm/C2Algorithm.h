//
//  C2Algorithm.h
//  C2Engine
//
//  Created by mike luo on 2014-2-11.
//
//

#ifndef C2_ALGORITHM_H
#define C2_ALGORITHM_H

#include "hash_functions.h"
#include "crc32.h"

#endif // C2_ALGORITHM_H