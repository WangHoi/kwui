#ifndef HASH_FUNCTIONS_H
#define HASH_FUNCTIONS_H

#include "data/data_type.h"

inline uint32 hash_combine(uint32 seed, uint32 hash) {
    return seed ^ (hash + 0x9e3779b9 + (seed << 6) + (seed >> 2)); // copied from internet
}

inline uint32 hash_bool(bool b) {
    return b ? 0x4bed4bca : 0xb412b435; // a random number and its inversion
}

inline uint32 hash_float(float x) {
    return *((uint32*)(&x)) ^ 0xa12ee494; // xor a random number to avoid zero result
}

inline uint32 hash_float_array(const float* a, int count) {
    uint32 result = 0x53552f70; // a random number
    for (int i = 0; i < count; i++) result = hash_combine(result, hash_float(a[i]));
    return result;
}

inline uint32 hash_string(const char* s) {
    uint32 h = 0x811c9dc5;
    while (uint32 c = *s++) {
        h ^= c;
        h *= 0x1000193;
    }
    return h;
}

#endif // HASH_FUNCTIONS_H