#ifndef CRC_32_H
#define CRC_32_H

#include "data/data_type.h"

extern uint32 compute_crc32_length(byte* buffer, uint32 length, uint32 partial_crc = 0);
extern uint32 compute_crc32_null(byte* buffer, uint32 partial_crc = 0);

#endif // CRC_32_H