#ifndef _CRT_SECURE_NO_WARNINGS
#define _CRT_SECURE_NO_WARNINGS 1
#endif

#include "InstallService.h"
#include "install/InstallMessage.h"
#include "install/InstallTimer.h"
#include "text/EncodingManager.h"
#include "debug/log.h"
#include "debug/debug_helpers.h"
#include "platform/platform_helpers.h"
#include "memory/pack_utils.h"
#include <assert.h>
#include <stdlib.h>
#include <io.h>
#include <WinReg.hpp>
#include <msi.h>
#include <psapi.h>

static const size_t MAX_MSG_SIZE = 65536;

// TODO: make it random
const char* INSTALL_SERVICE_PIPE_NAME = "\\\\.\\pipe\\cx-install-service";

static const WCHAR* REG_SHELL_FOLDERS_KEY = L"Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Shell Folders";
static const WCHAR* REG_UNINSTALL_KEY = L"Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall";

static const WCHAR* VCREDIST_2019_X86_PROVIDER_KEY = L"SOFTWARE\\Classes\\Installer\\Dependencies\\Microsoft.VS.VC_RuntimeMinimumVSU_x86,v14";

static const uint32 MAX_QSTRING_LEN = 64 * 1024;

// Qt install related config key
static const String SC_PRODUCT_NAME = "ProductName";
static const String SC_PRODUCT_VERSION = "ProductVersion";
static const String SC_PRODUCT_UUID = "ProductUUID";
static const String SC_USER_START_MENU_DIR = "StartMenuDir";
static const String SC_DESKTOP_DIR = "DesktopDir";

static bool directory_exists(const wstring& dir);
static DWORD create_directory(const wstring& name);
static void create_directory_recursive(const wstring& name);
static BOOL delete_directory_recursive(const WCHAR* sPath);
static bool notify_shell_dir_updated(int csidl);
static bool create_link(const wstring& file_name, const wstring& link_name);
static void* memmem(const void* haystack, size_t haystackLen, const void* needle, size_t needleLen);
static bool parse_qvariant(const byte* data, const byte* end, wstring* out_str, size_t* consumed);
static unordered_map<String, String> parse_qvariant_hash(const byte* data, size_t len);
static bool parse_qstring(const byte* data, const byte* end, wstring* out_str, size_t* consumed);
static optional<byte> convert_hex(byte c);
static vector<byte> unescape_qt_data(const byte* data, size_t len);

extern "C" {
	void* archive_open(const uint8_t* data, size_t size, const char* u8_dest);
	unsigned long archive_num_entries(void* ptr);
	int archive_entry(void* ptr, int index, char *out_name, int *out_name_len);
	int archive_extract(void* ptr, int index);
	void archive_close(void *ptr);
}

struct InstallService::WorkerContext {
	~WorkerContext() {
		if (msg)
			delete msg;
	}
	InstallMessageBase* msg = nullptr;
	UvJobQueueRef job_queue;
	InstallService* service;
};

struct InstallService::WriteRequestContext {
	uv_write_t req;
	std::vector<uint8_t> buf;
};

static void on_alloc(uv_handle_t* handle, size_t suggested_size, uv_buf_t* buf)
{
	buf->base = (char*)malloc(suggested_size);
	buf->len = suggested_size;
}

unique_ptr<InstallService> InstallService::Create(uv_loop_t* loop)
{
	return std::make_unique<InstallService>(loop);
}

InstallService::InstallService(uv_loop_t* loop)
	: _loop(loop)
{
	_job_queue = UvJobQueue::Create(loop);
	ReConnect();
}

InstallService::~InstallService()
{
	
}
void InstallService::ReConnect()
{
	int ret;
	_pipe = (uv_pipe_t*)malloc(sizeof(uv_pipe_t));
	ret = uv_pipe_init(_loop, _pipe, 0);
	_pipe->data = this;
	uv_connect_t* conn = (uv_connect_t*)malloc(sizeof(uv_connect_t));
	conn->data = this;
	SetConnState(CONN_STATE_CONNECTING);
	uv_pipe_connect(conn, _pipe, INSTALL_SERVICE_PIPE_NAME, &InstallService::OnConnected);
}

void InstallService::Disconnect()
{
	if (_pipe) {
		_pipe->data = nullptr;
		uv_close((uv_handle_t*)_pipe, [](uv_handle_t* h) {
			free(h);
			});
		_pipe = nullptr;
	}
}

void InstallService::SetConnState(ConnectionState state)
{
	if (_conn_state != state) {
		_conn_state = state;
		c2_log("worker: state changed to %s\n", CONN_STATE_NAMES[state]);
	}
}

void InstallService::OnConnected(uv_connect_t* conn, int status)
{
	if (status) {
		c2_log("worker: connect to named pipe [%s] failed.\n", INSTALL_SERVICE_PIPE_NAME, uv_strerror(status));
		free(conn);
		return;
	}
	c2_log("worker: connected to named pipe [%s].\n", INSTALL_SERVICE_PIPE_NAME);
	auto me = (InstallService*)conn->data;
	if (me->_conn_state == CONN_STATE_CONNECTING && (uv_stream_t*)me->_pipe == conn->handle) {
		me->SendMsg({
			{ "cmd", "connect" },
			});
		uv_read_start((uv_stream_t*)me->_pipe, on_alloc, &InstallService::OnReaded);
		me->SetConnState(CONN_STATE_READY);
	}
	free(conn);
}
bool InstallService::ParseReadedData()
{
	if (_read_buf.size() < 4)
		return false;
	uint32_t size = unpack_be32(&_read_buf[0]);
	if (size > MAX_MSG_SIZE) {
		_read_buf.clear();
		return false;
	}
	if (4 + size > _read_buf.size())
		return false;
	try {
		json j = json::from_bson(_read_buf.begin() + 4, _read_buf.begin() + 4 + size);
		_read_buf.erase(_read_buf.begin(), _read_buf.begin() + 4 + size);

		c2_log("worker: recv [%s]\n", j.dump().c_str());

		std::string cmd = j["cmd"].get<std::string>();
		if (cmd == "run_exe") {
			auto req = new RunExeRequest;
			req->resource = j["data"]["resource"].get<UINT>();
			req->exe_filename = j["data"]["exe_filename"].get<std::string>();
			req->target_dir = j["data"]["target_dir"].get<std::string>();
			auto EM = EncodingManager::Instance();
			for (json& a : j["data"]["arguments"]) {
				req->arguments.push_back(EM->UTF8ToWide(a.get<std::string>()));
			}
			StartWorker(req);
		} else if (cmd == "unpack_archive") {
			auto req = new UnpackArchiveRequest;
			req->resource = j["data"]["resource"].get<UINT>();
			req->target_dir = j["data"]["target_dir"].get<std::string>();
			_target_dir = req->target_dir;
			StartWorker(req);
		} else if (cmd == "kill_process") {
			auto req = new KillProcessRequest;
			auto process_ids = j["data"]["process_ids"];
			for (auto& id : process_ids)
				req->process_ids.push_back(id.get<DWORD>());
			StartWorker(req);
		} else if (cmd == "unpack_resource") {
			auto req = new UnpackResourceRequest;
			req->resource = j["data"]["resource"].get<UINT>();
			req->filename = j["data"]["filename"].get<std::string>();
			req->target_dir = j["data"]["target_dir"].get<std::string>();
			StartWorker(req);
		} else if (cmd == "create_shortcut") {
			auto req = new CreateShortcutRequest;
			req->target_dir = j["data"]["target_dir"].get<std::string>();
			req->product_name = j["data"]["product_name"].get<std::string>();
			req->display_name = j["data"]["display_name"].get<std::string>();
			req->product_version = j["data"]["product_version"].get<std::string>();
			req->exe_filename = j["data"]["exe_filename"].get<std::string>();
			req->uninstaller_filename = j["data"]["uninstaller_filename"].get<std::string>();
			req->publisher = j["data"]["publisher"].get<std::string>();
			size_t estimated_size = j["data"]["estimated_size"].get<size_t>();
			if (estimated_size > 0)
				req->estimated_size.emplace(estimated_size);
			StartWorker(req);
		} else if (cmd == "remove_shortcut") {
			auto req = new RemoveShortcutRequest;
			req->product_name = j["data"]["product_name"].get<std::string>();
			req->display_name = j["data"]["display_name"].get<std::string>();
			StartWorker(req);
		} else if (cmd == "remove_dir") {
			auto req = new RemoveDirRequest;
			req->target_dir  = j["data"]["target_dir"].get<std::string>();
			StartWorker(req);
		} else if (cmd == "detect_exist_install") {
			auto req = new DetectExistInstallRequest;
			req->program_files_dir_hint = j["data"]["program_files_dir_hint"].get<std::string>();
			req->product_name = j["data"]["product_name"].get<std::string>();
			req->display_name = j["data"]["display_name"].get<std::string>();
			req->current_vcredist_version = j["data"]["current_vcredist_version"].get<std::string>();
			StartWorker(req);
		} else if (cmd == "remove_exist_install") {
			std::string data_type = j["data"]["type"].get<std::string>();
			auto req = new RemoveExistInstallRequest;
			ExistInstallData data;
			data.product_name = j["data"]["product_name"].get<std::string>();
			data.display_name = j["data"]["display_name"].get<std::string>();
			data.version = j["data"]["version"].get<std::string>();
			data.target_dir = j["data"]["target_dir"].get<std::string>();
			req->data = data;
			StartWorker(req);
		} else if (cmd == "error_user_action") {
			auto request_msg_type = (InstallMessageType)j["data"]["request_msg_type"].get<int>();
			auto action = (InstallErrorAction)j["data"]["action"].get<int>();
			auto req = new ErrorUserAction(request_msg_type, action);
			auto worker_thread_id = j["data"]["worker_thread_id"].get<DWORD>();
			if (!PostThreadMessageW(worker_thread_id, WM_APP, 0, (LPARAM)req)) {
				c2_log("ErrorUserAction: PostThreadMessage Error %08X\n", GetLastError());
				delete req;
			}
		} else if (cmd == "get_running_process") {
			auto req = new GetRunningProcessRequest;
			req->product_name = j["data"]["product_name"].get<std::string>();
			auto exe_filenames = j["data"]["exe_filenames"];
			for (auto& exe_filename : exe_filenames)
				req->exe_filenames.push_back(exe_filename.get<std::string>());
			StartWorker(req);
		} else {
			c2_log("worker: unhandled cmd type [%s]\n", cmd.c_str());
		}

		return true;
	}
	catch (...) {
		_read_buf.clear();
		return false;
	}
}

void InstallService::SendMsg(json&& j)
{
	c2_log("worker: send [%s]\n", j.dump().c_str());

	if (!_pipe) {
		c2_log("worker: send error: no connection.\n");
		return;
	}

	WriteRequestContext* ctx = new WriteRequestContext;
	ctx->buf.resize(4);
	json::to_bson(j, ctx->buf);
	uint32_t size = (uint32_t)(ctx->buf.size() - 4);
	pack_be32(&ctx->buf[0], size);

	uv_buf_t uv_buf = uv_buf_init((char*)ctx->buf.data(), ctx->buf.size());
	ctx->req.data = ctx;
	int ret = uv_write(&ctx->req, (uv_stream_t*)_pipe, &uv_buf, 1, &InstallService::OnWritten);
	if (ret < 0) {
		c2_log("worker: send error: %s\n", uv_strerror(ret));
		uv_close((uv_handle_t*)_pipe, [](uv_handle_t* h) { free(h); });
		_pipe = nullptr;
	}
}

void InstallService::OnWritten(uv_write_t* req, int status)
{
	WriteRequestContext* ctx = (WriteRequestContext*)req->data;
	delete ctx;
}

void InstallService::OnReaded(uv_stream_t* stream, ssize_t nread, const uv_buf_t* buf)
{
	auto me = (InstallService*)stream->data;
	if (nread < 0) {
		c2_log("worker: read error %s, exit.\n", uv_strerror(nread));
		me->Disconnect();
		uv_stop(stream->loop);
		return;
	}
	if (nread == 0)
		return;

	std::copy(buf->base, buf->base + nread, std::back_inserter(me->_read_buf));
	free(buf->base);

	while (me->ParseReadedData()) {}
}
void InstallService::StartWorker(InstallMessageBase* msg)
{
	WorkerContext *ctx = new WorkerContext;
	ctx->msg = msg;
	ctx->job_queue = _job_queue;
	ctx->service = this;
	HANDLE h = CreateThread(NULL, 0, &InstallService::WorkerThreadFunc, ctx, 0, NULL);
	if (h == INVALID_HANDLE_VALUE) {
		c2_log("create worker thread failed, GetLastError()=0x%08X\n", GetLastError());
		delete ctx;
	}
}
DWORD WINAPI InstallService::WorkerThreadFunc(LPVOID lpParam) {
	auto ctx = (WorkerContext*)lpParam;
	switch (ctx->msg->GetType()) {
	case INSTALL_MSG_RUN_EXE_REQUEST:
		ctx->service->DoRunExe(*(RunExeRequest*)ctx->msg);
		break;
	case INSTALL_MSG_UNPACK_ARCHIVE_REQUEST:
		ctx->service->DoUnpackArchive(*(UnpackArchiveRequest*)ctx->msg);
		break;
	case INSTALL_MSG_CREATE_SHORTCUT_REQUEST:
		ctx->service->DoCreateShortcut(*(CreateShortcutRequest*)ctx->msg);
		break;
	case INSTALL_MSG_REMOVE_SHORTCUT_REQUEST:
		ctx->service->DoRemoveShortcut(*(RemoveShortcutRequest*)ctx->msg);
		break;
	case INSTALL_MSG_REMOVE_DIR_REQUEST:
		ctx->service->DoRemoveDir(*(RemoveDirRequest*)ctx->msg);
		break;
	case INSTALL_MSG_KILL_PROCESS_REQUEST:
		ctx->service->DoKillProcess(*(KillProcessRequest*)ctx->msg);
		break;
	case INSTALL_MSG_DETECT_EXIST_INSTALL_REQUEST:
		ctx->service->DoDetectExistInstall(*(DetectExistInstallRequest*)ctx->msg);
		break;
	case INSTALL_MSG_REMOVE_EXIST_INSTALL_REQUEST:
		ctx->service->DoRemoveExistInstall(*(RemoveExistInstallRequest*)ctx->msg);
		break;
	case INSTALL_MSG_UNPACK_RESOURCE_REQUEST:
		ctx->service->DoUnpackResource(*(UnpackResourceRequest*)ctx->msg);
		break;
	case INSTALL_MSG_GET_RUNNING_PROCESS_REQUEST:
		ctx->service->DoGetRunningProcess(*(GetRunningProcessRequest*)ctx->msg);
		break;
	default:
		c2_log("WorkerThreadFunc(): unhandled install message type %d\n", ctx->msg->GetType());
	}
	delete ctx;
	return 0;
}
void InstallService::DoRunExe(RunExeRequest& request) {
	InstallTimer timer;
	String exe_path;
	wstring target_filename;
	DWORD ret;
	HANDLE hfile;
	BOOL success;
	DWORD written = 0;
	RunExeReply *reply = new RunExeReply;
	PROCESS_INFORMATION pi = {};
	wstring cmdline;
	STARTUPINFOW si = {};
	si.cb = sizeof(si);
	auto EM = EncodingManager::Instance();
	wstring target_dir = EM->UTF8ToWide(request.target_dir);

	c2_log("Start RunExe [%s].\n", request.exe_filename.GetCString());

	reply->src_thread_id = GetCurrentThreadId();
	if (request.resource) {
		reply->resource = request.resource;

		create_directory_recursive(target_dir);

		exe_path = request.target_dir;
		exe_path.Append('\\');
		exe_path.Append(request.exe_filename);
		target_filename = EM->UTF8ToWide(exe_path);

	retry_create_file:
		hfile = CreateFileW(target_filename.c_str(),
			GENERIC_WRITE,
			0,
			NULL,
			CREATE_ALWAYS,
			FILE_ATTRIBUTE_NORMAL,
			NULL);
		if (hfile == NULL || hfile == INVALID_HANDLE_VALUE) {
			c2_log("RunExe: create file [%s] failed, GetLastError()=0x%08X.\n",
				exe_path.GetCString(), GetLastError());
			InstallErrorAction action
				= ErrorUserConfirm(request.src_thread_id, request.src_hwnd, request.GetType(), request.exe_filename);
			if (action == INSTALL_ERR_ABORT) {
				goto error_out;
			} else if (action == INSTALL_ERR_RETRY) {
				goto retry_create_file;
			} else if (action == INSTALL_ERR_CONTINUE) {
				goto error_out;
			}
		}
		Resource res = ResourceManager::Instance()->LoadResource(request.resource);
		if (res.IsValid()) {
			success = WriteFile(hfile, res.data, res.size, &written, NULL);
		} else {
			success = FALSE;
		}
		if (!success) {
			c2_log("RunExe: write file [%s] failed, GetLastError()=0x%08X.\n",
				exe_path.GetCString(), GetLastError());
			goto error_out;
		}
		if (written != res.size) {
			c2_log("RunExe: write file [%s] failed, written bytes=%u.\n",
				exe_path.GetCString(), written);
			goto error_out;
		}
		if (!CloseHandle(hfile)) {
			c2_log("RunExe: close file handle [%s] failed, GetLastError()=0x%08X.\n",
				exe_path.GetCString(), GetLastError());
			goto error_out;
		}
		cmdline = L"\"" + target_filename + L"\"";
	} else {
		cmdline = EM->UTF8ToWide(request.exe_filename);
		String dir = request.exe_filename;
		dir.RemoveLastSection('\\');
		if (dir.StartsWith("\""))
			dir = dir.Substr(1);
		target_dir = EM->UTF8ToWide(dir);
	}

	for (auto& a : request.arguments) {
		cmdline.push_back(L' ');
		cmdline += a;
	}

	success = CreateProcessW(NULL,
		&cmdline[0],
		NULL,
		NULL,
		FALSE,
		0,
		NULL,
		target_dir.c_str(),
		&si,
		&pi);
	if (!success) {
		c2_log("RunExe: create process cmdline [%s] failed, GetLastError()=0x%08X.\n",
			EM->WideToUTF8(cmdline).GetCString(), GetLastError());
		goto error_out;
	}
	ret = WaitForSingleObject(pi.hProcess, INFINITE);
	if (ret != WAIT_OBJECT_0) {
		if (ret == WAIT_FAILED) {
			c2_log("RunExe: wait [%s] exit failed, ret 0x%08X, GetLastError()=0x%08X\n",
				request.exe_filename.GetCString(), ret, GetLastError());
		} else {
			c2_log("RunExe: wait [%s] exit failed, ret 0x%08X\n",
				request.exe_filename.GetCString(), ret);
		}
		CloseHandle(pi.hProcess);
		goto error_out;
	}
	success = GetExitCodeProcess(pi.hProcess, &reply->exit_code);
	if (!success) {
		c2_log("RunExe: GetExitCodeProcess [%s] failed, GetLastError()=0x%08X\n",
			request.exe_filename.GetCString(), GetLastError());
		CloseHandle(pi.hProcess);
		goto error_out;
	}
	c2_log("RunExe: [%s] exit code 0x%08X\n",
		request.exe_filename.GetCString(), reply->exit_code);
	CloseHandle(pi.hProcess);
	reply->status = 0;

error_out:
	success = post_thread_message(WM_APP, 0, reply);
	c2_log("Done RunExe [%s], time cost %.03lf s.\n",
		request.exe_filename.GetCString(),
		timer.GetElapsed());
}

DWORD create_directory(const wstring& name) {
	return CreateDirectoryW((LPCWSTR)name.c_str(), NULL) ? 0 : GetLastError();
}
bool directory_exists(const wstring& dir) {
	DWORD attribs = ::GetFileAttributesW(dir.c_str());
	if (attribs == INVALID_FILE_ATTRIBUTES) {
		return false;
	}
	return (attribs & FILE_ATTRIBUTE_DIRECTORY);
}
void create_directory_recursive(const wstring& dir_) {
	size_t off = 3;
	wstring dir = dir_;
	size_t idx;
	while ((idx = dir.find(L'\\', off)) != wstring::npos) {
		dir[idx] = L'\0';
		create_directory(dir);
		dir[idx] = L'\\';
		off = idx + 1;
	}
	create_directory(dir_);
}

InstallErrorAction InstallService::ErrorUserConfirm(DWORD ui_thread_id, HWND hwnd,
	InstallMessageType orig_request_type,
	const String& data) {
	MSG msg;
	BOOL success;
	InstallErrorAction action;

	PeekMessageW(&msg, NULL, 0, 0, PM_NOREMOVE);

	auto request = new ErrorUserCallback(orig_request_type, data);
	request->src_thread_id = GetCurrentThreadId();
	success = post_thread_message(WM_APP, 0, request);
	if (!success) {
		delete request;
		return INSTALL_ERR_ABORT;
	}

	success = GetMessageW(&msg, NULL, 0, 0);
	if (msg.message != WM_APP) {
		c2_log("ErrorUserConfirm() recv unexpect window msg 0x%04X\n", msg.message);
		return INSTALL_ERR_ABORT;
	}
	auto reply_base = (InstallMessageBase*)msg.lParam;
	if (reply_base->GetType() != INSTALL_MSG_ERROR_USER_ACTION) {
		c2_log("ErrorUserConfirm() recv unexpect InstallMessageType %d\n", reply_base->GetType());
		delete reply_base;
		return INSTALL_ERR_ABORT;
	}
	auto reply = (ErrorUserAction*)reply_base;
	reply_base = nullptr;
	if (reply->request_msg_type != orig_request_type) {
		c2_log("ErrorUserConfirm() recv unexpect original request InstallMessageType %d\n",
			reply->request_msg_type);
		delete reply;
		return INSTALL_ERR_ABORT;
	}
	action = reply->action;
	delete reply;
	if (action == INSTALL_ERR_RETRY || action == INSTALL_ERR_CONTINUE) {
		::Sleep(50);
	}
	return action;
}
static BOOL is_dots(const WCHAR* str) {
	if (wcscmp(str, L".") && wcscmp(str, L".."))
		return FALSE;
	return TRUE;
}
BOOL delete_directory_recursive(const WCHAR* sPath) {
	HANDLE hFind;    // file handle
	WIN32_FIND_DATAW find_file_data;
	WCHAR dir_path[MAX_PATH];
	WCHAR filename[MAX_PATH];

	wcscpy(dir_path, sPath);
	wcscat(dir_path, L"\\*");    // searching all files

	wcscpy(filename, sPath);
	wcscat(filename, L"\\");

	// find the first file
	hFind = FindFirstFileW(dir_path, &find_file_data);
	if (hFind == INVALID_HANDLE_VALUE)
		return FALSE;
	wcscpy(dir_path, filename);

	auto EM = EncodingManager::Instance();
	bool bSearch = true;
	while (bSearch) {    // until we find an entry
		if (FindNextFile(hFind, &find_file_data)) {
			if (is_dots(find_file_data.cFileName))
				continue;

			wcscat(filename, find_file_data.cFileName);
			if ((find_file_data.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)) {
				// we have found a directory, recurse
				if (!delete_directory_recursive(filename)) {
					c2_log("Delete directory [%s] failed.\n", EM->WideToUTF8(filename).GetCString());
					//FindClose(hFind);
					//return FALSE;    // directory couldn��t be deleted
				}
				// remove the empty directory
				RemoveDirectoryW(filename);
				wcscpy(filename, dir_path);
			} else {
				if (find_file_data.dwFileAttributes & FILE_ATTRIBUTE_READONLY) {
					// change read-only file mode
					_wchmod(filename, _S_IWRITE);
				}
				if (!DeleteFileW(filename)) {    // delete the file
					c2_log("Delete file [%s] failed.\n", EM->WideToUTF8(filename).GetCString());
					//FindClose(hFind);
					//return FALSE;
				}
				wcscpy(filename, dir_path);
			}
		} else {
			// no more files there
			if (GetLastError() == ERROR_NO_MORE_FILES) {
				bSearch = false;
			} else {
				// some error occurred; close the handle and return FALSE
				FindClose(hFind);
				return FALSE;
			}
		}
	}
	FindClose(hFind);                  // close the file handle
	return RemoveDirectoryW(sPath);     // remove the empty directory
}
bool notify_shell_dir_updated(int csidl) {
	PIDLIST_ABSOLUTE pidl;  // Force start menu/desktop cache update
	if (SUCCEEDED(SHGetFolderLocation(0, csidl, 0, 0, &pidl))) {
		SHChangeNotify(SHCNE_UPDATEDIR, SHCNF_IDLIST, pidl, 0);
		CoTaskMemFree(pidl);
		return true;
	}
	return false;
}
bool create_link(const wstring& file_name, const wstring& link_name) {
	// CoInitialize cleanup object
	wstring working_dir = file_name;
	{
		size_t pos = working_dir.rfind(L'\\');
		if (pos != wstring::npos)
			working_dir.erase(pos);
	}

	ComPtr<IShellLink> psl;
	if (FAILED(CoCreateInstance(CLSID_ShellLink, NULL, CLSCTX_INPROC_SERVER,
		IID_IShellLink, (LPVOID*)psl.GetAddressOf()))) {
		return false;
	}

	// TODO: implement this server side, since there's not Qt equivalent to set working dir and arguments
	psl->SetPath(file_name.c_str());
	psl->SetWorkingDirectory(working_dir.c_str());

	ComPtr<IPersistFile> ppf;
	if (SUCCEEDED(psl.As(&ppf))) {
		if (FAILED(ppf->Save(link_name.c_str(), true))) {
			return false;
		}
	}
	return true;
}
bool InstallService::post_thread_message(UINT Msg, WPARAM wParam, InstallMessageBase *lParam) {
	c2_log("post_thread_message InstallMessage type %d\n", lParam->GetType());
	_job_queue->Submit([=]() {
		this->HandlePostThreadMessage(Msg, wParam, lParam);
		});
	return true;
}

void InstallService::HandlePostThreadMessage(UINT /* Msg */, WPARAM /* wParam */, InstallMessageBase *msg)
{
	switch (msg->GetType()) {
	case INSTALL_MSG_RUN_EXE_REPLY: {
		auto reply = (RunExeReply*)msg;
		json j({
			{ "cmd", "run_exe_reply" },
			{ "data", {
				{ "resource", reply->resource },
				{ "status", reply->status },
				{ "exit_code", reply->exit_code },
			}}
		});
		SendMsg(move(j));
		break;
	}
	case INSTALL_MSG_UNPACK_ARCHIVE_REPLY: {
		auto reply = (UnpackArchiveReply*)msg;
		json j({
			{ "cmd", "unpack_archive_reply" },
			{ "data", {
				{ "resource", reply->resource },
				{ "status", reply->status },
			}}
			});
		SendMsg(move(j));
		break;
	}
	case INSTALL_MSG_UNPACK_ARCHIVE_PROGRESS: {
		auto reply = (UnpackArchiveProgress*)msg;
		json j({
			{ "cmd", "unpack_archive_progress" },
			{ "data", {
				{ "resource", reply->resource },
				{ "progress", reply->progress },
			}}
			});
		SendMsg(move(j));
		break;
	}
	case INSTALL_MSG_CREATE_SHORTCUT_REPLY: {
		auto reply = (CreateShortcutReply*)msg;
		json j({
			{ "cmd", "create_shortcut_reply" },
			{ "data", {
				{ "resource", reply->resource },
				{ "status", reply->status },
			}}
			});
		SendMsg(move(j));
		break;
	}
	case INSTALL_MSG_REMOVE_SHORTCUT_REPLY: {
		auto reply = (RemoveShortcutReply*)msg;
		json j({
			{ "cmd", "remove_shortcut_reply" },
			{ "data", {
				{ "resource", reply->resource },
				{ "status", reply->status },
			}}
			});
		SendMsg(move(j));
		break;
	}
	case INSTALL_MSG_REMOVE_DIR_REPLY: {
		auto reply = (RemoveDirReply*)msg;
		json j({
			{ "cmd", "remove_dir_reply" },
			{ "data", {
				{ "resource", reply->resource },
				{ "status", reply->status },
			}}
			});
		SendMsg(move(j));
		break;
	}
	case INSTALL_MSG_KILL_PROCESS_REPLY: {
		auto reply = (KillProcessReply*)msg;
		json j({
			{ "cmd", "kill_process_reply" },
			{ "data", {
				{ "resource", reply->resource },
				{ "status", reply->status },
			}}
			});
		SendMsg(move(j));
		break;
	}
	case INSTALL_MSG_DETECT_EXIST_INSTALL_REPLY: {
		auto reply = (DetectExistInstallReply*)msg;
		json chengxun_result;
		if (reply->chengxun_result.has_value()) {
			ExistInstallData data = *reply->chengxun_result;
			chengxun_result = json::object({
				{ "type", "my" },
				{ "product_name", data.product_name.GetCString() },
				{ "display_name", data.display_name.GetCString() },
				{ "target_dir", data.target_dir.GetCString() },
				{ "version", data.version.GetCString() },
				});
		}
		json j({
			{ "cmd", "detect_exist_install_reply" },
			{ "data", {
				{ "resource", reply->resource },
				{ "vcredist_installed", reply->vcredist_installed },
				{ "chengxun_result", chengxun_result },
			}}
			});
		SendMsg(move(j));
		break;
	}
	case INSTALL_MSG_REMOVE_EXIST_INSTALL_REPLY: {
		auto reply = (RemoveExistInstallReply*)msg;
		json j({
			{ "cmd", "remove_exist_install_reply" },
			{ "data", {
				{ "resource", reply->resource },
				{ "status", reply->status },
			}}
			});
		SendMsg(move(j));
		break;
	}
	case INSTALL_MSG_UNPACK_RESOURCE_REPLY: {
		auto reply = (UnpackResourceReply*)msg;
		json j({
			{ "cmd", "unpack_resource_reply" },
			{ "data", {
				{ "resource", reply->resource },
				{ "status", reply->status },
			}}
			});
		SendMsg(move(j));
		break;
	}
	case INSTALL_MSG_ERROR_USER_CALLBACK: {
		auto reply = (ErrorUserCallback*)msg;
		json j({
			{ "cmd", "error_user_callback" },
			{ "data", {
				{ "src_thread_id", reply->src_thread_id },
				{ "request_msg_type", reply->request_msg_type },
				{ "detail", reply->detail.GetCString() },
			}}
			});
		SendMsg(move(j));
		break;
	}
	case INSTALL_MSG_GET_RUNNING_PROCESS_REPLY: {
		auto reply = (GetRunningProcessReply*)msg;
		json process_ids = json::array();
		for (DWORD id : reply->process_ids)
			process_ids.push_back(id);
		json j({
			{ "cmd", "get_running_process_reply" },
			{ "data", {
				{ "process_ids", process_ids }
			}}
			});
		SendMsg(move(j));
		break;
	}

	default:
		c2_log("HandlePostThreadMessage: msg type %d not handled.\n", msg->GetType());
	}
}

void InstallService::DoUnpackArchive(UnpackArchiveRequest& request) {
	InstallTimer timer;
	InstallTimer notify_timer;
	bool success;
	auto EM = EncodingManager::Instance();
	wstring target_dir = EM->UTF8ToWide(request.target_dir);
	UnpackArchiveReply *reply = new UnpackArchiveReply;
	reply->resource = request.resource;
	reply->src_thread_id = GetCurrentThreadId();

	c2_log("Start UnpackArchive, target dir=[%s].\n", request.target_dir.GetCString());

	//uintptr_t d = (uintptr_t)request.resource.data / 4096 * 4096;
	//uintptr_t s = (request.resource.size + 4095) / 4096 * 4096;
	//WIN32_MEMORY_RANGE_ENTRY r = { (LPVOID)d, (SIZE_T)s };
	//success = PrefetchVirtualMemory(GetCurrentProcess(), 1, &r, 0);
	//c2_log("%.03lf PrefetchVirtualMemory ret %d.\n", timer.GetElapsed(), success);
	//::Sleep(1500);

	create_directory_recursive(target_dir);
	if (!directory_exists(target_dir)) {
		c2_log("Directory [%s] not exists, retry once.\n", request.target_dir.GetCString());
		::Sleep(500);
		create_directory_recursive(target_dir);
	}

	Resource resource = ResourceManager::Instance()->LoadResource(request.resource);
	int ret = -1;
	char filename_buf[1024] = {};
	int filename_len = 0;
	void* archive = nullptr;
	int num_entries = 0;
	int i;
	double file_progress = 0.0;
	auto report_progress = [&](bool force = false) {
		if (force || notify_timer.GetElapsed() >= 0.05) {
			auto time = notify_timer.Restart();
			auto p = new UnpackArchiveProgress;
			p->resource = reply->resource;
			p->src_thread_id = reply->src_thread_id;
			p->progress = file_progress;
			//p->progress = max(file_progress, dec_progress);
			/*
			c2_log("%.03lf Unpack progress %.0f%% (%.0f%%/%.0f%%)\n",
				   time,
				   p->progress * 100.0f,
				   file_progress * 100.0f,
				   dec_progress * 100.0f);
			*/
			if (!post_thread_message(WM_APP, 0, p)) {
				c2_log("Notify ui [UnpackArchiveProgress] failed, GetLastError()=0x%08X\n", GetLastError());
				delete p;
			}
		}
	};

	if (!resource.IsValid()) {
		c2_log("LoadResource failed.\n");
		goto error_out;
	}

	archive = archive_open(resource.data, resource.size, request.target_dir.GetCString());
	if (!archive) {
		c2_log("%.03lf archive_open failed.\n", timer.GetElapsed());
		goto error_out;
	}
	num_entries = archive_num_entries(archive);
	for (i = 0; i < num_entries; ++i) {
		memset(filename_buf, 0, sizeof(filename_buf));
		ret = archive_entry(archive, i, filename_buf, &filename_len);
		if (ret != 0) {
			c2_log("archive_entry index %d failed.\n", i);
			goto error_out;
		}
		String filename(filename_buf, filename_len);
		ret = archive_extract(archive, i);
		while (ret != 0) {
			c2_log("archive_extract [%s] error 0x%08X\n", filename_buf, ret);
			String data = request.target_dir + "\\" + filename;
			InstallErrorAction action
				= ErrorUserConfirm(request.src_thread_id, request.src_hwnd, request.GetType(), data);
			if (action == INSTALL_ERR_ABORT) {
				ret = -1;
				goto error_out;
			} else if (action == INSTALL_ERR_CONTINUE) {
				break;
			} else if (action == INSTALL_ERR_RETRY) {
				ret = archive_extract(archive, i);
			}
		}

		file_progress = (double(i) + 1.0) / num_entries;
		report_progress();
	}

error_out:
	file_progress = 1.0;
	report_progress(true);

	reply->status = ret;

	if (archive) {
		archive_close(archive);
		archive = nullptr;
	}
	success = post_thread_message(WM_APP, 0, reply);
	if (!success)
		delete reply;
	c2_log("Done UnpackArchive, time cost %.03lf s.\n", timer.GetElapsed());
}
void InstallService::DoCreateShortcut(CreateShortcutRequest& request) {
	bool success;
	auto EM = EncodingManager::Instance();
	wstring product_name = EM->UTF8ToWide(request.product_name);
	wstring display_name = EM->UTF8ToWide(request.display_name);
	wstring product_version = EM->UTF8ToWide(request.product_version);
	wstring target_dir = EM->UTF8ToWide(request.target_dir);
	wstring exe_filename = EM->UTF8ToWide(request.exe_filename);
	wstring uninstaller_filename = EM->UTF8ToWide(request.uninstaller_filename);
	wstring publisher = EM->UTF8ToWide(request.publisher);
	wstring shortcut_filename = display_name + L".lnk";
	wstring uninstaller_shortcut_filename = L"ж��" + shortcut_filename;
	CreateShortcutReply *reply = new CreateShortcutReply;
	reply->src_thread_id = GetCurrentThreadId();
	CoInitializeEx(NULL, COINIT_MULTITHREADED);
	try {
		wstring u16_filename;
		wstring u16_linkname;
		DWORD wres;

		winreg::RegKey shell_folders_key(HKEY_LOCAL_MACHINE, REG_SHELL_FOLDERS_KEY, KEY_READ);
		// StartMenu Shortcut
		wstring programs_dir = shell_folders_key.GetStringValue(L"Common Programs");
		programs_dir += L'\\';
		programs_dir += display_name;
		wres = create_directory(programs_dir);
		c2_log("CreateDirectory [%s] result 0x%08X\n",
			EM->WideToUTF8(programs_dir).GetCString(),
			wres);

		u16_filename = target_dir + L'\\' + exe_filename;
		u16_linkname = programs_dir + L'\\' + shortcut_filename;
		success = create_link(u16_filename, u16_linkname);
		if (success) {
			c2_log("CreateShortcut [%s]->[%s] success\n",
				EM->WideToUTF8(u16_linkname).GetCString(),
				EM->WideToUTF8(u16_filename).GetCString());
		} else {
			c2_log("CreateShortcut [%s]->[%s] failed, GetLastError()=0x%08X\n",
				EM->WideToUTF8(u16_linkname).GetCString(),
				EM->WideToUTF8(u16_filename).GetCString(),
				GetLastError());
			//goto error_out;
		}

		u16_filename = target_dir + L'\\' + uninstaller_filename;
		u16_linkname = programs_dir + L'\\' + uninstaller_shortcut_filename;
		success = create_link(u16_filename, u16_linkname);
		if (success) {
			c2_log("CreateShortcut [%s]->[%s] success\n",
				EM->WideToUTF8(u16_linkname).GetCString(),
				EM->WideToUTF8(u16_filename).GetCString());
		} else {
			c2_log("CreateShortcut [%s]->[%s] failed, GetLastError()=0x%08X\n",
				EM->WideToUTF8(u16_linkname).GetCString(),
				EM->WideToUTF8(u16_filename).GetCString(),
				GetLastError());
			//goto error_out;
		}

		notify_shell_dir_updated(CSIDL_STARTMENU);
		notify_shell_dir_updated(CSIDL_COMMON_STARTMENU);

		// Desktop Shortcut
		wstring desktop_dir = shell_folders_key.GetStringValue(L"Common Desktop");
		u16_filename = target_dir + L'\\' + exe_filename;
		u16_linkname = desktop_dir + L'\\' + shortcut_filename;
		success = create_link(target_dir + L'\\' + exe_filename,
			desktop_dir + L'\\' + shortcut_filename);
		if (success) {
			c2_log("CreateShortcut: [%s]->[%s] success\n",
				EM->WideToUTF8(u16_linkname).GetCString(),
				EM->WideToUTF8(u16_filename).GetCString());
		} else {
			c2_log("CreateShortcut: [%s]->[%s] failed, GetLastError()=0x%08X\n",
				EM->WideToUTF8(u16_linkname).GetCString(),
				EM->WideToUTF8(u16_filename).GetCString(),
				GetLastError());
			//goto error_out;
		}
		notify_shell_dir_updated(CSIDL_DESKTOPDIRECTORY);
		notify_shell_dir_updated(CSIDL_COMMON_DESKTOPDIRECTORY);
		/*
		PIDLIST_ABSOLUTE pidl;
		if (SUCCEEDED(SHGetFolderLocation(0, CSIDL_STARTMENU, 0, 0, &pidl))) {
			SHChangeNotify(SHCNE_UPDATEDIR, SHCNF_IDLIST, pidl, 0);
			CoTaskMemFree(pidl);
		}

		//PIDLIST_ABSOLUTE pidl;
		if (SUCCEEDED(SHGetFolderLocation(0, CSIDL_COMMON_STARTMENU, 0, 0, &pidl))) {
			SHChangeNotify(SHCNE_UPDATEDIR, SHCNF_IDLIST, pidl, 0);
			CoTaskMemFree(pidl);
		}
		*/

		// Registry Uninstaller
		wstring path(REG_UNINSTALL_KEY);
		wstring value;
		path += L'\\';
		path += product_name;
		winreg::RegKey uninstall_key;

		c2_log("CreateShortcut: TryCreate RegKey [HKEY_LOCAL_MACHINE\\%s]\n", EM->WideToUTF8(path).GetCString());
		(void)uninstall_key.TryCreate(HKEY_LOCAL_MACHINE, path, KEY_READ | KEY_WRITE/* | KEY_EXECUTE*/);

		c2_log("CreateShortcut: Open RegKey [HKEY_LOCAL_MACHINE\\%s]\n", EM->WideToUTF8(path).GetCString());
		uninstall_key.Open(HKEY_LOCAL_MACHINE, path, KEY_READ | KEY_WRITE);

		value = L'"' + target_dir + L'\\' + exe_filename + L'"';
		c2_log("CreateShortcut: Set RegKey [HKEY_LOCAL_MACHINE\\%s] StringValue [DisplayIcon] = [%s]\n",
			EM->WideToUTF8(path).GetCString(),
			EM->WideToUTF8(value).GetCString());
		uninstall_key.SetStringValue(L"DisplayIcon", value);

		c2_log("CreateShortcut: Set RegKey [HKEY_LOCAL_MACHINE\\%s] StringValue [DisplayName] = [%s]\n",
			EM->WideToUTF8(path).GetCString(),
			EM->WideToUTF8(display_name).GetCString());
		uninstall_key.SetStringValue(L"DisplayName", display_name);

		c2_log("CreateShortcut: Set RegKey [HKEY_LOCAL_MACHINE\\%s] StringValue [DisplayVersion] = [%s]\n",
			EM->WideToUTF8(path).GetCString(),
			EM->WideToUTF8(product_version).GetCString());
		uninstall_key.SetStringValue(L"DisplayVersion", product_version);

		c2_log("CreateShortcut: Set RegKey [HKEY_LOCAL_MACHINE\\%s] StringValue [Publisher] = [%s]\n",
			EM->WideToUTF8(path).GetCString(),
			EM->WideToUTF8(publisher).GetCString());
		uninstall_key.SetStringValue(L"Publisher", publisher);

		value = L'"' + target_dir + L'\\' + uninstaller_filename + L'"';
		c2_log("CreateShortcut: Set RegKey [HKEY_LOCAL_MACHINE\\%s] StringValue [UninstallString] = [%s]\n",
			EM->WideToUTF8(path).GetCString(),
			EM->WideToUTF8(value).GetCString());
		uninstall_key.SetStringValue(L"UninstallString", L'"' + target_dir + L'\\' + uninstaller_filename + L'"');

		c2_log("CreateShortcut: Set RegKey [HKEY_LOCAL_MACHINE\\%s] DwordValue [NoModify] = [%u]\n",
			EM->WideToUTF8(path).GetCString(), 1);
		uninstall_key.SetDwordValue(L"NoModify", 1);

		c2_log("CreateShortcut: Set RegKey [HKEY_LOCAL_MACHINE\\%s] DwordValue [NoRepair] = [%u]\n",
			EM->WideToUTF8(path).GetCString(), 1);
		uninstall_key.SetDwordValue(L"NoRepair", 1);
		{
			RtcTime time = get_rtc_time();
			WCHAR install_date[32] = {};
			_snwprintf(install_date, sizeof(install_date) - 1, L"%04d%02d%02d",
				time.year, time.month, time.day);
			c2_log("CreateShortcut: Set RegKey [HKEY_LOCAL_MACHINE\\%s] StringValue [InstallDate] = [%s]\n",
				EM->WideToUTF8(path).GetCString(),
				EM->WideToUTF8(install_date).GetCString());
			uninstall_key.SetStringValue(L"InstallDate", install_date);
		}
		if (request.estimated_size.has_value()) {
			c2_log("CreateShortcut: Set RegKey [HKEY_LOCAL_MACHINE\\%s] DwordValue [EstimatedSize] = [%u]\n",
				EM->WideToUTF8(path).GetCString(),
				(DWORD)request.estimated_size.value());
			uninstall_key.SetDwordValue(L"EstimatedSize", (DWORD)request.estimated_size.value());
		}

		uninstall_key.Close();
	} catch (...) {
		c2_log("CreateShortcut: Registry operation failed\n");
		goto error_out;
	}
	reply->status = 0;
error_out:
	CoUninitialize();
	success = post_thread_message(WM_APP, 0, reply);
	if (!success) {
		delete reply;
	}
}
void InstallService::DoRemoveShortcut(RemoveShortcutRequest& req) {
	BOOL success;
	auto EM = EncodingManager::Instance();
	wstring product_name = EM->UTF8ToWide(req.product_name);
	wstring display_name = EM->UTF8ToWide(req.display_name);
	wstring shortcut_filename = display_name + L".lnk";
	auto reply = new RemoveShortcutReply;
	reply->src_thread_id = GetCurrentThreadId();
	wstring path(REG_UNINSTALL_KEY);
	try {
		PIDLIST_ABSOLUTE pidl;
		winreg::RegKey shell_folders_key(HKEY_LOCAL_MACHINE, REG_SHELL_FOLDERS_KEY, KEY_READ);
		// StartMenu Shortcut
		wstring programs_dir = shell_folders_key.GetStringValue(L"Common Programs");
		programs_dir += L'\\';
		programs_dir += display_name;
		delete_directory_recursive(programs_dir.c_str());
		if (SUCCEEDED(SHGetFolderLocation(0, CSIDL_COMMON_PROGRAMS, 0, 0, &pidl))) {
			SHChangeNotify(SHCNE_UPDATEDIR, SHCNF_IDLIST, pidl, 0);
			CoTaskMemFree(pidl);
		}

		// Desktop Shortcut
		wstring desktop_dir = shell_folders_key.GetStringValue(L"Common Desktop");
		wstring desktop_shortcut_path = desktop_dir + L'\\' + shortcut_filename;
		success = DeleteFileW(desktop_shortcut_path.c_str());

		if (success) {
			c2_log("RemoveShortcut: [%s] success\n",
				EM->WideToUTF8(desktop_shortcut_path).GetCString());
		} else {
			c2_log("RemoveShortcut: [%s] failed, GetLastError()=0x%08X\n",
				EM->WideToUTF8(desktop_shortcut_path).GetCString(),
				GetLastError());
		}

		if (SUCCEEDED(SHGetFolderLocation(0, CSIDL_COMMON_DESKTOPDIRECTORY, 0, 0, &pidl))) {
			SHChangeNotify(SHCNE_UPDATEDIR, SHCNF_IDLIST, pidl, 0);
			CoTaskMemFree(pidl);
		}


		// Remove Startup Shortcut
		try {
			winreg::RegKey curr_shell_folders_key(HKEY_CURRENT_USER, REG_SHELL_FOLDERS_KEY, KEY_READ);
			wstring startup_dir = curr_shell_folders_key.GetStringValue(L"Startup");
			wstring startup_shortcut = startup_dir + L"\\" + display_name + L".lnk";
			success = DeleteFileW(startup_shortcut.c_str());
			if (!success) {
				c2_log("remove file [%s] failed, GetLastError()=0x%08X\n",
					EM->WideToUTF8(startup_shortcut).GetCString(),
					GetLastError());
			}
		} catch (...) {
			c2_log("remove startup shortcut failed, GetLastError()=0x%08X\n",
				GetLastError());
		}

		// Uninstaller
		winreg::RegKey uninstall_key(HKEY_LOCAL_MACHINE, path, KEY_READ | KEY_WRITE);
		uninstall_key.DeleteKey(product_name, DELETE);
	} catch (...) {
		goto error_out;
	}
	reply->status = 0;

error_out:
	success = post_thread_message(WM_APP, 0, reply);
	if (!success) {
		delete reply;
	}
}
void InstallService::DoRemoveDir(RemoveDirRequest& req) {
	auto reply = new RemoveDirReply;
	reply->src_thread_id = GetCurrentThreadId();
	BOOL success;
	wstring path = EncodingManager::Instance()->UTF8ToWide(req.target_dir);
	delete_directory_recursive(path.c_str());
	success = post_thread_message(WM_APP, 0, reply);
	if (!success) {
		delete reply;
	}
}
void InstallService::DoKillProcess(KillProcessRequest& req) {
	auto reply = new KillProcessReply;
	reply->src_thread_id = GetCurrentThreadId();
	HANDLE handle;
	for (auto process_id : req.process_ids) {
		handle = OpenProcess(PROCESS_TERMINATE, FALSE, process_id);
		if (handle) {
			if (TerminateProcess(handle, 0)) {
				WaitForSingleObject(handle, INFINITE);
				reply->status = 0;
			}
			CloseHandle(handle);
		}
	}

	/* �ȴ�С���˳� */
	::Sleep(500);

	BOOL success = post_thread_message(WM_APP, 0, reply);
	if (!success) {
		delete reply;
	}
}
void InstallService::DoGetRunningProcess(GetRunningProcessRequest& req) {
	BOOL success;
	auto reply = new GetRunningProcessReply;
	reply->src_thread_id = GetCurrentThreadId();

	auto EM = EncodingManager::Instance();
	wstring product_name = EM->UTF8ToWide(req.product_name);

	DWORD aProcesses[1024], cbNeeded, cProcesses;
	unsigned int i;
	
	if (!EnumProcesses(aProcesses, sizeof(aProcesses), &cbNeeded)) {
		c2_log("DoGetRunningProcess: EnumProcess failed, GetLastError()=0x%08X\n", GetLastError());
		goto error_out;
	}
	if (cbNeeded > sizeof(aProcesses))
		cbNeeded = sizeof(aProcesses);
	cProcesses = cbNeeded / sizeof(DWORD);
	for (i = 0; i < cProcesses; i++) {
		if (aProcesses[i] == NULL)
			continue;
		HANDLE process_handle = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, FALSE, aProcesses[i]);
		if (process_handle) {
			WCHAR path[MAX_PATH + 1] = {};
			DWORD path_len = MAX_PATH;
			if (QueryFullProcessImageNameW(process_handle, 0, path, &path_len) && path_len <= MAX_PATH) {
				path[path_len] = 0;
				wstring wpath(path, path + path_len);
				for (auto& u8_exe_filename : req.exe_filenames) {
					wstring exe_filename = EM->UTF8ToWide(u8_exe_filename);
					wstring suffix;
					// Check exe filename
					suffix.reserve(exe_filename.length() + 1);
					suffix += '\\';
					suffix += exe_filename;
					if (wpath.length() >= suffix.length()
						&& _wcsnicmp(&wpath[wpath.length() - suffix.length()], suffix.c_str(), suffix.length()) == 0) {

						reply->process_ids.push_back(aProcesses[i]);
					}
				}
			}
			CloseHandle(process_handle);
		}
	}

error_out:
	success = post_thread_message(WM_APP, 0, reply);
	if (!success) {
		delete reply;
	}
}
void InstallService::DoDetectExistInstall(DetectExistInstallRequest& req) {
	InstallTimer timer;
	auto reply = new DetectExistInstallReply;
	reply->src_thread_id = GetCurrentThreadId();
	auto EM = EncodingManager::Instance();
	BOOL success;

	c2_log("Start DetectExistInstall.\n");

	// Detect VCRedist 2019 x86
	try {
		winreg::RegKey key(HKEY_LOCAL_MACHINE, VCREDIST_2019_X86_PROVIDER_KEY, KEY_READ | KEY_WOW64_64KEY);
		wstring product_key = key.GetStringValue(wstring());
		wstring product_version = key.GetStringValue(L"Version");
		INSTALLSTATE msi_state = MsiQueryProductStateW(product_key.c_str());
		c2_log("Found vcredist_2019_x86 installation, version=[%s] product=%s install_state=[%d].\n",
			EM->WideToUTF8(product_version).GetCString(),
			EM->WideToUTF8(product_key).GetCString(),
			msi_state);
		if (msi_state == INSTALLSTATE_DEFAULT) {
			String version = EM->WideToUTF8(product_version);
			optional<int> cmp = version.VersionCompare(req.current_vcredist_version);
			if (cmp.has_value() && *cmp != -1)
				reply->vcredist_installed = true;
		}
	} catch (...) {
		c2_log("vcredist_2019_x86 installation not detected.\n");
	}

	// detect new install
	try {
		wstring path(REG_UNINSTALL_KEY);
		path += L'\\';
		path += EM->UTF8ToWide(req.product_name);
		winreg::RegKey uninstall_key(HKEY_LOCAL_MACHINE, path, KEY_READ | KEY_WRITE);
		wstring display_name = uninstall_key.GetStringValue(L"DisplayName");
		wstring version = uninstall_key.GetStringValue(L"DisplayVersion");
		wstring uninstaller_path = uninstall_key.GetStringValue(L"UninstallString");

		// ȥ�����ܵ�˫����
		if (uninstaller_path.find(L'"') == 0)
			uninstaller_path.erase(0, 1);
		if (!uninstaller_path.empty()
			&& uninstaller_path.rfind(L'"') == uninstaller_path.size() - 1)
			uninstaller_path.erase(uninstaller_path.size() - 1, 1);
		wstring::size_type pos = uninstaller_path.rfind(L'\\');
		if (pos != wstring::npos)
			uninstaller_path.erase(pos);

		ExistInstallData data;
		data.product_name = req.product_name;
		data.display_name = EM->WideToUTF8(display_name);
		data.target_dir = EM->WideToUTF8(uninstaller_path);
		data.version = EM->WideToUTF8(version);
		c2_log("Found chengxun installation, display_name=\"%s\", version=\"%s\"\n",
			data.display_name.GetCString(), data.version.GetCString());
		reply->chengxun_result.emplace(data);
	} catch (...) {}

	success = post_thread_message(WM_APP, 0, reply);
	if (!success) {
		delete reply;
	}
	c2_log("Done DetectExistInstall, time cost %.03lf s.\n", timer.GetElapsed());
}
void InstallService::DoRemoveExistInstall(RemoveExistInstallRequest& req) {
	InstallTimer timer;
	auto reply = new RemoveExistInstallReply;
	reply->src_thread_id = GetCurrentThreadId();
	auto EM = EncodingManager::Instance();
	BOOL success;
	PIDLIST_ABSOLUTE pidl;

	c2_log("Start RemoveExistInstall\n");

	auto& my_data = req.data;
	wstring target_dir = EM->UTF8ToWide(my_data.target_dir);
	wstring product_name = EM->UTF8ToWide(my_data.product_name);
	wstring display_name = EM->UTF8ToWide(my_data.display_name);

	// Remove files
	success = delete_directory_recursive(target_dir.c_str());
	if (!success) {
		c2_log("remove dir [%s] failed.\n", my_data.target_dir.GetCString());
	}

	// Remove StartMenu Shortcut
	try {
		winreg::RegKey shell_folders_key(HKEY_LOCAL_MACHINE, REG_SHELL_FOLDERS_KEY, KEY_READ);
		wstring programs_dir = shell_folders_key.GetStringValue(L"Common Programs");
		programs_dir += L'\\';
		programs_dir += display_name;
		if (!delete_directory_recursive(programs_dir.c_str())) {
			auto p = EM->WideToUTF8(programs_dir);
			c2_log("remove dir [%s] failed.\n", p.GetCString());
		}
		if (SUCCEEDED(SHGetFolderLocation(0, CSIDL_COMMON_PROGRAMS, 0, 0, &pidl))) {
			SHChangeNotify(SHCNE_UPDATEDIR, SHCNF_IDLIST, pidl, 0);
			CoTaskMemFree(pidl);
		}
	} catch (...) {
		auto k = EM->WideToUTF8(REG_SHELL_FOLDERS_KEY);
		c2_log("read [HKEY_LOCAL_MACHINE\\%s] value [Common Programs] failed.\n",
			k.GetCString());
	}

	// Desktop Shortcut
	try {
		winreg::RegKey shell_folders_key(HKEY_LOCAL_MACHINE, REG_SHELL_FOLDERS_KEY, KEY_READ);
		wstring desktop_dir = shell_folders_key.GetStringValue(L"Common Desktop");
		wstring desktop_shortcut_path = desktop_dir + L'\\' + display_name + L".lnk";
		DeleteFileW(desktop_shortcut_path.c_str());
		if (SUCCEEDED(SHGetFolderLocation(0, CSIDL_COMMON_DESKTOPDIRECTORY, 0, 0, &pidl))) {
			SHChangeNotify(SHCNE_UPDATEDIR, SHCNF_IDLIST, pidl, 0);
			CoTaskMemFree(pidl);
		}
	} catch (...) {
		auto k = EM->WideToUTF8(REG_SHELL_FOLDERS_KEY);
		c2_log("read [HKEY_LOCAL_MACHINE\\%s] value [Common Desktop] failed.\n",
			k.GetCString());
	}

	// Remove Startup Shortcut
	try {
		winreg::RegKey curr_shell_folders_key(HKEY_CURRENT_USER, REG_SHELL_FOLDERS_KEY, KEY_READ);
		wstring startup_dir = curr_shell_folders_key.GetStringValue(L"Startup");
		wstring startup_shortcut = startup_dir + L"\\" + display_name + L".lnk";
		success = DeleteFileW(startup_shortcut.c_str());
		if (!success) {
			c2_log("remove file [%s] failed, GetLastError()=0x%08X\n",
				EM->WideToUTF8(startup_shortcut).GetCString(),
				GetLastError());
		}
	} catch (...) {
		c2_log("remove startup shortcut failed, GetLastError()=0x%08X\n",
			GetLastError());
	}

	// Uninstaller
	try {
		winreg::RegKey uninstall_key(HKEY_LOCAL_MACHINE, REG_UNINSTALL_KEY, KEY_READ | KEY_WRITE);
		uninstall_key.DeleteKey(product_name, DELETE);
	} catch (...) {
		auto k = EM->WideToUTF8(REG_UNINSTALL_KEY);
		c2_log("remove [HKEY_LOCAL_MACHINE\\%s\\%s] failed.\n",
			k.GetCString(),
			my_data.product_name.GetCString());
	}

	reply->status = 0;
	success = post_thread_message(WM_APP, 0, reply);
	if (!success) {
		delete reply;
	}
	c2_log("Done RemoveExistInstall, time cost %.3lf s.\n", timer.GetElapsed());
}
void InstallService::DoUnpackResource(UnpackResourceRequest& request) {
	bool success;
	auto EM = EncodingManager::Instance();
	wstring target_dir = EM->UTF8ToWide(request.target_dir);
	wstring filename = EM->UTF8ToWide(request.filename);
	size_t n;
	Resource resource;
	auto reply = new UnpackResourceReply;
	reply->resource = request.resource;
	reply->src_thread_id = GetCurrentThreadId();

	create_directory(target_dir);

	wstring path = target_dir + L"\\" + filename;
	FILE* f;
retry_file_open:
	f = _wfopen(path.c_str(), L"wb");
	if (!f) {
		c2_log("UnpackResource: open file [%s] failed, GetLastError()=0x%08X.\n",
			EM->WideToUTF8(path).GetCString(), GetLastError());
		InstallErrorAction action
			= ErrorUserConfirm(request.src_thread_id, request.src_hwnd, request.GetType(), request.filename);
		if (action == INSTALL_ERR_ABORT) {
			goto error_out;
		} else if (action == INSTALL_ERR_RETRY) {
			goto retry_file_open;
		} else if (action == INSTALL_ERR_CONTINUE) {
			goto error_out;
		}

		goto error_out;
	}
	resource = ResourceManager::Instance()->LoadResource(request.resource);
	if (!resource.IsValid()) {
		c2_log("LoadResource failed.\n");
		goto error_out;
	}
	n = fwrite(resource.data, 1, resource.size, f);
	if (n != resource.size) {
		c2_log("UnpackResource: write file [%s] failed, ret_code %zd.\n",
			EM->WideToUTF8(path).GetCString(), n);
		fclose(f);
		goto error_out;
	}
	fclose(f);
	reply->status = 0;

error_out:
	success = post_thread_message(WM_APP, 0, reply);
	if (!success) {
		delete reply;
	}
}

/* static */void* memmem(const void* haystack, size_t haystackLen, const void* needle, size_t needleLen)
{
	/* The first occurrence of the empty string is deemed to occur at
	the beginning of the string.  */
	if (needleLen == 0 || haystack == needle)
	{
		return (void*)haystack;
	}

	if (haystack == NULL || needle == NULL)
	{
		return NULL;
	}

	const unsigned char* haystackStart = (const unsigned char*)haystack;
	const unsigned char* needleStart = (const unsigned char*)needle;
	const unsigned char needleEndChr = *(needleStart + needleLen - 1);

	++haystackLen;
	for (; --haystackLen >= needleLen; ++haystackStart)
	{
		size_t x = needleLen;
		const unsigned char* n = needleStart;
		const unsigned char* h = haystackStart;

		/* Check for the first and the last character */
		if (*haystackStart != *needleStart ||
			*(haystackStart + needleLen - 1) != needleEndChr)
		{
			continue;
		}

		while (--x > 0)
		{
			if (*h++ != *n++)
			{
				break;
			}
		}

		if (x == 0)
		{
			return (void*)haystackStart;
		}
	}

	return NULL;
}
/* static */optional<byte> convert_hex(byte c) {
	if (c >= '0' && c <= '9')
		return byte(c - '0');
	if (c >= 'a' && c <= 'f')
		return byte(c - 'a' + 10);
	if (c >= 'A' && c <= 'F')
		return byte(c - 'A' + 10);
	return nullopt;
}
/* static */vector<byte> unescape_qt_data(const byte* data, size_t len) {
	vector<byte> buf;
	buf.reserve(len / 2);
	const byte* p = data;
	while (p < data + len) {
		switch (*p) {
		case '\\':
			if (p + 1 < data + len) {
				switch (p[1]) {
				case '0':
					buf.push_back(0);
					p += 2;
					break;
				case 'x':
					if (p + 3 < data + len) {
						auto c0 = convert_hex(p[2]);
						auto c1 = convert_hex(p[3]);
						if (c0.has_value() && c1.has_value()) {
							buf.push_back(*c0 * 16 + *c1);
							p += 4;
						} else if (c0.has_value()) {
							buf.push_back(*c0);
							p += 3;
						} else {
							c2_log("parse \\x failed.\n");
							p += 4;
						}
					} else {
						c2_log("parse \\x failed.\n");
						p += 4;
					}
					break;
				case 'r':
					buf.push_back('\r');
					p += 2;
					break;
				case 'n':
					buf.push_back('\n');
					p += 2;
					break;
				case 'b':
					buf.push_back('\b');
					p += 2;
					break;
				case '\\':
					buf.push_back('\\');
					p += 2;
					break;
				case 't':
					buf.push_back('\t');
					p += 2;
					break;
				case 'v':
					buf.push_back('\v');
					p += 2;
					break;
				case 'f':
					buf.push_back('\f');
					p += 2;
					break;
				case '\'':
					buf.push_back('\'');
					p += 2;
					break;
				case '"':
					buf.push_back('"');
					p += 2;
					break;
				default:
					c2_log("parse \\ failed.\n");
					p += 2;
				}
			} else {
				buf.push_back(*p++);
			}
			break;
		default:
			buf.push_back(*p++);
		}
	}
	return buf;
}

/* static */bool parse_qstring(const byte* data, const byte* end, wstring* out_str, size_t* consumed) {
	if (data + 4 > end)
		return false;
	uint32 len = unpack_be32(data); // byte len
	if (len == 0xffffffff) { // NULL marker
		out_str->clear();
		*consumed = 4;
		return true;
	}
	if (len % 2 != 0 || len > MAX_QSTRING_LEN || data + 4 + len > end)
		return false;
	len /= 2; // utf16 len
	out_str->clear();
	out_str->reserve(len);
	const byte* p = data + 4;
	for (uint32 i = 0; i < len; ++i) {
		wchar_t ch = ((wchar_t)p[0] << 8) | (wchar_t)p[1];
		out_str->push_back(ch);
		p += 2;
	}
	*consumed = 4 + len * 2;
	return true;
}
/* static */bool parse_qvariant(const byte* data, const byte* end, wstring* out_str, size_t* consumed) {
	if (data + 4 > end)
		return false;
	uint32 meta_type = unpack_be32(data);
	if (meta_type != 10) // QMetaType::QString
		return false;
	if (parse_qstring(data + 4, end, out_str, consumed)) {
		*consumed += 4;
		return true;
	} else {
		return false;
	}
}
/* static */unordered_map<String, String> parse_qvariant_hash(const byte* data, size_t len) {
	unordered_map<String, String> table;
	if (len < 8)
		return table;
	const byte* p = data;
	wstring key;
	wstring value;
	size_t n;
	uint32 i;
	uint32 metatype = unpack_be32(p);
	p += 4;
	if (metatype != 28) // QMetaType::QVariantHash
		return table;
	uint32 num_entries = unpack_be32(p);
	p += 4;
	c2_log("total %u entries.\n", (unsigned)num_entries);
	for (i = 0; i < num_entries; ++i) {
		if (!parse_qstring(p, data + len, &key, &n))
			break;
		p += n;
		if (!parse_qvariant(p, data + len, &value, &n))
			break;
		p += n;
		auto EM = EncodingManager::Instance();
		auto k = EM->WideToUTF8(key);
		auto v = EM->WideToUTF8(value);
		table[k] = v;
		c2_log("  #%u, key=[%s], value=[%s], offset=%04x\n", i, k.GetCString(), v.GetCString(), (int)(p - data));
	}
	c2_log("parsed %u entries\n", i);
	return table;
}
