//
//  debug_helpers.h
//  C2Engine
//
//  Created by mike luo on 12-11-28.
//
//
#ifndef DEBUG_HELPERS_H
#define DEBUG_HELPERS_H

#include <assert.h>

#define c2_assert assert
#define c2_assert_return(Expression) \
  if (!(Expression)) { \
    c2_log("%s:%d Assert: %s\n", __FILE__, __LINE__, #Expression); \
    return; \
  }
#define c2_assert_return_x(Expression, Ret) \
  if (!(Expression)) { \
    c2_log("%s:%d Assert: %s\n", __FILE__, __LINE__, #Expression); \
    return (Ret); \
      }

#endif // DEBUG_HELPERS_H
