//
//  debug_print.h
//  C2Engine
//
//  Created by mike luo on 2014-2-11.
//
//

#ifndef DEBUG_PRINT_H
#define DEBUG_PRINT_H

extern void debug_print(const char* format, ...);

#endif // DEBUG_PRINT_H