#ifndef LOGGER_H
#define LOGGER_H

#include "memory/memory_helpers.h"
#include "file/File.h"
#include "string/String.h"
#include "platform/platform_config.h"

SMART_REF(Logger);
class Logger {
public:
    virtual ~Logger() {}
    virtual void Log(const char* text) {}
};

class StdoutLogger : public Logger {
public:
    void Log(const char* text) override;
};

SMART_REF(IFile);
class FileLogger : public Logger {
public:
    FileLogger(const String& filename);
    void Log(const char* text) override;
private:
    IFileHandle _file;
};

#if ON_WINDOWS
class VSDebugLogger : public Logger {
public:
    void Log(const char* text) override;
};
#define DebugLogger VSDebugLogger
#else
#define DebugLogger StdoutLogger
#endif

#endif // LOGGER_H