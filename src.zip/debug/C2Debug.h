//
//  C2Debug.h
//  C2Engine
//
//  Created by mike luo on 12-12-11.
//
//

#ifndef C2_DEBUG_H
#define C2_DEBUG_H

#include "debug_helpers.h"
#include "debug_print.h"
#include "log.h"
#include "LogManager.h"
#include "Logger.h"

#endif // C2_DEBUG_H
