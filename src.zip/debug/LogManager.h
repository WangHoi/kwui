#ifndef LOG_MANAGER_H
#define LOG_MANAGER_H

#include "pattern/singleton.h"
#include "data/data_helpers.h"
#include "thread/thread_helpers.h"

SMART_REF(Logger);

class LogManager {
public:
    void AddLogger(const LoggerRef& logger) { _loggers.push_back(logger); }
	void Log(const char* file, int line, const char* format, ...) const;
    unique_lock<recursive_mutex> Lock() const { return unique_lock<recursive_mutex>{_mutex}; }
private:
    vector<LoggerRef> _loggers;
    mutable recursive_mutex _mutex;
    SUPPORT_SINGLETON(LogManager);
};

#endif // LOG_MANAGER_H