//
//  EngineLogConfig.cpp
//  C2Engine
//
//  Created by mike luo on 2014-3-13.
//
//
#include "stdafx.h"
#include "EngineLogConfig.h"

namespace EngineLogConfig {
  // Font
  bool LOG_FONT_RESIZED = false;
  bool LOG_GLYPH_RENDERING = false;
  bool LOG_RENDER_GLYPH_STRING = false;
  bool LOG_RERENDER_GLYPH_STRING = false;
  bool LOG_REFORMAT_FONT_LABEL = false;

  // Resource Loading
  bool LOG_ASSET_ADD = false;
  bool LOG_ASSET_CLEANUP = false;
  bool LOG_ASSET_PRELOADER = true;

  // System
  bool LOG_WINDOW_RESIZED = false;

  // Game
  bool LOG_GAME_SAVE = false;
  bool LOG_GAME_LOAD = false;
}