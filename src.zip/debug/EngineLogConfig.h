//
//  EngineLogConfig.h
//  C2Engine
//
//  Created by mike luo on 2014-3-13.
//
//
#ifndef ENGINE_LOG_CONFIG_H
#define ENGINE_LOG_CONFIG_H

namespace EngineLogConfig {
  // Font
  extern bool LOG_FONT_RESIZED;
  extern bool LOG_GLYPH_RENDERING;
  extern bool LOG_RENDER_GLYPH_STRING;
  extern bool LOG_RERENDER_GLYPH_STRING;
  extern bool LOG_REFORMAT_FONT_LABEL;

  // Resource Loading
  extern bool LOG_ASSET_ADD;
  extern bool LOG_ASSET_CLEANUP;
  extern bool LOG_ASSET_PRELOADER;

  // System
  extern bool LOG_WINDOW_RESIZED;
  
  // Game
  extern bool LOG_GAME_SAVE;
  extern bool LOG_GAME_LOAD;
}

#endif // EngineLogConfig