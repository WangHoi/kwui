#ifndef LOG_H
#define LOG_H

#include "LogManager.h"

#define c2_log(...) LogManager::Instance()->Log(__FILE__, __LINE__, __VA_ARGS__)

#define c2_lock_log() auto log_lock = LogManager::Instance()->Lock()

#endif // LOG_H