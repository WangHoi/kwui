#include "Logger.h"
#include "file/File.h"
#include "file/FileSystem.h"
#include "text/EncodingManager.h"
#include "platform/platform_helpers.h"

void StdoutLogger::Log(const char* text) {
    fputs(text, stdout);
}

FileLogger::FileLogger(const String& filename) {
    const String& path = filename;
    _file = FileSystem::Instance()->OpenWriteText(path);
}

void FileLogger::Log(const char* text) {
    if (_file) {
        _file->WriteBytes((const_pointer)text, strlen(text));
        _file->Flush();
    }
}

#if ON_WINDOWS
#include "platform/windows/windows_header.h"
void VSDebugLogger::Log(const char* text) {
	const wstring wstr = EncodingManager::Instance()->UTF8ToWide(text);
	OutputDebugStringW(wstr.c_str());
}
#endif