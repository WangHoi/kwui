#include "LogManager.h"
#include "Logger.h"

#if ON_WINDOWS
#pragma warning(disable:4996)
#endif

DEFINE_SINGLETON_INSTANCE(LogManager);

static thread_local char s_buf[32768];

static inline int format_time(char* buf, size_t size)
{
	RtcTime time = get_rtc_time();
	return snprintf(
		buf, size, "%04d-%02d-%02d %02d:%02d:%02d.%03d ",
		time.year, time.month, time.day,
		time.hour, time.minute, time.second, time.millisecond);
}

static inline int format_thread_id(char* buf, size_t size)
{
	return snprintf(buf, size, "[%u] ", (unsigned)GetCurrentThreadId());
}

static inline int format_source_location(char* buf, size_t size, const char* file, int line)
{
	const char* base_file = (strrchr(file, '\\') ? strrchr(file, '\\') + 1 : file);
	return snprintf(buf, size, "(%s:%d): ", base_file, line);
}

void LogManager::Log(const char* file, int line, const char* format, ...) const
{
	int n = format_time(s_buf, sizeof(s_buf));
	n += format_thread_id(s_buf + n, sizeof(s_buf) - n);
	n += format_source_location(s_buf + n, sizeof(s_buf) - n, file, line);

	va_list ap;
	va_start(ap, format);
	n = vsnprintf(s_buf + n, sizeof(s_buf) - n, format, ap);
	va_end(ap);

	lock_guard<recursive_mutex> lock(_mutex);
	for (auto& logger : _loggers) logger->Log(s_buf);
}
