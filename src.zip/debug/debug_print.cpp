//
//  debug_print.cpp
//  C2Engine
//
//  Created by mike luo on 2014-2-11.
//
//
#include "stdafx.h"
#include "debug_print.h"

#include "text/text_helpers.h"
#include "text/EncodingManager.h"

#include "platform/platform_config.h"

#if ON_WINDOWS
#include "platform/windows/windows_header.h"
#pragma warning(disable:4996)
#endif

void debug_print(const char* format, ...) {
#if ON_WINDOWS
  char buf[1024];
  va_list ap;
  va_start(ap, format);
  vsnprintf(buf, sizeof(buf), format, ap);
  va_end(ap);

  auto EM = EncodingManager::Instance();
  if (EM) OutputDebugString(EM->UTF8ToSystem(buf).GetCString());
  else OutputDebugString(buf);
#else
  va_list ap;
  va_start(ap, format);
  vprintf(format, ap);
  va_end(ap);
#endif
}