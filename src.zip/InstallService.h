#pragma once
#include "platform/platform_config.h"
#include "platform/windows/windows_header.h"
#include "install/InstallMessage.h"
#include "UvJobQueue.h"
#include <json.hpp>
using json = nlohmann::json;

class InstallService {
public:
	static std::unique_ptr<InstallService> Create(uv_loop_t* loop);
	explicit InstallService(uv_loop_t* loop);
	const String& GetTargetDir() const { return _target_dir; }
	~InstallService();

private:
	struct WorkerContext;
	struct WriteRequestContext;
	enum ConnectionState {
		CONN_STATE_INIT,
		CONN_STATE_CONNECTING,
		CONN_STATE_READY,
		NUM_CONN_STATES,
	};
	static constexpr std::array<const char*, NUM_CONN_STATES> CONN_STATE_NAMES = {
		"INIT",
		"CONNECTING",
		"READY",
	};
	void SetConnState(ConnectionState state);
	void ReConnect();
	void Disconnect();
	void SendMsg(json&& j);
	bool ParseReadedData();
	void StartWorker(InstallMessageBase* msg);

	// run on libuv thread
	static void OnConnected(uv_connect_t* conn, int status);
	// run on libuv thread
	static void OnWritten(uv_write_t* req, int status);
	// run on libuv thread
	static void OnReaded(uv_stream_t* stream, ssize_t nread, const uv_buf_t* buf);
	// worker thread entry function
	static DWORD WINAPI WorkerThreadFunc(LPVOID lpParam);
	// run on worker thread
	void DoRunExe(RunExeRequest& request);
	// run on worker thread
	void DoUnpackArchive(UnpackArchiveRequest& req);
	// run on worker thread
	void DoCreateShortcut(CreateShortcutRequest& request);
	// run on worker thread
	void DoRemoveShortcut(RemoveShortcutRequest& req);
	// run on worker thread
	void DoRemoveDir(RemoveDirRequest& req);
	// run on worker thread
	void DoKillProcess(KillProcessRequest& req);
	// run on worker thread
	void DoGetRunningProcess(GetRunningProcessRequest& req);
	// run on worker thread
	void DoDetectExistInstall(DetectExistInstallRequest& req);
	// run on worker thread
	void DoRemoveExistInstall(RemoveExistInstallRequest& req);
	// run on worker thread
	void DoUnpackResource(UnpackResourceRequest& request);
	// run on worker thread
	bool post_thread_message(UINT Msg, WPARAM wParam, InstallMessageBase *lParam);
	// run on worker thread
	InstallErrorAction ErrorUserConfirm(DWORD ui_thread_id, HWND hwnd,
		InstallMessageType orig_request_type,
		const String& data);
	// run on libuv loop thread
	void HandlePostThreadMessage(UINT Msg, WPARAM wParam, InstallMessageBase *lParam);

	uv_loop_t* _loop = nullptr;
	uv_pipe_t* _pipe = nullptr;
	ConnectionState _conn_state = CONN_STATE_INIT;
	std::vector<uint8_t> _read_buf;
	UvJobQueueRef _job_queue;
	String _target_dir;
};

extern const char* INSTALL_SERVICE_PIPE_NAME;
