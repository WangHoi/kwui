#include "stdafx.h"
//
//  bit_arithmetics.cpp
//  C2Engine
//
//  Created by mike luo on 12-12-11.
//
//

#include "math/bit_arithmetics.h"

/*
static uint8 BIT_POSITION_MAPPING[32] = {
  31, 0, 27, 1, 28, 18, 23, 2,
  29, 21, 19, 12, 24, 9, 14, 3,
  30, 26, 17, 22, 20, 11, 8, 13,
  25, 16, 10, 7, 15, 6, 5, 4
};

int first_bit_position(uint32 x) {
  return BIT_POSITION_MAPPING[(low_bit(x) * 263572066u) >> 27];
}
*/
int first_bit_position(uint32 x) {
#if ON_WINDOWS
  unsigned long index;
  return _BitScanForward(&index, x) ? index : -1;
#else
  return __builtin_ffs(x) - 1;
#endif
}

int last_bit_position(uint32 x) {
#if ON_WINDOWS
  unsigned long index;
  return _BitScanReverse(&index, x) ? index : -1;
#else
  const int bit = x ? 32 - __builtin_clz(x) : 0;
  return bit - 1;
#endif
}

uint8 count_set_bits(uint32 x) {
#if ON_WINDOWS
  return (uint8)__popcnt(x);
#endif
  c2_assert_return_x(0 && "count_set_bits not implemented.", 0);
}
