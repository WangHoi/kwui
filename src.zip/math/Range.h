#ifndef RANGE_H
#define RANGE_H

#include "Vector2.h"
#include "Vector3.h"

template <typename T>
class Range {
public:
    struct EMPTY {};
    struct FULL {};

    Range() {} // uninitialized
    Range(const T& min, const T& max) : _min(min), _max(max) {}
    Range(const Range<T>& r) : _min(r._min), _max(r._max) {}
    Range(EMPTY) { SetEmpty(); }
    Range(FULL) { SetFull(); }

    const T& GetMin() const { return _min; }
    const T& GetMax() const { return _max; }

    float GetMin(Axis axis) const { return _min[axis]; }
    float GetMax(Axis axis) const { return _max[axis]; }

    void SetMin(const T& min) { _min = min; }
    void SetMax(const T& max) { _max = max; }
    void SetMin(Axis axis, float v) { _min[axis] = v; }
    void SetMax(Axis axis, float v) { _max[axis] = v; }
    void Set(const T& min, const T& max) {
        _min = min;
        _max = max;
    }

    void SetEmpty() {
        _min.Set(oo);
        _max.Set(-oo);
    }

    void SetFull() {
        _min.Set(-oo);
        _max.Set(oo);
    }

    Range<T>& operator+=(const T& v) {
        _min += v;
        _max += v;
        return *this;
    }
    Range<T>& operator-=(const T& v) {
        _min -= v;
        _max -= v;
        return *this;
    }
    Range<T>& operator*=(float k) {
        _min *= k;
        _max *= k;
        return *this;
    }
    Range<T>& operator/=(float k) {
        return *this *= (1.0f / k);
    }

    Range<T> operator+(const T& v) const { return { _min + v, _max + v }; }
    Range<T> operator-(const T& v) const { return { _min - v, _max - v }; }
    Range<T> operator*(float k) const { return { _min * k, _max * k }; }
    Range<T> operator/(float k) const { return *this * (1.0f / k); }

    void Expand(const T& v) {
        _min.UpdateMin(v);
        _max.UpdateMax(v);
    }

    void Merge(const Range<T>& r) {
        _min.UpdateMin(r._min);
        _max.UpdateMax(r._max);
    }

    T GetSpan() const { return _max - _min; }
    float GetAxisSpan(Axis axis) const { return _max[axis] - _min[axis]; }
    T Sample(const T& t) const { return (_max - _min) * t + _min; }
    float SampleAxis(Axis axis, float t) const { return _max[axis] * t + _min[axis] * (1 - t); }
    bool Contain(const T& x) const { return _min <= x && x <= _max; }
    Vector2 GetRange(Axis axis) const { return Vector2(_min[axis], _max[axis]); }

private:
    T _min, _max;
};

typedef Range<Vector2> Range2;
typedef Range<Vector3> Range3;

extern Range2 EMPTY_RANGE2;
extern Range2 FULL_RANGE2;
extern Range3 EMPTY_RANGE3;
extern Range3 FULL_RANGE3;

#endif // RANGE_H