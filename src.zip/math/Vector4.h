#ifndef VECTOR4_H
#define VECTOR4_H

#include "Vector2.h"
#include "Vector3.h"
#include "debug/log.h"

class Vector4 {
public:
    float x, y, z, w;

    /***** initializers *****/
    Vector4() {} // uninitialized
    explicit Vector4(float v) { Set(v); }
    Vector4(float x, float y, float z, float w) { Set(x, y, z, w); }
    explicit Vector4(const float* v) { Set(v); }
    Vector4(const Vector4& v) { Set(v.x, v.y, v.z, v.w); }
    Vector4(const Vector3& v, float w) { Set(v.x, v.y, v.z, w); }

    /***** getters *****/
    const float* GetBuffer() const { return (const float*)this; }
    float* GetBuffer() { return (float*)this; }
    const float& operator[](int index) const { return GetBuffer()[index]; } // no bound check!
    float& operator[](int index) { return GetBuffer()[index]; } // no bound check!

    /***** setters *****/
    Vector4& operator=(const Vector4& v) {
        if (this != &v) Set(v.x, v.y, v.z, v.w);
        return *this;
    }

    void Set(float x, float y, float z, float w) {
        this->x = x;
        this->y = y;
        this->z = z;
        this->w = w;
    }

    void Set(float v) { Set(v, v, v, v); }
    void Set(const float* v) { Set(v[0], v[1], v[2], v[3]); }

    /***** operations *****/
    Vector4& operator+=(const Vector4& v);
    Vector4& operator-=(const Vector4& v);
    Vector4& operator*=(const Vector4& v);
    Vector4& operator/=(const Vector4& v);
    Vector4& operator+=(float k);
    Vector4& operator-=(float k);
    Vector4& operator*=(float k);
    Vector4& operator/=(float k);

    Vector3 GetPosition() const;

    //swizzle operations
    Vector2 XY() const { return Vector2(x, y); }
    Vector2 YZ() const { return Vector2(y, z); }
    Vector2 ZW() const { return Vector2(z, w); }
    Vector2 ZX() const { return Vector2(z, x); }
    Vector3 XXX() const { return Vector3(x, x, x); }
    Vector3 XYZ() const { return Vector3(x, y, z); }

    bool IsZero() const;
    void UpdateMin(const Vector4& v);
    void UpdateMax(const Vector4& v);
    void SwapIfLargerThan(Vector4& v);

    float Length() const;
    float SquareLength() const;
    Vector4& Normalize();
    Vector4& SetLength(float length);
    Vector4 MakeUnitVector() const;
    Vector4 MakeVectorWithLength(float length) const;
    float DistanceTo(const Vector4& v) const;
    float SquareDistanceTo(const Vector4& v) const;
};

/*** constants ***/
extern const Vector4 ZERO_VECTOR4;

/*** arithmetics ***/
inline Vector4 operator-(const Vector4& v) { return{ -v.x, -v.y, -v.z, -v.w }; }

#define DEFINE_BINARY_OPERATIONS(op) \
  inline Vector4& Vector4::operator op##= (const Vector4& v) { \
    x op##= v.x; \
    y op##= v.y; \
    z op##= v.z; \
    w op##= v.w; \
    return *this; \
  } \
  inline Vector4 operator op(const Vector4& v1, const Vector4& v2) { return{v1.x op v2.x, v1.y op v2.y, v1.z op v2.z, v1.w op v2.w}; }

#define DEFINE_BINARAY_SCALAR_OPERATIONS(op) \
  inline Vector4& Vector4::operator op##= (float k) { \
    x op##= k; \
    y op##= k; \
    z op##= k; \
    w op##= k; \
    return *this; \
  } \
  inline Vector4 operator op(const Vector4& v, float k) { return{v.x op k, v.y op k, v.z op k, v.w op k}; }

DEFINE_BINARY_OPERATIONS(+);
DEFINE_BINARY_OPERATIONS(-);
DEFINE_BINARY_OPERATIONS(*);
DEFINE_BINARY_OPERATIONS(/ );
DEFINE_BINARAY_SCALAR_OPERATIONS(+);
DEFINE_BINARAY_SCALAR_OPERATIONS(-);
DEFINE_BINARAY_SCALAR_OPERATIONS(*);
inline Vector4& Vector4::operator/=(float k) { return *this *= (1 / k); }
inline Vector4 operator/(const Vector4& v, float k) { return v * (1 / k); }
inline Vector4 operator/(float k, const Vector4& v) { return { k / v.x, k / v.y, k / v.z, k / v.w }; }

#undef DEFINE_BINARY_OPERATIONS
#undef DEFINE_BINARAY_SCALAR_OPERATIONS

inline float dot(const Vector4& v1, const Vector4& v2) {
    return v1.x * v2.x + v1.y * v2.y + v1.z * v2.z + v1.w * v2.w;
}

inline Vector3 Vector4::GetPosition() const {
    auto inv_w = INV(w);
    return { x * inv_w, y * inv_w, z * inv_w };
}

inline bool Vector4::IsZero() const { return x == 0 && y == 0 && z == 0 && w == 0; }

inline void Vector4::UpdateMin(const Vector4& v) {
    update_min(x, v.x);
    update_min(y, v.y);
    update_min(z, v.z);
    update_min(w, v.w);
}

inline void Vector4::UpdateMax(const Vector4& v) {
    update_max(x, v.x);
    update_max(y, v.y);
    update_max(z, v.z);
    update_max(w, v.w);
}

inline void Vector4::SwapIfLargerThan(Vector4& v) {
    swap_if_larger_than(x, v.x);
    swap_if_larger_than(y, v.y);
    swap_if_larger_than(z, v.z);
    swap_if_larger_than(w, v.w);
}

inline float Vector4::Length() const { return sqrtf(dot(*this, *this)); }
inline float Vector4::SquareLength() const { return dot(*this, *this); }
inline Vector4& Vector4::Normalize() { return *this /= Length(); }
inline Vector4& Vector4::SetLength(float length) { return *this *= (length / Length()); }
inline Vector4 Vector4::MakeUnitVector() const { return Vector4{ *this }.Normalize(); }
inline Vector4 Vector4::MakeVectorWithLength(float length) const { return Vector4{ *this }.SetLength(length); }
inline float Vector4::DistanceTo(const Vector4& v) const { return (*this - v).Length(); }
inline float Vector4::SquareDistanceTo(const Vector4& v) const { return (*this - v).SquareLength(); }

#endif // VECTOR4_H
