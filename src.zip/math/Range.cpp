#include "Range.h"

Range2 EMPTY_RANGE2(Range2::EMPTY{});
Range2 FULL_RANGE2(Range2::FULL{});
Range3 EMPTY_RANGE3(Range3::EMPTY{});
Range3 FULL_RANGE3(Range3::FULL{});
