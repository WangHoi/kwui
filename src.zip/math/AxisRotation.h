//
//  AxisRotation.h
//  C2Engine
//
//  Created by mike luo on 2015-2-6.
//
//
#ifndef AXIS_ROTATION_H
#define AXIS_ROTATION_H

#include "math_types.h"
#include "data/data_helpers.h"

struct AxisRotation {
  Axis axis;
  float angle;

  AxisRotation() {}
  AxisRotation(Axis axis, float angle) : axis(axis), angle(angle) {}
};

typedef vector<AxisRotation> MultiAxisRotation;

#endif // AXIS_ROTATION_H