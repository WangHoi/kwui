//
//  float_math.h
//  C2Engine
//
//  Created by mike luo on 12-11-26.
//
//

#ifndef FLOAT_MATH_H
#define FLOAT_MATH_H

#include "math.h"
#include "math_constants.h"
#include <limits>

const float FLOAT_ERROR = 1e-6f;
const float FLOAT_MIN = 1.175494351e-38f;
const float FLOAT_MAX = 3.402823466e+38f;
const float oo = FLOAT_MAX;

#if defined(_MSC_VER) || defined(EMSCRIPTEN)
const float FLOAT_NAN = ((float)std::numeric_limits<float>::quiet_NaN());
const float FLOAT_INF = ((float)std::numeric_limits<float>::infinity());
#else
const float FLOAT_NAN = ((float)NAN);
const float FLOAT_INF = ((float)INFINITY);
#endif

#define INV(x) (1.0f / (x))
#define NEG(x) (-(x))

inline float square(float x) { return x * x; }
inline float pow3(float x) { return x * x * x; }

inline float sign(float x) { return x >= 0.0f ? 1.0f : -1.0f; }
inline int sign_int(float x) { return x >= 0.0f ? 1 : -1; }

inline float square_with_sign(float x) {
  float result = square(x);
  if (x < 0) result = -result;
  return result;
}

inline void sin_cos(float angle, float& sin_out, float& cos_out) {
  if (angle == 0) {
    sin_out = 0;
    cos_out = 1;
  } else {
    sin_out = sinf(angle);
    cos_out = cosf(angle);
  }
}

inline void polar(float r, float phi, float& x_out, float& y_out) {
  sin_cos(phi, y_out, x_out);
  x_out *= r;
  y_out *= r;
}

inline void rotate_2d(float& x, float& y, float phi) {
  float s, c; // sin & cos
  sin_cos(phi, s, c);
  float new_x = c * x - s * y;
  y = s * x + c * y;
  x = new_x;
}

inline float degrees_to_radians(float degrees) {
  return degrees / 180.0f * PI;
}

inline float radians_to_degrees(float radians) {
  return radians / PI * 180.0f;
}

inline float cotf(float radians) {
  return 1 / tanf(radians);
}

inline bool float_zero(float x) {
  return fabsf(x) < FLOAT_ERROR;
}

inline bool float_equal(float x1, float x2) {
  return fabsf(x1 - x2) < FLOAT_ERROR;
}

template <typename T>
inline T clamp(T x, T lower_bound, T upper_bound) {
  if (x < lower_bound) return lower_bound;
  if (x > upper_bound) return upper_bound;
  return x;
}

inline float smooth_step(float t) {
  return t * t * (3 - 2 * t);
}

inline float angle_minimal_difference(float a, float b) {
  float delta = a - b;
  delta = fmodf(delta, PI * 2);
  if (delta > PI) delta -= 2 * PI;
  else if (delta <= -PI) delta += 2 * PI;
  return delta;
}

inline float interpolate_angle(float a0, float a1, float t) {
  return a0 + angle_minimal_difference(a1, a0) * t;
}

#endif // FLOAT_MATH_H
