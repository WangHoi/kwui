#ifndef MATRIX3_H
#define MATRIX3_H

#include "Vector2.h"
#include "Vector3.h"
#include "Range.h"

/***** matrix layout *****
  0  1  2
  3  4  5
  6  7  8
 */

class Quaternion;
class Matrix3 {
public:
    /*** traits classes for constructors ***/
    struct IDENTITY {};
    struct TRANSLATION {};
    struct SCALE {};
    struct FLIP {};
    struct TURN {};
    struct ROTATION {};
    struct ROWS {};
    struct COLUMNS {};
    struct ORTHO_2D {};
    struct CROSS {};

    /***** initializers *****/
    Matrix3() {} // uninitialized
    explicit Matrix3(const float* m) { memcpy(_m, m, sizeof(_m)); }
    Matrix3(float x1, float x2, float x3, float x4, float x5, float x6, float x7, float x8, float x9) {
        _m[0] = x1; _m[1] = x2; _m[2] = x3; _m[3] = x4; _m[4] = x5; _m[5] = x6; _m[6] = x7; _m[7] = x8; _m[8] = x9;
    }

    explicit Matrix3(IDENTITY) { MakeIdentity(); }
    Matrix3(ROWS, const float* v1, const float* v2, const float* v3) { MakeRows(v1, v2, v3); }
    Matrix3(COLUMNS, const float* v1, const float* v2, const float* v3) { MakeColumns(v1, v2, v3); }
    Matrix3(TRANSLATION, float x, float y) { MakeTranslation(x, y); }
    Matrix3(TRANSLATION, const Vector2& v) { MakeTranslation(v); }
    Matrix3(SCALE, float x, float y) { MakeScale(x, y); }
    Matrix3(SCALE, const Vector2& v) { MakeScale(v); }
    Matrix3(FLIP, Axis axis) { MakeFlip(axis); }
    Matrix3(TURN, bool x_flipped, bool y_flipped) { MakeTurn(x_flipped, y_flipped); }
    Matrix3(ROTATION, float cosine, float sine) { MakeRotation(cosine, sine); }
    Matrix3(ROTATION, const Quaternion& q) { SetRotation(q); }
    Matrix3(ORTHO_2D, const Vector2& origin, const Vector2& terminal) { MakeOrtho2D(origin, terminal); }
    Matrix3(CROSS, const Vector3& v1, const Vector3& v2) { MakeCross(v1, v2); }

    /***** setters *****/
    void Set(const float* m) { memcpy(_m, m, sizeof(_m)); }
    void Clear() { memset(_m, 0, sizeof(_m)); }
    void MakeIdentity();
    void MakeRows(const float* v1, const float* v2, const float* v3);
    void MakeColumns(const float* v1, const float* v2, const float* v3);
    void MakeTranslation(float x, float y);
    void MakeTranslation(const Vector2& v) { MakeTranslation(v.x, v.y); }
    void MakeScale(float x, float y);
    void MakeScale(float scale) { MakeScale(scale, scale); }
    void MakeScale(const Vector2& v) { MakeScale(v.x, v.y); }
    void MakeFlip(Axis axis);
    void MakeTurn(bool x_flipped, bool y_flipped);
    void MakeRotation(float cosine, float sine);
    void MakeRotation(const Quaternion& q) { SetRotation(q); }
    void MakeOrtho2D(const Vector2& origin, const Vector2& terminal);
    void MakeCross(const Vector3& v1, const Vector3& v2);

    void SetRows(const float* v1, const float* v2, const float* v3);
    void SetColumns(const float* v1, const float* v2, const float* v3);
    void SetRows(const Vector3& v1, const Vector3& v2, const Vector3& v3) { SetRows(v1.GetBuffer(), v2.GetBuffer(), v3.GetBuffer()); }
    void SetColumns(const Vector3& v1, const Vector3& v2, const Vector3& v3) { SetColumns(v1.GetBuffer(), v2.GetBuffer(), v3.GetBuffer()); }

    // only set the upper-left 2x2 matrix
    void SetScaleWithoutRotation(const Vector2& scale);
    void SetRotation(float cosine, float sine);
    void SetRotation(const Quaternion& q);

    // only set the lower-left 1x2 matrix
    void SetTranslation(float x, float y);
    void SetTranslation(const Vector2& v) { SetTranslation(v.x, v.y); }

    // set last column to (0, 0, 1)
    void ResetLastColumn();

    /***** getters *****/
    const float* GetBuffer() const { return _m; }
    float* GetBuffer() { return _m; }

    /***** transformations *****/
    Matrix3& Scale(float x, float y);
    Matrix3& Scale(float scale) { return Scale(scale, scale); }
    Matrix3& Scale(const Vector2& v) { return Scale(v.x, v.y); }
    Matrix3& TranslateAffine(float x, float y);
    Matrix3& TranslateAffine(const Vector2& v) { return TranslateAffine(v.x, v.y); }
    Matrix3& Flip(Axis axis);
    Matrix3& Rotate(const Quaternion& q) { return *this = *this * Matrix3(ROTATION(), q); }
    Matrix3& Transform(const Matrix3& m) { return *this = *this * m; }

    /***** operations *****/
    friend Matrix3 operator*(const Matrix3& m1, const Matrix3& m2);
    Matrix3& operator+=(const Matrix3& m);
    Matrix3& operator*=(float k);
    Matrix3 ComputeMul(float k) const;

    Matrix3& Transpose();
    Matrix3 ComputeTranspose() const;
    float ComputeDeterminant() const;
    Matrix3 ComputeInverse() const;
    Matrix3 ComputeInverseTranspose() const;
    Vector3 ExtractScale() const;
    Vector2 ExtractTranslation() const { return { _m[6], _m[7] }; }

    Vector3 Transform(const Vector3& v) const;
    Vector2 TransformPositionAffine(const Vector2& v) const;

    Vector2 GetTranslation() const { return { _m[6], _m[7] }; }
    float ComputeRotationOrtho() const { return atan2f(_m[1], _m[0]); }

    Range2 TransformAABBAffine(const Range2& aabb) const;

private:
    float _m[9];

    friend class Quaternion;
    friend class Matrix4;
};

extern const Matrix3 IDENTITY_MATRIX3;

#endif // MATRIX3_H
