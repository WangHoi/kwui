#include "stdafx.h"
//
//  LinearSampler.cpp
//  C2Engine
//
//  Created by mike luo on 12-12-9.
//
//

#include "LinearSampler.h"

void LinearSampler::Initialize(const Vector3& p0, const Vector3& p1) {
  _c0 = p0;
  _c1 = p1 - p0;
}

void LinearSampler::Sample(float t, Vector3* position, Vector3* tangent) {
  *position = _c0 + _c1 * t;
  if (tangent) *tangent = _c1.MakeUnitVector();
}