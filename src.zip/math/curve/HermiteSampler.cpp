#include "stdafx.h"
//
//  HermiteSampler.cpp
//  C2Engine
//
//  Created by mike luo on 12-12-9.
//
//

#include "HermiteSampler.h"

void HermiteSampler::Initialize(const Vector3& p0, const Vector3& v0,
                                const Vector3& p1, const Vector3& v1) {
  _c0 = p0;
  _c1 = v0;
  _c2 = p0 * (-3) - v0 * 2 - v1 + p1 * 3;
  _c3 = p0 * 2 + v0 + v1 - p1 * 2;
}