//
//  CubicSplineInterpolator.h
//  C2Engine
//
//  Created by mike luo on 2013-10-8.
//
//

#include "CubicSplineSegment.h"
#include "debug/debug_helpers.h"

template <typename FType>
class CubicSplineInterpolator {
public:
  enum BoundaryConditionType {
    STATIC_BOUNDARY_CONDITION,
    NATURAL_BOUNDARY_CONDITION,
    PERIODIC_BOUNDARY_CONDITION
  };

  vector<CubicSplineSegment<FType> > Run(int N, float* x, FType* f, BoundaryConditionType boundary_condition_type) {
    if (N == 0) return {};
    auto mu = ComputeMu(N, x, boundary_condition_type);
    auto D = ComputeD(N, x, f, boundary_condition_type);
    auto M = ComputeM(N, x, f, mu.data(), D.data(), boundary_condition_type);
    // CheckResult(N, x, f, M.data());
    return ComputeSegments(N, x, f, M.data());
  }
private:

  vector<float> ComputeMu(int N, float* x, BoundaryConditionType boundary_condition_type) {
    vector<float> mu(N + 1);
    float t;
    for (int j = 1; j < N; j++) {
      t = x[j - 1];
      mu[j] = (x[j] - t) / (x[j + 1] - t);
    }
    switch (boundary_condition_type) {
      case STATIC_BOUNDARY_CONDITION:
        mu[0] = 0; // lambda[0] = 1
        mu[N] = 1;
        break;
      case NATURAL_BOUNDARY_CONDITION:
        mu[0] = 1; // lambda[0] = 0
        mu[N] = 0;
        break;
      case PERIODIC_BOUNDARY_CONDITION:
        mu[0] = 1; // lambda[0] = 0
        t = x[N] - x[N - 1];
        mu[N] = t / (t + x[1] - x[0]);
        break;
    }
    return mu;
  }

  vector<FType> ComputeD(int N, float* x, FType* f, BoundaryConditionType boundary_condition_type) {
    vector<FType> D(N + 1);
    float h0, h1;
    FType d0, d1;
    for (int j = 1; j < N; j++) {
      h0 = x[j] - x[j - 1];
      h1 = x[j + 1] - x[j];
      d0 = (f[j] - f[j - 1]) / h0;
      d1 = (f[j + 1] - f[j]) / h1;
      D[j] = (d1 - d0) * (6 / (h0 + h1));
    }
    switch (boundary_condition_type) {
      case STATIC_BOUNDARY_CONDITION:
        D[0] = (f[1] - f[0]) * (6 / square(x[1] - x[0]));
        D[N] = (f[N] - f[N - 1]) * (-6 / square(x[N] - x[N - 1]));
        break;
      case NATURAL_BOUNDARY_CONDITION:
        D[0] = FType{0.0f};
        D[N] = FType{0.0f};
        break;
      case PERIODIC_BOUNDARY_CONDITION:
        D[0] = FType{0.0f};
        h0 = x[1] - x[0];
        h1 = x[N] - x[N - 1];
        d0 = (f[1] - f[0]) / h0;
        d1 = (f[N] - f[N - 1]) / h1;
        D[N] = (d0 - d1) * (6 / (h0 + h1));
        break;
    }
    return D;
  }

  vector<FType> ComputeM(int N, float* x, FType* f, float* mu, FType* D, BoundaryConditionType boundary_condition_type) {
    vector<FType> M(N + 1);
    if (boundary_condition_type == STATIC_BOUNDARY_CONDITION || boundary_condition_type == NATURAL_BOUNDARY_CONDITION) {
      // a[j] * M[j] + b[j] * M[j + 1] = C[j]
      //   b[j] === lambda[j] === 1 - mu[j]
      vector<float> a(N);
      vector<FType> C(N);
      a[0] = 2;
      C[0] = D[0];
      for (int j = 0; j < N - 1; j++) {
        float t = mu[j + 1] / a[j];
        a[j + 1] = 2 - (1 - mu[j]) * t;
        C[j + 1] = D[j + 1] - C[j] * t;
      }

      float a11 = a[N - 1], a12 = 1 - mu[N - 1], a21 = mu[N], a22 = 2;
      FType& Y1 = C[N - 1], &Y2 = D[N];
      float det_inv = 1 / (a11 * a22 - a12 * a21);
      M[N - 1] = (Y1 * a22 - Y2 * a12) * det_inv;
      M[N] = (Y2 * a11 - Y1 * a21) * det_inv;

      for (int j = N - 2; j >= 0; j--) {
        M[j] = (C[j] - M[j + 1] * (1 - mu[j])) / a[j];
      }
    } else if (boundary_condition_type == PERIODIC_BOUNDARY_CONDITION) {
      // a[j] * M[j] + b[j] * M[j + 1] + e[j] * M[N] = C[j]
      //   b[j] === lambda[j] === 1 - mu[j]
      vector<float> a(N);
      vector<float> e(N);
      vector<FType> C(N);
      a[0] = 1;
      e[0] = -1;
      C[0] = FType{0.0f};

      // ta(j) * M[j + 1] + tb(j) * M[N - 1] + te(j) * M[N] = tC(j) 
      float ta = 1 - mu[N], tb = mu[N], te = 2;
      FType tC = D[N];

      for (int j = 0; j < N - 1; j++) {
        float t = mu[j + 1] / a[j];
        a[j + 1] = 2 - (1 - mu[j]) * t;
        e[j + 1] = -e[j] * t;
        C[j + 1] = D[j + 1] - C[j] * t;

        t = ta / a[j + 1];
        ta = -(1 - mu[j + 1]) * t;
        te -= e[j + 1] * t;
        tC -= C[j + 1] * t;
      }

      float a11 = a[N - 1], a12 = 1 - mu[N - 1] + e[N - 1], a21 = tb, a22 = ta + te;
      FType& Y1 = C[N - 1], &Y2 = tC;
      float det_inv = 1 / (a11 * a22 - a12 * a21);
      M[N - 1] = (Y1 * a22 - Y2 * a12) * det_inv;
      M[N] = (Y2 * a11 - Y1 * a21) * det_inv;

      for (int j = N - 2; j >= 0; j--) {
        M[j] = (C[j] - M[j + 1] * (1 - mu[j]) - M[N] * e[j]) / a[j];
      }

    } else {
      assert(false);
    }

    return M;
  }

  vector<CubicSplineSegment<FType> > ComputeSegments(int N, float* x, FType* f, FType* M) {
    vector<CubicSplineSegment<FType> > segments(N);
    for (int j = 0; j < N; j++) {
      auto& s = segments[j];
      float h = x[j + 1] - x[j];
      FType& M0 = M[j], &M1 = M[j + 1];
      float t = 1 / (6 * h);
      s.C[0] = M0 * t;
      s.C[1] = M1 * t;
      s.C[2] = (f[j] / h - M0 * h / 6);
      s.C[3] = (f[j + 1] / h - M1 * h / 6);
    }
    return segments;
  }

  FType RightDerivative(int i, float* x, FType* f, FType* M) {
    float h = x[i + 1] - x[i];
    return M[i] * (-h / 3) - M[i + 1] * (h / 6) + (f[i + 1] - f[i]) / h;
  }

  FType LeftDerivative(int i, float* x, FType* f, FType* M) {
    float h = x[i] - x[i - 1];
    return M[i - 1] * (h / 6) + M[i] * (h / 3) + (f[i] - f[i - 1]) / h;
  }

};