//
//  CatmullRomCurve.h
//  C2Engine
//
//  Created by mike luo on 12-12-3.
//
//

#ifndef CATMULL_ROM_CURVE_H
#define CATMULL_ROM_CURVE_H

#include "Curve.h"
#include "CatmullRomSampler.h"

class CatmullRomCurve : public Curve {
public:
  CatmullRomCurve(float tao, float t_base = 0.0f);
  virtual ~CatmullRomCurve();

  virtual void PushBack(const Vector3& knot);
  virtual void PopFront();

  virtual void Sample(int segment, float t, Vector3* position,
                      Vector3* tangent = NULL,
                      Vector3* normal = NULL) const;

private:
  void SetupSampler(int segment) const;

  float _tao;
  mutable CatmullRomSampler _sampler;
  mutable int _sampler_index;
};

#endif // CATMULL_ROM_CURVE_H
