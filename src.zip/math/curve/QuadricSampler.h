#pragma once

#include "math/Vector3.h"

class QuadricSampler2D {
public:
  void Sample(float t, Vector2* position, Vector2* tangent = nullptr);

  Vector2 c0, c1, c2;
};

