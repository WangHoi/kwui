//
//  CubicSampler.h
//  C2Engine
//
//  Created by mike luo on 12-12-9.
//
//

#ifndef CUBIC_SAMPLER_H
#define CUBIC_SAMPLER_H

#include "math/Vector3.h"

class CubicSampler {
public:
  void Sample(float t, Vector3* position, Vector3* tangent, Vector3* normal);
  
protected:
  CubicSampler() {} // abstract class
  Vector3 _c0, _c1, _c2, _c3;
};

#endif // CUBIC_SAMPLER_H
