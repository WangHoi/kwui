#include "stdafx.h"
//
//  Curve.cpp
//  C2Engine
//
//  Created by mike luo on 12-12-3.
//
//

#include "Curve.h"
#include "data/data_helpers.h"

const Vector3& Curve::GetKnot(int index) const {
  return get_with_negative_index(_knots, index);
}

const Vector3& Curve::GetTangent(int index) const {
  return get_with_negative_index(_tangents, index);
}

int Curve::SegmentIndexFromT(float t) const {
  t -= _t_base;

  int segment = (int) floorf(t);
  int length = GetLength();

  if (segment < 0) segment = 0;
  else if (segment >= length) segment = length - 1;

  return segment;
}

void Curve::Sample(float t, Vector3* position, Vector3* tangent, Vector3* normal) const {
  int segment = SegmentIndexFromT(t);
  t -= _t_base;
  Sample(segment, t - segment, position, tangent, normal);
}

unique_ptr<vector<Vector3> > Curve::UniformlySample(int sample_count, int multisample_rate) const {
  int space_count = sample_count - 1;
  int sub_space_count = space_count * multisample_rate;
  int multisample_count = sub_space_count + 1;
  float sub_space_width = GetLength() / (float) sub_space_count;
  float t = _t_base;
  Vector3 sample;
  vector<Vector3> multisamples(multisample_count);
  for (int i = 0; i < multisample_count; i++) {
    Sample(t, &multisamples[i]);
    t += sub_space_width;
  }
  vector<float> arch_length(multisample_count);
  for (int i = 1; i < multisample_count; i++) {
    arch_length[i] = multisamples[i - 1].DistanceTo(multisamples[i]) + arch_length[i - 1];
  }
  float average_arch_length = arch_length[sub_space_count] / space_count;
  unique_ptr<vector<Vector3> > samples_ptr(new vector<Vector3>(sample_count));
  vector<Vector3>& samples = *samples_ptr;
  samples[0] = multisamples[0];
  int i = 1;
  float s = 0;
  for (int j = 1; j < space_count; j++) {
    s += average_arch_length;
    while (arch_length[i] < s) i++;
    samples[j] = multisamples[i];
  }
  samples[space_count] = multisamples[sub_space_count];
  return samples_ptr;
}

#include "HermiteCurve.h"

class UniformlySampleUnitTest {
public:
  UniformlySampleUnitTest() {
    HermiteCurve curve;
    vector<Vector3> knots = {Vector3(0.1f, 0, 0), Vector3(0.3f, 0, 0), Vector3(0.5f, 1.0f, 0), Vector3(0.7f, 0, 0), Vector3(0.9f, 0, 0)};
    Vector3 tangent(1, 0, 0);
    for (auto& knot: knots) curve.PushBackWithTangent(knot, tangent);
    curve.UniformlySample(10, 10);
  }
};

// static UniformlySampleUnitTest test;