//
//  CubicSampler.cpp
//  C2Engine
//
//  Created by mike luo on 12-12-9.
//
//
#include "stdafx.h"
#include "CubicSampler.h"

void CubicSampler::Sample(float t, Vector3* position, Vector3* tangent, Vector3* normal) {
  float t2 = t * t, t3 = t2 * t;
  *position = _c0 + _c1 * t + _c2 * t2 + _c3 * t3;
  if (tangent) {
    Vector3 dr = _c1 + _c2 * (2 * t) + _c3 * (3 * t2);
    float dr_length_r = 1.0f / dr.Length();
    *tangent = dr; //dr * dr_length_r;
    if (normal) {
      Vector3 ddr = _c2 * 2 + _c3 * (6 * t);
      float d_dr_length = dot(dr, ddr) * dr_length_r;
      *normal = ddr - dr * d_dr_length * dr_length_r;
      normal->Normalize();
    }
  }
}