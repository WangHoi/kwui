//
//  CubicSplineSegment.h
//  C2Engine
//
//  Created by mike luo on 2013-11-20.
//
//

#ifndef CUBIC_SPLINE_SEGMENT_H
#define CUBIC_SPLINE_SEGMENT_H

template <typename FType>
struct CubicSplineSegment {
  FType C[4];

  FType Sample(float x, float l, float r) const {
    // the precision will suffer if expand this expression
    float xr = r - x;
    float xl = x - l;
    return (C[0] * (xr * xr) + C[2]) * xr + (C[1] * (xl * xl) + C[3]) * xl;
  }
};

#endif // CUBIC_SPLINE_SEGMENT_H