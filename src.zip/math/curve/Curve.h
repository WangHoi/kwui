//
//  Curve.h
//  C2Engine
//
//  Created by mike luo on 12-12-3.
//
//

#ifndef CURVE_H
#define CURVE_H

#include "data/data_helpers.h"
#include "memory/memory_helpers.h"
#include "math/Vector3.h"

class Curve {
public:
  Curve(float t_base) : _knots(), _tangents(), _t_base(t_base) {}
  virtual ~Curve() {}

  virtual void PushBack(const Vector3& knot) { _knots.push_back(knot); }
  virtual void PopFront() {
    _knots.pop_front();
    _t_base += 1;
  }

  virtual void PushBackWithTangent(const Vector3& knot, const Vector3& tangent) {
    PushBack(knot);
    _tangents.push_back(tangent);
  }

  virtual void PopFrontWithTangent() {
    PopFront();
    _tangents.pop_front();
  }

  const Vector3& GetKnot(int index) const;
  const Vector3& GetTangent(int index) const;

  void Sample(float t, Vector3* position,
              Vector3* tangent = NULL,
              Vector3* normal = NULL) const;

  virtual void Sample(int segment, float t, Vector3* position,
                      Vector3* tangent = NULL,
                      Vector3* normal = NULL) const = 0;

  int GetLength() const { return _knots.size() - 1; }
  float GetBaseT() const { return _t_base; }
  float GetEndT() const { return _t_base + GetLength(); }
  int SegmentIndexFromT(float t) const;

  unique_ptr<vector<Vector3> > UniformlySample(int sample_count, int multisample_rate) const;

protected:
  typedef std::deque<Vector3> VectorList;

  VectorList _knots;
  VectorList _tangents;
  float _t_base; // control point 0 is at t_base
};

#endif // CURVE_H
