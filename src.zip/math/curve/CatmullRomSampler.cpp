#include "stdafx.h"
//
//  CatmullRomSampler.cpp
//  C2Engine
//
//  Created by mike luo on 12-12-3.
//
//

#include "CatmullRomSampler.h"

void CatmullRomSampler::Initialize(const Vector3& p0, const Vector3& p1,
                                   const Vector3& p2, const Vector3& p3,
                                   float tao) {
  _c0 = p1;
  _c1 = p0 * (-tao) + p2 * tao;
  _c2 = p0 * (2 * tao) + p1 * (tao - 3) + p2 * (3 - 2 * tao) - p3 * tao;
  _c3 = p0 * (-tao) + p1 * (2 - tao) + p2 * (tao - 2) + p3 * tao;
}