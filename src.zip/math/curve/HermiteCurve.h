//
//  HermiteCurve.h
//  C2Engine
//
//  Created by mike luo on 12-12-9.
//
//

#ifndef HERMITE_CURVE_H
#define HERMITE_CURVE_H

#include "Curve.h"
#include "HermiteSampler.h"

class HermiteCurve : public Curve {
public:
  HermiteCurve(float t_base = 0.0f);
  virtual ~HermiteCurve();

  virtual void PushBackWithTangent(const Vector3& knot, const Vector3& tangent);
  virtual void PopFrontWithTangent();

  virtual void Sample(int segment, float t, Vector3* position,
                      Vector3* tangent = NULL,
                      Vector3* normal = NULL) const;

private:
  void SetupSampler(int segment) const;

  mutable HermiteSampler _sampler;
  mutable int _sampler_index;
};

#endif // HERMITE_CURVE_H
