#include "stdafx.h"
#include "QuadricSampler.h"

void QuadricSampler2D::Sample(float t, Vector2* position, Vector2* tangent) {
  auto one_minus_t = 1 - t;
  *position = c0 * (one_minus_t * one_minus_t) + c1 * (2.f * t * one_minus_t) + c2 * (t * t);
  if (tangent) *tangent = (c1 - c0) * (2.f * one_minus_t) + (c2 - c1) * (2.f * t);
}
