//
//  HermiteSampler.h
//  C2Engine
//
//  Created by mike luo on 12-12-9.
//
//

#ifndef HERMITE_SAMPLER_H
#define HERMITE_SAMPLER_H

#include "CubicSampler.h"

class HermiteSampler : public CubicSampler {
public:
  void Initialize(const Vector3& p0, const Vector3& v0,
                  const Vector3& p1, const Vector3& v1);
};

#endif // HERMITE_SAMPLER_H
