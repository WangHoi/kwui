//
//  LinearSampler.h
//  C2Engine
//
//  Created by mike luo on 12-12-9.
//
//

#ifndef LINEAR_SAMPLER_H
#define LINEAR_SAMPLER_H

#include "math/Vector3.h"

class LinearSampler {
public:
  void Initialize(const Vector3& p0, const Vector3& p1);
  void Sample(float t, Vector3* position, Vector3* tangent);

private:
  Vector3 _c0, _c1;
};

#endif // LINEAR_SAMPLER_H
