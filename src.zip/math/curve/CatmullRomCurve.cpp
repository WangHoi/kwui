#include "stdafx.h"
//
//  CatmullRomCurve.cpp
//  C2Engine
//
//  Created by mike luo on 12-12-3.
//
//

#include "CatmullRomCurve.h"
#include "debug/debug_helpers.h"
#include <math.h>

CatmullRomCurve::CatmullRomCurve(float tao, float t_base)
: _tao(tao), Curve(t_base), _sampler_index(-1) {}

CatmullRomCurve::~CatmullRomCurve() {}

void CatmullRomCurve::PushBack(const Vector3& knot) {
  Curve::PushBack(knot);
  _sampler_index = -1;
}

void CatmullRomCurve::PopFront() {
  Curve::PopFront();
  _sampler_index = -1;
}

void CatmullRomCurve::SetupSampler(int segment) const {
  if (segment == _sampler_index) return;

  const int i = segment; // alias
  bool first_segment = (i == 0);
  bool last_segment = (i + 1 == GetLength());
  
  const Vector3& p1 = _knots[i];
  const Vector3& p2 = _knots[i + 1];
  const Vector3& p0 = (first_segment ? p1 : _knots[i - 1]);
  const Vector3& p3 = (last_segment ? p2 : _knots[i + 2]);
  
  _sampler.Initialize(p0, p1, p2, p3, _tao);
  _sampler_index = segment;
}

void CatmullRomCurve::Sample(int segment, float t, Vector3* position, Vector3* tangent, Vector3* normal) const {
  SetupSampler(segment);
  _sampler.Sample(t, position, tangent, normal);
}