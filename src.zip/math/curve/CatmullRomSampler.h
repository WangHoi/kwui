//
//  CatmullRomSampler.h
//  C2Engine
//
//  Created by mike luo on 12-12-3.
//
//

#ifndef CATMULL_ROM_SAMPLER_H
#define CATMULL_ROM_SAMPLER_H

#include "CubicSampler.h"

class CatmullRomSampler : public CubicSampler {
public:
  void Initialize(const Vector3& p0, const Vector3& p1,
                  const Vector3& p2, const Vector3& p3,
                  float tao);
};

#endif // CATMULL_ROM_SAMPLER_H
