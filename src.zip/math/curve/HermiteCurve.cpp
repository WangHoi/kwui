#include "stdafx.h"
//
//  HermiteCurve.cpp
//  C2Engine
//
//  Created by mike luo on 12-12-9.
//
//

#include "HermiteCurve.h"

HermiteCurve::HermiteCurve(float t_base) : Curve(t_base), _sampler_index(-1) {}
HermiteCurve::~HermiteCurve() {}

void HermiteCurve::PushBackWithTangent(const Vector3& knot, const Vector3& tangent) {
  Curve::PushBackWithTangent(knot, tangent); // sampler is still valid
}

void HermiteCurve::PopFrontWithTangent() {
  Curve::PopFrontWithTangent();
  if (_sampler_index <= 0) _sampler_index = -1; // sampler becomes invalid
  else _sampler_index--; // sampler is still valid
}

void HermiteCurve::Sample(int segment, float t, Vector3* position,
                          Vector3* tangent,
                          Vector3* normal) const {
  SetupSampler(segment);
  _sampler.Sample(t, position, tangent, normal);
}

void HermiteCurve::SetupSampler(int segment) const {
  if (segment == _sampler_index) return;
  int i = segment; // alias

  _sampler.Initialize(_knots[i], _tangents[i], _knots[i + 1], _tangents[i + 1]);
  _sampler_index = segment;
}