//
//  C2Math.h
//  C2Engine
//
//  Created by mike luo on 12-11-28.
//
//
#ifndef C2_MATH_H
#define C2_MATH_H

#include "math_constants.h"
#include "math_templates.h"
#include "float_math.h"
#include "integer_math.h"
#include "bit_arithmetics.h"
#include "random/random_helpers.h"

#include "math_types.h"
#include "Vector2.h"
#include "Vector3.h"
#include "Vector4.h"
#include "vector_math.h"
#include "Matrix3.h"
#include "Matrix4.h"
#include "Range.h"
#include "Quaternion.h"

#include "equation/C2Equation.h"
#include "geometry/C2Geometry.h"
#include "curve/C2Curve.h"

#endif // C2_MATH_H
