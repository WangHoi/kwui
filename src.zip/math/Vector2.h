#ifndef VECTOR2_H
#define VECTOR2_H

#include "float_math.h"
#include "math_templates.h"

class Vector2 {
public:
    float x, y;

    struct EMPTY_RANGE {};
    struct CENTER_RADIUS {};
    struct POLAR {};

    /***** initializers *****/
    Vector2() {} // uninitialized
    explicit Vector2(float v) { Set(v); }
    Vector2(float x, float y) { Set(x, y); }
    explicit Vector2(const float* v) { Set(v); }
    Vector2(const Vector2& v) { Set(v.x, v.y); }
    Vector2(EMPTY_RANGE) { SetEmptyRange(); }
    Vector2(CENTER_RADIUS, float center, float radius) { SetCenterRadius(center, radius); }
    Vector2(POLAR, float phi) { SetPolar(phi); }
    Vector2(POLAR, float phi, float radius) { SetPolar(phi, radius); }

    /***** getters *****/
    const float* GetBuffer() const { return (const float*)this; }
    float* GetBuffer() { return (float*)this; }
    const float& operator[](int index) const { return GetBuffer()[index]; } // no bound check!
    float& operator[](int index) { return GetBuffer()[index]; } // no bound check!

    /***** setters *****/
    Vector2& operator=(const Vector2& v) {
        if (this != &v) Set(v.x, v.y);
        return *this;
    }

    void Set(float x, float y) {
        this->x = x;
        this->y = y;
    }

    void Set(float v) { Set(v, v); }
    void Set(const float* v) { Set(v[0], v[1]); }

    void SetEmptyRange() { Set(oo, -oo); }
    void SetCenterRadius(float center, float radius) { Set(center - radius, center + radius); }
    void SetPolar(float phi) { Set(cosf(phi), sinf(phi)); }
    void SetPolar(float phi, float radius) { Set(cosf(phi) * radius, sinf(phi) * radius); }

    /***** operations *****/
    Vector2& operator+=(const Vector2& v);
    Vector2& operator-=(const Vector2& v);
    Vector2& operator*=(const Vector2& v);
    Vector2& operator/=(const Vector2& v);
    Vector2& operator+=(float k);
    Vector2& operator-=(float k);
    Vector2& operator*=(float k);
    Vector2& operator/=(float k);

#define DECLARE_METHOD_FUNCTION(Method) \
    Vector2& Method(); \
    Vector2 Make##Method() const;

    DECLARE_METHOD_FUNCTION(Negate);
    DECLARE_METHOD_FUNCTION(Inverse);
    DECLARE_METHOD_FUNCTION(Round);
    DECLARE_METHOD_FUNCTION(Abs);
#undef DECLARE_METHOD_FUNCTION

    bool IsZero() const;
    void UpdateMin(const Vector2& v);
    void UpdateMax(const Vector2& v);
    void SwapIfLargerThan(Vector2& v);
    void Sort();

    float Length() const;
    float SquareLength() const;
    Vector2& Normalize();
    Vector2 MakeUnitVector() const;
    float DistanceTo(const Vector2& v) const;
    float SquareDistanceTo(const Vector2& v) const;

    float GetArgument() const;
    Vector2& Rotate(float phi);
    Vector2 MakeRotatedVector(float phi) const;
    Vector2 MakeOrthoVector() const;

    float GetSizeAspect() const;
    bool IsEmptySize() const;

    bool IsEmptyRange() const;
    void RangeClamp(float& v) const;
    void ExtendRange(float v);
    float GetRangeSpan() const;
    float GetRangeT(float value) const;
    float GetRangeCenter() const;
    float SampleRange(float t) const;
    float SmoothSample(float t) const;
    void Smooth(float& value) const;
    bool RangeOverlap(const Vector2& r) const;
    bool RangeContain(float v) const;
};

/***** constants *****/
extern const Vector2 ZERO_VECTOR2;
extern const Vector2 UP_VECTOR2;
extern const Vector2 DOWN_VECTOR2;
extern const Vector2 RIGHT_VECTOR2;
extern const Vector2 LEFT_VECTOR2;

/*** arithmetics ***/
inline Vector2 operator-(const Vector2& v) { return { -v.x, -v.y }; }

#define DEFINE_BINARY_OPERATIONS(op) \
  inline Vector2& Vector2::operator op##=(const Vector2& v) { \
    x op##= v.x; \
    y op##= v.y; \
    return *this; \
  } \
  inline Vector2 operator op(const Vector2& v1, const Vector2& v2) { return {v1.x op v2.x, v1.y op v2.y}; }

#define DEFINE_BINARAY_SCALAR_OPERATIONS(op) \
  inline Vector2& Vector2::operator op##=(float k) { \
    x op##= k; \
    y op##= k; \
    return *this; \
  } \
  inline Vector2 operator op(const Vector2& v, float k) { return {v.x op k, v.y op k}; }

DEFINE_BINARY_OPERATIONS(+);
DEFINE_BINARY_OPERATIONS(-);
DEFINE_BINARY_OPERATIONS(*);
DEFINE_BINARY_OPERATIONS(/ );
DEFINE_BINARAY_SCALAR_OPERATIONS(+);
DEFINE_BINARAY_SCALAR_OPERATIONS(-);
DEFINE_BINARAY_SCALAR_OPERATIONS(*);
inline Vector2& Vector2::operator/=(float k) { return *this *= (1 / k); }
inline Vector2 operator/(const Vector2& v, float k) { return v * (1 / k); }
inline Vector2 operator/(float k, const Vector2& v) { return { k / v.x, k / v.y }; }

#undef DEFINE_BINARY_OPERATIONS
#undef DEFINE_BINARAY_SCALAR_OPERATIONS

inline float dot(const Vector2& v1, const Vector2& v2) { return v1.x * v2.x + v1.y * v2.y; }
inline float cross(const Vector2& v1, const Vector2& v2) { return v1.x * v2.y - v1.y * v2.x; }

/*** methods ***/

#define DEFINE_METHOD_FUNCTION(Method, method) \
  inline Vector2 Vector2::Make##Method() const { return {method(x), method(y)}; } \
  inline Vector2& Vector2::Method() { \
    x = method(x); \
    y = method(y); \
    return *this; \
  }

DEFINE_METHOD_FUNCTION(Abs, fabsf);
DEFINE_METHOD_FUNCTION(Round, roundf);
DEFINE_METHOD_FUNCTION(Inverse, INV);
DEFINE_METHOD_FUNCTION(Negate, NEG);

#undef DEFINE_METHOD_FUNCTION

/*** compare ***/
#define DEFINE_COMPARE_FUNCTION(op) \
  inline bool operator op(const Vector2& v1, const Vector2& v2) { return (v1.x op v2.x) && (v1.y op v2.y); }

DEFINE_COMPARE_FUNCTION(== )
DEFINE_COMPARE_FUNCTION(< )
    DEFINE_COMPARE_FUNCTION(> )
    DEFINE_COMPARE_FUNCTION(<= )
    DEFINE_COMPARE_FUNCTION(>= )
    inline bool operator!=(const Vector2& v1, const Vector2& v2) { return (v1.x != v2.x) || (v1.y != v2.y); }

#undef DEFINE_COMPARE_FUNCTION

inline bool Vector2::IsZero() const { return x == 0 && y == 0; }

inline void Vector2::UpdateMin(const Vector2& v) {
    update_min(x, v.x);
    update_min(y, v.y);
}

inline void Vector2::UpdateMax(const Vector2& v) {
    update_max(x, v.x);
    update_max(y, v.y);
}

inline void Vector2::SwapIfLargerThan(Vector2& v) {
    swap_if_larger_than(x, v.x);
    swap_if_larger_than(y, v.y);
}

inline void Vector2::Sort() {
    if (x > y) swap(x, y);
}

/*** about length ***/
inline float Vector2::Length() const { return sqrtf(dot(*this, *this)); }
inline float Vector2::SquareLength() const { return dot(*this, *this); };
inline Vector2& Vector2::Normalize() { return *this /= Length(); }
inline Vector2 Vector2::MakeUnitVector() const { return Vector2{ *this }.Normalize(); }
inline float Vector2::DistanceTo(const Vector2& v) const { return (*this - v).Length(); }
inline float Vector2::SquareDistanceTo(const Vector2& v) const { return (*this - v).SquareLength(); }

/*** about direction ***/
inline float Vector2::GetArgument() const { return atan2f(y, x); }
inline Vector2 Vector2::MakeRotatedVector(float phi) const { return Vector2{ *this }.Rotate(phi); }
inline Vector2 Vector2::MakeOrthoVector() const { return Vector2{ -y, x }.Normalize(); }

inline Vector2& Vector2::Rotate(float phi) {
    rotate_2d(x, y, phi);
    return *this;
}

/*** Vector2 as size ***/
inline float Vector2::GetSizeAspect() const { return x / y; }
inline bool Vector2::IsEmptySize() const { return x <= 0 || y <= 0; }

/*** Vector2 as range ***/
inline bool Vector2::IsEmptyRange() const { return x > y; }
inline void Vector2::RangeClamp(float& v) const { v = clamp(v, x, y); }
inline float Vector2::GetRangeSpan() const { return y - x; }
inline float Vector2::GetRangeT(float value) const { return (value - x) / (y - x); }
inline float Vector2::GetRangeCenter() const { return (x + y) * 0.5f; }
inline float Vector2::SampleRange(float t) const { return (1 - t) * x + t * y; }
inline float Vector2::SmoothSample(float t) const { return SampleRange(smooth_step(t)); }
inline void Vector2::Smooth(float& value) const { value = SmoothSample(GetRangeT(value)); }
inline bool Vector2::RangeContain(float v) const { return x <= v && v <= y; }

inline void Vector2::ExtendRange(float v) {
    if (v < x) x = v;
    if (v > y) y = v;
}

inline bool Vector2::RangeOverlap(const Vector2& r) const {
    if (r.x > y) return false;
    if (r.y < x) return false;
    return true;
}

#endif // VECTOR2_H