#include "Vector3.h"

const Vector3 ZERO_VECTOR3(0, 0, 0);
const Vector3 UP_VECTOR3(0, 1, 0);
const Vector3 DOWN_VECTOR3(0, -1, 0);
const Vector3 RIGHT_VECTOR3(1, 0, 0);
const Vector3 LEFT_VECTOR3(-1, 0, 0);
const Vector3 FRONT_VECTOR3(0, 0, 1);
const Vector3 BACK_VECTOR3(0, 0, -1);

Vector3& Vector3::SetSpherical(float radius, float theta, float phi) {
    float sin_phi, cos_phi, sin_theta, cos_theta;
    sin_cos(phi, sin_phi, cos_phi);
    sin_cos(theta, sin_theta, cos_theta);
    Set(cos_theta * sin_phi, sin_theta, cos_theta * cos_phi);
    return *this *= radius;
}

Vector3& Vector3::SetSpherical(const Vector3& base1, const Vector3& base2, float radius, float theta, float phi) {
    float sin_phi, cos_phi, sin_theta, cos_theta;
    sin_cos(phi, sin_phi, cos_phi);
    sin_cos(theta, sin_theta, cos_theta);
    float x = cos_theta * cos_phi;
    float y = cos_theta * sin_phi;
    float z = sin_theta;
    auto base3 = base1.Cross(base2);
    Set(base1.x * x + base2.x * y + base3.x * z,
        base1.y * x + base2.y * y + base3.y * z,
        base1.z * x + base2.z * y + base3.z * z);
    return *this *= radius;

}

Vector3& Vector3::SetPolar(const Vector3& base1, const Vector3& base2, float radius, float phi) {
    float x, y;
    polar(radius, phi, x, y);
    return *this = base1 * x + base2 * y;
}
