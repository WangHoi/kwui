//
//  vector_math.h
//  C2Engine
//
//  Created by mike luo on 2014-4-23.
//
//
#ifndef VECTOR_MATH_H
#define VECTOR_MATH_H

#include "Vector2.h"
#include "Vector3.h"
#include "Vector4.h"

template <typename VectorType>
float get_vector_length(const VectorType& vector) {
  return vector.Length();
}

inline float get_vector_length(const float& x) { return fabsf(x); }

template <typename VectorType>
bool is_zero_vector(const VectorType& vector) {
  return vector.IsZero();
}

inline bool is_zero_vector(const float& x) { return x == 0; }

template <typename VectorType>
bool vector_step_to(VectorType& v, const VectorType& vector_target, float step) {
  VectorType dv = vector_target - v;
  if (is_zero_vector(dv)) return true;
  float dl = get_vector_length(dv);
  if (dl <= step) {
    v = vector_target;
    return true;
  } else {
    v += dv * (step / dl);
    return false;
  }
}

#endif // VECTOR_MATH_H