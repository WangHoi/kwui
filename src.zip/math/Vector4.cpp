#include "Vector4.h"

const Vector4 ZERO_VECTOR4{ 0, 0, 0, 0 };
