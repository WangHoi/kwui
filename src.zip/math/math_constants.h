//
//  math_constants.h
//  C2Engine
//
//  Created by mike luo on 12-11-26.
//
//

#ifndef MATH_CONSTANTS_H
#define MATH_CONSTANTS_H

const float E = 2.71828182845904523536028747135266250f;
const float PI = 3.14159265358979323846264338327950288f;

const float HALF_PI = PI * 0.5f;

#endif // MATH_CONSTANTS_H