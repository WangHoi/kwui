#include "Vector2.h"

const Vector2 ZERO_VECTOR2(0, 0);
const Vector2 UP_VECTOR2(0, 1);
const Vector2 DOWN_VECTOR2(0, -1);
const Vector2 RIGHT_VECTOR2(1, 0);
const Vector2 LEFT_VECTOR2(-1, 0);
