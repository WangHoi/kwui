//
//  integer_math.h
//  C2Engine
//
//  Created by mike luo on 12-12-11.
//
//

#ifndef INTEGER_MATH_H
#define INTEGER_MATH_H

inline int group_count(int element_count, int elements_per_group) {
  return (element_count - 1) / elements_per_group + 1;
}

template<typename T>
inline void make_at_least(T& x, T lower_bound) {
  if (x < lower_bound) x = lower_bound;
}

#endif // INTEGER_MATH_H
