#include "Matrix3.h"
#include "Quaternion.h"

#include "data/data_helpers.h"

const Matrix3 IDENTITY_MATRIX3{ Matrix3::IDENTITY{} };

/***** setters *****/
void Matrix3::MakeIdentity() {
    Clear();
    _m[0] = _m[4] = _m[8] = 1.0f;
}

void Matrix3::MakeRows(const float* v1, const float* v2, const float* v3) {
    memcpy(_m, v1, sizeof(float) * 3);
    memcpy(_m + 3, v2, sizeof(float) * 3);
    memcpy(_m + 6, v3, sizeof(float) * 3);
}

void Matrix3::MakeColumns(const float* v1, const float* v2, const float* v3) {
    _m[0] = v1[0]; _m[1] = v2[0]; _m[2] = v3[0];
    _m[3] = v1[1]; _m[4] = v2[1]; _m[5] = v3[1];
    _m[6] = v1[2]; _m[7] = v2[2]; _m[8] = v3[2];
}

void Matrix3::MakeTranslation(float x, float y) {
    MakeIdentity();
    SetTranslation(x, y);
}

void Matrix3::MakeScale(float x, float y) {
    Clear();
    _m[0] = x; _m[4] = y; _m[8] = 1.0f;
}

void Matrix3::MakeFlip(Axis axis) {
    if (axis == AXIS_X) MakeScale(-1, 1);
    else MakeScale(1, -1);
}

void Matrix3::MakeTurn(bool x_flipped, bool y_flipped) {
    MakeIdentity();
    if (x_flipped) { _m[0] = -1; _m[6] = 1; }
    if (y_flipped) { _m[4] = -1; _m[7] = 1; }
}

void Matrix3::MakeRotation(float cosine, float sine) {
    SetRotation(cosine, sine);
    SetTranslation(0, 0);
    ResetLastColumn();
}

void Matrix3::MakeOrtho2D(const Vector2& origin, const Vector2& terminal) {
    Vector2 t = 2.0f / (terminal - origin);
    MakeScale(t);
    SetTranslation(-origin * t - 1.0f);
}

void Matrix3::MakeCross(const Vector3& v1, const Vector3& v2) {
    auto b1 = v1.GetBuffer(), b2 = v2.GetBuffer();
    _m[0] = b1[0] * b2[0]; _m[1] = b1[0] * b2[1]; _m[2] = b1[0] * b2[2];
    _m[3] = b1[1] * b2[0]; _m[4] = b1[1] * b2[1]; _m[5] = b1[1] * b2[2];
    _m[6] = b1[2] * b2[0]; _m[7] = b1[2] * b2[1]; _m[8] = b1[2] * b2[2];
}

void Matrix3::SetRows(const float* v1, const float* v2, const float* v3)
{
    memcpy(_m, v1, sizeof(float) * 3);
    memcpy(_m + 3, v2, sizeof(float) * 3);
    memcpy(_m + 6, v3, sizeof(float) * 3);
}

void Matrix3::SetColumns(const float* v1, const float* v2, const float* v3)
{
    _m[0] = v1[0]; _m[1] = v2[0]; _m[2] = v3[0];
    _m[3] = v1[1]; _m[4] = v2[1]; _m[5] = v3[1];
    _m[6] = v1[2]; _m[7] = v2[2]; _m[8] = v3[2];
}

void Matrix3::SetScaleWithoutRotation(const Vector2& scale) {
    _m[0] = scale.x; _m[3] = 0.0f;
    _m[1] = 0.0f; _m[4] = scale.y;
}

void Matrix3::SetRotation(float c, float s) {
    _m[0] = c; _m[3] = -s;
    _m[1] = s; _m[4] = c;
}

void Matrix3::SetRotation(const Quaternion& q) {
    const float x = q.x;
    const float y = q.y;
    const float z = q.z;
    const float w = q.w;
    _m[0] = 1 - 2 * (y*y + z * z); _m[1] = 2 * (x*y + z * w); _m[2] = 2 * (x*z - y * w);
    _m[3] = 2 * (x*y - z * w); _m[4] = 1 - 2 * (x*x + z * z); _m[5] = 2 * (y*z + x * w);
    _m[6] = 2 * (x*z + y * w); _m[7] = 2 * (y*z - x * w); _m[8] = 1 - 2 * (x*x + y * y);
}

void Matrix3::SetTranslation(float x, float y) {
    _m[6] = x; _m[7] = y;
}

void Matrix3::ResetLastColumn() {
    _m[2] = _m[5] = 0;
    _m[8] = 1;
}

/***** transformations *****/

Matrix3& Matrix3::Scale(float x, float y) {
    _m[0] *= x; _m[3] *= x; _m[6] *= x;
    _m[1] *= y; _m[4] *= y; _m[7] *= y;
    return *this;
}

Matrix3& Matrix3::TranslateAffine(float x, float y) {
    _m[6] += x; _m[7] += y;
    return *this;
}

Matrix3& Matrix3::Flip(Axis axis) {
    float* p = _m + axis;
    p[0] = -p[0]; p[3] = -p[3]; p[6] = -p[6];
    return *this;
}

/***** operations *****/

Matrix3 operator*(const Matrix3& m1, const Matrix3& m2) {
    Matrix3 result;
    auto b = result._m;
    auto b1 = m1._m, b2 = m2._m;
    for (int i = 0; i < 3; i++) {
        b[0] = b1[0] * b2[0] + b1[1] * b2[3] + b1[2] * b2[6];
        b[1] = b1[0] * b2[1] + b1[1] * b2[4] + b1[2] * b2[7];
        b[2] = b1[0] * b2[2] + b1[1] * b2[5] + b1[2] * b2[8];
        b += 3; b1 += 3;
    }
    return result;
}

Vector3 Matrix3::Transform(const Vector3& v) const {
    return {
      v.x * _m[0] + v.y * _m[3] + v.z * _m[6],
      v.x * _m[1] + v.y * _m[4] + v.z * _m[7],
      v.x * _m[2] + v.y * _m[5] + v.z * _m[8]
    };
}

Vector2 Matrix3::TransformPositionAffine(const Vector2& p) const {
    return {
      p.x * _m[0] + p.y * _m[3] + _m[6],
      p.x * _m[1] + p.y * _m[4] + _m[7],
    };
}

Range2 Matrix3::TransformAABBAffine(const Range2& aabb) const {
    Range2 result{ Range2::EMPTY{} };
    Vector2 vs[2] = { aabb.GetMin(), aabb.GetMax() };
    for (int i = 0; i < 2; i++) {
        for (int j = 0; j < 2; j++) {
            for (int k = 0; k < 2; k++) {
                result.Expand(TransformPositionAffine({ vs[i].x, vs[j].y }));
            }
        }
    }
    return result;
}

Matrix3& Matrix3::operator+=(const Matrix3& m) {
    auto b = m._m;
    for (int i = 0; i < 9; i++) _m[i] += b[i];
    return *this;
}

Matrix3& Matrix3::operator*=(float k) {
    for (int i = 0; i < 9; i++) _m[i] *= k;
    return *this;
}

float Matrix3::ComputeDeterminant() const {
    return
        _m[0] * (_m[4] * _m[8] - _m[5] * _m[7]) +
        _m[1] * (_m[5] * _m[6] - _m[3] * _m[8]) +
        _m[2] * (_m[3] * _m[7] - _m[4] * _m[6]);
}

Matrix3 Matrix3::ComputeMul(float k) const {
    Matrix3 m(*this);
    m *= k;
    return m;
}

Matrix3& Matrix3::Transpose() {
    swap(_m[1], _m[3]);
    swap(_m[2], _m[6]);
    swap(_m[5], _m[7]);
    return *this;
}

Matrix3 Matrix3::ComputeTranspose() const {
    return{
      _m[0], _m[3], _m[6],
      _m[1], _m[4], _m[7],
      _m[2], _m[5], _m[8]
    };
}

Matrix3 Matrix3::ComputeInverseTranspose() const {
    Matrix3 result{
      _m[4] * _m[8] - _m[5] * _m[7],
      _m[5] * _m[6] - _m[3] * _m[8],
      _m[3] * _m[7] - _m[4] * _m[6],
      _m[2] * _m[7] - _m[1] * _m[8],
      _m[0] * _m[8] - _m[2] * _m[6],
      _m[1] * _m[6] - _m[0] * _m[7],
      _m[1] * _m[5] - _m[2] * _m[4],
      _m[2] * _m[3] - _m[0] * _m[5],
      _m[0] * _m[4] - _m[1] * _m[3]
    };
    result *= 1.0f / ComputeDeterminant();
    return result;
}

Vector3 Matrix3::ExtractScale() const {
    return Vector3(Vector3(_m).Length(), Vector3(_m + 3).Length(), Vector3(_m + 6).Length());
}

Matrix3 Matrix3::ComputeInverse() const {
    return ComputeInverseTranspose().Transpose();
}
