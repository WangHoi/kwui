//
//  bit_arithmetics.h
//  C2Engine
//
//  Created by mike luo on 12-12-11.
//
//

#ifndef BIT_ARITHMETICS_H
#define BIT_ARITHMETICS_H

#include "data/data_type.h"

inline uint32 bit_mask(uint32 bit) {
  return 1u << bit;
}

inline bool test_bit(uint32 x, uint32 bit) {
  return (x & bit_mask(bit)) != 0;
}

inline void set_bit(uint32& x, uint32 bit) {
  x |= bit_mask(bit);
}

inline void clear_bit(uint32& x, uint32 bit) {
  x &= ~bit_mask(bit);
}

inline uint32 low_bit(uint32 x) {
  return x & ((~x) + 1);
}

inline uint32 low_pass(uint32 x, uint32 bit) {
  return x & ((1u << bit) - 1u);
}

extern int first_bit_position(uint32 x);
extern int last_bit_position(uint32 x);
extern uint8 count_set_bits(uint32 x);
#endif // BIT_ARITHMETICS_H
