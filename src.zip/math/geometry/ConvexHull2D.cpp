#include "stdafx.h"
//
//  ConvexHull2D.cpp
//  C2Engine
//
//  Created by mike li on 2014-6-26.
//
//

#include "ConvexHull2D.h"
#include "libqhullcpp/QhullVertexSet.h"
#include "libqhullcpp/QhullFacetList.h"
#include "libqhullcpp/QhullFacetSet.h"
using namespace orgQhull;

ConvexHull2D::ConvexHull2D() { _Init(false); }

ConvexHull2D::ConvexHull2D(const PointSet& points)
: _points(points) {
  _Init();
}

void ConvexHull2D::AddPoint(const Vector2& point) {
  _points.push_back(point);
  MarkUpdateAll();
}

const ConvexHull2D::PointSet& ConvexHull2D::RetrievePointSet() {
  CullInsidePoints();
  return _points;
}

const vector<int>& ConvexHull2D::RetrieveHullPointIndices() {
  if (!_need_update_hull_indices) return _hull_indices;
  _need_update_hull_indices = false;

  ComputeHull();
  _hull_indices.clear();
  auto facet = _qhull.firstFacet();
  while (1) {
    _hull_indices.push_back(facet.vertices().at(facet.isTopOrient() ? 0 : 1).point().id());
    auto next_facet = facet.neighborFacets().at(facet.isTopOrient() ? 0 : 1);
    if (next_facet == _qhull.firstFacet()) break;
    facet = next_facet;
  }
  return _hull_indices;
}

void ConvexHull2D::ComputeHull() {
  if (!_need_recompute_hull) return;
  _need_recompute_hull = false;

  try {
    _qhull.runQhull("rbox", 2, _points.size(), (float*)_points.data(), "");
  } catch (QhullError e) {
    c2_log(e.stringGlobalLog());
  }
}

void ConvexHull2D::MarkUpdateAll() {
  _need_recompute_hull = true;
  _need_update_hull_indices = true;
  _need_cull_points = true;
}

void ConvexHull2D::_Init(bool has_raw_points) {
  _need_recompute_hull = has_raw_points;
  _need_update_hull_indices = has_raw_points;
  _need_cull_points = has_raw_points;
}

void ConvexHull2D::CullInsidePoints() {
  if (!_need_cull_points) return;
  _need_cull_points = false;

  vector<int> hull_point_ids = RetrieveHullPointIndices(); // copy
  sort(hull_point_ids.begin(), hull_point_ids.end());
  auto it = std::unique(hull_point_ids.begin(), hull_point_ids.end());
  hull_point_ids.resize(std::distance(hull_point_ids.begin(), it));

  for (auto &point_id : _hull_indices) {
    point_id = lower_bound(hull_point_ids.begin(), hull_point_ids.end(), point_id) - hull_point_ids.begin();
  }

  it = hull_point_ids.begin();
  deque<int> removed_ids;
  for (int i = 0; i < (int)_points.size(); i++) {
    if (it != hull_point_ids.end() && i == *it) {
      it++;
      if (removed_ids.size()) {
        swap(_points[i], _points[removed_ids.front()]);
        removed_ids.pop_front();
        removed_ids.push_back(i);
      }
    } else {
      // should delete
      removed_ids.push_back(i);
    }
  }
  _points.resize(hull_point_ids.size());
  // no need to set update flag at least for now
}

void ConvexHull2D::FindEnclosingRectangle(Vector2& corner, Vector2& x_axis, Vector2& y_axis, Vector2& length) {
  // can be optimized
  auto& point_set = RetrievePointSet();
  auto& hull_indices = RetrieveHullPointIndices();
  int hull_size = hull_indices.size();
  float min_area = FLOAT_MAX;
#define GET(x) (point_set[hull_indices[x]])
#define NEXT(x) (((x) + 1 == hull_size) ? 0 : (x) + 1)
#define PREV(x) ((x) == 0 ? hull_size - 1 : (x) - 1)
  int l = 0, r = 1, h = 2;
  for (int i = 0; i < hull_size; i++) {
    int j = NEXT(i);
    auto& pi = GET(i);
    auto& pj = GET(j);
    auto right = (pj - pi).MakeUnitVector();
    auto left = -right;
    auto norm = (pj - pi).MakeOrthoVector();
    if (i == 0) {
      while (dot(GET(PREV(l)) - pi, left) > dot(GET(l) - pi, left)) l = PREV(l);
    } else {
      while (dot(GET(NEXT(l)) - pi, left) > dot(GET(l) - pi, left)) l = NEXT(l);
    }
    while (dot(GET(NEXT(r)) - pi, right) > dot(GET(r) - pi, right)) r = NEXT(r);
    while (dot(GET(NEXT(h)) - pi, norm) > dot(GET(h) - pi, norm)) h = NEXT(h);

    float width = dot(GET(l) - pi, left) + dot(GET(r) - pi, right);
    float height = dot(GET(h) - pi, norm);
    float cur_area = width * height;
    if (cur_area < min_area) {
      min_area = cur_area;
      length = {width, height};
      x_axis = right;
      y_axis = norm;
      corner = pi + left * dot(GET(l) - pi, left);
    }
  }
#undef GET
#undef PREV
#undef NEXT
}