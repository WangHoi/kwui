//
//  Segment3.h
//  C2Engine
//
//  Created by mike luo on 2015-1-17.
//
//
#ifndef SEGMENT3_H
#define SEGMENT3_H

#include "math/Vector3.h"

class Segment3 {
public:
  Vector3 v1, v2;

  Segment3() {} // uninitialized
  Segment3(const Vector3& v1, const Vector3& v2) : v1(v1), v2(v2) {}

  float Length() const { return v1.DistanceTo(v2); }
};

#endif // SEGMENT3_H