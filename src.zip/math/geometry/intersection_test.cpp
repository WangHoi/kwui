#include "stdafx.h"
//
//  intersection_test.cpp
//  C2Engine
//
//  Created by mike luo on 13-3-1.
//
//

#include "intersection_test.h"
#include "math/float_math.h"

bool intersect_sphere(const Sphere& sphere1, const Sphere& sphere2) {
  float d2 = sphere1._position.SquareDistanceTo(sphere2._position);
  return d2 < square(sphere1._radius + sphere2._radius);
}

bool intersect_aabb(const AABB& aabb1, const AABB& aabb2) {
  const Vector3& origin1 = aabb1.GetOrigin();
  const Vector3& terminal1 = aabb1.GetTerminal();
  const Vector3& origin2 = aabb2.GetOrigin();
  const Vector3& terminal2 = aabb2.GetTerminal();
  
  for (int i = 0; i < 3; i++) {
    if (terminal1[i] < origin2[i] || origin1[i] > terminal2[i]) return false;
  }
  
  return true;
}

bool intersect_shpere_aabb(const Sphere& sphere, const AABB& aabb) {
  float distance2 = aabb.SquareDistanceToPoint(sphere.GetPosition());
  return distance2 <= square(sphere.GetRadius());
}


/******** not tested below *******/
bool intersect_capsule(const Capsule& capsule1, const Capsule& capsule2 ) {
  float distance2 = capsule1.GetAxis().SquareDistanceToSegment(capsule2.GetAxis());
  float radius = capsule1.GetRadius() + capsule2.GetRadius();
  
  return distance2 <= square(radius);
}

bool intersect_shpere_capsule( const Sphere& sphere, const Capsule& capsule) {
  float distance2 = capsule.GetAxis().SquareDistanceToPoint(sphere.GetPosition());
  float radius = sphere.GetRadius() + capsule.GetRadius();
  
  return distance2 <= square(radius);
}

bool intersect_ray_aabb(const Ray& ray, const AABB& aabb, float& intersection_t) {

  float tmin = 0.0f, tmax = FLOAT_MAX;

  const Vector3& ray_origin = ray.GetOrigin();
  const Vector3& ray_direction = ray.GetDirection();
  const Vector3& aabb_origin = aabb.GetOrigin();
  const Vector3& aabb_terminal = aabb.GetTerminal();
  
  for (int i = 0; i < 3; i++) {
    float ray_d = ray_direction[i];
    float ray_p = ray_origin[i];
    float aabb_min = aabb_origin[i];
    float aabb_max = aabb_terminal[i];

    if (fabsf(ray_d) < FLOAT_ERROR) {
      if (ray_p < aabb_min || ray_p > aabb_max) return false;
    } else {
      float ood = 1.0f / ray_d;
      float t1 = (aabb_min - ray_p) * ood;
      float t2 = (aabb_max - ray_p) * ood;
      swap_if_greater_than(t1, t2);

      if (t1 > tmin) tmin = t1;
      if (t2 < tmax) tmax = t2;
      if (tmin > tmax) return false;
    }
  }

  intersection_t = tmin;
  return true;
}

bool intersect_ray_plane(const Ray& ray, const Plane& plane, float& intersection_t) {
	float denom = dot(plane.GetNormal(), ray.GetDirection());
	if (abs(denom) > 1e-4f) {
		// Compute the distance from the line starting point to the point of intersection.
		intersection_t = (plane.GetD() - dot(plane.GetNormal(), ray.GetOrigin())) / denom;
		return intersection_t >= 0.f;
	}

	if (denom != 0.f) {
		intersection_t = (plane.GetD() - dot(plane.GetNormal(), ray.GetOrigin())) / denom;
		if (intersection_t >= 0.f && intersection_t < 1e4f) return true;
	}
	intersection_t = 0.f;
	return abs(plane.GetD() - dot(plane.GetNormal(), ray.GetOrigin())) < 1e-3f;
}

bool intersect_capsule_aabb(const Capsule& capsule, const AABB& aabb) {

  float capsule_r = capsule.GetRadius();
  const Segment& capsule_axis = capsule.GetAxis();
  Vector3 expand(capsule_r, capsule_r, capsule_r);
  AABB expanded_aabb(aabb.GetOrigin() - expand, aabb.GetTerminal() + expand);

  float t = 0.0f;
  Ray ray(capsule_axis);
  if (!intersect_ray_aabb(ray, expanded_aabb, t) || t > 1.0f) return false;
  Vector3 intersection = ray.Sample(t);

  const Vector3& aabb_min = aabb.GetOrigin();
  const Vector3& aabb_max = aabb.GetTerminal();
  int u = 0, v = 0;
  for (int i = 0; i < 3; i++) {
    float p = intersection[i]; // int or float ?
    if (p < aabb_min[i]) u |= (1 << i);
    if (p > aabb_max[i]) v |= (1 << i);
  }
  
  int m = u + v;
  if ((m & (m - 1)) == 0) return true;

  float r2 = square(capsule_r);
  if (m == 7) {
    Segment s(aabb.GetCorner(v), aabb.GetCorner(v ^ 1));
    float d2 = capsule_axis.SquareDistanceToSegment(s);
    if (r2 >= d2) return true;
  }

  Segment s(aabb.GetCorner(v), aabb.GetCorner(u ^ 7));
  float d2 = capsule_axis.SquareDistanceToSegment(s);
  return r2 >= d2;
}