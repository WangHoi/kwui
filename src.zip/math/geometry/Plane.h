#ifndef PLANE_H
#define PLANE_H

#include "math/Vector3.h"

class Plane {
public:
  Plane(): _n{0, 0, 1}, _d(0) {}
  Plane(const Vector3& point, const Vector3& normal);
  Plane(const Vector3& n, float d); 
  const Vector3& GetNormal() const { return _n; }
  float GetD() const { return _d; }
  Vector3 GetPointOnPlane() const { return _n * -_d; } // return an arbitrary point on the point
  bool ContainsPoint(const Vector3& p) const { return dot(p, _n) + _d == 0; }
  float Compute(const Vector3& p) const { return dot(p, _n) + _d; }
private:
  Vector3 _n; // P * n + d == 0, for all P
  float _d;
};


#endif // PLANE_H
