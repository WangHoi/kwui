#include "stdafx.h"
#include "Plane.h"

Plane::Plane(const Vector3& point, const Vector3& normal) {
  _n = normal;
  _n.Normalize();
  _d = -dot(point, normal);
}

Plane::Plane(const Vector3& n, float d) {
  _n = n;
  float len = _n.Length();
  _n /= len;
  _d = d / len;
}
