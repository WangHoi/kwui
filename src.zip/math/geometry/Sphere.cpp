#include "stdafx.h"
//
//  Sphere.cpp
//  C2Engine
//
//  Created by mike luo on 13-3-1.
//
//

#include "Sphere.h"

Sphere Sphere::TransformUnifiedAffine(const Matrix4& matrix) const {
  return Sphere(matrix.TransformPositionAffine(_position),
                _radius * matrix.ComputeUnifiedScaleAffine());
}

Matrix4 Sphere::MakePlacementMatrix() const {
  return Matrix4(Matrix4::SCALE(), _radius).TranslateAffine(_position);
}

bool Sphere::ContainsPoint(const Vector3& point) const {
  return point.SquareDistanceTo(_position) <= square(_radius);
}