#include "stdafx.h"
#include "OrientedBoundingBox.h"
#include "BorrowedUtils.h"
#include "ConvexHull3D.h"
#include "math/Range.h"

OrientedBoundingBox::OrientedBoundingBox(const Vector3& center, const vector<Vector3>& axis, const Vector3& halfwidth)
: OrientedBoundingVolume(center, axis), _halfwidth(halfwidth) {}

auto OrientedBoundingBox::SafeIntersectionTest(const OrientedPlane& plane) const -> IntersectionOutcome {
  auto n = ConvertVectorToLocalAxis(plane.GetNormal());
  auto p = ConvertPointToLocalAxis(plane.GetPointOnPlane());
  Vector3 v_max;
  for (int i = 0; i < 3; i++) {
    v_max[i] = sign(n[i]) * _halfwidth[i];
  }
  if (dot(n, v_max - p) < 0) return DISJOINT;
  else if (dot(n, -v_max - p) <= 0) return INTERSECTING;
  return ENCLOSED;
}

vector<Vector3> OrientedBoundingBox::GetWireframeLineList() {
  vector<Vector3> result;
  for (int i = 0; i < 3; i++)
  for (int j = i + 1; j < 3; j++) {
    int k = 3 - i - j;
    for (int sign1 = -1; sign1 <= 1; sign1 += 2)
    for (int sign2 = -1; sign2 <= 1; sign2 += 2) {
      result.push_back(_center + _axis[i] * (sign1 * _halfwidth[i]) + _axis[j] * (sign2 * _halfwidth[j]) + _axis[k] * _halfwidth[k]);
      result.push_back(_center + _axis[i] * (sign1 * _halfwidth[i]) + _axis[j] * (sign2 * _halfwidth[j]) - _axis[k] * _halfwidth[k]);
    }
  }
  return result;
}

Vector3 OrientedBoundingBox::ConvertVectorToLocalAxis(const Vector3& point) const {
  return{dot(_axis[0], point), dot(_axis[1], point), dot(_axis[2], point)};
}

Vector3 OrientedBoundingBox::ConvertPointToLocalAxis(const Vector3& point) const {
  return{dot(_axis[0], point - _center), dot(_axis[1], point - _center), dot(_axis[2], point - _center)};
}

OrientedBoundingBoxRef OrientedBoundingBox::ConstructFromPoints(const vector<Vector3>& points, bool validated) {
  using namespace BorrowedUtils;
  if (!validated) assert(!CheckAllPointsCoplanar(points));

  ConvexHull3D hull(points);
  const auto& hull_points = hull.RetrievePointSet();
  const auto& indexed_facets = hull.RetrieveIndexedFacets();

  int nt = indexed_facets.size() / 3;
  float **p = new float*[nt], **q = new float*[nt], **r = new float*[nt], **m = new float*[nt], *a = new float[nt];
  for (int i = 0; i < nt; i++) m[i] = new float[3];
  float mh[3];
  float ah = 0;
  mh[0] = mh[1] = mh[2] = 0;
  for (int i = 0; i < nt; i++) {
    auto &v0 = hull_points[indexed_facets[3 * i + 0]];
    auto &v1 = hull_points[indexed_facets[3 * i + 1]];
    auto &v2 = hull_points[indexed_facets[3 * i + 2]];
    p[i] = (float*)&v0;
    q[i] = (float*)&v1;
    r[i] = (float*)&v2;
    for (int j = 0; j < 3; j++) m[i][j] = (p[i][j] + q[i][j] + r[i][j]) / 3;
    a[i] = cross(v1 - v0, v2 - v1).Length() / 2;
    ah += a[i];
    for (int j = 0; j < 3; j++) mh[j] += a[i] * m[i][j];
  }
  for (int j = 0; j < 3; j++) mh[j] /= ah;
  float c[3][3];
  for (int i = 0; i < 3; i++)
  for (int j = 0; j < 3; j++) {
    c[i][j] = 0;
    for (int k = 0; k < nt; k++)
      c[i][j] += a[k] / 12.0f * (9.0f * m[k][i] * m[k][j] + p[k][i] * p[k][j] + q[k][i] * q[k][j] + r[k][i] * r[k][j]);
    c[i][j] /= ah;
    c[i][j] -= mh[i] * mh[j];
  }
  float eigenvalues[3];
  float eigenvectors[3][3];
  BorrowedUtils::JacobiCyclicMethodF(eigenvalues, (float*)eigenvectors, (float*)c, 3);
  auto maxV = Vector3{eigenvectors[0][0], eigenvectors[1][0], eigenvectors[2][0]};
  auto midV = Vector3{eigenvectors[0][1], eigenvectors[1][1], eigenvectors[2][1]};
  auto minV = Vector3{eigenvectors[0][2], eigenvectors[1][2], eigenvectors[2][2]};
  if (eigenvalues[1] < eigenvalues[2]) swap(midV, minV);
  if (eigenvalues[0] < eigenvalues[1]) swap(maxV, midV);
  if (eigenvalues[1] < eigenvalues[2]) swap(midV, minV);

  Range3 range_box{Range3::EMPTY()};
  for (auto& t : hull_points) range_box.Expand(Vector3{dot(t, maxV), dot(t, midV), dot(t, minV)});
  auto center = (range_box.GetMin() + range_box.GetMax()) / 2;
  center = maxV * center.x + midV * center.y + minV * center.z;
  auto halfwidth = range_box.GetSpan() / 2;
  // clean up
  for (int i = 0; i < nt; i++) delete[] m[i];
  delete[] m;
  delete[] a;
  delete[] p; delete[] q; delete[] r;

  return make_shared<OrientedBoundingBox>(center, vector<Vector3>{maxV, midV, minV}, halfwidth);
}