#include "stdafx.h"
//
//  OrientedBoundingRectangle.cpp
//  C2Engine
//
//  Created by mike li on 2014-6-26.
//
//

#include "OrientedBoundingRectangle.h"
#include "Debug/debug_helpers.h"
#include "BorrowedUtils.h"
#include "ConvexHull2D.h"

#include "OrientedBoundingBox.h"

OrientedBoundingRectangle::OrientedBoundingRectangle(const Vector3& center, const vector<Vector3>& axis, const Vector2& halfwidth)
: OrientedBoundingVolume(center, axis), _halfwidth(halfwidth) {
  assert(axis.size() == 2);
  _z_axis = cross(axis[0], axis[1]);
}

auto OrientedBoundingRectangle::SafeIntersectionTest(const OrientedPlane& plane) const -> IntersectionOutcome {
  auto n = ConvertVectorToLocalAxis3D(plane.GetNormal());
  auto p = ConvertPointToLocalAxis3D(plane.GetPointOnPlane());
  Vector3 v_max;
  for (int i = 0; i < 2; i++) {
    v_max[i] = sign(n[i]) * _halfwidth[i];
  }
  v_max[2] = 0;
  if (dot(n, v_max - p) < 0) return DISJOINT;
  else if (dot(n, -v_max - p) <= 0) return INTERSECTING;
  return ENCLOSED;
}

vector<Vector3> OrientedBoundingRectangle::GetWireframeLineList() {
  return{
    _center + _axis[0] * _halfwidth[0] + _axis[1] * _halfwidth[1],
    _center + _axis[0] * _halfwidth[0] + _axis[1] * -_halfwidth[1],
    _center + _axis[0] * -_halfwidth[0] + _axis[1] * _halfwidth[1],
    _center + _axis[0] * -_halfwidth[0] + _axis[1] * -_halfwidth[1],
    _center + _axis[0] * _halfwidth[0] + _axis[1] * _halfwidth[1],
    _center + _axis[0] * -_halfwidth[0] + _axis[1] * _halfwidth[1],
    _center + _axis[0] * _halfwidth[0] + _axis[1] * -_halfwidth[1],
    _center + _axis[0] * -_halfwidth[0] + _axis[1] * -_halfwidth[1],
  };
}

Vector2 OrientedBoundingRectangle::ConvertVectorToLocalAxis(const Vector3& point) const {
  return{dot(_axis[0], point), dot(_axis[1], point)};
}

Vector2 OrientedBoundingRectangle::ConvertPointToLocalAxis(const Vector3& point) const {
  return{dot(_axis[0], point - _center), dot(_axis[1], point - _center)};
}

Vector3 OrientedBoundingRectangle::ConvertVectorToLocalAxis3D(const Vector3& point) const {
  return{dot(_axis[0], point), dot(_axis[1], point), dot(_z_axis, point)};
}

Vector3 OrientedBoundingRectangle::ConvertPointToLocalAxis3D(const Vector3& point) const {
  return{dot(_axis[0], point - _center), dot(_axis[1], point - _center), dot(_z_axis, point - _center)};
}

OrientedBoundingRectangleRef OrientedBoundingRectangle::ConstructFromPoints(const vector<Vector3>& points, bool validated) {
  using namespace BorrowedUtils;
  if (!validated) assert(CheckAllPointsCoplanar(points) && !CheckAllPointsCollinear(points));
  Vector3 p0, p1, p2;
  bool succeed = ExtractThreeNonCollinearPoints(points, p0, p1, p2);
  assert(succeed);
  auto x_axis = (p1 - p0).MakeUnitVector();
  auto z_axis = cross(x_axis, p2 - p0).MakeUnitVector();
  auto y_axis = cross(z_axis, x_axis);
  OrientedBoundingRectangle obb_tmp(p0, vector<Vector3>{x_axis, y_axis}, Vector2{1, 1}); // just used temporarily
  vector<Vector2> transformed_points;
  for (auto& p : points) transformed_points.push_back(obb_tmp.ConvertPointToLocalAxis(p));

  ConvexHull2D hull(transformed_points);
  {
    Vector2 corner, x_axis, y_axis, length;
    hull.FindEnclosingRectangle(corner, x_axis, y_axis, length);

    Vector2 center = corner + x_axis * (length.x / 2) + y_axis * (length.y / 2);
    return make_shared<OrientedBoundingRectangle>(
      obb_tmp.ConvertPointBackToGlobal(center),
      vector<Vector3> {obb_tmp.ConvertVectorBackToGlobal(x_axis), obb_tmp.ConvertVectorBackToGlobal(y_axis)},
      length / 2
    );
  }
}

Vector3 OrientedBoundingRectangle::ConvertVectorBackToGlobal(const Vector2& point) const {
  return _axis[0] * point.x + _axis[1] * point.y;
}

Vector3 OrientedBoundingRectangle::ConvertPointBackToGlobal(const Vector2& point) const {
  return _center + _axis[0] * point.x + _axis[1] * point.y;
}