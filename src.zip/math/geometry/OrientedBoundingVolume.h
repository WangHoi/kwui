//
//  OrientedBoundingVolume.h
//  C2Engine
//
//  Created by mike li on 2014-6-26.
//
//  The base class of all bounding volume. 
//  Each subclass needs to override the virtual method
//  "SafeIntersectionTest" to provide customed collision 
//  test with a give halfspace represented by OrientedPlane.

#ifndef ORIENTED_BOUNDING_VOLUME_H
#define ORIENTED_BOUNDING_VOLUME_H

#include "math/geometry/OrientedPlane.h"

SMART_REF(OrientedBoundingVolume)
class OrientedBoundingVolume {
public:
  enum IntersectionOutcome {
    DISJOINT,
    INTERSECTING,
    ENCLOSED,
    INTERSECTION_OUTCOME_COUNT
  };
  virtual ~OrientedBoundingVolume() {};
  static OrientedBoundingVolumeRef Create(const vector<Vector3>& points);
  virtual IntersectionOutcome SafeIntersectionTest(const OrientedPlane& plane) const = 0;
  virtual vector<Vector3> GetWireframeLineList() { return{}; };
  const Vector3& GetCenter() const { return _center; }
  const Vector3& GetAxis(int i) const { return _axis[i]; }
  int GetDimension() const { return _axis.size(); }
  int& GetMask() const { return _mask; };
protected:
  OrientedBoundingVolume(const Vector3& center, const vector<Vector3> axis);
  Vector3 _center;
  vector<Vector3> _axis;
  mutable int _mask;
};

#endif // ORIENTED_BOUNDING_VOLUME_H