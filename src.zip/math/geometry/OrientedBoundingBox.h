//
//  OrientedBoundingBox.h
//  C2Engine
//
//  Created by mike li on 2014-6-26.
//
//
//  A subclass of abstract class OrientedBoundingVolume,
//  specialized for bounding box in space.

#ifndef ORIENTED_BOUNDING_BOX_H
#define ORIENTED_BOUNDING_BOX_H

#include "OrientedBoundingVolume.h"

SMART_REF(OrientedBoundingBox);
class OrientedBoundingBox : public OrientedBoundingVolume {
public:
  OrientedBoundingBox(const Vector3& center, const vector<Vector3>& axis, const Vector3& halfwidth);
  IntersectionOutcome SafeIntersectionTest(const OrientedPlane& plane) const override;
  vector<Vector3> GetWireframeLineList() override;

  static OrientedBoundingBoxRef ConstructFromPoints(const vector<Vector3>& points, bool validated = false);
private:
  Vector3 ConvertVectorToLocalAxis(const Vector3& point) const;
  Vector3 ConvertPointToLocalAxis(const Vector3& point) const;

  Vector3 _halfwidth;
};

#endif // ORIENTED_BOUNDING_BOX_H