//
//  Line2.h
//  C2Engine
//
//  Created by mike luo on 2015-1-20.
//
//
#ifndef LINE2_H
#define LINE2_H

#include "math/Vector2.h"

class Line2 {
public:
  Vector2 p, d;

  Line2() {} // uninitialized
  Line2(const Vector2& p, const Vector2& d) : p(p), d(d) {}

  void NormalizeDirection() { d.Normalize(); }
  Vector2 Sample(float t) const { return p + d * t; }
};

#endif // LINE2_H