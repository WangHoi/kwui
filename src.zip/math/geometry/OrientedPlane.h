//
//  OrientedPlane.h
//  C2Engine
//
//  Created by mike li on 2014-5-15.
//
//

#ifndef ORIENTED_PLANE_H
#define ORIENTED_PLANE_H

#include "math/Vector3.h"

class OrientedPlane {
public:
  OrientedPlane(): _n{0, 0, 1}, _d(0) {}
  OrientedPlane(const Vector3& point, const Vector3& normal);
  OrientedPlane(const Vector3& n, float d); 
  const Vector3& GetNormal() const { return _n; }
  Vector3 GetPointOnPlane() const { return _n * -_d; } // return an arbitrary point on the point
  bool ContainsPoint(const Vector3& p) const { return dot(p, _n) + _d >= 0; }
  float Compute(const Vector3& p) const { return dot(p, _n) + _d; }
private:
  Vector3 _n; // P * n + d >= 0, for all P
  float _d;
};

#endif // ORIENTED_PLANE_H