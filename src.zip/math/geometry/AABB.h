//
//  AABB.h
//  C2Engine
//
//  Created by mike luo on 13-1-11.
//
//

#ifndef AABB_H
#define AABB_H

#include "math/Vector3.h"
#include "math/Matrix4.h"
#include "Sphere.h"
#include "data/data_helpers.h"

class AABB {
public:
  AABB() {} // uninitialized
  AABB(const Vector3& origin, const Vector3& terminal) : _origin(origin), _terminal(terminal) {}

  const Vector3& GetOrigin() const { return _origin; }
  const Vector3& GetTerminal() const { return _terminal; }
  Vector3 GetSize() const { return _terminal - _origin; }
  float GetSize(int index) const { return _terminal[index] - _origin[index]; }
  float GetDiameter() const { return GetSize().Length(); }
  Vector3 GetCenter() const { return (_terminal + _origin) * 0.5f; }
  Vector2 GetRange(Axis axis) const { return Vector2(_origin[axis], _terminal[axis]); }

  Matrix4 MakePlacementMatrix() const;

  void Set(const Vector3& origin, const Vector3& terminal) {
    _origin = origin;
    _terminal = terminal;
  }
  void SetOrigin(const Vector3& origin) { _origin = origin; }
  void SetTerminal(const Vector3& terminal) { _terminal = terminal; }
  void SetSize(const Vector3& size) { _terminal = _origin + size; }

  void MakeEmpty();
  void Expand(const Vector3& point);

  bool ContainsPoint(const Vector3& point) const {
    return _origin <= point && point <= _terminal;
  }

  Sphere GetBoundingSphere() const;
  Vector3 GetCorner(int mask) const;
  
  float SquareDistanceToPoint(const Vector3& point) const;

private:
  Vector3 _origin;
  Vector3 _terminal;
};

#endif // AABB_H