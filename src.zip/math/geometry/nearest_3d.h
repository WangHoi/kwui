//
//  nearest_3d.h
//  C2Engine
//
//  Created by mike luo on 2015-1-20.
//
//
#ifndef NEAREST_3D_H
#define NEAREST_3D_H

#include "math/Vector3.h"
#include "Line3.h"

void nearest_point_line_3d(const Vector3& p, const Line3& l, Vector3* lp_out, float* dist2_out);
bool nearest_line_line_3d(const Line3& l1, const Line3& l2, Vector3* lp1_out, Vector3* lp2_out, float* dist2_out);

#endif // NEAREST_3D_H