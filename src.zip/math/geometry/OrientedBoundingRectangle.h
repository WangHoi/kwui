//
//  OrientedBoundingRectangle.h
//  C2Engine
//
//  Created by mike li on 2014-6-26.
//
//
//  A subclass of abstract class OrientedBoundingVolume,
//  specialized for bounding rectangle in space.

#ifndef ORIENTED_BOUNDING_RECTANGLE_H
#define ORIENTED_BOUNDING_RECTANGLE_H

#include "OrientedBoundingVolume.h"

SMART_REF(OrientedBoundingRectangle);
class OrientedBoundingRectangle : public OrientedBoundingVolume {
public:
  OrientedBoundingRectangle(const Vector3& center, const vector<Vector3>& axis, const Vector2& halfwidth);
  IntersectionOutcome SafeIntersectionTest(const OrientedPlane& plane) const override;
  vector<Vector3> GetWireframeLineList() override;
  static OrientedBoundingRectangleRef ConstructFromPoints(const vector<Vector3>& points, bool validated = false);

  Vector2 ConvertVectorToLocalAxis(const Vector3& point) const;
  Vector2 ConvertPointToLocalAxis(const Vector3& point) const;
  Vector3 ConvertVectorToLocalAxis3D(const Vector3& point) const;
  Vector3 ConvertPointToLocalAxis3D(const Vector3& point) const;
  Vector3 ConvertVectorBackToGlobal(const Vector2& point) const;
  Vector3 ConvertPointBackToGlobal(const Vector2& point) const;
private:
  Vector3 _z_axis;
  Vector2 _halfwidth;
};

#endif // ORIENTED_BOUNDING_RECTANGLE_H