#include "stdafx.h"
//
//  nearest_3d.cpp
//  C2Engine
//
//  Created by mike luo on 2015-1-20.
//
//
#include "nearest_3d.h"

#include "math/equation/system_of_linear_equations.h"

void nearest_point_line_3d(const Vector3& p, const Line3& l, Vector3* lp_out, float* dist2_out) {
  float t = dot(p - l.p, l.d) / dot(l.d, l.d);
  Vector3 lp = l.Sample(t);
  if (lp_out) *lp_out = lp;
  if (dist2_out) *dist2_out = p.SquareDistanceTo(lp);
}

bool nearest_line_line_3d(const Line3& l1, const Line3& l2, Vector3* lp1_out, Vector3* lp2_out, float* dist2_out) {
  auto& d1 = l1.d, &d2 = l2.d;
  auto r = l1.p - l2.p;
  float a = dot(d1, d1), b = dot(d1, d2), c = dot(d1, r), e = dot(d2, d2), f = dot(d2, r);
  float s, t;
  if (solve_system_of_linear_equations(a, -b, b, -e, -c, -f, &s, &t)) {
    Vector3 p1 = l1.Sample(s), p2 = l2.Sample(t);
    if (lp1_out) *lp1_out = p1;
    if (lp2_out) *lp2_out = p2;
    if (dist2_out) *dist2_out = p1.SquareDistanceTo(p2);
    return true;
  } else { // two lines are parallel
    if (lp1_out) *lp1_out = l1.p;
    nearest_point_line_3d(l1.p, l2, lp2_out, dist2_out);
    return false;
  }
}