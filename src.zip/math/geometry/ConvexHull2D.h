//
//  ConvexHull2D.h
//  C2Engine
//
//  Created by mike li on 2014-6-26.
//
//
// Implementation of two dimensional convex hull,
// a wrapper class of open-source library qhull at www.qhull.org.
// 
// Apart from computing convex hull, it also supports the calculation
// of smallest enclosing rectangle(in area), through rotating calipers.

#ifndef CONVEX_HULL_2D_H
#define CONVEX_HULL_2D_H

#include "libqhullcpp/Qhull.h"
#include "math/vector_math.h"

class ConvexHull2D {
public:
  typedef vector<Vector2> PointSet;
  ConvexHull2D();
  ConvexHull2D(const PointSet& points);
  void AddPoint(const Vector2& point);
  const PointSet& RetrievePointSet();
  // RetrieveHullPointIndices is the method to get convex hull.
  // Hull computing will be done if necessary.
  const vector<int>& RetrieveHullPointIndices();
  void ComputeHull();
  void FindEnclosingRectangle(Vector2& corner, Vector2& x_axis, Vector2& y_axis, Vector2& length); // minimum area
  void CullInsidePoints();
  void MarkUpdateAll();
private:
  void _Init(bool has_raw_points = true);

  bool _need_recompute_hull;
  bool _need_update_hull_indices;
  bool _need_cull_points;

  PointSet _points;
  orgQhull::Qhull _qhull;
  vector<int> _hull_indices;
};

#endif // CONVEX_HULL_2D_H