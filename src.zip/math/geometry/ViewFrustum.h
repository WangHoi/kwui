//
//  ViewFrustum.h
//  C2Engine
//
//  Created by mike li on 2014-6-26.
//
//
//  Class of view frustum used during frustum culling.

#ifndef VIEW_FRUSTUM_H
#define VIEW_FRUSTUM_H

#include "OrientedBoundingVolume.h"
#include "math/vector_math.h"
#include "math/Range.h"
#include "math/Matrix4.h"

class ViewFrustum {
public:
  enum IntersectionOutcome {
    DISJOINT,
    INTERSECTING,
    ENCLOSING
  };
  // invalid frustum
  ViewFrustum() {}
  // In order to quickly compute the six planes of the frustum,
  // user can put the view projection matrix gained through vertex 
  // processing directly into the constructor, together with clip
  // space range.
  ViewFrustum(const Matrix4& view_projection_matrix);
  IntersectionOutcome SafeIntersectionTest(const OrientedBoundingVolume& obj) const;
  // fast culling, don't care aabb is partially or fully inside
  // true: probably intersect or inside frustum,
  // false: disjoint certainly
  bool FastIntersectionTest(const Range3& aabb) const;
  const vector<OrientedPlane>& GetPlanes() const { return _planes; }
private:
  vector<OrientedPlane> _planes;
};

#endif // VIEW_FRUSTUM_H
