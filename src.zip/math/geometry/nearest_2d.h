//
//  nearest_2d.h
//  C2Engine
//
//  Created by mike luo on 2015-1-17.
//
//
#ifndef NEAREST_2D_H
#define NEAREST_2D_H

#include "math/Vector2.h"
#include "Segment2.h"

void nearest_point_segment_2d(const Vector2& p, const Segment2& s, Vector2* sp_out, float* dist2_out);

#endif // NEAREST_2D_H