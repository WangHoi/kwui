//
//  ConvexHull3D.h
//  C2Engine
//
//  Created by mike li on 2014-6-26.
//
//
// Implementation of three dimensional convex hull,
// a wrapper class of open-source library qhull at www.qhull.org.
//
// The returned result is the set of facets on the
// hull, each represented by three point index in the 
// originally given point set.

#ifndef CONVEX_HULL_3D_H
#define CONVEX_HULL_3D_H

#include "libqhullcpp/Qhull.h"
#include "math/vector_math.h"

class ConvexHull3D {
public:
  typedef vector<Vector3> PointSet;
  ConvexHull3D();
  ConvexHull3D(const PointSet& points);
  void AddPoint(const Vector3& point);
  const PointSet& RetrievePointSet();
  // The method to get all facets on the hull. Each
  // facet is represented by three int, the index of
  // point in the originally give point set.
  const vector<int>& RetrieveIndexedFacets();
  void ComputeHull();
  void CullInsidePoints();
  void MarkUpdateAll();
  vector<Vector3> GetWireframeLineList();
private:
  void _Init(bool has_raw_points = true);

  bool _need_recompute_hull;
  bool _need_update_indexed_facets;
  bool _need_cull_points;

  PointSet _points;
  orgQhull::Qhull _qhull;
  vector<int> _indexed_facets;
};

#endif // CONVEX_HULL_3D_H