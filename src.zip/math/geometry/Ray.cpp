#include "stdafx.h"
//
//  Ray.cpp
//  C2Engine
//
//  Created by Game Dev on 13-3-18.
//
//

#include "Ray.h"
#include "Segment.h"

Ray::Ray(const Segment& segment) {
  const Vector3& o = segment.GetOrigin();
  _origin = o;
  _direction = segment.GetTerminal() - o;
}