#include "stdafx.h"
//
//  ConvexHull3D.cpp
//  C2Engine
//
//  Created by mike li on 2014-6-26.
//
//

#include "ConvexHull3D.h"
#include "libqhullcpp/QhullVertexSet.h"

using namespace orgQhull;

ConvexHull3D::ConvexHull3D() { _Init(false); }

ConvexHull3D::ConvexHull3D(const PointSet& points) 
: _points(points) {
  _Init();
}

void ConvexHull3D::AddPoint(const Vector3& point) {
  _points.push_back(point);
  MarkUpdateAll();
}

const ConvexHull3D::PointSet& ConvexHull3D::RetrievePointSet() {
  CullInsidePoints();
  return _points;
}

void ConvexHull3D::ComputeHull() {
  if (!_need_recompute_hull) return;
  _need_recompute_hull = false;

  try {
    _qhull.runQhull("rbox", 3, _points.size(), (float*)_points.data(), "");
  } catch (QhullError e) {
    // treat very likely coplanar points as a hull
    c2_log(e.stringGlobalLog());
  }
}

void ConvexHull3D::MarkUpdateAll() {
  _need_recompute_hull = true;
  _need_update_indexed_facets = true;
  _need_cull_points = true;
}

void ConvexHull3D::_Init(bool has_raw_points) {
  _need_recompute_hull = has_raw_points;
  _need_update_indexed_facets = has_raw_points;
  _need_cull_points = has_raw_points;
}

const vector<int>& ConvexHull3D::RetrieveIndexedFacets() {
  if (!_need_update_indexed_facets) return _indexed_facets;
  _need_update_indexed_facets = false;

  ComputeHull();
  _indexed_facets.clear();
  for (auto facet = _qhull.firstFacet(); facet != _qhull.endFacet(); facet = facet.next()) {
    auto vertices = facet.ordered_vertices().toStdVector(); // pointing to the inside of hull if right-handed
    for (int i = 1; i < (int)vertices.size() - 1; i++) {
      _indexed_facets.push_back(vertices[0].point().id());
      _indexed_facets.push_back(vertices[i].point().id());
      _indexed_facets.push_back(vertices[i+1].point().id());
    }
  }
  return _indexed_facets;
}

void ConvexHull3D::CullInsidePoints() {
  if (!_need_cull_points) return;
  _need_cull_points = false;

  vector<int> hull_point_ids = RetrieveIndexedFacets(); // copy
  sort(hull_point_ids.begin(), hull_point_ids.end());
  auto it = std::unique(hull_point_ids.begin(), hull_point_ids.end());
  hull_point_ids.resize(std::distance(hull_point_ids.begin(), it));

  for (auto &point_id : _indexed_facets) {
    point_id = lower_bound(hull_point_ids.begin(), hull_point_ids.end(), point_id) - hull_point_ids.begin();
  }
  
  it = hull_point_ids.begin();
  deque<int> removed_ids;
  for (int i = 0; i < (int)_points.size(); i++) {
    if (it != hull_point_ids.end() && i == *it) {
      it++;
      if (removed_ids.size()) {
        swap(_points[i], _points[removed_ids.front()]);
        removed_ids.pop_front();
        removed_ids.push_back(i);
      }
    } else {
      // should delete
      removed_ids.push_back(i);
    }
  }
  _points.resize(hull_point_ids.size());
  // no need to set update flag at least for now
}

vector<Vector3> ConvexHull3D::GetWireframeLineList() {
  auto& point_set = RetrievePointSet();
  auto& indexed_facets = RetrieveIndexedFacets();
  vector<Vector3> data;
  for (int i = 0; i < (int)indexed_facets.size(); i += 3) {
    data.push_back(point_set[indexed_facets[i]]);
    data.push_back(point_set[indexed_facets[i + 1]]);
    data.push_back(point_set[indexed_facets[i + 1]]);
    data.push_back(point_set[indexed_facets[i + 2]]);
    data.push_back(point_set[indexed_facets[i + 2]]);
    data.push_back(point_set[indexed_facets[i]]);
  }
  return data;
}