//
//  Segment.h
//  C2Engine
//
//  Created by Game Dev on 13-3-12.
//
//

#ifndef SEGMENT_H
#define SEGMENT_H

#include "math/Vector3.h"

class Segment {
public:
  Segment() {}
  Segment(const Vector3& origin, const Vector3& terminal)
  : _origin(origin), _terminal(terminal) {}
  
  void Set(const Vector3& origin, const Vector3& terminal) {
    _origin = origin;
    _terminal = terminal;
  }

  const Vector3& GetOrigin() const { return _origin; }
  const Vector3& GetTerminal() const { return _terminal; }
  Vector3 GetDirection() const { return _terminal - _origin; }
  
  float GetSquareLength() const {
    return GetDirection().SquareLength();
  }

  Vector3 Sample(float t) const {
    return _origin * (1 - t) + _terminal * t;
  }
  
  float SquareDistanceToPoint(const Vector3& point) const;
  float SquareDistanceToSegment(const Segment& segment) const;
  
private:
  Vector3 _origin;
  Vector3 _terminal;
};

#endif // SEGMENT_H
