//
//  Segment2.h
//  C2Engine
//
//  Created by mike luo on 2015-1-17.
//
//
#ifndef SEGMENT2_H
#define SEGMENT2_H

#include "math/Vector2.h"

class Segment2 {
public:
  Vector2 v1, v2;

  Segment2() {} // uninitialized
  Segment2(const Vector2& v1, const Vector2& v2) : v1(v1), v2(v2) {}

  float Length() const { return v1.DistanceTo(v2); }
};

#endif // SEGMENT2_H