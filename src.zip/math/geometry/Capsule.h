//
//  Capsule.h
//  C2Engine
//
//  Created by Game Dev on 13-3-12.
//
//

#ifndef _CAPSULE_H
#define _CAPSULE_H

#include "Segment.h"

class Capsule {
public:
  Capsule() {} // uninitialized
  Capsule(const Segment& axis, float radius) : _axis(axis), _radius(radius) {}
  
  void Set(const Segment& axis, float radius) {
    _axis = axis;
    _radius = radius;
  }
  
  const Segment& GetAxis() const { return _axis; }
  const float GetRadius() const { return _radius; }
  
private:
  Segment _axis;
  float _radius;
};

#endif // _CAPSULE_H