//
//  Ray.h
//  C2Engine
//
//  Created by Game Dev on 13-3-18.
//
//

#ifndef RAY_H
#define RAY_H

#include "math/Vector3.h"

class Segment;

class Ray {
public:
  Ray() {}
  Ray(const Vector3& origin, const Vector3& direction)
  : _origin(origin), _direction(direction) {}
  Ray(const Segment& segment);
  
  void Set(const Vector3& origin, const Vector3& direction) {
    _origin = origin;
    _direction = direction;
  }

  Vector3 Sample(float t) const { return _origin + _direction * t; }
  
  const Vector3& GetOrigin() const { return _origin; }
  const Vector3& GetDirection() const { return _direction; }
  
private:
  Vector3 _origin;
  Vector3 _direction;
};


#endif // RAY_H
