//
//  BorrowedUtils.h
//  C2Engine
//
//  Created by mike li on 2014-6-26.
//
//
// BorrowedUtils defines some math functions borrowed from other resources,
// as well as some nasty functions that don't belong to any specific class.

#ifndef BORROWED_UTILS_H
#define BORROWED_UTILS_H

#include "math/vector_math.h"

namespace BorrowedUtils {
  const float kEps = 1e-3f;
  extern void JacobiCyclicMethodF(float eigenvalues[], float* eigenvectors, float* A, int n);
  extern void JacobiCyclicMethod(double eigenvalues[], double* eigenvectors, double* A, int n);
  extern bool CheckAllPointsCoplanar(const vector<Vector3>& points);
  extern bool CheckAllPointsCollinear(const vector<Vector3>& points);
  extern bool ExtractThreeNonCollinearPoints(const vector<Vector3>& points, Vector3& p0, Vector3& p1, Vector3& p2);
}

#endif // BORROWED_UTILS_H