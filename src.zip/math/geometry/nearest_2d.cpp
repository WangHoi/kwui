#include "stdafx.h"
//
//  nearest_2d.cpp
//  C2Engine
//
//  Created by mike luo on 2015-1-17.
//
//
#include "nearest_2d.h"

void nearest_point_segment_2d(const Vector2& p, const Segment2& s, Vector2* sp_out, float* dist2_out) {
  Vector2 v1 = p - s.v1;
  Vector2 v2 = s.v2 - s.v1;
  float t = dot(v1, v2) / dot(v2, v2);
  t = clamp(t, 0.0f, 1.0f);
  Vector2 sp = s.v1 + v2 * t;
  if (sp_out) *sp_out = sp;
  if (dist2_out) *dist2_out = p.SquareDistanceTo(sp);
}