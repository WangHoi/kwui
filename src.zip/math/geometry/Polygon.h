//
//  Polygon.h
//  C2Engine
//
//  Created by mike luo on 13-3-11.
//
//

#ifndef POLYGON_H
#define POLYGON_H

#include "data/data_helpers.h"
#include "math/Vector2.h"

namespace C2 {
class Polygon {
public:
  Polygon() {}
  Polygon(const vector<Vector2>& vertices): _vertices(vertices) {}

  void AppendVertex(const Vector2& vertex) { _vertices.push_back(vertex); }

  int GetVertexCount() const { return _vertices.size(); }
  const Vector2& GetVertex(int index) const { return _vertices[index]; }

private:
  vector<Vector2> _vertices;
};
}
#endif // POLYGON_H
