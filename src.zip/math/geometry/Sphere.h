//
//  Sphere.h
//  C2Engine
//
//  Created by mike luo on 13-3-1.
//
//

#ifndef SPHERE_H
#define SPHERE_H

#include "math/Vector3.h"
#include "math/Matrix4.h"

class Sphere {
public:
  Sphere() {} // uninitialized
  Sphere(const Vector3& position, float radius) : _position(position), _radius(radius) {}

  const Vector3& GetPosition() const  { return _position; }
  float GetRadius() const { return _radius; }

  void SetPosition(const Vector3& position) { _position = position; }
  void SetRadius(float radius) { _radius = radius; }
  void Set(const Vector3& position, float radius) {
    _position = position;
    _radius = radius;
  }

  bool ContainsPoint(const Vector3& point) const;

  Sphere TransformUnifiedAffine(const Matrix4& matrix) const;

  Matrix4 MakePlacementMatrix() const;

private:
  Vector3 _position;
  float _radius;

  friend bool intersect_sphere(const Sphere& sphere1, const Sphere& sphere2);
};

#endif // SPHERE_H
