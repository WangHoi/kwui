//
//  Line3.h
//  C2Engine
//
//  Created by mike luo on 2015-1-20.
//
//
#ifndef LINE3_H
#define LINE3_H

#include "math/Vector3.h"

class Line3 {
public:
  Vector3 p, d;

  Line3() {} // uninitialized
  Line3(const Vector3& p, const Vector3& d) : p(p), d(d) {}

  void NormalizeDirection() { d.Normalize(); }
  Vector3 Sample(float t) const { return p + d * t; }
};

#endif // LINE3_H