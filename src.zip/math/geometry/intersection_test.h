//
//  intersection_test.h
//  C2Engine
//
//  Created by mike luo on 13-3-1.
//
//

#ifndef INTERSECTION_TEST_H
#define INTERSECTION_TEST_H

#include "Ray.h"
#include "Sphere.h"
#include "math/geometry/AABB.h"
#include "math/geometry/Plane.h"
#include "Capsule.h"

extern bool intersect_sphere(const Sphere& sphere1, const Sphere& sphere2);
extern bool intersect_aabb(const AABB& aabb1, const AABB& aabb2);
extern bool intersect_shpere_aabb(const Sphere& sphere, const AABB& aabb);
extern bool intersect_capsule(const Capsule& capsule1, const Capsule& capsule2);
extern bool intersect_shpere_capsule(const Sphere& sphere, const Capsule& capsule);
extern bool intersect_ray_aabb(const Ray& ray, const AABB& aabb, float& intersection_t);
extern bool intersect_ray_plane(const Ray& ray, const Plane& plane, float& intersection_t);
extern bool intersect_capsule_aabb(const Capsule& capsule, const Sphere& sphere);

#endif // INTERSECTION_TEST_H
