#include "stdafx.h"
//
//  Segment.cpp
//  C2Engine
//
//  Created by Game Dev on 13-3-12.
//
//

#include "Segment.h"
#include "math/math_templates.h"

//           C
//          /|
//         / |
//        /  |
//     A /___|_______B
//           D
//
// formula: CD * CD = AC * AC - square(AC * AB) / AB * AB
float Segment::SquareDistanceToPoint(const Vector3& point) const {
  Vector3 ab = GetDirection(), ac = point - _origin, bc = point - _terminal;

  float e = dot(ac, ab);
  if (e <= 0.0f) return dot(ac, ac);
  
  float f = dot(ab, ab);
  if (e >= f) return dot(bc, bc);
  
  return dot(ac, ac) - e * e / f;
}

float Segment::SquareDistanceToSegment(const Segment& segment) const {
  Vector3 d1 = GetDirection();
  Vector3 d2 = segment.GetDirection();
  Vector3 r = _origin - segment.GetOrigin();
  float a = dot(d1, d1);
  float e = dot(d2, d2);
  float f = dot(d2, r);
  float s = 0.0f, t = 0.0f;
  
  if (a <= FLOAT_ERROR && e <= FLOAT_ERROR) return dot(r, r);
  
  if (a <= FLOAT_ERROR) {
    t = f / e;
    t = clamp(t, 0.0f, 1.0f);

  } else {
    float c = dot(d1, r);
    
    if (e <= FLOAT_ERROR) {
      s = clamp(-c / a, 0.0f, 1.0f);
    } else {
      float b = dot(d1, d2);
      float denom = a * e - b * b;
      
      if (denom != 0.0f) {
        s = clamp((b * f - c * e) / denom, 0.0f, 1.0f);
      } else {
        s = 0.0f;
      }
      
      float tnom = b * s + f;
      
      if (tnom < 0.0f) {
        t = 0.0f;
        s = clamp(-c / a, 0.0f, 1.0f);
      } else if (tnom > e) {
        t = 1.0f;
        s = clamp((b - c) / a, 0.0f, 1.0f);
      } else {
        t = tnom / e;
      }
    }
  }
  
  return (Sample(s) - segment.Sample(t)).SquareLength();
}