//
//  ViewFrustum.cpp
//  C2Engine
//
//  Created by mike li on 2014-6-26.
//
//


#include "stdafx.h"
#include "ViewFrustum.h"

static inline void calc_pn_vertex(const Vector3& vmin, const Vector3& vmax, const Vector3& normal, Vector3& out_near, Vector3& out_far) {
  // manually loop unrolling
#define CALC_AXIS(X) \
  if (normal.X > 0) { \
    out_near.X = vmin.X; \
    out_far.X = vmax.X; \
  } else { \
    out_near.X = vmax.X; \
    out_far.X = vmin.X; \
  }
  CALC_AXIS(x)
  CALC_AXIS(y)
  CALC_AXIS(z)
#undef CALC_AXIS
}

ViewFrustum::ViewFrustum(const Matrix4& view_projection_matrix) {
  auto m = view_projection_matrix.GetBuffer();
  _planes.resize(6);
  // Left clipping plane
  _planes[0] = OrientedPlane(
    Vector3(m[0 * 4 + 3] + m[0 * 4 + 0],
      m[1 * 4 + 3] + m[1 * 4 + 0],
      m[2 * 4 + 3] + m[2 * 4 + 0]), 
    m[3 * 4 + 3] + m[3 * 4 + 0]);
  // Right clipping plane
  _planes[1] = OrientedPlane(
    Vector3(m[0 * 4 + 3] - m[0 * 4 + 0],
      m[1 * 4 + 3] - m[1 * 4 + 0],
      m[2 * 4 + 3] - m[2 * 4 + 0]),
    m[3 * 4 + 3] - m[3 * 4 + 0]);
  // Top clipping plane
  _planes[2] = OrientedPlane(
    Vector3(m[0 * 4 + 3] - m[0 * 4 + 1],
      m[1 * 4 + 3] - m[1 * 4 + 1],
      m[2 * 4 + 3] - m[2 * 4 + 1]),
    m[3 * 4 + 3] - m[3 * 4 + 1]);
  // Bottom clipping plane
  _planes[3] = OrientedPlane(
    Vector3(m[0 * 4 + 3] + m[0 * 4 + 1],
      m[1 * 4 + 3] + m[1 * 4 + 1],
      m[2 * 4 + 3] + m[2 * 4 + 1]),
    m[3 * 4 + 3] + m[3 * 4 + 1]);
  // Near clipping plane
  _planes[4] = OrientedPlane(
    Vector3(m[0 * 4 + 3] + m[0 * 4 + 2],
      m[1 * 4 + 3] + m[1 * 4 + 2],
      m[2 * 4 + 3] + m[2 * 4 + 2]),
    m[3 * 4 + 3] + m[3 * 4 + 2]);
  // Far clipping plane
  _planes[5] = OrientedPlane(
    Vector3(m[0 * 4 + 3] - m[0 * 4 + 2],
    m[1 * 4 + 3] - m[1 * 4 + 2],
    m[2 * 4 + 3] - m[2 * 4 + 2]),
    m[3 * 4 + 3] - m[3 * 4 + 2]);
}


auto ViewFrustum::SafeIntersectionTest(const OrientedBoundingVolume& obj) const -> IntersectionOutcome {
  int& tag = obj.GetMask(), tag_cp = tag;
  int enclose_count = 0;
  for (int i = 0; i < 6; i++) {
    if (tag_cp & (1 << i)) {
      auto outcome = obj.SafeIntersectionTest(_planes[i]);
      if (outcome == OrientedBoundingVolume::DISJOINT) return DISJOINT;
      tag ^= 1 << i;
      if (outcome == OrientedBoundingVolume::ENCLOSED) enclose_count++;
    }
  }
  for (int i = 0; i < 6; i++) {
    if (!(tag_cp & (1 << i))) {
      auto outcome = obj.SafeIntersectionTest(_planes[i]);
      if (outcome == OrientedBoundingVolume::DISJOINT) {
        tag ^= 1 << i;
        return DISJOINT;
      }
      if (outcome == OrientedBoundingVolume::ENCLOSED) enclose_count++;
    }
  }
  if (enclose_count == 6) return ENCLOSING;
  return INTERSECTING;
}

bool ViewFrustum::FastIntersectionTest(const Range3& aabb) const {
  Vector3 n, f;
  const OrientedPlane* __restrict p = _planes.data();
  for (int i = 0; i < 6; ++i) {
    calc_pn_vertex(aabb.GetMin(), aabb.GetMax(), p->GetNormal(), n, f);
    if (p->Compute(n) < 0.f && p->Compute(f) < 0.f) return false;
    ++p;
  }
  return true;
}
