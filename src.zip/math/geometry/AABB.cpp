#include "stdafx.h"
//
//  AABB.cpp
//  C2Engine
//
//  Created by mike luo on 13-1-11.
//
//

#include "AABB.h"
#include "math/bit_arithmetics.h"
#include "math/float_math.h"
#include "math/math_templates.h"

void AABB::MakeEmpty() {
  float oo = FLOAT_MAX;
  _origin.Set(oo, oo, oo);
  _terminal.Set(-oo, -oo, -oo);
}

void AABB::Expand(const Vector3& point) {
  for (int i = 0; i < 3; i++) {
    expand_range(point[i], _origin[i], _terminal[i]);
  }
}

Sphere AABB::GetBoundingSphere() const {
  return Sphere(GetCenter(), GetDiameter() * 0.5f);
}

Matrix4 AABB::MakePlacementMatrix() const {
  return Matrix4(Matrix4::SCALE(), GetSize() * 0.5f).TranslateAffine(GetCenter());
}

float AABB::SquareDistanceToPoint(const Vector3& point) const{
  float distance = 0.0f;
  
  for (int i = 0; i < 3; i++) {
    float p = point[i];
    if (p < _origin[i]) distance += square(_origin[i] - p);
    if (p > _terminal[i]) distance += square(_terminal[i] - p);
  }
  
  return distance;
}

Vector3 AABB::GetCorner(int mask) const {
  Vector3 corner;
  for (int i = 0; i < 3; i++) {
    corner[i] = test_bit(mask, i) ? _terminal[i] : _origin[i];
  }
  return corner;
}