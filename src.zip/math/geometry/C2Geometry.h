//
//  C2Geometry.h
//  C2Engine
//
//  Created by mike luo on 13-1-11.
//
//
#ifndef C2_GEOMETRY_H
#define C2_GEOMETRY_H

#include "Line2.h"
#include "Line3.h"
#include "Segment2.h"
#include "Segment3.h"

#include "nearest_2d.h"
#include "nearest_3d.h"

// the following files are not tested

#include "Ray.h"
#include "Segment.h"
#include "AABB.h"
#include "Sphere.h"
#include "Capsule.h"
#include "Polygon.h"
#include "intersection_test.h"

/*
#include "ConvexHull2D.h"
#include "ConvexHull3D.h"
#include "OrientedBoundingBox.h"
#include "OrientedBoundingRectangle.h"
#include "OrientedBoundingVolume.h"
#include "ViewFrustum.h"
 */

#endif // C2_GEOMETRY_H