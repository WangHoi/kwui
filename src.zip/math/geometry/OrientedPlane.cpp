#include "stdafx.h"
//
//  OrientedPlane.cpp
//  C2Engine
//
//  Created by mike li on 2014-5-15.
//
//

#include "OrientedPlane.h"

OrientedPlane::OrientedPlane(const Vector3& point, const Vector3& normal) {
  _n = normal;
  _n.Normalize();
  _d = -dot(point, normal);
}

OrientedPlane::OrientedPlane(const Vector3& n, float d) {
  _n = n;
  float len = _n.Length();
  _n /= len;
  _d = d / len;
}