#include "stdafx.h"
//
//  OrientedBoundingVolume.cpp
//  C2Engine
//
//  Created by mike li on 2014-6-26.
//
//

#include "OrientedBoundingVolume.h"
#include "OrientedBoundingRectangle.h"
#include "OrientedBoundingBox.h"
#include "BorrowedUtils.h"

OrientedBoundingVolume::OrientedBoundingVolume(const Vector3& center, const vector<Vector3> axis)
: _center(center), _axis(axis), _mask(0) {}

OrientedBoundingVolumeRef OrientedBoundingVolume::Create(const vector<Vector3>& points) {
  static int rect_count = 0;
  using namespace BorrowedUtils;
  if (CheckAllPointsCoplanar(points)) return OrientedBoundingRectangle::ConstructFromPoints(points, true);
  else return OrientedBoundingBox::ConstructFromPoints(points, true);
}