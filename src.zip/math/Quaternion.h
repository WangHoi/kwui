#ifndef MATH_QUATERNION_H
#define MATH_QUATERNION_H

#include "Matrix3.h"
#include "Matrix4.h"
#include "Vector3.h"
#include "Vector4.h"
#include <string>

/// Represents a rotation or an orientation of a 3D object.
class Quaternion
{
public:

    float x; ///< The factor of i.
    float y; ///< The factor of j. [similarOverload: x]
    float z; ///< The factor of k. [similarOverload: x]
    float w; ///< The scalar part. Sometimes also referred to as 'r'. [similarOverload: x]

    /// @note The default ctor does not initialize any member values.
    Quaternion() {}
    Quaternion(const Quaternion& rhs) { x = rhs.x; y = rhs.y; z = rhs.z; w = rhs.w; }

    /// Constructs a quaternion from the given data buffer.
    /// @param data An array of four floats to use for the quaternion, in the order 'x, y, z, w'. (== 'i, j, k, r')
    /// @note The input data is not normalized after construction, this has to be done manually.
    explicit Quaternion(const float *data);

    explicit Quaternion(const Matrix3& m) { Set(m); }
    explicit Quaternion(const Matrix4& m) { Set(m); }

    /// @param x The factor of i.
    /// @param y The factor of j.
    /// @param z The factor of k.
    /// @param w The scalar factor (or 'w').
    /// @note The input data is not normalized after construction, this has to be done manually.
    Quaternion(float x, float y, float z, float w);

    /// Constructs this quaternion by specifying a rotation axis and the amount of rotation to be performed
    /// about that axis.
    /** @param rotationAxis The normalized rotation axis to rotate about. If using the Vector4 version of the constructor, the w component of this vector must be 0.
          @param rotationAngleRadians The angle to rotate by, in radians. For example, Pi/4.f equals to 45 degrees, Pi/2.f is 90 degrees, and Pi is 180 degrees.
          @see DegToRad(). */
    Quaternion(const Vector3& axis, float angle_radians) { SetFromAxisAngle(axis, angle_radians); }
    Quaternion(const Vector4& axis, float angle_radians) { SetFromAxisAngle(axis, angle_radians); }

    /// Returns the local +X axis in the post-transformed coordinate space. This is the same as transforming the vector (1,0,0) by this quaternion.
    Vector3 WorldX() const;
    /// Returns the local +Y axis in the post-transformed coordinate space. This is the same as transforming the vector (0,1,0) by this quaternion.
    Vector3 WorldY() const;
    /// Returns the local +Z axis in the post-transformed coordinate space. This is the same as transforming the vector (0,0,1) by this quaternion.
    Vector3 WorldZ() const;

    /// Returns the axis of rotation for this quaternion.
    Vector3 Axis() const;

    /// Returns the angle of rotation for this quaternion, in radians.
    float Angle() const;

    /// Computes the dot product of this and the given quaternion.
    /// Dot product is commutative.
    float Dot(const Quaternion& rhs) const;

    float LengthSq() const;

    float Length() const;

    /// Normalizes this quaternion in-place.
    /// Returns the old length of this quaternion, or 0 if normalization failed.
    float Normalize();

    /// Returns a normalized copy of this quaternion.
    Quaternion Normalized() const;

    /// Returns true if the length of this quaternion is one.
    bool IsNormalized(float epsilon = 1e-5f) const;

    bool IsInvertible(float epsilon = 1e-3f) const;

    /// Returns true if the entries of this quaternion are all finite.
    bool IsFinite() const;

    /// Returns true if this quaternion equals rhs, up to the given epsilon.
    bool Equals(const Quaternion& rhs, float epsilon = 1e-3f) const;

    /// Compares whether this Quat and the given Quat are identical bit-by-bit in the underlying representation.
    /** @note Prefer using this over e.g. memcmp, since there can be SSE-related padding in the structures. */
    bool BitEquals(const Quaternion& other) const;

    /// @return A pointer to the first element (x). The data is contiguous in memory.
    /// ptr[0] gives x, ptr[1] is y, ptr[2] is z and ptr[3] is w.
    float *GetBuffer() { return &x; }
    const float *GetBuffer() const { return &x; }

    /// Inverses this quaternion in-place.
    /// @note For optimization purposes, this function assumes that the quaternion is unitary, in which
    ///	   case the inverse of the quaternion is simply just the same as its conjugate. This function
    ///	   does not detect whether the operation succeeded or failed.
    void Inverse();

    /// Returns an inverted copy of this quaternion.
    Quaternion Inverted() const;

    /// Inverses this quaternion in-place.
    /// Call this function when the quaternion is not known beforehand to be normalized. This function
    /// computes the inverse proper, and normalizes the result.
    /// @note Because of the normalization, it does not necessarily hold that q * q.InverseAndNormalize() == id.
    /// @return Returns the old length of this quaternion (not the old length of the inverse quaternion).
    float InverseAndNormalize();

    /// Computes the conjugate of this quaternion in-place.
    void Conjugate();

    /// Returns a conjugated copy of this quaternion.
    Quaternion Conjugated() const;

    /// Rotates the given vector by this quaternion.
    Vector3 Transform(float x, float y, float z) const;
    Vector3 Transform(const Vector3& v) const;

    /// Rotates the given vector by this quaternion. The w component of the vector is assumed to be zero or one.
    Vector4 Transform(const Vector4& v) const;

    Quaternion Lerp(const Quaternion& target, float t) const;
    static Quaternion Lerp(const Quaternion& source, const Quaternion& target, float t) { return source.Lerp(target, t); }
    Quaternion Slerp(const Quaternion& target, float t) const;
    static Quaternion Slerp(const Quaternion& source, const Quaternion& target, float t) { return source.Slerp(target, t); }

    /// Returns the 'from' vector rotated towards the 'to' vector by the given normalized time parameter.
    /** This function slerps the given 'from' vector towards the 'to' vector.
          @param from A normalized direction vector specifying the direction of rotation at t=0.
          @param to A normalized direction vector specifying the direction of rotation at t=1.
          @param t The interpolation time parameter, in the range [0,1]. Input values outside this range are
              silently clamped to the [0, 1] interval.
          @return A spherical linear interpolation of the vector 'from' towards the vector 'to'. */
    static Vector3 SlerpVector(const Vector3& from, const Vector3& to, float t);

    /// Returns the 'from' vector rotated towards the 'to' vector by the given absolute angle, in radians.
    /** This function slerps the given 'from' vector towards the 'to' vector.
          @param from A normalized direction vector specifying the direction of rotation at angleRadians=0.
          @param to A normalized direction vector specifying the target direction to rotate towards.
          @param angleRadians The maximum angle to rotate the 'from' vector by, in the range [0, pi]. If the
              angle between 'from' and 'to' is smaller than this angle, then the vector 'to' is returned.
              Input values outside this range are silently clamped to the [0, pi] interval.
          @return A spherical linear interpolation of the vector 'from' towards the vector 'to'. */
    static Vector3 SlerpVectorAbs(const Vector3& from, const Vector3& to, float angle_radians);

    /// Returns the angle between this and the target orientation (the shortest route) in radians.
    float AngleBetween(const Quaternion& target) const;
    /// Returns the axis of rotation to get from this orientation to target orientation (the shortest route).
    Vector3 AxisFromTo(const Quaternion& target) const;

    /// Returns the rotation axis and angle of this quaternion.
    /// @param rotationAxis [out] Received the normalized axis of the rotation.
    /// @param rotationAngleRadians [out] Receives the angle of rotation around the given axis. This parameter is returned in the range [0, 2pi].
    void ToAxisAngle(Vector3& axis, float &angle_radians) const;
    void ToAxisAngle(Vector4& axis, float &angle_radians) const;
    /// Sets this quaternion by specifying the axis about which the rotation is performed, and the angle of rotation.
    /** @param rotationAxis The axis of rotation. This vector must be normalized to call this function. If using the Vector4 version of this function,
          then the w component must be zero.
          @param rotationAngleRadians The angle of rotation in radians. */
    void SetFromAxisAngle(const Vector3& axis, float angle_radians);
    void SetFromAxisAngle(const Vector4& axis, float angle_radians);

    /// Sets this quaternion to represent the same rotation as the given matrix.
    void Set(const Matrix3 &matrix);
    void Set(const Matrix4 &matrix);
    /// Sets all elements of this quaternion.
    /// @note This sets the raw elements, which do *not* correspond directly to the axis and angle of the rotation. Use
    ///	   SetFromAxisAngle to define this Quat using a rotation axis and an angle.
    void Set(float x, float y, float z, float w);

    /// Creates a new quaternion that rotates about the positive X axis by the given angle.
    static Quaternion RotateX(float angle_radians);
    /// Creates a new quaternion that rotates about the positive Y axis by the given angle.
    static Quaternion RotateY(float angle_radians);
    /// Creates a new quaternion that rotates about the positive Z axis by the given angle.
    static Quaternion RotateZ(float angle_radians);

    /// Creates a new Quat that rotates about the given axis by the given angle.
    static Quaternion RotateAxisAngle(const Vector3& axis, float angle_radians);

    /// Creates a new quaternion that rotates sourceDirection vector (in world space) to coincide with the
    /// targetDirection vector (in world space).
    /// Rotation is performed around the origin.
    /// The vectors sourceDirection and targetDirection are assumed to be normalized.
    /// @note There are multiple such rotations - this function returns the rotation that has the shortest angle
    /// (when decomposed to axis-angle notation).
    static Quaternion RotateFromTo(const Vector3& source_direction, const Vector3& target_direction);
    static Quaternion RotateFromTo(const Vector4& source_direction, const Vector4& target_direction);

    /// Creates a new Quat from the given sequence of Euler rotation angles (in radians).
    /** The FromEulerABC function returns a matrix M = A(a) * B(b) * C(c). Rotation
          C is applied first, followed by B and then A. [indexTitle: FromEuler***] */
    static Quaternion FromEulerTransform(float p, float h, float b);
    static Quaternion FromEulerTransform(const Vector3& v) { return FromEulerTransform(v.x, v.y, v.z); }

    /// Returns a uniformly random unitary quaternion.
    static Quaternion RandomRotation();

    /// Extracts the rotation part of this quaternion into Euler rotation angles (in radians).
    Vector3 ExtractEulerTransform() const;

    Matrix3 ToMatrix3() const;
    Matrix4 ToMatrix4() const;
    Matrix4 ToMatrix4(const Vector3& translation) const;
    Matrix4 ToMatrix4(const Vector4& translation) const;

    /// Returns "(x,y,z,w)".
    std::string ToString() const;

    /// Returns "Quat(axis:(x,y,z) angle:degrees)".
    std::string ToString2() const;

    /// Returns "x,y,z,w". This is the preferred format for the quaternion if it has to be serialized to a string for machine transfer.
    std::string SerializeToString() const;

    /// Returns a string of C++ code that can be used to construct this object. Useful for generating test cases from badly behaving objects.
    std::string SerializeToCodeString() const;

    /// Parses a string that is of form "x,y,z,w" or "(x,y,z,w)" or "(x;y;z;w)" or "x y z w" to a new quaternion.
    static Quaternion FromString(const char *str, const char** outEndStr = 0);
    static Quaternion FromString(const std::string& str) { return FromString(str.c_str()); }

    /// Multiplies two quaternions together.
    /// The product q1 * q2 returns a quaternion that concatenates the two orientation rotations. The rotation
    /// q2 is applied first before q1.
    Quaternion operator *(const Quaternion& rhs) const;

    /// Transforms the given vector by this Quaternion.
    /// @note Technically, this function does not perform a simple multiplication of 'q * v',
    /// but instead performs a conjugation operation 'q*v*q^-1'. This corresponds to transforming
    /// the given vector by this Quaternion.
    Vector3 operator *(const Vector3& rhs) const;
    Vector4 operator *(const Vector4& rhs) const;

    /// The identity quaternion performs no rotation when applied to a vector.
    /// For quaternions, the identity has the value r = 1, i,j,k = 0.
    static const Quaternion Identity;
    /// A compile-time constant Quat with value (NaN, NaN, NaN, NaN).
    /// For this constant, each element has the value of quiet NaN, or Not-A-Number.
    /// @note Never compare a Quat to this value! Due to how IEEE floats work, "nan == nan" returns false!
    ///	   That is, nothing is equal to NaN, not even NaN itself!
    static const Quaternion Nan;

    /// Divides a quaternion by another. Division "a / b" results in a quaternion that rotates the orientation b to coincide with the orientation a.
    Quaternion operator /(const Quaternion& rhs) const;

    /// Unary operator + allows this structure to be used in an expression '+x'.
    Quaternion operator +() const { return *this; }

    /// Multiplies two quaternions in the order 'this * rhs'.
    /// This corresponds to the concatenation of the two operations ('this * rhs * vector' applies the rotation 'rhs' first, followed by the rotation 'this'.
    Quaternion Mul(const Quaternion& rhs) const;
    /// Converts the given matrix to a quaternion and computes the concatenated transform 'this * rhs'.
    Quaternion Mul(const Matrix3 &rhs) const;
    /// Transforms the given vector by this Quaternion.
    /// @note Technically, this function does not perform a simple multiplication of 'q * v',
    /// but instead performs a conjugation operation 'q*v*q^-1'. This corresponds to transforming
    /// the given vector by this Quaternion.
    Vector3 Mul(const Vector3& vector) const;
    Vector4 Mul(const Vector4& vector) const;

    /// Negates the quaternion.
    /// @note Negating a quaternion will not produce the inverse rotation. Call Quat::Inverse() to generate the inverse rotation.
    Quaternion Neg() const { return -*this; }

private: // Hide the unsafe operations from the user, so that he doesn't accidentally invoke an unintended operation.

  /// Multiplies a quaternion by a scalar.
  /// @note Technically, multiplication by scalar would not affect the rotation this quaternion represents, but since
  /// Quat uses conjugation to compute the inverse (to optimize), an unnormalized quaternion will not produce a proper rotation transform.
  /// @note Multiplication by a scalar does not "accumulate" rotations, e.g. "quat * 5.f" will not produce a quaternion that would rotate
  ///			"5 times more".
    Quaternion operator *(float scalar) const;

    Quaternion operator /(float scalar) const;

    /// Adds two quaternions.
    /// @note Adding two quaternions does not concatenate the two rotation operations. Use quaternion multiplication to achieve that.
    Quaternion operator +(const Quaternion& rhs) const;

    Quaternion operator -(const Quaternion& rhs) const;

    /// Negates the quaternion.
    /// @note Negating a quaternion will not produce the inverse rotation. Call Quat::Inverse() to generate the inverse rotation.
    Quaternion operator -() const;
};

/// Prints this Quat to the given stream.
std::ostream& operator <<(std::ostream& out, const Quaternion& rhs);

inline Quaternion Lerp(const Quaternion& a, const Quaternion& b, float t) { return a.Lerp(b, t); }
inline Quaternion Slerp(const Quaternion& a, const Quaternion& b, float t) { return a.Slerp(b, t); }

#endif // MATH_QUATERNION_H
