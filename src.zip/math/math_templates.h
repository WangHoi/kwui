//
//  math_templates.h
//  C2Engine
//
//  Created by mike luo on 13-4-1.
//
//

#ifndef MATH_TEMPLATES_H
#define MATH_TEMPLATES_H

#include "data/data_helpers.h"
#include "data/data_type.h"

template <typename T>
inline bool in_range(const T& x, const T& min, const T& max) {
  return min <= x && x <= max;
}

template <typename T>
inline void expand_range(const T& x, T& min, T& max) {
  if (x < min) min = x;
  if (x > max) max = x;
}

template <typename T>
inline void update_min(T& min, const T& x) {
  if (x < min) min = x;
}

template <typename T>
inline void update_max(T& max, const T& x) {
  if (x > max) max = x;
}

template <typename T>
inline void lower_clamp(T& x, const T& lower_bound) {
  if (x < lower_bound) x = lower_bound;
}

template <typename T>
inline void upper_clamp(T& x, const T& upper_bound) {
  if (x > upper_bound) x = upper_bound;
}

template <typename T>
inline void swap_if_larger_than(T& a, T& b) {
  if (a > b) swap(a, b);
}

template <typename T>
inline T linear_interpolate(const T& x1, const T& x2, float t) {
  return x1 * (1 - t) + x2 * t;
}
template <typename T>
inline T linear_interpolate(const T& x1, const T& x2, double t) {
    return x1 * (1 - t) + x2 * t;
}

/// Greatest common divisor.
template <typename T>
inline T num_gcd(T a, T b) {
  do {
    T tmp = a % b;
    a = b;
    b = tmp;
  } while (b);

  return a;
}

/// Least common multiple.
template <typename T>
inline T num_lcm(T a, T b) { return a * (b / num_gcd(a, b)); }

/// Align number
template <typename P, typename Q>
inline P num_align(P x, Q a) {
  Q m = x % a;
  if (!m) return x;
  return x + (a - m);
}

template <typename T>
inline bool test_bit(T n, uint8 bit) { return (n & (1 << bit)) != 0; }
template <typename T>
inline void set_bit(T& n, uint8 bit) { n |= (1 << bit); }
template <typename T>
inline void clear_bit(T& n, uint8 bit) { n &= ~(1 << bit); }
template <typename T>
inline void flip_bit(T& n, uint8 bit) { n ^= (1 << bit); }

#endif // MATH_TEMPLATES_H
