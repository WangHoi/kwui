#include "Quaternion.h"
#include "Matrix3.h"
#include "Matrix4.h"
#include "float_math.h"
#include "random/random_helpers.h"
#include <math.h>
#include <stdlib.h>
#include <iostream>
#include <assert.h>

static inline uint32 reinterpret_as_u32(float f)
{
    union {
        float f;
        uint32 i;
    } fi;
    fi.f = f;
    return fi.i;
}

static inline bool equal_abs(float a, float b, float epsilon = 1e-4f)
{
    return abs(a - b) < epsilon;
}

Quaternion::Quaternion(const float* data)
{
    if (!data)
        return;
    x = data[0];
    y = data[1];
    z = data[2];
    w = data[3];
}

Quaternion::Quaternion(float x_, float y_, float z_, float w_)
    :x(x_), y(y_), z(z_), w(w_)
{
}

Vector3 Quaternion::WorldX() const
{
    return Transform(1.f, 0.f, 0.f);
}

Vector3 Quaternion::WorldY() const
{
    return Transform(0.f, 1.f, 0.f);
}

Vector3 Quaternion::WorldZ() const
{
    return Transform(0.f, 0.f, 1.f);
}

Vector3 Quaternion::Axis() const
{
    // Best: 6.529 nsecs / 18.152 ticks, Avg: 6.851 nsecs, Worst: 8.065 nsecs

    // Convert cos to sin via the identity sin^2 + cos^2 = 1, and fuse reciprocal and square root to the same instruction,
    // since we are about to divide by it.
    float rcpSinAngle = 1 / sqrt(1.f - w * w);
    return Vector3(x, y, z) * rcpSinAngle;
}

float Quaternion::Angle() const
{
    return acos(w) * 2.f;
}

float Quaternion::Dot(const Quaternion& rhs) const
{
    return x * rhs.x + y * rhs.y + z * rhs.z + w * rhs.w;
}

float Quaternion::LengthSq() const
{
    return x * x + y * y + z * z + w * w;
}

float Quaternion::Length() const
{
    return sqrt(LengthSq());
}

float Quaternion::Normalize()
{
    float length = Length();
    if (length < 1e-4f)
        return 0.f;
    float rcpLength = 1.f / length;
    x *= rcpLength;
    y *= rcpLength;
    z *= rcpLength;
    w *= rcpLength;
    return length;
}

Quaternion Quaternion::Normalized() const
{
    Quaternion copy = *this;
    float success = copy.Normalize();
    assert(success > 0 && "Quaternion::Normalized failed!");
    (void)success;
    return copy;
}

bool Quaternion::IsNormalized(float epsilonSq) const
{
    return equal_abs(LengthSq(), 1.f, epsilonSq);
}

bool Quaternion::IsInvertible(float epsilon) const
{
    return LengthSq() > epsilon && IsFinite();
}

bool Quaternion::IsFinite() const
{
    return isfinite(x) && isfinite(y) && isfinite(z) && isfinite(w);
}

bool Quaternion::Equals(const Quaternion& rhs, float epsilon) const
{
    return equal_abs(x, rhs.x, epsilon) && equal_abs(y, rhs.y, epsilon) && equal_abs(z, rhs.z, epsilon) && equal_abs(w, rhs.w, epsilon);
}

bool Quaternion::BitEquals(const Quaternion& other) const
{
    return reinterpret_as_u32(x) == reinterpret_as_u32(other.x) &&
        reinterpret_as_u32(y) == reinterpret_as_u32(other.y) &&
        reinterpret_as_u32(z) == reinterpret_as_u32(other.z) &&
        reinterpret_as_u32(w) == reinterpret_as_u32(other.w);
}

void Quaternion::Inverse()
{
    assert(IsNormalized());
    assert(IsInvertible());
    Conjugate();
}

Quaternion Quaternion::Inverted() const
{
    assert(IsNormalized());
    assert(IsInvertible());
    return Conjugated();
}

float Quaternion::InverseAndNormalize()
{
    Conjugate();
    return Normalize();
}

void Quaternion::Conjugate()
{
    x = -x;
    y = -y;
    z = -z;
}

Quaternion Quaternion::Conjugated() const
{
    return Quaternion(-x, -y, -z, w);
}

Vector3 Quaternion::Transform(const Vector3& v) const
{
    assert(IsNormalized());
    ///\todo Optimize/benchmark the scalar path not to generate a matrix!
    Matrix3 mat = ToMatrix3();
    return mat.Transform(v);
}

Vector3 Quaternion::Transform(float x, float y, float z) const
{
    return Transform(Vector3(x, y, z));
}

Vector4 Quaternion::Transform(const Vector4& v) const
{
    return Vector4(Transform(v.x, v.y, v.z), v.w);
}

Quaternion Quaternion::Lerp(const Quaternion& b, float t) const
{
    assert(0.f <= t && t <= 1.f);

    return *this * (1.f - t) + b * t;
}

/** Implementation based on the math in the book Watt, Policarpo. 3D Games: Real-time rendering and Software Technology, pp. 383-386. */
Quaternion Quaternion::Slerp(const Quaternion& q2, float t) const
{
    assert(0.f <= t && t <= 1.f);
    assert(IsNormalized());
    assert(q2.IsNormalized());

    float angle = Dot(q2);
    float sign = 1.f; // Multiply by a sign of +/-1 to guarantee we rotate the shorter arc.
    if (angle < 0.f)
    {
        angle = -angle;
        sign = -1.f;
    }

    float a;
    float b;
    if (angle <= 0.97f) // perform spherical linear interpolation.
    {
        angle = acos(angle); // After this, angle is in the range pi/2 -> 0 as the original angle variable ranged from 0 -> 1.

        float angle_t = t * angle;

        float s[3] = { sin(angle), sin(angle - angle_t), sin(angle_t) };
        float c = 1.f / s[0];
        a = s[1] * c;
        b = s[2] * c;
    } else // If angle is close to taking the denominator to zero, resort to linear interpolation (and normalization).
    {
        a = 1.f - t;
        b = t;
    }

    return (*this * (a * sign) + q2 * b).Normalized();
}

Vector3 Quaternion::SlerpVector(const Vector3& from, const Vector3& to, float t)
{
    if (t <= 0.f)
        return from;
    if (t >= 1.f)
        return to;
    ///\todo The following chain can be greatly optimized.
    Quaternion q = Quaternion::RotateFromTo(from, to);
    q = Slerp(Quaternion::Identity, q, t);
    return q.Transform(from);
}

Vector3 Quaternion::SlerpVectorAbs(const Vector3& from, const Vector3& to, float angle_radians)
{
    if (angle_radians <= 0.f)
        return from;
    Quaternion q = Quaternion::RotateFromTo(from, to);
    float a = q.Angle();
    if (a <= angle_radians)
        return to;
    float t = angle_radians / a;
    q = Slerp(Quaternion::Identity, q, t);
    return q.Transform(from);
}

float Quaternion::AngleBetween(const Quaternion& target) const
{
    assert(IsInvertible());
    Quaternion q = target / *this;
    return q.Angle();
}

Vector3 Quaternion::AxisFromTo(const Quaternion& target) const
{
    assert(IsInvertible());
    Quaternion q = target / *this;
    return q.Axis();
}

void Quaternion::ToAxisAngle(Vector3& axis, float &angle_radians) const
{
    // Best: 36.868 nsecs / 98.752 ticks, Avg: 37.095 nsecs, Worst: 37.636 nsecs
    assert(IsNormalized());
    float halfAngle = acos(w);
    angle_radians = halfAngle * 2.f;
    // Convert cos to sin via the identity sin^2 + cos^2 = 1, and fuse reciprocal and square root to the same instruction,
    // since we are about to divide by it.
    float rcpSinAngle = 1.f / sqrt(1.f - w * w);
    axis.x = x * rcpSinAngle;
    axis.y = y * rcpSinAngle;
    axis.z = z * rcpSinAngle;
}

void Quaternion::ToAxisAngle(Vector4& axis, float &angle_radians) const
{
    // Best: 85.258 nsecs / 227.656 ticks, Avg: 85.492 nsecs, Worst: 86.410 nsecs
    ToAxisAngle(reinterpret_cast<Vector3&>(axis), angle_radians);
    axis.w = 0.f;
}

void Quaternion::SetFromAxisAngle(const Vector3& axis, float angle_radians)
{
    assert(isfinite(angle_radians));
    float sinz, cosz;
    sin_cos(angle_radians * 0.5f, sinz, cosz);
    x = axis.x * sinz;
    y = axis.y * sinz;
    z = axis.z * sinz;
    w = cosz;
}

void Quaternion::SetFromAxisAngle(const Vector4& axis, float angle_radians)
{
    assert(equal_abs(axis.w, 0.f));
    assert(isfinite(angle_radians));

    // Best: 36.868 nsecs / 98.312 ticks, Avg: 36.980 nsecs, Worst: 41.477 nsecs
    SetFromAxisAngle(axis.XYZ(), angle_radians);
}

void Quaternion::Set(const Matrix3& m)
{
    // The rotation matrix is of form:
    // 1 - 2y^2 - 2z^2        2xy + 2wz            2xz - 2wy
    //    2xy - 2wz        1 - 2x^2 - 2z^2         2yz + 2wx
    //    2xz + 2wy           2yz - 2wx         1 - 2x^2 - 2y^2
    float r_w = m._m[0] + m._m[4] + m._m[8]; // 4w^2 - 1
    float r_x = m._m[0] - m._m[4] - m._m[8]; // 4x^2 - 1
    float r_y = m._m[4] - m._m[0] - m._m[8]; // 4y^2 - 1
    float r_z = m._m[8] - m._m[0] - m._m[4]; // 4z^2 - 1
    int best_index = 0;
    float best_r = r_w;
    if (r_x > r_w) {
        best_index = 1;
        best_r = r_x;
    }
    if (r_y > r_w) {
        best_index = 2;
        best_r = r_y;
    }
    if (r_z > r_w) {
        best_index = 3;
        best_r = r_z;
    }
    float val = sqrt(best_r + 1.f) * 0.5f;
    float mult = 0.25f / val;
    switch (best_index) {
    case 0:
        w = val;
        x = (m._m[5] - m._m[7]) * mult;
        y = (m._m[6] - m._m[2]) * mult;
        z = (m._m[1] - m._m[3]) * mult;
        break;
    case 1:
        x = val;
        w = (m._m[5] - m._m[7]) * mult;
        y = (m._m[1] + m._m[3]) * mult;
        z = (m._m[6] + m._m[2]) * mult;
        break;
    case 2:
        y = val;
        w = (m._m[6] - m._m[2]) * mult;
        x = (m._m[1] + m._m[3]) * mult;
        z = (m._m[5] + m._m[7]) * mult;
        break;
    case 3:
        z = val;
        w = (m._m[1] - m._m[3]) * mult;
        x = (m._m[6] + m._m[2]) * mult;
        y = (m._m[5] + m._m[7]) * mult;
        break;
    }
}

void Quaternion::Set(const Matrix4& m)
{
    // The rotation matrix is of form:
    // 1 - 2y^2 - 2z^2        2xy + 2wz            2xz - 2wy
    //    2xy - 2wz        1 - 2x^2 - 2z^2         2yz + 2wx
    //    2xz + 2wy           2yz - 2wx         1 - 2x^2 - 2y^2
    float r_w = m._m[0] + m._m[5] + m._m[10]; // 4w^2 - 1
    float r_x = m._m[0] - m._m[5] - m._m[10]; // 4x^2 - 1
    float r_y = m._m[5] - m._m[0] - m._m[10]; // 4y^2 - 1
    float r_z = m._m[10] - m._m[0] - m._m[5]; // 4z^2 - 1
    int best_index = 0;
    float best_r = r_w;
    if (r_x > r_w) {
        best_index = 1;
        best_r = r_x;
    }
    if (r_y > r_w) {
        best_index = 2;
        best_r = r_y;
    }
    if (r_z > r_w) {
        best_index = 3;
        best_r = r_z;
    }
    float val = sqrt(best_r + 1.f) * 0.5f;
    float mult = 0.25f / val;
    switch (best_index) {
    case 0:
        w = val;
        x = (m._m[6] - m._m[9]) * mult;
        y = (m._m[8] - m._m[2]) * mult;
        z = (m._m[1] - m._m[4]) * mult;
        break;
    case 1:
        x = val;
        w = (m._m[6] - m._m[9]) * mult;
        y = (m._m[1] + m._m[4]) * mult;
        z = (m._m[8] + m._m[2]) * mult;
        break;
    case 2:
        y = val;
        w = (m._m[8] - m._m[2]) * mult;
        x = (m._m[1] + m._m[4]) * mult;
        z = (m._m[6] + m._m[9]) * mult;
        break;
    case 3:
        z = val;
        w = (m._m[1] - m._m[4]) * mult;
        x = (m._m[8] + m._m[2]) * mult;
        y = (m._m[6] + m._m[9]) * mult;
        break;
    }
}

void Quaternion::Set(float x_, float y_, float z_, float w_)
{
    x = x_;
    y = y_;
    z = z_;
    w = w_;
}

Quaternion Quaternion::RotateX(float angle_radians)
{
    return Quaternion(Vector3(1, 0, 0), angle_radians);
}

Quaternion Quaternion::RotateY(float angle_radians)
{
    return Quaternion(Vector3(0, 1, 0), angle_radians);
}

Quaternion Quaternion::RotateZ(float angle_radians)
{
    return Quaternion(Vector3(0, 0, 1), angle_radians);
}

Quaternion Quaternion::RotateAxisAngle(const Vector3& axis, float angle_radians)
{
    return Quaternion(axis, angle_radians);
}

Quaternion Quaternion::RotateFromTo(const Vector3& source_direction, const Vector3& target_direction)
{
    // If source_direction == target_direction, the cross product comes out zero, and normalization would fail. In that case, pick an arbitrary axis.
    Vector3 axis = source_direction.Cross(target_direction);
    axis.Normalize();
    float halfCosAngle = 0.5f * source_direction.Dot(target_direction);
    float cosHalfAngle = sqrt(0.5f + halfCosAngle);
    float sinHalfAngle = sqrt(0.5f - halfCosAngle);
    return Quaternion(axis.x * sinHalfAngle, axis.y * sinHalfAngle, axis.z * sinHalfAngle, cosHalfAngle);
}

Quaternion Quaternion::RotateFromTo(const Vector4& source_direction, const Vector4& target_direction)
{
    // Best: 19.970 nsecs / 53.632 ticks, Avg: 20.197 nsecs, Worst: 21.122 nsecs
    assert(equal_abs(source_direction.w, 0.f));
    assert(equal_abs(target_direction.w, 0.f));
    return Quaternion::RotateFromTo(source_direction.XYZ(), target_direction.XYZ());
}

Quaternion Quaternion::FromEulerTransform(float p, float h, float b)
{
    float cos_half_p = cos(p * 0.5f);
    float sin_half_p = sin(p * 0.5f);
    float cos_half_h = cos(h * 0.5f);
    float sin_half_h = sin(h * 0.5f);
    float cos_half_b = cos(b * 0.5f);
    float sin_half_b = sin(b * 0.5f);
    return Quaternion(cos_half_h * sin_half_p * cos_half_b + sin_half_h * cos_half_p * sin_half_b,
                      sin_half_h * cos_half_p * cos_half_b - cos_half_h * sin_half_p * sin_half_b,
                      cos_half_h * cos_half_p * sin_half_b - sin_half_h * sin_half_p * cos_half_b,
                      cos_half_h * cos_half_p * cos_half_b + sin_half_h * sin_half_p * sin_half_b);
}

Quaternion Quaternion::RandomRotation()
{
    // Generate a random point on the 4D unitary hypersphere using the rejection sampling method.
    for (int i = 0; i < 1000; ++i)
    {
        float x = random_float(-1, 1);
        float y = random_float(-1, 1);
        float z = random_float(-1, 1);
        float w = random_float(-1, 1);
        float len_sq = x * x + y * y + z * z + w * w;
        if (len_sq >= 1e-6f && len_sq <= 1.f)
            return Quaternion(x, y, z, w) / sqrt(len_sq);
    }
    assert(false && "Quaternion::RandomRotation failed!");
    return Quaternion::Identity;
}

Vector3 Quaternion::ExtractEulerTransform() const
{
    float h, p, b;
    float sp = -2.f * (y*z - w * x);
    // check gimbal lock
    if (abs(sp) > 0.9999f) {
        p = HALF_PI * sp;
        h = atan2(-x * z + w * y, 0.5f - y * y - z * z);
        b = 0.0f;
    } else {
        p = asin(sp);
        h = atan2(x*z + w * y, 0.5f - x * x - y * y);
        b = atan2(x*y + w * z, 0.5f - x * x - z * z);
    }
    return Vector3(p, h, b);
}

Matrix3 Quaternion::ToMatrix3() const
{
    return Matrix3(Matrix3::ROTATION(), *this);
}

Matrix4 Quaternion::ToMatrix4() const
{
    assert(IsNormalized());
    return Matrix4(Matrix4::ROTATION(), *this);
}

Matrix4 Quaternion::ToMatrix4(const Vector3& translation) const
{
    Matrix4 m(Matrix4::ROTATION(), *this);
    m.TranslateAffine(translation);
    return m;
}

Matrix4 Quaternion::ToMatrix4(const Vector4& translation) const
{
    assert(IsNormalized());
    Matrix4 m(Matrix4::ROTATION(), *this);
    m.TranslateAffine(translation.XYZ());
    return m;
}

std::string Quaternion::ToString() const
{
    char str[256];
    sprintf(str, "(%.3f, %.3f, %.3f, %.3f)", x, y, z, w);
    return str;
}

Quaternion Quaternion::operator +(const Quaternion& rhs) const
{
    return Quaternion(x + rhs.x, y + rhs.y, z + rhs.z, w + rhs.w);
}

Quaternion Quaternion::operator -(const Quaternion& rhs) const
{
    return Quaternion(x - rhs.x, y - rhs.y, z - rhs.z, w - rhs.w);
}

Quaternion Quaternion::operator -() const
{
    return Quaternion(-x, -y, -z, -w);
}

Quaternion Quaternion::operator *(float scalar) const
{
    return Quaternion(x * scalar, y * scalar, z * scalar, w * scalar);
}

Vector3 Quaternion::operator *(const Vector3& rhs) const
{
    return Transform(rhs);
}

Vector4 Quaternion::operator *(const Vector4& rhs) const
{
    return Transform(rhs);
}

Quaternion Quaternion::operator /(float scalar) const
{
    assert(!equal_abs(scalar, 0.f));

    return *this * (1.f / scalar);
}

Quaternion Quaternion::operator *(const Quaternion& r) const
{
    // Best: 12.289 nsecs / 33.216 ticks, Avg: 12.585 nsecs, Worst: 13.442 nsecs
    return Quaternion(x*r.w + y * r.z - z * r.y + w * r.x,
                      -x * r.z + y * r.w + z * r.x + w * r.y,
                      x*r.y - y * r.x + z * r.w + w * r.z,
                      -x * r.x - y * r.y - z * r.z + w * r.w);
}

Quaternion Quaternion::operator /(const Quaternion& r) const
{
    return Quaternion(x*r.w - y * r.z + z * r.y - w * r.x,
                      x*r.z + y * r.w - z * r.x - w * r.y,
                      -x * r.y + y * r.x + z * r.w - w * r.z,
                      x*r.x + y * r.y + z * r.z + w * r.w);
}

std::ostream &operator <<(std::ostream& out, const Quaternion& rhs)
{
    out << rhs.ToString();
    return out;
}

Quaternion Quaternion::Mul(const Quaternion& rhs) const { return *this * rhs; }
Quaternion Quaternion::Mul(const Matrix3& rhs) const { return *this * Quaternion(rhs); }
Vector3 Quaternion::Mul(const Vector3& vector) const { return Transform(vector); }
Vector4 Quaternion::Mul(const Vector4& vector) const { return Transform(vector); }

const Quaternion Quaternion::Identity = Quaternion(0.f, 0.f, 0.f, 1.f);
const Quaternion Quaternion::Nan = Quaternion(FLOAT_NAN, FLOAT_NAN, FLOAT_NAN, FLOAT_NAN);
