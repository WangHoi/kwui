#ifndef MATRIX4_H
#define MATRIX4_H

#include "Vector3.h"
#include "Vector4.h"
#include "Matrix3.h"
#include "Range.h"
#include "math_types.h"
#include "AxisRotation.h"

/***** matrix layout *****
  0  1  2  3
  4  5  6  7
  8  9 10 11
 12 13 14 15
 */

class Quaternion;
class Matrix4 {
public:

    /*** traits classes for constructor ***/
    struct IDENTITY {};
    struct TRANSLATION {};
    struct AXIS_ROTATION {};
    struct MULTI_AXIS_ROTATION {};
    struct EULER_TRANSFORM {};
    struct ROTATION {};
    struct SCALE {};
    struct FLIP {};
    struct TO_AABB {};
    struct PROJECTION {};
    struct ROWS {};
    struct COLUMNS {};
    struct SQT {};

    /*** configuration for matrix ***/
    enum CullingSpaceZRange {
        NEGATIVE_ONE_TO_ONE_Z, // for opengl
        ZERO_TO_ONE_Z, // for dx
        CULLING_SPACE_Z_RANGE_COUNT
    };
    static Vector2 DEPTH_RANGE[CULLING_SPACE_Z_RANGE_COUNT];

    /***** initializers *****/
    Matrix4() {} // uninitialized
    explicit Matrix4(const float* m) { Set(m); }
    Matrix4(float x1, float x2, float x3, float x4, float x5, float x6, float x7, float x8,
            float x9, float x10, float x11, float x12, float x13, float x14, float x15, float x16) {
        _m[0] = x1; _m[1] = x2; _m[2] = x3; _m[3] = x4; _m[4] = x5; _m[5] = x6; _m[6] = x7; _m[7] = x8;
        _m[8] = x9; _m[9] = x10; _m[10] = x11; _m[11] = x12; _m[12] = x13; _m[13] = x14; _m[14] = x15; _m[15] = x16;
    }

    explicit Matrix4(IDENTITY) { MakeIdentity(); }
    Matrix4(TRANSLATION, float x, float y, float z) { MakeTranslation(x, y, z); }
    Matrix4(TRANSLATION, const Vector3& v) { MakeTranslation(v); }
    Matrix4(AXIS_ROTATION, Axis axis, float radians) { MakeAxisRotation(axis, radians); }
    Matrix4(AXIS_ROTATION, const AxisRotation& rotation) { MakeAxisRotation(rotation); }
    Matrix4(MULTI_AXIS_ROTATION, const MultiAxisRotation& rotation) { MakeMultiAxisRotation(rotation); }
    Matrix4(EULER_TRANSFORM, const Vector3& euler_angle) { MakeEulerTransform(euler_angle); }
    Matrix4(ROTATION, const Quaternion& q) { MakeRotation(q); }
    Matrix4(SCALE, float x, float y, float z) { MakeScale(x, y, z); }
    Matrix4(SCALE, float scale) { MakeScale(scale); }
    Matrix4(SCALE, const Vector3& v) { MakeScale(v); }
    Matrix4(FLIP, Axis axis) { MakeFlip(axis); }
    Matrix4(PROJECTION, float fov_y, float aspect, float near_z, float far_z, CullingSpaceZRange z_range) { MakeProjection(fov_y, aspect, near_z, far_z, z_range); }
    Matrix4(ROWS, const Vector3& v1, const Vector3& v2, const Vector3& v3) { MakeByRows(v1, v2, v3); }
    Matrix4(COLUMNS, const Vector3& v1, const Vector3& v2, const Vector3& v3) { MakeByColumns(v1, v2, v3); }
    Matrix4(SQT, const Vector3& scale, const Vector3& euler_angles, const Vector3& translation) { MakeSQT(scale, euler_angles, translation); }
    Matrix4(SQT, const Vector3& scale, const Quaternion& q, const Vector3& translation) { MakeSQT(scale, q, translation); }

    /***** setters *****/
    void Set(const float* m) { memcpy(_m, m, sizeof(_m)); }
    void Clear() { memset(_m, 0, sizeof(_m)); }
    void MakeIdentity();
    void MakeTranslation(float x, float y, float z);
    void MakeTranslation(const Vector3& v) { MakeTranslation(v.x, v.y, v.z); }
    void MakeAxisRotation(Axis axis, float radians);
    void MakeAxisRotation(const AxisRotation& rotation) { MakeAxisRotation(rotation.axis, rotation.angle); }
    void MakeMultiAxisRotation(const MultiAxisRotation& rotation);
    void MakeEulerTransform(const Vector3& euler_angle);
    void MakeRotation(const Quaternion& q);
    void MakeScale(float x, float y, float z);
    void MakeScale(float scale) { MakeScale(scale, scale, scale); }
    void MakeScale(const Vector3& v) { MakeScale(v.x, v.y, v.z); }
    void MakeFlip(Axis axis);
    void MakeByRows(const Vector3& v1, const Vector3& v2, const Vector3& v3);
    void MakeByColumns(const Vector3& v1, const Vector3& v2, const Vector3& v3);
    void MakeProjection(float fov_y, float aspect, float near_z, float far_z, CullingSpaceZRange z_range);
    void MakeSQT(const Vector3& scale, const Quaternion& q, const Vector3& translation);
    void MakeSQT(const Vector3& scale, const Vector3& euler_angles, const Vector3& translation);

    // only set the upper-left 3x3 matrix
    void SetRows(const float* v1, const float* v2, const float* v3);
    void SetColumns(const float* v1, const float* v2, const float* v3);
    void SetRows(const Vector3& v1, const Vector3& v2, const Vector3& v3) { SetRows(v1.GetBuffer(), v2.GetBuffer(), v3.GetBuffer()); }
    void SetColumns(const Vector3& v1, const Vector3& v2, const Vector3& v3) { SetColumns(v1.GetBuffer(), v2.GetBuffer(), v3.GetBuffer()); }
    void SetMatrix3(const Matrix3& m);
    void SetRotation(const Quaternion& q);
    void SetSQT(const Vector3& scale, const Quaternion& q, const Vector3& translation);
    void SetSQT(const Vector3& scale, const Vector3& euler_angles, const Vector3& translation);

    // only set the lower-left 1x3 matrix
    void SetTranslation(float x, float y, float z);
    void SetTranslation(const Vector3& v) { SetTranslation(v.x, v.y, v.z); }

    // set last column to (0, 0, 0, 1)
    void ResetLastColumn();

    // expand the upper-left 3x3 matrix to 4x4
    void ExpandMatrix3();

    /***** getters *****/
    const float* GetBuffer() const { return _m; }
    float* GetBuffer() { return _m; }

    /***** transformations *****/
    Matrix4& Scale(float x, float y, float z);
    Matrix4& Scale(float scale) { return Scale(scale, scale, scale); }
    Matrix4& Scale(const Vector3& v) { return Scale(v.x, v.y, v.z); }
    Matrix4& TranslateAffine(float x, float y, float z);
    Matrix4& TranslateAffine(const Vector3& v) { return TranslateAffine(v.x, v.y, v.z); }
    Matrix4& AxisRotate(Axis axis, float angle) {
        if (angle == 0) return *this;
        return Transform({ Matrix4::AXIS_ROTATION{}, axis, angle });
    }
    Matrix4& Rotate(const Quaternion& q) { return Transform(Matrix4(ROTATION(), q)); }
    Matrix4& AxisRotate(const AxisRotation& rotation) { return AxisRotate(rotation.axis, rotation.angle); }
    Matrix4& MultiAxisRotate(const MultiAxisRotation& rotation) {
        for (auto& r : rotation) AxisRotate(r);
        return *this;
    }
    Matrix4& EulerTransform(const Vector3& euler_angle) {
        if (euler_angle.IsZero()) return *this;
        return Transform({ Matrix4::EULER_TRANSFORM{}, euler_angle });
    }
    Matrix4& Flip(Axis axis);
    Matrix4& Transform(const Matrix4& m) { return *this = *this * m; }

    /***** operations *****/
    friend Matrix4 operator*(const Matrix4& m1, const Matrix4& m2);
    Matrix4& operator+=(const Matrix4& m);
    Matrix4& operator*=(float k);
    Matrix4 ComputeMul(float k) const;

    Vector3 ExtractScale() const;
    Quaternion ExtractRotation() const;
    Vector3 ExtractEulerTransform() const;
    Vector3 ExtractTranslation() const { return { _m[12], _m[13], _m[14] }; }
    Matrix3 ExtractMatrix3() const { return{ Matrix3::ROWS{}, _m, _m + 4, _m + 8 }; }
    void ExtractMatrix3Rows(Vector3* r1, Vector3* r2, Vector3* r3) const;
    void ExtractMatrix3Columns(Vector3* c1, Vector3* c2, Vector3* c3) const;
    Matrix4 ComputeTranspose() const;
    Matrix3 ComputeNormalMatrix() const { return ExtractMatrix3().ComputeInverseTranspose(); }
    Matrix4 ComputeInverseAffine() const;
    float ComputeUnifiedScaleAffine() const;
    void ExtractSQT(Vector3 &scale, Quaternion& rotation, Vector3 &translate);
    void ExtractSQT(Vector3 &scale, Vector3& rotation, Vector3 &translate);

    Vector4 Transform(const Vector4& v) const;
    Vector3 TransformPositionAffine(const Vector3& position) const;
    Vector3 TransformPositionInaffine(const Vector3& position) const;
    Range3 TransformAABBAffine(const Range3& aabb) const;

private:
    float _m[16];

    friend class Quaternion;
};

extern const Matrix4 IDENTITY_MATRIX4;

#endif // MATRIX4_H
