//
//  C2Equation.h
//  C2Engine
//
//  Created by mike luo on 2015-1-20.
//
//
#ifndef C2_EQUATION_H
#define C2_EQUATION_H

#include "system_of_linear_equations.h"

#endif // C2_EQUATION_H