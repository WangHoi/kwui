#include "stdafx.h"
//
//  system_of_linear_equations.cpp
//  C2Engine
//
//  Created by mike luo on 2015-1-20.
//
//
#include "system_of_linear_equations.h"

#include "math/float_math.h"

bool solve_system_of_linear_equations(float a11, float a12, float a21, float a22, float b1, float b2, float* x1, float* x2) {
  float D = a11 * a22 - a12 * a21;
  if (fabsf(D) < 1e-6) return false;
  float inv_D = INV(D);
  if (x1) *x1 = (a22 * b1 - a12 * b2) * inv_D;
  if (x2) *x2 = (a11 * b2 - a21 * b1) * inv_D;
  return true;
}