//
//  system_of_linear_equations.h
//  C2Engine
//
//  Created by mike luo on 2015-1-20.
//
//
#ifndef SYSTEM_OF_LINEAR_EQUATIONS_H
#define SYSTEM_OF_LINEAR_EQUATIONS_H

bool solve_system_of_linear_equations(float a11, float a12, float a21, float a22, float b1, float b2, float* x1, float* x2);

#endif // SYSTEM_OF_LINEAR_EQUATIONS_H