//
//  random_helpers.h
//  C2Engine
//
//  Created by mike luo on 12-12-3.
//
//

#ifndef RANDOM_HELPERS_H
#define RANDOM_HELPERS_H

#include "math/Vector2.h"

#include <stdlib.h>
#include <time.h>

#ifdef log // ad-hoc
#undef log
#define LOG_HIDDEN
#endif

#include <random>

#ifdef LOG_HIDDEN // ad-hoc
#define c2_log(...) LogManager::Instance()->Log(__VA_ARGS__)
#undef LOG_HIDDEN
#endif

using std::default_random_engine;
using std::normal_distribution;

inline void random_initialize() {
  srand((unsigned int) time(0));
}

inline float random_float() {
  return rand() / (float) RAND_MAX;
}

inline float random_float(float min, float max) {
  return min + (max - min) * random_float();
}

inline float random_float(const Vector2& range) {
  return random_float(range[0], range[1]);
}

inline int random_int(int range) {
  return rand() % range;
}

inline int random_int(int min, int max) {
  return min + random_int(max - min + 1);
}

inline bool binary_test(float p) {
  return random_float() < p;
}

inline int random_sign() {
  return random_int(2) * 2 - 1;
}

inline int random_sign(float positive_possibility) {
  if (binary_test(positive_possibility)) return 1;
  return -1;
}

inline float random_radians() {
  return random_float(0, 2 * PI);
}

#endif // RANDOM_HELPERS_H