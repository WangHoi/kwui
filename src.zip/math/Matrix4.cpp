#include "Matrix4.h"
#include "Quaternion.h"
#include "float_math.h"

Vector2 Matrix4::DEPTH_RANGE[CULLING_SPACE_Z_RANGE_COUNT] = {
  {-1.0f, 1.0f}, // NEGATIVE_ONE_TO_ONE_Z
  {0.0f, 1.0f} // ZERO_TO_ONE_Z
};

const Matrix4 IDENTITY_MATRIX4{ Matrix4::IDENTITY{} };

/***** setters *****/
void Matrix4::MakeIdentity() {
    Clear();
    _m[0] = _m[5] = _m[10] = _m[15] = 1.0f;
}

void Matrix4::SetTranslation(float x, float y, float z) {
    _m[12] = x; _m[13] = y; _m[14] = z;
}

void Matrix4::SetRotation(const Quaternion &q) {
    const float x = q.x;
    const float y = q.y;
    const float z = q.z;
    const float w = q.w;
    _m[0] = 1 - 2 * (y*y + z * z); _m[1] = 2 * (x*y + z * w); _m[2] = 2 * (x*z - y * w);
    _m[4] = 2 * (x*y - z * w); _m[5] = 1 - 2 * (x*x + z * z); _m[6] = 2 * (y*z + x * w);
    _m[8] = 2 * (x*z + y * w); _m[9] = 2 * (y*z - x * w); _m[10] = 1 - 2 * (x*x + y * y);
}

void Matrix4::SetSQT(const Vector3& scale, const Quaternion& q, const Vector3& translation) {
    SetRotation(q);
    _m[0] *= scale.x; _m[1] *= scale.x; _m[2] *= scale.x;
    _m[4] *= scale.y; _m[5] *= scale.y; _m[6] *= scale.y;
    _m[8] *= scale.z; _m[9] *= scale.z; _m[10] *= scale.z;
    SetTranslation(translation);
}

void Matrix4::SetSQT(const Vector3& scale, const Vector3& euler_angles, const Vector3& translation) {
    SetSQT(scale, Quaternion::FromEulerTransform(euler_angles), translation);
}

void Matrix4::MakeTranslation(float x, float y, float z) {
    MakeIdentity();
    SetTranslation(x, y, z);
}

void Matrix4::MakeAxisRotation(Axis axis, float radians) {
    float s, c; // sin & cos
    sin_cos(radians, s, c);
    switch (axis) {
    case AXIS_X:
        _m[5] = _m[10] = c; //  1  0  0             0  1  2
        _m[9] = -s;         //  0  c  s             4  5  6
        _m[6] = s;          //  0  -s c             8  9  10
        _m[1] = _m[2] = _m[4] = _m[8] = 0.0f;
        _m[0] = 1.0f;
        break;
    case AXIS_Y:
        _m[0] = _m[10] = c; //  c  0 -s
        _m[2] = -s;         //  0  1  0
        _m[8] = s;          //  s  0  c
        _m[1] = _m[4] = _m[6] = _m[9] = 0.0f;
        _m[5] = 1.0f;
        break;
    default:
        _m[0] = _m[5] = c; //  c  s  0
        _m[4] = -s;        //  -s c  0
        _m[1] = s;         //  0  0  1
        _m[2] = _m[6] = _m[8] = _m[9] = 0.0f;
        _m[10] = 1.0f;
        break;
    }
    ExpandMatrix3();
}

void Matrix4::MakeMultiAxisRotation(const MultiAxisRotation& rotation) {
    int rotation_count = rotation.size();
    if (rotation_count == 0) {
        MakeIdentity();
        return;
    }

    MakeAxisRotation(rotation.front());
    for (int i = 1; i < rotation_count; i++) AxisRotate(rotation[i]);
}

void Matrix4::MakeEulerTransform(const Vector3& euler_angle) {
    float h = euler_angle.y, p = euler_angle.x, r = euler_angle.z;
    float sinh, cosh, sinp, cosp, sinr, cosr;
    sin_cos(h, sinh, cosh);
    sin_cos(p, sinp, cosp);
    sin_cos(r, sinr, cosr);
    _m[0] = cosr * cosh - sinr * sinp * sinh;
    _m[1] = sinr * cosh + cosr * sinp * sinh;
    _m[2] = -cosp * sinh;
    _m[4] = -sinr * cosp;
    _m[5] = cosr * cosp;
    _m[6] = sinp;
    _m[8] = cosr * sinh + sinr * sinp * cosh;
    _m[9] = sinr * sinh - cosr * sinp * cosh;
    _m[10] = cosp * cosh;
    ExpandMatrix3();
}

void Matrix4::MakeRotation(const Quaternion &q) {
    SetRotation(q);
    _m[3] = _m[7] = _m[11] = 0;
    _m[12] = _m[13] = _m[14] = 0;
    _m[15] = 1;
}

void Matrix4::MakeScale(float x, float y, float z) {
    Clear();
    _m[0] = x; _m[5] = y; _m[10] = z; _m[15] = 1.0f;
}

void Matrix4::MakeFlip(Axis axis) {
    MakeIdentity();
    if (axis == AXIS_X) _m[0] = -1.0f;
    else if (axis == AXIS_Y) _m[5] = -1.0f;
    else _m[10] = -1.0f;
}

void Matrix4::SetRows(const float* v1, const float* v2, const float* v3) {
    memcpy(_m, v1, sizeof(float) * 3);
    memcpy(_m + 4, v2, sizeof(float) * 3);
    memcpy(_m + 8, v3, sizeof(float) * 3);
}

void Matrix4::SetColumns(const float* v1, const float* v2, const float* v3) {
    _m[0] = v1[0]; _m[1] = v2[0]; _m[2] = v3[0];
    _m[4] = v1[1]; _m[5] = v2[1]; _m[6] = v3[1];
    _m[8] = v1[2]; _m[9] = v2[2]; _m[10] = v3[2];
}

void Matrix4::SetMatrix3(const Matrix3& m) {
    const float* buf = m.GetBuffer();
    SetRows(buf, buf + 3, buf + 6);
}

void Matrix4::MakeByRows(const Vector3& v1, const Vector3& v2, const Vector3& v3) {
    SetRows(v1, v2, v3);
    ExpandMatrix3();
}

void Matrix4::MakeByColumns(const Vector3& v1, const Vector3& v2, const Vector3& v3) {
    SetColumns(v1, v2, v3);
    ExpandMatrix3();
}

void Matrix4::ResetLastColumn() {
    _m[3] = _m[7] = _m[11] = 0.0;
    _m[15] = 1.0f;
}

void Matrix4::MakeProjection(float fov_y, float aspect, float near_z, float far_z, CullingSpaceZRange z_range) {
    // alias
    float a = aspect, n = near_z, f = far_z;
    float r = cotf(fov_y * 0.5f);

    // compose the matrix
    Clear();
    _m[0] = r / a;
    _m[5] = r;
    if (z_range == NEGATIVE_ONE_TO_ONE_Z) {
        _m[10] = -(f + n) / (f - n);
        _m[14] = -2 * n * f / (f - n);
    } else {
        _m[10] = -f / (f - n);
        _m[14] = -n * f / (f - n);
    }
    _m[11] = -1;
}

void Matrix4::MakeSQT(const Vector3& scale, const Quaternion& q, const Vector3& translation) {
    SetSQT(scale, q, translation);
    _m[3] = _m[7] = _m[11] = 0;
    _m[15] = 1;
}

void Matrix4::MakeSQT(const Vector3& scale, const Vector3& euler_angles, const Vector3& translation) {
    SetSQT(scale, euler_angles, translation);
    _m[3] = _m[7] = _m[11] = 0;
    _m[15] = 1;
}

void Matrix4::ExpandMatrix3() {
    SetTranslation(0, 0, 0);
    ResetLastColumn();
}

/***** transformations *****/

Matrix4& Matrix4::Scale(float x, float y, float z) {
    _m[0] *= x; _m[1] *= y; _m[2] *= z;
    _m[4] *= x; _m[5] *= y; _m[6] *= z;
    _m[8] *= x; _m[9] *= y; _m[10] *= z;
    _m[12] *= x; _m[13] *= y; _m[14] *= z;
    return *this;
}

Matrix4& Matrix4::TranslateAffine(float x, float y, float z) {
    _m[12] += x; _m[13] += y; _m[14] += z;
    return *this;
}

Matrix4& Matrix4::Flip(Axis axis) {
    float* p = _m + axis;
    p[0] = -p[0]; p[4] = -p[4]; p[8] = -p[8]; p[12] = -p[12];
    return *this;
}


/***** operations *****/

Matrix4 operator*(const Matrix4& m1, const Matrix4& m2) {
    Matrix4 result;
    auto b = result._m;
    auto b1 = m1._m, b2 = m2._m;
    for (int i = 0; i < 4; i++) {
        b[0] = b1[0] * b2[0] + b1[1] * b2[4] + b1[2] * b2[8] + b1[3] * b2[12];
        b[1] = b1[0] * b2[1] + b1[1] * b2[5] + b1[2] * b2[9] + b1[3] * b2[13];
        b[2] = b1[0] * b2[2] + b1[1] * b2[6] + b1[2] * b2[10] + b1[3] * b2[14];
        b[3] = b1[0] * b2[3] + b1[1] * b2[7] + b1[2] * b2[11] + b1[3] * b2[15];
        b += 4; b1 += 4;
    }
    return result;
}

Vector4 Matrix4::Transform(const Vector4& v) const {
    return {
      v.x * _m[0] + v.y * _m[4] + v.z * _m[8] + v.w * _m[12],
      v.x * _m[1] + v.y * _m[5] + v.z * _m[9] + v.w * _m[13],
      v.x * _m[2] + v.y * _m[6] + v.z * _m[10] + v.w * _m[14],
      v.x * _m[3] + v.y * _m[7] + v.z * _m[11] + v.w * _m[15]
    };
}

Matrix4& Matrix4::operator+=(const Matrix4& m) {
    auto b = m._m;
    for (int i = 0; i < 16; i++) _m[i] += b[i];
    return *this;
}

Matrix4& Matrix4::operator*=(float k) {
    for (int i = 0; i < 16; i++) _m[i] *= k;
    return *this;
}

Matrix4 Matrix4::ComputeMul(float k) const {
    Matrix4 m(*this);
    m *= k;
    return m;
}

Vector3 Matrix4::ExtractScale() const
{
    Vector3 r1, r2, r3;
    ExtractMatrix3Rows(&r1, &r2, &r3);
    return Vector3(r1.Length(), r2.Length(), r3.Length());
}

Quaternion Matrix4::ExtractRotation() const
{
    Matrix3 m;
    Vector3 r1, r2, r3;
    ExtractMatrix3Rows(&r1, &r2, &r3);
    m.SetRows(r1 / r1.Length(), r2 / r2.Length(), r3 / r3.Length());
    return Quaternion(m);
}

Vector3 Matrix4::ExtractEulerTransform() const
{
    Matrix3 m;
    Vector3 r1, r2, r3;
    ExtractMatrix3Rows(&r1, &r2, &r3);
    m.SetRows(r1 / r1.Length(), r2 / r2.Length(), r3 / r3.Length());
    float h, p, b;
    float sp = -m._m[7];
    if (sp <= -1.f)
        p = -HALF_PI;
    else if (sp >= 1.f)
        p = HALF_PI;
    else
        p = asin(sp);
    // check gimbal lock
    if (abs(sp) > 0.999f) {
        b = 0.0f;
        h = atan2(-m._m[2], m._m[0]);
    } else {
        h = atan2(-m._m[6], m._m[8]);
        b = atan2(m._m[1], m._m[4]);
    }
    return Vector3(p, h, b);
}

void Matrix4::ExtractMatrix3Rows(Vector3* r1, Vector3* r2, Vector3* r3) const {
    if (r1) r1->Set(_m);
    if (r2) r2->Set(_m + 4);
    if (r3) r3->Set(_m + 8);
}

void Matrix4::ExtractMatrix3Columns(Vector3* c1, Vector3* c2, Vector3* c3) const {
    if (c1) c1->Set(_m[0], _m[4], _m[8]);
    if (c2) c2->Set(_m[1], _m[5], _m[9]);
    if (c3) c3->Set(_m[2], _m[6], _m[10]);
}

Matrix4 Matrix4::ComputeTranspose() const {
    return {
      _m[0], _m[4], _m[8], _m[12],
      _m[1], _m[5], _m[9], _m[13],
      _m[2], _m[6], _m[10], _m[14],
      _m[3], _m[7], _m[11], _m[15]
    };
}

Matrix4 Matrix4::ComputeInverseAffine() const {
    Matrix3 A_inv = ExtractMatrix3().ComputeInverse();
    Vector3 t = ExtractTranslation();
    Matrix4 result;
    result.SetMatrix3(A_inv);
    result.SetTranslation(A_inv.Transform(-t));
    result.ResetLastColumn();
    return result;
}

Vector3 Matrix4::TransformPositionAffine(const Vector3& p) const {
    return {
      p.x * _m[0] + p.y * _m[4] + p.z * _m[8] + _m[12],
      p.x * _m[1] + p.y * _m[5] + p.z * _m[9] + _m[13],
      p.x * _m[2] + p.y * _m[6] + p.z * _m[10] + _m[14]
    };
}

Vector3 Matrix4::TransformPositionInaffine(const Vector3& p) const {
    return Vector4{
      p.x * _m[0] + p.y * _m[4] + p.z * _m[8] + _m[12],
      p.x * _m[1] + p.y * _m[5] + p.z * _m[9] + _m[13],
      p.x * _m[2] + p.y * _m[6] + p.z * _m[10] + _m[14],
      p.x * _m[3] + p.y * _m[7] + p.z * _m[11] + _m[15]
    }.GetPosition();
}

Range3 Matrix4::TransformAABBAffine(const Range3& aabb) const {
    Range3 result{ Range3::EMPTY{} };
    Vector3 vs[2] = { aabb.GetMin(), aabb.GetMax() };
    for (int i = 0; i < 2; i++) {
        for (int j = 0; j < 2; j++) {
            for (int k = 0; k < 2; k++) {
                result.Expand(TransformPositionAffine({ vs[i].x, vs[j].y, vs[k].z }));
            }
        }
    }
    return result;
}

float Matrix4::ComputeUnifiedScaleAffine() const {
    return sqrtf(square(_m[0]) + square(_m[1]) + square(_m[2]));
}

void Matrix4::ExtractSQT(Vector3& scale, Quaternion& rotation, Vector3& translate)
{
    translate = ExtractTranslation();
    Matrix3 m;
    Vector3 r1, r2, r3;
    ExtractMatrix3Rows(&r1, &r2, &r3);
    if (Matrix3(Matrix3::ROWS(), &r1.x, &r2.x, &r3.x).ComputeDeterminant() < 0) r1 = -r1;
    scale.x = r1.Length();
    scale.y = r2.Length();
    scale.z = r3.Length();
    m.SetRows(r1 / r1.Length(), r2 / r2.Length(), r3 / r3.Length());
    rotation = Quaternion(m);
}

void Matrix4::ExtractSQT(Vector3& scale, Vector3& rotation, Vector3& translate)
{
    translate = ExtractTranslation();
    Matrix3 m;
    Vector3 r1, r2, r3;
    ExtractMatrix3Rows(&r1, &r2, &r3);
    scale.x = r1.Length();
    scale.y = r2.Length();
    scale.z = r3.Length();
    m.SetRows(r1 / r1.Length(), r2 / r2.Length(), r3 / r3.Length());
    float h, p, b;
    float sp = -m._m[7];
    if (sp <= -1.f)
        p = -HALF_PI;
    else if (sp >= 1.f)
        p = HALF_PI;
    else
        p = asin(sp);
    // check gimbal lock
    if (abs(sp) > 0.999f) {
        b = 0.0f;
        h = atan2(-m._m[2], m._m[0]);
    } else {
        h = atan2(-m._m[6], m._m[8]);
        b = atan2(m._m[1], m._m[4]);
    }
    rotation.x = p;
    rotation.y = h;
    rotation.z = b;
}

/***** test *****/
/* class GetInverseMatrixAffineUnitTest {
public:
  GetInverseMatrixAffineUnitTest() {
    Matrix4 M{
      1.3f, -0.9f, 2.8f, 4.6f,
      0.0f, 19.8f, -23.2f, 0.1f,
      3.3f, 1.15f, 6.9f, 10.2f,
      0.0f, 0.0f, 0.0f, 1.0f
    };
    Matrix4 M_inv = M.ComputeInverseAffine();
    Matrix4 I = M * M_inv;
  }
}; */

// static GetInverseMatrixAffineUnitTest test;
