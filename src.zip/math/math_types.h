//
//  math_types.h
//  C2Engine
//
//  Created by mike luo on 12-11-26.
//
//

#ifndef MATH_TYPES_H
#define MATH_TYPES_H

enum Axis {
  AXIS_X,
  AXIS_Y,
  AXIS_Z,
  AXIS_COUNT
};

#endif // MATH_TYPES_H
