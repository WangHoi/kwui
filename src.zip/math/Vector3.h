#ifndef VECTOR3_H
#define VECTOR3_H

#include "math_types.h"
#include "float_math.h"
#include "math_templates.h"
#include "Vector2.h"
#include "algorithm/hash_functions.h"
#include "debug/log.h"
#include "Vector2.h"

class Vector3 {
public:
    float x, y, z;

    struct SPHERICAL {};
    struct POLAR {};

    /***** initializers *****/
    Vector3() {} // uninitialized
    explicit Vector3(float v) { Set(v); }
    Vector3(float x, float y, float z) { Set(x, y, z); }
    explicit Vector3(const float* v) { Set(v); }
    Vector3(const Vector3& v) { Set(v.x, v.y, v.z); }
    Vector3(const Vector2& v, Axis axis, float u) { Set(v, axis, u); }
    Vector3(SPHERICAL, float radius, float theta, float phi) { SetSpherical(radius, theta, phi); }
    Vector3(POLAR, const Vector3& base1, const Vector3& base2, float radius, float phi) { SetPolar(base1, base2, radius, phi); }

    /***** getters *****/
    const float* GetBuffer() const { return (const float*)this; }
    float* GetBuffer() { return (float*)this; }
    const float& operator[](int index) const { return GetBuffer()[index]; } // no bound check!
    float& operator[](int index) { return GetBuffer()[index]; } // no bound check!
    Vector2 GetXY() const { return { x, y }; }
    Vector2 GetYZ() const { return { y, z }; }
    Vector2 GetZX() const { return { z, x }; }

    /***** setters *****/
    Vector3& operator=(const Vector3& v) {
        if (this != &v) Set(v.x, v.y, v.z);
        return *this;
    }

    void Set(float x, float y, float z) {
        this->x = x;
        this->y = y;
        this->z = z;
    }

    void Set(float v) { Set(v, v, v); }
    void Set(const float* v) { Set(v[0], v[1], v[2]); }
    void Set(const Vector2& v, Axis axis, float u) {
        if (axis == AXIS_X) Set(u, v.x, v.y);
        else if (axis == AXIS_Y) Set(v.y, u, v.x);
        else Set(v.x, v.y, u);
    }

    void SetXY(float x, float y) {
        this->x = x;
        this->y = y;
    }
    void SetYZ(float y, float z) {
        this->y = y;
        this->z = z;
    }
    void SetZX(float z, float x) {
        this->z = z;
        this->x = x;
    }
    void SetXY(const Vector2& v) { SetXY(v.x, v.y); }
    void SetYZ(const Vector2& v) { SetYZ(v.x, v.y); }
    void SetZX(const Vector2& v) { SetZX(v.x, v.y); }

    Vector3& SetSpherical(float radius, float theta, float phi);
    Vector3& SetSpherical(const Vector3& base1, const Vector3& base2, float radius, float theta, float phi);
    Vector3& SetPolar(const Vector3& base1, const Vector3& base2, float radius, float phi);

    /***** operations *****/
    Vector3& operator+=(const Vector3& v);
    Vector3& operator-=(const Vector3& v);
    Vector3& operator*=(const Vector3& v);
    Vector3& operator/=(const Vector3& v);
    Vector3& operator+=(float k);
    Vector3& operator-=(float k);
    Vector3& operator*=(float k);
    Vector3& operator/=(float k);

    //swizzle operations
    Vector2 XX() const { return Vector2(x, x); }
    Vector2 XY() const { return Vector2(x, y); }
    Vector2 YZ() const { return Vector2(y, z); }
    Vector2 ZX() const { return Vector2(z, x); }

#define DECLARE_METHOD_FUNCTION(Method) \
  Vector3& Method(); \
  Vector3 Make##Method() const;

    DECLARE_METHOD_FUNCTION(Negate);
    DECLARE_METHOD_FUNCTION(Inverse);
    DECLARE_METHOD_FUNCTION(Round);
    DECLARE_METHOD_FUNCTION(Abs);
#undef DECLARE_METHOD_FUNCTION

    bool IsZero() const;
    float GetMinValue() const;
    float GetMaxValue() const;
    Axis GetMainAxis() const;
    void UpdateMin(const Vector3& v);
    void UpdateMax(const Vector3& v);
    void SwapIfLargerThan(Vector3& v);

    float Length() const;
    float SquareLength() const;
    Vector3& Normalize();
    Vector3& SetLength(float length);
    Vector3 MakeUnitVector() const;
    Vector3 MakeVectorWithLength(float length) const;
    float DistanceTo(const Vector3& v) const;
    float SquareDistanceTo(const Vector3& v) const;

    Vector3& AxisRotate(Axis axis, float phi);
    Vector3 MakeOrthoVector() const;
    void MakeOrthoPlaneUnit(Vector3& base1, Vector3& base2) const;
    void MakeOrthoPlane(Vector3& base1, Vector3& base2) const;

    Vector2 ProjectAlong(Axis axis) const;
    Vector2 ProjectTo(const Vector3& base1, const Vector3& base2) const;

    float Dot(const Vector3& rhs) const;
    Vector3 Cross(const Vector3& rhs) const;

    struct Hash {
        size_t operator()(const Vector3& v) const {
            return hash_float_array(v.GetBuffer(), 3);
        }
    };
};

/***** constants *****/
extern const Vector3 ZERO_VECTOR3;
extern const Vector3 UP_VECTOR3;
extern const Vector3 DOWN_VECTOR3;
extern const Vector3 RIGHT_VECTOR3;
extern const Vector3 LEFT_VECTOR3;
extern const Vector3 FRONT_VECTOR3;
extern const Vector3 BACK_VECTOR3;

/*** arithmetics ***/
inline Vector3 operator-(const Vector3& v) { return { -v.x, -v.y, -v.z }; }

#define DEFINE_BINARY_OPERATIONS(op) \
  inline Vector3& Vector3::operator op##=(const Vector3& v) { \
    x op##= v.x; \
    y op##= v.y; \
    z op##= v.z; \
    return *this; \
  } \
  inline Vector3 operator op(const Vector3& v1, const Vector3& v2) { return {v1.x op v2.x, v1.y op v2.y, v1.z op v2.z}; }

#define DEFINE_BINARAY_SCALAR_OPERATIONS(op) \
  inline Vector3& Vector3::operator op##=(float k) { \
    x op##= k; \
    y op##= k; \
    z op##= k; \
    return *this; \
  } \
  inline Vector3 operator op(const Vector3& v, float k) { return {v.x op k, v.y op k, v.z op k }; }

DEFINE_BINARY_OPERATIONS(+);
DEFINE_BINARY_OPERATIONS(-);
DEFINE_BINARY_OPERATIONS(*);
DEFINE_BINARY_OPERATIONS(/ );
DEFINE_BINARAY_SCALAR_OPERATIONS(+);
DEFINE_BINARAY_SCALAR_OPERATIONS(-);
DEFINE_BINARAY_SCALAR_OPERATIONS(*);
inline Vector3& Vector3::operator/=(float k) { return *this *= (1 / k); }
inline Vector3 operator/(const Vector3& v, float k) { return v * (1 / k); }
inline Vector3 operator/(float k, const Vector3& v) { return { k / v.x, k / v.y, k / v.z }; }

#undef DEFINE_BINARY_OPERATIONS
#undef DEFINE_BINARAY_SCALAR_OPERATIONS

inline float dot(const Vector3& v1, const Vector3& v2) {
    return v1.x * v2.x + v1.y * v2.y + v1.z * v2.z;
}

inline Vector3 cross(const Vector3& v1, const Vector3& v2) {
    return { v1.y * v2.z - v1.z * v2.y,
            v1.z * v2.x - v1.x * v2.z,
            v1.x * v2.y - v1.y * v2.x };
}

/*** methods ***/
#define DEFINE_METHOD_FUNCTION(Method, method) \
  inline Vector3 Vector3::Make##Method() const { return {method(x), method(y), method(z)}; } \
  inline Vector3& Vector3::Method() { \
  x = method(x); \
  y = method(y); \
  z = method(z); \
  return *this; \
}

DEFINE_METHOD_FUNCTION(Abs, fabsf);
DEFINE_METHOD_FUNCTION(Round, roundf);
DEFINE_METHOD_FUNCTION(Inverse, INV);
DEFINE_METHOD_FUNCTION(Negate, NEG);

#undef DEFINE_METHOD_FUNCTION

/*** compare ***/
#define DEFINE_COMPARE_FUNCTION(op) \
  inline bool operator op(const Vector3& v1, const Vector3& v2) { return (v1.x op v2.x) && (v1.y op v2.y) && (v1.z op v2.z); }

DEFINE_COMPARE_FUNCTION(== )
DEFINE_COMPARE_FUNCTION(< )
    DEFINE_COMPARE_FUNCTION(> )
    DEFINE_COMPARE_FUNCTION(<= )
    DEFINE_COMPARE_FUNCTION(>= )
    inline bool operator!=(const Vector3& v1, const Vector3& v2) { return (v1.x != v2.x) || (v1.y != v2.y) || (v1.z != v2.z); }

#undef DEFINE_COMPARE_FUNCTION

inline bool Vector3::IsZero() const { return x == 0 && y == 0 && z == 0; }

inline float Vector3::GetMinValue() const {
    if (x < y) {
        if (x < z) return x;
        else return z;
    } else {
        if (y < z) return y;
        else return z;
    }
}

inline float Vector3::GetMaxValue() const {
    if (x > y) {
        if (x > z) return x;
        else return z;
    } else {
        if (y > z) return y;
        else return z;
    }
}

inline Axis Vector3::GetMainAxis() const {
    Vector3 v = { fabsf(x), fabsf(y), fabsf(z) };
    if (v.x > v.y) {
        if (v.x > v.z) return AXIS_X;
        else return AXIS_Z;
    } else {
        if (v.y > v.z) return AXIS_Y;
        else return AXIS_Z;
    }
}

inline void Vector3::UpdateMin(const Vector3& v) {
    update_min(x, v.x);
    update_min(y, v.y);
    update_min(z, v.z);
}

inline void Vector3::UpdateMax(const Vector3& v) {
    update_max(x, v.x);
    update_max(y, v.y);
    update_max(z, v.z);
}

inline void Vector3::SwapIfLargerThan(Vector3& v) {
    swap_if_larger_than(x, v.x);
    swap_if_larger_than(y, v.y);
    swap_if_larger_than(z, v.z);
}

/*** about length ***/
inline float Vector3::Length() const { return sqrtf(dot(*this, *this)); }
inline float Vector3::SquareLength() const { return dot(*this, *this); }
inline Vector3& Vector3::Normalize() { return *this /= Length(); }
inline Vector3& Vector3::SetLength(float length) { return *this *= (length / Length()); }
inline Vector3 Vector3::MakeUnitVector() const { return Vector3{ *this }.Normalize(); }
inline Vector3 Vector3::MakeVectorWithLength(float length) const { return Vector3{ *this }.SetLength(length); }
inline float Vector3::DistanceTo(const Vector3& v) const { return (*this - v).Length(); }
inline float Vector3::SquareDistanceTo(const Vector3& v) const { return (*this - v).SquareLength(); }

/*** about direction ***/
inline Vector3& Vector3::AxisRotate(Axis axis, float phi) {
    if (axis == AXIS_X) rotate_2d(y, z, phi);
    else if (axis == AXIS_Y) rotate_2d(z, x, phi);
    else if (axis == AXIS_Z) rotate_2d(x, y, phi);
    return *this;
}

inline Vector3 Vector3::MakeOrthoVector() const {
    if (float_zero(y)) return { 0, 1, 0 };
    return Vector3{ 0, z, -y }.Normalize();
}

inline void Vector3::MakeOrthoPlaneUnit(Vector3& base1, Vector3& base2) const {
    base1 = MakeOrthoVector();
    base2 = cross(*this, base1);
}

inline void Vector3::MakeOrthoPlane(Vector3 &base1, Vector3 &base2) const {
    return MakeUnitVector().MakeOrthoPlaneUnit(base1, base2);
}

/*** projection ***/
inline Vector2 Vector3::ProjectAlong(Axis axis) const {
    switch (axis) {
    case AXIS_X: return { y, z };
    case AXIS_Y: return { z, x };
    default: return { x, y };
    }
}

inline Vector2 Vector3::ProjectTo(const Vector3& base1, const Vector3& base2) const {
    return { dot(*this, base1), dot(*this, base2) };
}

inline float Vector3::Dot(const Vector3& rhs) const { return dot(*this, rhs); }
inline Vector3 Vector3::Cross(const Vector3& rhs) const { return cross(*this, rhs); }

#endif // VECTOR3_H
