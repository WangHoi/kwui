#include "platform/platform_config.h"
#include "platform/windows/windows_header.h"
#include "graphics/GraphicDevice.h"
#include "debug/LogManager.h"
#include "debug/Logger.h"
#include "install/SingleInstanceApplication.h"
#include "InstallService.h"
#include "InstallServiceProxy.h"
#include "memory/ResourceManager.h"
#include "text/EncodingManager.h"
#include "MainDialog.h"
#include "ConfirmDialog.h"
#include "theme.h"
#include "InstallDirector.h"
#include "../installer_resource.h"
#include <stdlib.h>
#include <shellapi.h>
#include <uv.h>

#pragma comment(lib, "d2d1.lib")
#pragma comment(lib, "dwrite.lib")
#pragma comment(lib, "archive.lib")
#pragma comment(lib, "c2.lib")
#pragma comment(lib, "Bcrypt.lib")
#pragma comment(lib, "Windowscodecs.lib")
#pragma comment(lib, "Imm32.lib")
#pragma comment(lib, "msi.lib")
#pragma comment(lib, "uv_a.lib")
#pragma comment(lib, "ws2_32.lib")
#pragma comment(lib, "userenv.lib")
#pragma comment(lib, "Iphlpapi.lib")

static void LoadResourceBitmaps();
static void CreateLogManager(InstallConfig& cfg, const std::wstring& ident);
static void CopyLogFileToTargetDir(const InstallConfig& cfg,
	const std::string& ident, const String& target_dir);
static int service_main(HINSTANCE hInstance, HINSTANCE hPrevInstance, 
	PWSTR pCmdLine, int nCmdShow);

int WINAPI wWinMain(HINSTANCE hInstance,
                    HINSTANCE hPrevInstance,
                    PWSTR pCmdLine,
                    int nCmdShow) {

	if (__argc == 2) {
		std::wstring arg1(__wargv[1]);
		if (arg1 == L"--service")
			return service_main(hInstance, hPrevInstance, pCmdLine, nCmdShow);
	}

	auto install_config = InstallConfig::MakePublishConfig();
    
    SingleInstanceApplication app("install_" + install_config.product_name);
    if (app.IsLate())
        return 0;

    CoInitializeEx(NULL, COINIT_MULTITHREADED);
    EncodingManager::CreateInstance();
	CreateLogManager(install_config, L"shell");
	ResourceManager::Instance()->CreateInstance(hInstance);
	GraphicDevice::CreateInstance()->Init();

	LoadResourceBitmaps();
	int exit_code = 0;
	MSG msg;
	PeekMessageW(&msg, NULL, 0, 0, PM_NOREMOVE);
	
	InstallServiceProxy::CreateInstance();
	auto ID = InstallDirector::CreateInstance();
	ID->SetConfig(install_config);
	ID->Start();
    
    while (GetMessageW(&msg, NULL, 0, 0)) {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }

	InstallDirector::ReleaseInstance();
    GraphicDevice::ReleaseInstance();
	// To log error message, copy before release |InstallServiceProxy| and |LogManager| 
	CopyLogFileToTargetDir(install_config, "shell", InstallServiceProxy::Instance()->GetTargetDir());
	InstallServiceProxy::Instance()->Quit();
	LogManager::ReleaseInstance();
	EncodingManager::ReleaseInstance();
	CoUninitialize();
    return exit_code;
}

void LoadResourceBitmaps() {
	auto GD = GraphicDevice::Instance();
	{
		auto x1_res = ResourceManager::Instance()->LoadResource(IDR_LOGO_X1);
		auto x1_5_res = ResourceManager::Instance()->LoadResource(IDR_LOGO_X1_5);
		auto x2_res = ResourceManager::Instance()->LoadResource(IDR_LOGO_X2);
		GD->LoadBitmapToCache(theme::LOGO_PNG, x1_res, x1_5_res, x2_res);
	}
    {
		auto x1_res = ResourceManager::Instance()->LoadResource(IDR_CLOSE_BUTTON_X1);
		auto x1_5_res = ResourceManager::Instance()->LoadResource(IDR_CLOSE_BUTTON_X1_5);
		auto x2_res = ResourceManager::Instance()->LoadResource(IDR_CLOSE_BUTTON_X2);
		GD->LoadBitmapToCache(theme::CLOSE_BUTTON_PNG, x1_res, x1_5_res, x2_res);
	}
	{
		auto x1_res = ResourceManager::Instance()->LoadResource(IDR_CLOSE_BUTTON_HOVER_X1);
		auto x1_5_res = ResourceManager::Instance()->LoadResource(IDR_CLOSE_BUTTON_HOVER_X1_5);
		auto x2_res = ResourceManager::Instance()->LoadResource(IDR_CLOSE_BUTTON_HOVER_X2);
		GD->LoadBitmapToCache(theme::CLOSE_BUTTON_HOVER_PNG, x1_res, x1_5_res, x2_res);
	}
	{
		auto x1_res = ResourceManager::Instance()->LoadResource(IDR_EXPAND_X1);
		auto x1_5_res = ResourceManager::Instance()->LoadResource(IDR_EXPAND_X1_5);
		auto x2_res = ResourceManager::Instance()->LoadResource(IDR_EXPAND_X2);
		GD->LoadBitmapToCache(theme::EXPAND_PNG, x1_res, x1_5_res, x2_res);
	}
	{
		auto x1_res = ResourceManager::Instance()->LoadResource(IDR_COLLAPSE_X1);
		auto x1_5_res = ResourceManager::Instance()->LoadResource(IDR_COLLAPSE_X1_5);
		auto x2_res = ResourceManager::Instance()->LoadResource(IDR_COLLAPSE_X2);
		GD->LoadBitmapToCache(theme::COLLAPSE_PNG, x1_res, x1_5_res, x2_res);
	}
	{
		auto x1_res = ResourceManager::Instance()->LoadResource(IDR_DIALOG_SHADOW_X1);
        auto x1_5_res = ResourceManager::Instance()->LoadResource(IDR_DIALOG_SHADOW_X1_5);
        auto x2_res = ResourceManager::Instance()->LoadResource(IDR_DIALOG_SHADOW_X2);
		GD->LoadBitmapToCache(theme::DIALOG_SHADOW_PNG, x1_res, x1_5_res, x2_res);
	}
}

void CreateLogManager(InstallConfig& cfg, const std::wstring& ident) {
	auto EM = EncodingManager::Instance();
	auto LM = LogManager::CreateInstance();
	LM->AddLogger(make_shared<VSDebugLogger>());
	WCHAR temp_dir[MAX_PATH + 1] = {};
	DWORD temp_dir_len = GetTempPathW(MAX_PATH, temp_dir);
	if (temp_dir_len > 0 && temp_dir_len <= MAX_PATH) {
		wstring utf16_logger_path = temp_dir;
		if (*utf16_logger_path.rbegin() != L'\\')
			utf16_logger_path += L'\\';
		utf16_logger_path += EM->UTF8ToWide(cfg.product_name);
		utf16_logger_path += L"_";
		utf16_logger_path += ident;
		utf16_logger_path += L"_install.log";
		cfg.temp_log_filename = EM->WideToUTF8(utf16_logger_path);
		LM->AddLogger(make_shared<FileLogger>(cfg.temp_log_filename));
	}
}

void CopyLogFileToTargetDir(const InstallConfig& cfg, const std::string& ident, const String& target_dir) {
	if (target_dir.IsEmpty()) {
		c2_log("install not fully finished, skip copy log file to target dir.\n");
		return;
	}
	auto EM = EncodingManager::Instance();
	wstring src_filename = EM->UTF8ToWide(cfg.temp_log_filename);
	String u8_dst_filename = target_dir;
	u8_dst_filename.Append('\\');
	u8_dst_filename.Append(cfg.product_name);
	u8_dst_filename.Append('_');
	u8_dst_filename.Append(ident);
	u8_dst_filename.Append("_install.log");
	wstring dst_filename = EM->UTF8ToWide(u8_dst_filename);
	if (FAILED(CopyFileW(src_filename.c_str(), dst_filename.c_str(), TRUE))) {
		c2_log("CopyFile [%s] to [%s] failed, GetLastError()=%08X\n",
			   EM->WideToUTF8(src_filename),
			   u8_dst_filename,
			   GetLastError());
	}
}

int service_main(HINSTANCE hInstance, HINSTANCE hPrevInstance, PWSTR pCmdLine, int nCmdShow) {
	auto install_config = InstallConfig::MakePublishConfig();
	auto loop = uv_loop_new();
	unique_ptr<InstallService> install_service;

	CoInitializeEx(NULL, COINIT_MULTITHREADED);
	EncodingManager::CreateInstance();
	CreateLogManager(install_config, L"service");
	ResourceManager::Instance()->CreateInstance(hInstance);
	install_service = InstallService::Create(loop);

	uv_run(loop, UV_RUN_DEFAULT);

	// To log error message, copy before release |InstallServiceProxy| and |LogManager| 
	CopyLogFileToTargetDir(install_config, "service", install_service->GetTargetDir());
	//install_service->Stop();
	LogManager::ReleaseInstance();
	EncodingManager::ReleaseInstance();
	CoUninitialize();
	return 0;
}
