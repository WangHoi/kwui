#pragma once
#include <functional>

class JobQueueInterface
{
public:
	typedef std::function <void()> Functor;
	virtual void Submit(Functor&& f) = 0;
};