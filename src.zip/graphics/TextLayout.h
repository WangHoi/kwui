#ifndef TEXT_LAYOUT_H
#define TEXT_LAYOUT_H

#include "data/data_type.h"
#include "platform/platform_config.h"
#include "platform/windows/windows_header.h"
#include "string/String.h"
#include "math/Vector4.h"

enum class FontStyle {
	REGULAR,
	ITALIC,
};
enum TextAlignment {
	TEXT_ALIGN_LEFT = 1,
	TEXT_ALIGN_HCENTER = 2,
	TEXT_ALIGN_RIGHT = 4,
	TEXT_ALIGN_TOP = 8,
	TEXT_ALIGN_VCENTER = 16,
	TEXT_ALIGN_BOTTOM = 32,
	
	TEXT_ALIGN_TOP_LEFT = TEXT_ALIGN_LEFT | TEXT_ALIGN_TOP,
	TEXT_ALIGN_CENTER = TEXT_ALIGN_HCENTER | TEXT_ALIGN_VCENTER,
};

class FontWeight {
public:
	FontWeight();
	FontWeight(uint16 raw) : _raw(raw) {}
	inline uint16 GetRaw() const {
		return _raw;
	}
	inline bool operator==(const FontWeight& rhs) {
		return rhs._raw == this->_raw;
	}
	inline bool operator<(const FontWeight& rhs) {
		return rhs._raw < this->_raw;
	}
	static FontWeight THIN;
	static FontWeight EXTRA_LIGHT;
	static FontWeight LIGHT;
	static FontWeight SEMI_LIGHT;
	static FontWeight NORMAL;
	static FontWeight MEDIUM;
	static FontWeight SEMI_BOLD;
	static FontWeight BOLD;
	static FontWeight HEAVY;
private:
	uint16 _raw;
};

SMART_REF(TextLayout)
class TextLayoutBuilder {
public:
	TextLayoutBuilder(const String& text);
	TextLayoutBuilder(const wstring& text);
	inline TextLayoutBuilder& MaxWidth(float w) {
		_max_width = w;
		return *this;
	}
	inline TextLayoutBuilder& SetFontFamily(const String& name) {
		_font_family = name;
		return *this;
	}
	inline TextLayoutBuilder& FontSize(float s) {
		_font_size = s;
		return *this;
	}
	inline TextLayoutBuilder& FontStyle(::FontStyle s) {
		_font_style = s;
		return *this;
	}
	inline TextLayoutBuilder& FontWeight(::FontWeight w) {
		_font_weight = w;
		return *this;
	}
	inline TextLayoutBuilder& Align(TextAlignment align) {
		_align = align;
		return *this;
	}
	TextLayoutHandle Build();
private:
	void Init(const wstring& text);
	wstring _text;
	float _max_width;
	String _font_family;
	float _font_size;
	::FontStyle _font_style;
	::FontWeight _font_weight;
	TextAlignment _align;
};

class TextLayout {
public:
	TextLayout(const wstring& text, const String& font_family,
			   float font_size, ComPtr<IDWriteTextLayout> layout);
	inline float GetLineHeight() const { return _line_height; }
	inline float GetBaseline() const { return _baseline; }
	inline IDWriteTextLayout *GetRaw() const { return _layout.Get(); }
	inline const Vector4& GetRect() const { return _rect; }
	Vector4 GetCaretRect(int idx) const;
	Vector4 GetRangeRect(int start_idx, int end_idx) const;
	int HitTest(const Vector2& pos, Vector4* out_caret_rect = nullptr) const;

private:
	void UpdateTextMetrics();
	Vector4 MakeCaretRect(const DWRITE_HIT_TEST_METRICS* htm) const;
	wstring _text;
	String _font_family;
	float _font_size;
	ComPtr<IDWriteTextLayout> _layout;
	float _line_height;
	float _baseline;
	Vector4 _rect;
};
extern const float DEFAULT_FONT_SIZE;

#endif // TEXT_LAYOUT_H