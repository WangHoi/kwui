#include "Color.h"
#include <string.h>

const Vector3 Color::COMPONENT_WEIGHTS(0.299f, 0.587f, 0.114f);

Color Color::FromString(const String& str) {
    if (str.IsEmpty()) return Color();
    if (str[0] == '#') {
        uint32 c = (uint32)strtoul(&str[1], nullptr, 16);
        if (str.GetLength() == 4) {
            int r = (c & 0xf00) >> 8;
            int g = (c & 0xf0) >> 4;
            int b = (c & 0xf);
            return Color((r << 4) | r, (g << 4) | g, (b << 4) | b);
        } if (str.GetLength() == 7) {
            return Color((int)((c & 0xff0000) >> 16), (int)((c & 0xff00) >> 8), (int)(c & 0xff));
        } else if (str.GetLength() == 9) {
            return Color((int)((c & 0xff000000) >> 24), (int)((c & 0xff0000) >> 16), (int)((c & 0xff00) >> 8), (int)(c & 0xff));
        }
    }
    return Color();
}

Matrix3 Color::MakeFilter() const {
    return Matrix3{ Matrix3::CROSS{}, COMPONENT_WEIGHTS, Vector3{_c} };
}

Matrix3 Color::MakeFilterWithAlpha() const {
    float a = _c[3];
    Matrix3 m{ Matrix3::CROSS{}, COMPONENT_WEIGHTS, Vector3{_c} *a };
    auto b = m.GetBuffer();
    a = 1 - a;
    b[0] += a; b[4] += a; b[8] += a;
    return m;
}
uint32 Color::GetGdiRgb() const {
    return (uint32(_c[0] * 255.0f) & 0xff)
        | ((uint32(_c[1] * 255.0f) & 0xff) << 8)
        | ((uint32(_c[2] * 255.0f) & 0xff) << 16);
}