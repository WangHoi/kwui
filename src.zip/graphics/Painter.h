#ifndef PAINTER_H
#define PAINTER_H

#include "math/Vector2.h"
#include "Color.h"
#include "data/data_helpers.h"
#include "platform/platform_config.h"
#include "platform/windows/windows_header.h"
#include "TextLayout.h"
#include "GraphicDevice.h"

class Painter {
public:
	Painter(ID2D1RenderTarget* rt, const Vector2& mouse_pos);
    inline Vector2 GetMousePosition() const { return _mouse_position; }
	inline float GetDpiScale() const { return _dpi_scale; }
    void Clear(const Color& c);
    void SetColor(const Color& c);
    void SetStrokeColor(const Color& c);
    void SetStrokeWidth(float w);
    void DrawRect(float x, float y, float w, float h);
    void DrawRect(const Vector2& origin, const Vector2& size) { DrawRect(origin.x, origin.y, size.x, size.y); }
    void DrawRoundedRect(float x, float y, float w, float h, float r);
    void DrawRoundedRect(const Vector2& origin, const Vector2& size, float r) { DrawRoundedRect(origin.x, origin.y, size.x, size.y, r); }
    void DrawTextLayout(const Vector2& origin, const TextLayout& layout) { DrawTextLayout(origin.x, origin.y, layout); }
    void DrawTextLayout(float x, float y, const TextLayout& layout);
    void Translate(float x, float y) { Translate({ x, y }); }
    void Translate(const Vector2& offset) { _current.offset += offset; }
    const Vector2& GetAccumTranslate() const { return _current.offset; }
    void PushClipRect(const Vector2& origin, const Vector2& size);
    void PopClipRect();
    void Save();
    void Restore();
	ComPtr<ID2D1Bitmap> CreateBitmap(const BitmapSubItem& item);
	inline void DrawBitmap(ID2D1Bitmap* bitmap, const Vector2& origin, const Vector2& size) {
		DrawBitmap(bitmap, origin.x, origin.y, size.x, size.y);
	}
	void DrawBitmap(ID2D1Bitmap* bitmap, float x, float y, float w, float h);
	void DrawScale9Bitmap(ID2D1Bitmap* bitmap, float x, float y, float w, float h,
						  float src_margin, float dst_margin);
    ComPtr<ID2D1LinearGradientBrush> CreateLinearGradientBrush_Logo();
    ComPtr<ID2D1RadialGradientBrush> CreateRadialGradientBrush_Highlight();
    void SetBrush(ComPtr<ID2D1Brush> brush);

private:
    ComPtr<ID2D1Brush> CreateBrush(const Color& c);
    inline float Painter::PixelSnap(float x) {
        return roundf(x * _dpi_scale) / _dpi_scale;
    }
    inline D2D1_POINT_2F Painter::PixelSnap(const D2D1_POINT_2F& p) {
        return D2D1::Point2F(PixelSnap(p.x), PixelSnap(p.y));
    }
    D2D1_RECT_F PixelSnap(const D2D1_RECT_F& rect);
    D2D1_RECT_F PixelSnapConservative(const D2D1_RECT_F& rect);

    struct State {
        Vector2 offset;
        Color color;
        Color stroke_color;
        float stroke_width;
        bool pixel_snap;
        ComPtr<ID2D1Brush> gradient_brush;

        State() {
            Reset();
        }
        inline void Reset() {
            offset = ZERO_VECTOR2;
            color = NO_COLOR;
            stroke_color = NO_COLOR;
            stroke_width = 0.0f;
            pixel_snap = true;
            gradient_brush = nullptr;
        }
        inline bool HasFill() const {
            return color.GetAlpha() != 0 || gradient_brush != nullptr;
        }
        inline bool HasStroke() const {
            return stroke_width != 0 && stroke_color.GetAlpha() != 0;
        }
    };
    ID2D1RenderTarget *_rt;
    Vector2 _mouse_position;
	float _dpi_scale;
    State _current;
    vector<State> _state_stack;
};

#endif // PAINTER_H
