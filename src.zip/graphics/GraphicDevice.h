#ifndef GRAPHIC_DEVICE_H
#define GRAPHIC_DEVICE_H

#include "pattern/singleton.h"
#include "platform/platform_config.h"
#include "platform/windows/windows_header.h"
#include "math/Vector2.h"
#include "memory/ResourceManager.h"
#include "string/String.h"
#include "TextLayout.h"

struct BitmapSubItem {
	ComPtr<IWICBitmapFrameDecode> frame;
	ComPtr<IWICFormatConverter> converter;
	Vector2 dpi_scale;
	operator bool() const {
		return frame != nullptr;
	}
};
struct BitmapItem {
	BitmapSubItem x1;
	BitmapSubItem x1_5;
	BitmapSubItem x2;
	operator bool() const {
		return (bool)x1;
	}
};

struct WicBitmapRenderTarget {
	ComPtr<IWICBitmap> bitmap;
	ComPtr<ID2D1BitmapRenderTarget> target;
	ComPtr<ID2D1GdiInteropRenderTarget> interop_target;
};
class GraphicDevice {
public:
	bool Init();
	ComPtr<ID2D1HwndRenderTarget> CreateHwndRenderTarget(
		HWND hwnd, const Vector2& size, float dpi_scale);
	WicBitmapRenderTarget CreateWicBitmapRenderTarget(
		float width, float height, float dpi_scale);
	ComPtr<IDWriteTextLayout> CreateTextLayout(
		const wstring& text,
        const String &font_family,
        float font_size,
        FontWeight font_weight = FontWeight(),
        FontStyle font_style = FontStyle());
	bool GetFontMetrics(const String& font_family, DWRITE_FONT_METRICS& out_metrics);
	void LoadBitmapToCache(const String& name, const Resource& res_x1);
	void LoadBitmapToCache(const String& name, const Resource& res_x1,
						   const Resource& res_x1_5, const Resource& res_x2);
	BitmapSubItem GetBitmap(const String& name, float dpi_scale = 1.0f) const;
	float GetInitialDesktopDpiScale() const;

private:
	BitmapSubItem LoadBitmapFromResource(const Resource& res, const Vector2& dpi_scale);

	ComPtr<ID2D1Factory> _factory;
	ComPtr<IDWriteFactory> _dwrite;
	ComPtr<IDWriteFontCollection> _font_collection;
	ComPtr<IWICImagingFactory> _wic_factory;
	unordered_map<String, BitmapItem> _bitmap_cache;

	SUPPORT_SINGLETON(GraphicDevice)
};

#endif // GRAPHIC_DEVICE_H
