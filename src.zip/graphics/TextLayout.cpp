#include "TextLayout.h"
#include "math/float_math.h"
#include "GraphicDevice.h"
#include "text/EncodingManager.h"

#define DEFINE_FONT_WEIGHT(x) \
    FontWeight FontWeight::x = { DWRITE_FONT_WEIGHT_##x };
DEFINE_FONT_WEIGHT(THIN);
DEFINE_FONT_WEIGHT(EXTRA_LIGHT);
DEFINE_FONT_WEIGHT(LIGHT);
DEFINE_FONT_WEIGHT(SEMI_LIGHT);
DEFINE_FONT_WEIGHT(NORMAL);
DEFINE_FONT_WEIGHT(MEDIUM);
DEFINE_FONT_WEIGHT(SEMI_BOLD);
DEFINE_FONT_WEIGHT(BOLD);
DEFINE_FONT_WEIGHT(HEAVY);
#undef DEFINE_FONT_WEIGHT

const float DEFAULT_FONT_SIZE = 14;
static const char* DEFAULT_FONT_FAMILY = "Microsoft YaHei";

FontWeight::FontWeight() : _raw(DWRITE_FONT_WEIGHT_NORMAL) {}

TextLayoutBuilder::TextLayoutBuilder(const String& text) {
    wstring utf16_text = EncodingManager::Instance()->UTF8ToWide(text);
    Init(utf16_text);
}
TextLayoutBuilder::TextLayoutBuilder(const wstring& text) {
    Init(text);
}
void TextLayoutBuilder::Init(const wstring& text) {
    _text = text;
    _max_width = FLOAT_MAX;
    _font_family = DEFAULT_FONT_FAMILY;
    _font_size = DEFAULT_FONT_SIZE;
    _font_style = FontStyle::REGULAR;
	_align = TEXT_ALIGN_TOP_LEFT;
}
TextLayoutHandle TextLayoutBuilder::Build() {
    ComPtr<IDWriteTextLayout> layout = GraphicDevice::Instance()
        ->CreateTextLayout(_text, _font_family, _font_size, _font_weight, _font_style);
    layout->SetMaxWidth(_max_width);
	DWRITE_TEXT_ALIGNMENT align = DWRITE_TEXT_ALIGNMENT_LEADING;
	if (_align & TEXT_ALIGN_LEFT)
		align = DWRITE_TEXT_ALIGNMENT_LEADING;
	else if (_align & TEXT_ALIGN_CENTER)
		align = DWRITE_TEXT_ALIGNMENT_CENTER;
	else if (_align & TEXT_ALIGN_RIGHT)
		align = DWRITE_TEXT_ALIGNMENT_TRAILING;
	layout->SetTextAlignment(align);
    return make_unique<TextLayout>(_text, _font_family, _font_size, layout);
}
TextLayout::TextLayout(const wstring& text, const String& font_family,
                       float font_size, ComPtr<IDWriteTextLayout> layout)
    : _text(text)
    , _font_family(font_family)
    , _font_size(font_size)
    , _layout(layout) {
    UpdateTextMetrics();
}
void TextLayout::UpdateTextMetrics() {
    DWRITE_FONT_METRICS fm;
    if (GraphicDevice::Instance()->GetFontMetrics(_font_family, fm)) {
        _line_height = (fm.ascent + fm.descent + fm.lineGap) * _font_size / fm.designUnitsPerEm;
        _baseline = fm.ascent * _font_size / fm.designUnitsPerEm;
    } else {
        _line_height = _font_size;
        _baseline = _line_height * 0.8f;
    }
    DWRITE_TEXT_METRICS tm;
    if (SUCCEEDED(_layout->GetMetrics(&tm))) {
        //DWRITE_LINE_METRICS lm;
        //UINT lines;
        //_layout->GetLineMetrics(&lm, 1, &lines);
        _rect.Set(tm.left, tm.top, tm.widthIncludingTrailingWhitespace, tm.height);
    } else {
        _rect = ZERO_VECTOR4;
    }
}
Vector4 TextLayout::GetCaretRect(int idx) const {
    UINT index;
    BOOL trailing_hit;
    if (idx == _text.length()) {
        index = (idx > 0) ? (idx - 1) : 0;
        trailing_hit = TRUE;
    } else {
        index = idx;
        trailing_hit = FALSE;
    }
    DWRITE_HIT_TEST_METRICS htm;
    FLOAT x, y;
    HRESULT hr;
    hr = _layout->HitTestTextPosition(idx, trailing_hit, &x, &y, &htm);
    if (SUCCEEDED(hr)) {
        return MakeCaretRect(&htm);
    } else {
        return MakeCaretRect(nullptr);
    }
}
Vector4 TextLayout::GetRangeRect(int start_idx, int end_idx) const {
	if (start_idx == end_idx)
		return ZERO_VECTOR4;
	if (start_idx > end_idx)
		swap(start_idx, end_idx);
	Vector4 r1 = GetCaretRect(start_idx);
	Vector4 r2 = GetCaretRect(end_idx);
	float x = r1.x + 0.5f * r1.z;
	float w = r2.x - r1.x;
	return Vector4(x, r1.y, w, r1.w);
}
int TextLayout::HitTest(const Vector2& pos, Vector4* out_caret_rect) const {
    BOOL trailing_hit = FALSE;
    BOOL inside = FALSE;
    DWRITE_HIT_TEST_METRICS htm;
    HRESULT hr;
    hr = _layout->HitTestPoint(pos.x, pos.y, &trailing_hit, &inside, &htm);
    if (SUCCEEDED(hr)) {
        if (out_caret_rect) *out_caret_rect = MakeCaretRect(&htm);
        return trailing_hit ? (htm.textPosition + 1) : htm.textPosition;
    } else {
        return -1;
    }
}
Vector4 TextLayout::MakeCaretRect(const DWRITE_HIT_TEST_METRICS* htm) const {
    if (htm) 
        return Vector4(htm->left - 0.5f, 0, 1, _line_height);
    else
        return Vector4(-0.5f, 0, 1, _line_height);
}