#include "UninstallProgressSmoother.h"
#include "platform/platform_helpers.h"
#include "MainDialog.h"

static constexpr double TIME_ESTIMATE = 1.0;

UninstallProgressSmoother::UninstallProgressSmoother()
    : _done(false)
    , _start_ts(0.0)
    , _display_progress(0.0)
    , _total_paused_time(0.0)
    , _pause_counter(0) {
    _full_time = TIME_ESTIMATE;
}

void UninstallProgressSmoother::Start(EventContext& ctx) {
    _start_ts = get_timestamp();
    ctx.RequestAnimationFrame(this);
}

void UninstallProgressSmoother::Done() {
    _done = true;
}

void UninstallProgressSmoother::OnAnimationFrame(double timestamp, EventContext& ctx) {
    if (!_animation_start_ts.has_value())
        _animation_start_ts.emplace(timestamp);

    if (_pause_start_ts.has_value()) {
        ctx.RequestAnimationFrame(this);
        return;
    }

    double time = timestamp - _animation_start_ts.value() - _total_paused_time;
    if (!_done) {
        _display_progress = clamp(time, 0.0, _full_time) / _full_time;
        _display_progress = min(_display_progress, 0.99);
    } else {
        const double T = 0.02;
        if (!_catchup_state.has_value()) {
            double step = _display_progress / time * T;
            _catchup_state.emplace(CatchupState{ _display_progress, step });
        }
        _display_progress = min(1.0, _display_progress + _catchup_state->step);
        const double A = 0.0015;
        _catchup_state->step += A;
        //c2_log("real=%.0lf%%, fake=%.0lf%% display=%.0lf%%\n",
        //       real_progress * 100.0,
        //       fake_progress * 100.0,
        //       _display_progress * 100.0);
    }
    if (_display_progress < 1.0)
        ctx.RequestAnimationFrame(this);
    if (_progress_callback)
        _progress_callback(_display_progress);
}
void UninstallProgressSmoother::Pause() {
    ++_pause_counter;
    if (_pause_counter == 1)
        _pause_start_ts.emplace(get_timestamp());
}
void UninstallProgressSmoother::Resume() {
    if (_pause_counter <= 0)
        return;
    --_pause_counter;
    if (_pause_counter == 0) {
        _total_paused_time += get_timestamp() - _pause_start_ts.value_or(0);
        _pause_start_ts = nullopt;
    }
}
