//
//  IntegerSet.h
//  C2Engine
//
//  Created by mike luo on 12-12-11.
//
//

#ifndef INTEGER_SET_H
#define INTEGER_SET_H

#include "data/data_type.h"
#include "math/integer_math.h"
#include "math/bit_arithmetics.h"

class IntegerSet {
public:
  IntegerSet(int range) : _range(range), _v(group_count(range, BLOCK_SIZE)) {}
  ~IntegerSet() {}

  void Insert(int value) { set_bit(_v[value / BLOCK_SIZE], value % BLOCK_SIZE); } // no bound check
  void Remove(int value) { clear_bit(_v[value / BLOCK_SIZE], value % BLOCK_SIZE); } // no bound check
  bool Contain(int value) const { return test_bit(_v[value / BLOCK_SIZE], value % BLOCK_SIZE); }; // no bound check

  int FirstAbsence();

private:
  typedef std::vector<uint32> Buffer;
  static const int BLOCK_SIZE = 32;

  bool OutOfRange(int value) { return value < 0 || value >= _range; }

  int _range;
  Buffer _v;
};

#endif // INTEGER_SET_H
