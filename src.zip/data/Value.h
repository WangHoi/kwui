//
//  Value.h
//  C2Engine
//
//  Created by mike luo on 2013-11-1.
//
//

#ifndef VALUE_H
#define VALUE_H

template<typename T>
class Value {
public:
  Value() : _nil(true) {}
  explicit Value(const T& value) : _value(value), _nil(false) {}
  Value(const Value<T>& v2) : _nil(v2._nil) { if (!_nil) _value = v2.value; }
  
  Value<T>& operator=(const T& value) {
    _value = value;
    _nil = false;
    return *this;
  }

  Value<T>& operator=(const Value<T>& v2) {
    _nil = v2._nil;
    if (!_nil) _value = v2._value;
    return *this;
  }
  
  operator bool() const { return !_nil; }
  const T& Get() const { return _value; }
  
  void SetNil() { _nil = true; }

private:
  T _value;
  bool _nil;
};

#endif // VALUE_H