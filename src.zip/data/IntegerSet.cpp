//
//  IntegerSet.cpp
//  C2Engine
//
//  Created by mike luo on 12-12-11.
//
//

#include "stdafx.h"
#include "IntegerSet.h"

int IntegerSet::FirstAbsence() {
  for (uint32 i = 0; i < _v.size(); i++) {
    if (_v[i] == ~(0u)) continue;
    int value = i * BLOCK_SIZE + first_bit_position(~_v[i]);
    if (value >= _range) return -1;
    return value;
  }
  return -1;
}

/***** test *****/
#include "debug/debug_print.h"

class IntegerSetUnitTest {
public:
  IntegerSetUnitTest() {
    IntegerSet set(100);
    debug_print("first absence: %d\n", set.FirstAbsence());
    for (int i = 0; i < 100; i++) {
      set.Insert(i);
      debug_print("first absence after inserting %d: %d\n", i, set.FirstAbsence());
    }

    for (int i = 99; i >= 0; i--) {
      set.Remove(i);
      debug_print("first absence after removing %d: %d\n", i, set.FirstAbsence());
    }
  }
};

// static IntegerSetUnitTest test;