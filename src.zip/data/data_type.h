#ifndef DATA_TYPE_H
#define DATA_TYPE_H

#include <stddef.h>
#include <stdint.h>

typedef int8_t int8;
typedef uint8_t uint8;
typedef int16_t int16;
typedef uint16_t uint16;
typedef int32_t int32;
typedef uint32_t uint32;
typedef int64_t int64;
typedef uint64_t uint64;
typedef int32_t bool32;

typedef uint8 byte;

typedef uint8_t char8;
typedef uint16_t char16;
typedef uint32_t char32;

typedef uint8 pixel8;

typedef uint8* pointer;
typedef const uint8* const_pointer;

typedef unsigned char uchar;

typedef float real32;
typedef double real64;

enum DataType {
    INVALID_DATA_TYPE = -1,
    INT8_TYPE,
    UINT8_TYPE,
    INT16_TYPE,
    UINT16_TYPE,
    INT32_TYPE,
    UINT32_TYPE,
    INT64_TYPE,
    UINT64_TYPE,
    FLOAT_TYPE,
    DOUBLE_TYPE,
    NUM_DATA_TYPES
};

extern bool IS_FIXED_POINT_TYPE[NUM_DATA_TYPES];
extern int DATA_TYPE_SIZE[NUM_DATA_TYPES];

inline int get_integer_data(pointer buffer, DataType data_type) {
    int result = 0;
#define CASE(TYPE_NAME, type) case TYPE_NAME: result = static_cast<int>(*((type*) buffer)); break;
    switch (data_type) {
    CASE(INT8_TYPE, int8)
    CASE(UINT8_TYPE, uint8)
    CASE(INT16_TYPE, int16)
    CASE(UINT16_TYPE, uint16)
    CASE(INT32_TYPE, int32)
    CASE(UINT32_TYPE, uint32)
    CASE(INT64_TYPE, int64)
    CASE(UINT64_TYPE, uint64)
    default: break;
    }
    return result;
#undef CASE
}

#endif // DATA_TYPE_H
