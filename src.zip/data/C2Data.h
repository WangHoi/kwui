//
//  C2Data.h
//  C2Engine
//
//  Created by mike luo on 12-12-6.
//
//

#ifndef C2_DATA_H
#define C2_DATA_H

#include "data_type.h"
#include "data_helpers.h"

#include "Value.h"

#include "IntegerSet.h"

#endif // C2_DATA_H
