#include "data/data_type.h"

bool IS_FIXED_POINT_TYPE[NUM_DATA_TYPES] = {
    true, true, true, true, true, true, true, true, // int8, uint8, ...
    false, false // float and double
};

int DATA_TYPE_SIZE[NUM_DATA_TYPES] = {
    sizeof(int8), sizeof(uint8),
    sizeof(int16), sizeof(uint16),
    sizeof(int32), sizeof(uint32),
    sizeof(int64), sizeof(uint64),
    sizeof(float), sizeof(double)
};