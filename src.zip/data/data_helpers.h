#ifndef DATA_HELPERS_H
#define DATA_HELPERS_H

#include <vector>
#include <string>
#include <unordered_set>
#include <unordered_map>
#include <list>
#include <map>
#include <deque>
#include <queue>
#include <functional>
#include <algorithm>
#include <regex>
#include <memory>
#include <optional>
#include <variant>

using std::vector;
using std::string;
using std::wstring;
using std::unordered_set;
using std::unordered_map;
using std::pair;
using std::make_pair;
using std::list;
using std::move;
using std::deque;
using std::queue;
using std::function;
using std::mem_fn;
using std::tuple;
using std::get;
using std::for_each;
using std::find;
using std::find_if;
using std::sort;
using std::lower_bound;
using std::upper_bound;
using std::unique;
using std::swap;
using std::min;
using std::max;
using std::reverse;
using std::optional;
using std::make_optional;
using std::nullopt;
using std::variant;
template <typename T>
using enabled_shared_from_this = std::enable_shared_from_this<T>;

#include "platform/platform_config.h"
#if ON_WINDOWS
#define sprintf sprintf_s
#define strncpy strncpy_s
#else
#define strncpy strncpy_s
#endif

template <typename ContainerType>
inline const typename ContainerType::value_type& get_with_negative_index(const ContainerType& container, int index) {
    if (index < 0) return container[container.size() + index];
    else return container[index];
}

template <typename T>
inline void swap_if_greater_than(T& a, T& b) {
    if (a > b) swap(a, b);
}

template <typename T>
inline bool to_bool(T x) {
    return x != 0;
}

#define STRUCT_OFFSET(StructName, field_name) ((int) (&(((StructName*) 0)->field_name)))
#define ARRAY_SIZE(Array) (sizeof(Array) / sizeof((Array)[0]))
#define MAKE_FOURCC(a, b, c, d) (((uint32)(a) | ((uint32)(b) << 8) | ((uint32)(c) << 16) | ((uint32)(d) << 24)))

#endif // DATA_HELPERS_H