#include "LogoNode.h"
#include "graphics/Painter.h"
#include "graphics/GraphicDevice.h"
#include "theme.h"
#include "platform/platform_helpers.h"

static constexpr double SCROLL_Y_START = 10.0;
static constexpr double SCROLL_Y_END = 70.0;
static constexpr double SCROLL_SPEED = 80.0;
static constexpr double SCROLL_ACCEL = 40.0;
static constexpr double ACCEL_TIME = 2.0;

void LogoNode::PaintNode(Painter& p) {
    if (!_brush)
        _brush = p.CreateLinearGradientBrush_Logo();
    if (_brush) {
        p.SetBrush(_brush);
        p.DrawRoundedRect(ZERO_VECTOR2, _size, 21.0f);
    }
    
    if (!_bitmap) {
        BitmapSubItem item = GraphicDevice::Instance()
            ->GetBitmap(_image_name, p.GetDpiScale());
        if (item)
            _bitmap = p.CreateBitmap(item);
    }
    if (_bitmap) {
		p.DrawBitmap(_bitmap.Get(), ZERO_VECTOR2, _size);
    }
}
void LogoNode::DiscardDeviceResources() {
	_bitmap = nullptr;
    _brush = nullptr;
}
void LogoNode::OnAnimationFrame(double timestamp, EventContext& ctx) {
    if (!_start_ts.has_value())
        _start_ts.emplace(timestamp);
    _time = timestamp - _start_ts.value();

    if (!_stop_ts.has_value()) {
        if (_time < ACCEL_TIME) {
            // ����
            double offset = 0.5 * SCROLL_ACCEL * _time * _time;
            _brush->SetStartPoint({ 40, (float)(SCROLL_Y_START - offset) });
            _brush->SetEndPoint({ 40, (float)(SCROLL_Y_END - offset) });
        } else {
            // ����
            double offset = 0.5 * SCROLL_ACCEL * ACCEL_TIME * ACCEL_TIME
                + (_time - ACCEL_TIME) * SCROLL_SPEED;
            _brush->SetStartPoint({ 40, (float)(SCROLL_Y_START - offset) });
            _brush->SetEndPoint({ 40, (float)(SCROLL_Y_END - offset) });
        }
        ctx.RequestAnimationFrame(this);
    } else {
        // ����
        const double REPEAT_PERIOD = 2.0 * (SCROLL_Y_END - SCROLL_Y_START);
        double y_remain = REPEAT_PERIOD - fmod(-(_stop_brush_yoffset.value() - SCROLL_Y_START), REPEAT_PERIOD);
        double time = max(0.0, timestamp - _stop_ts.value());
        if (time >= ACCEL_TIME) {
            _brush->SetStartPoint({ 40, (float)SCROLL_Y_START });
            _brush->SetEndPoint({ 40, (float)SCROLL_Y_END });
        } else {
            double y = SCROLL_SPEED * time - 0.5 * SCROLL_ACCEL * time * time;
            if (y <= y_remain) {
                y = min(y_remain, y);
                D2D1_POINT_2F p = _brush->GetStartPoint();
                _brush->SetStartPoint(D2D1::Point2F(p.x, (float)(_stop_brush_yoffset.value() - y)));
                _brush->SetEndPoint(D2D1::Point2F(p.x, (float)((SCROLL_Y_END - SCROLL_Y_START) + _stop_brush_yoffset.value() - y)));
                ctx.RequestAnimationFrame(this);
            } else {
                _brush->SetStartPoint({ 40, (float)SCROLL_Y_START });
                _brush->SetEndPoint({ 40, (float)SCROLL_Y_END });
            }
        }
    }

    ctx.RequestPaint();
}
LogoNode::LogoNode()
    : _time(0.0) {}
void LogoNode::SetImageName(const String& name) {
	_image_name = name;
	_bitmap = nullptr;
}

void LogoNode::StartAnimate(EventContext& ctx) {
    _stop_ts = nullopt;
    ctx.RequestAnimationFrame(this);
}

void LogoNode::StopAnimate(EventContext& ctx) {
    _stop_ts.emplace(get_timestamp());
    if (_brush)
        _stop_brush_yoffset.emplace(_brush->GetStartPoint().y);
    else
        _stop_brush_yoffset.emplace(SCROLL_Y_START);
}
