#include "AdminAuthorization.h"
#include "platform/platform_config.h"
#include "platform/windows/windows_header.h"
#include "debug/log.h"
#include "text/EncodingManager.h"
#include <WinReg.hpp>
#include <shellapi.h>

bool AdminAuthorization::HasAdminRights()
{
    SID_IDENTIFIER_AUTHORITY authority = { SECURITY_NT_AUTHORITY };
    PSID adminGroup;
    // Initialize SID.
    if (!AllocateAndInitializeSid(&authority,
                                  2,
                                  SECURITY_BUILTIN_DOMAIN_RID,
                                  DOMAIN_ALIAS_RID_ADMINS,
                                  0, 0, 0, 0, 0, 0,
                                  &adminGroup))
        return false;

    BOOL isInAdminGroup = FALSE;
    if (!CheckTokenMembership(0, adminGroup, &isInAdminGroup))
        isInAdminGroup = FALSE;

    FreeSid(adminGroup);
    return isInAdminGroup;
}

bool AdminAuthorization::ExecuteElevated(const std::string& arguments)
{
    // AdminAuthorization::execute uses UAC to ask for admin privileges. If the user is no
    // administrator yet and the computer's policies are set to not use UAC (which is the case
    // in some corporate networks), the call to execute() will simply succeed and not at all
    // launch the child process. To avoid this, we detect this situation here and return early.
    if (!HasAdminRights()) {
		const WCHAR* path = L"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System";
		try {
			winreg::RegKey key(HKEY_LOCAL_MACHINE, path, KEY_READ | KEY_WRITE);
			DWORD enable = key.GetDwordValue(L"EnableLUA");
			if (enable == 0)
				return false;
		} catch (...) {
		}
    }

	WCHAR filename[8192] = {};
	GetModuleFileNameW(NULL, filename, sizeof(filename) - 1);
	std::wstring args = EncodingManager::Instance()->UTF8ToWide(arguments);

    SHELLEXECUTEINFOW shellExecuteInfo = { 0 };
    shellExecuteInfo.nShow = SW_HIDE;
    shellExecuteInfo.lpVerb = L"runas";
    shellExecuteInfo.lpFile = filename;
    shellExecuteInfo.cbSize = sizeof(SHELLEXECUTEINFOW);
    shellExecuteInfo.lpParameters = args.c_str();
    shellExecuteInfo.fMask = SEE_MASK_NOASYNC | SEE_MASK_NOZONECHECKS;

    c2_log("Starting elevated process [%s] with arguments [%s].\n",
		EncodingManager::Instance()->WideToUTF8(filename).GetCString(),
		arguments.c_str());

    if (ShellExecuteExW(&shellExecuteInfo)) {
        c2_log("Finished starting elevated process.\n");
        return true;
    } else {
        c2_log("Error while starting elevated process [%s], last error=0x%08X.\n",
			EncodingManager::Instance()->WideToUTF8(filename).GetCString(),
            GetLastError());
    }
    return false;
}

bool AdminAuthorization::ExecuteDirectly(const std::string & arguments)
{
	return ExecuteElevated(arguments);
}
