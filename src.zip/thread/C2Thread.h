//
//  C2Thread.h
//  C2Engine
//
//  Created by mike luo on 13-5-26.
//
//
#ifndef C2_THREAD_H
#define C2_THREAD_H

#include "thread/thread_helpers.h"

#endif // C2_THREAD_H
