#ifndef THREAD_HELPERS_H
#define THREAD_HELPERS_H

#include <thread>
#include <mutex>
#include <condition_variable>
#include <future>

using std::thread;
using std::mutex;
using std::recursive_mutex;
using std::lock_guard;
using std::unique_lock;
using std::condition_variable;
using std::future;
using std::shared_future;
using std::packaged_task;


#include "platform/platform_config.h"
#if ON_WINDOWS
#define thread_local __declspec(thread)
#endif // ON_WINDOWS

#endif // THREAD_HELPERS_H
