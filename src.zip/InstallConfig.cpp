﻿#include "InstallConfig.h"

InstallConfig InstallConfig::MakePublishConfig() {
    InstallConfig cfg;
    cfg.publisher = u8"中电科网络安全科技股份有限公司";
    cfg.product_name = u8"secmeet-test";
    cfg.version = "1.0.0";
    cfg.vcredist_version = "14.24.28127";
    cfg.display_name = u8"橙讯密会(测试版)";
    cfg.exe_filename = u8"secmeet.exe";
    cfg.uninstaller_filename = u8"uninstaller.exe";
    cfg.estimated_size_kb = 190388;
	return cfg;
}
