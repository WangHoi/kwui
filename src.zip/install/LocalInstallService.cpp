#include "LocalInstallService.h"
#include "debug/log.h"
#include "debug/debug_helpers.h"
#include "text/EncodingManager.h"
#include "platform/platform_helpers.h"
#include "memory/pack_utils.h"
#include "InstallTimer.h"
#include <assert.h>
#include <stdlib.h>
#include <io.h>
#include <WinReg.hpp>
#include <msi.h>
#include <psapi.h>

#define MAX_ARG_LEN 8192
#pragma warning(disable:4996)

DEFINE_SINGLETON_INSTANCE(LocalInstallService);

static const char* DEFAULT_PRODUCT_NAME = "TestProduct";
static const char* DEFAULT_PRODUCT_VERSION = "1.0.0";
static const char* DEFAULT_UNINSTALLER_NAME = "Uninstall.exe";
static const WCHAR* REG_SHELL_FOLDERS_KEY = L"Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Shell Folders";
static const WCHAR* REG_UNINSTALL_KEY = L"Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall";

static const WCHAR* VCREDIST_2019_X86_PROVIDER_KEY = L"SOFTWARE\\Classes\\Installer\\Dependencies\\Microsoft.VS.VC_RuntimeMinimumVSU_x86,v14";

// Qt install related config key
static const String SC_PRODUCT_NAME = "ProductName";
static const String SC_PRODUCT_VERSION = "ProductVersion";
static const String SC_PRODUCT_UUID = "ProductUUID";
static const String SC_USER_START_MENU_DIR = "StartMenuDir";
static const String SC_DESKTOP_DIR = "DesktopDir";

static bool directory_exists(const wstring& dir);
static DWORD create_directory(const wstring& name);
static void create_directory_recursive(const wstring& name);
static BOOL delete_directory_recursive(const WCHAR* sPath);
static bool notify_shell_dir_updated(int csidl);
static bool create_link(const wstring& file_name, const wstring& link_name);
static InstallErrorAction ErrorUserConfirm(DWORD ui_thread_id, HWND hwnd,
                                           InstallMessageType orig_request_type,
                                           const String& data);
static bool post_thread_message(DWORD idThread, HWND hwnd, UINT Msg, WPARAM wParam, InstallMessageBase *lParam);

void LocalInstallService::SetTargetDir(const String& dir) {
    c2_log("Set target dir to [%s]\n", dir.GetCString());
    _target_dir = dir;
}
void LocalInstallService::RunExe(const String& exe_filename,
                            const vector<String>& args) {
    RunExe(exe_filename, Resource(), args);
}

void LocalInstallService::RunExe(const String& exe_filename,
                            const Resource& exe,
                            const vector<String>& args) {
    RunExeRequest* req = new RunExeRequest;
	req->src_hwnd = GetMsgHwnd();
    req->resource = exe.id;
    req->target_dir = _target_dir;
    req->exe_filename = exe_filename;
    auto EM = EncodingManager::Instance();
    for (auto& arg : args) {
        req->arguments.push_back(EM->UTF8ToWide(arg));
    }
    StartWorker(req);
}
void LocalInstallService::UnpackArchive(const Resource& data) {
    UnpackArchiveRequest* req = new UnpackArchiveRequest;
	req->src_hwnd = GetMsgHwnd();
    req->resource = data.id;
    req->target_dir = _target_dir;
    StartWorker(req);
}
void LocalInstallService::UnpackResource(const String& filename, const Resource& data) {
    auto req = new UnpackResourceRequest;
	req->src_hwnd = GetMsgHwnd();
    req->resource = data.id;
    req->target_dir = _target_dir;
    req->filename = filename;
    StartWorker(req);
}
void LocalInstallService::RemoveTargetDir() {
    RemoveDirRequest* req = new RemoveDirRequest;
	req->src_hwnd = GetMsgHwnd();
    req->target_dir = _target_dir;
    StartWorker(req);
}
void LocalInstallService::CreateShortcut() {
    CreateShortcutRequest* req = new CreateShortcutRequest;
	req->src_hwnd = GetMsgHwnd();
    req->product_name = _product_name;
    req->target_dir = _target_dir;
    req->display_name = _display_name;
    req->product_version = _product_version;
    req->exe_filename = _exe_filename;
    req->uninstaller_filename = _uninstaller_filename;
    req->publisher = _publisher;
    req->estimated_size = _estimated_size_kb;
    StartWorker(req);
}
void LocalInstallService::RemoveShortcut() {
    RemoveShortcutRequest* req = new RemoveShortcutRequest;
	req->src_hwnd = GetMsgHwnd();
    req->product_name = _product_name;
    req->display_name = _display_name;
    StartWorker(req);
}
bool LocalInstallService::CreateTargetDir() {
    wstring utf16_dir = EncodingManager::Instance()
        ->UTF8ToWide(_target_dir);
    return create_directory(utf16_dir) == 0;
}
void LocalInstallService::StartWorker(InstallMessageBase* msg) {
    HANDLE h = CreateThread(NULL, 0, &LocalInstallService::WorkerThreadFunc, msg, 0, NULL);
    if (h == INVALID_HANDLE_VALUE) {
        c2_log("create worker thread failed, GetLastError()=0x%08X\n", GetLastError());
        delete msg;
    }
}
DWORD WINAPI LocalInstallService::WorkerThreadFunc(LPVOID lpParam) {
    InstallMessageBase* msg = (InstallMessageBase*)lpParam;
    switch (msg->GetType()) {
    case INSTALL_MSG_RUN_EXE_REQUEST:
        DoRunExe(*(RunExeRequest*)msg);
        break;
    case INSTALL_MSG_UNPACK_ARCHIVE_REQUEST:
        DoUnpackArchive(*(UnpackArchiveRequest*)msg);
        break;
    case INSTALL_MSG_CREATE_SHORTCUT_REQUEST:
        DoCreateShortcut(*(CreateShortcutRequest*)msg);
        break;
    case INSTALL_MSG_REMOVE_SHORTCUT_REQUEST:
        DoRemoveShortcut(*(RemoveShortcutRequest*)msg);
        break;
    case INSTALL_MSG_REMOVE_DIR_REQUEST:
        DoRemoveDir(*(RemoveDirRequest*)msg);
        break;
    case INSTALL_MSG_KILL_PROCESS_REQUEST:
        DoKillProcess(*(KillProcessRequest*)msg);
        break;
    case INSTALL_MSG_DETECT_EXIST_INSTALL_REQUEST:
        DoDetectExistInstall(*(DetectExistInstallRequest*)msg);
        break;
    case INSTALL_MSG_REMOVE_EXIST_INSTALL_REQUEST:
        DoRemoveExistInstall(*(RemoveExistInstallRequest*)msg);
        break;
    case INSTALL_MSG_UNPACK_RESOURCE_REQUEST:
        DoUnpackResource(*(UnpackResourceRequest*)msg);
        break;
    default:
        c2_log("LocalInstallService::WorkerThreadFunc(): unhandled install message type %d\n", msg->GetType());
    }
    delete msg;
    return 0;
}
void LocalInstallService::DoRunExe(RunExeRequest& request) {
    InstallTimer timer;
    String exe_path;
    wstring target_filename;
    DWORD ret;
    HANDLE hfile;
    BOOL success;
    DWORD written = 0;
    RunExeReply *reply = new RunExeReply;
    PROCESS_INFORMATION pi = {};
    wstring cmdline;
    STARTUPINFOW si = {};
    si.cb = sizeof(si);
    auto EM = EncodingManager::Instance();
    wstring target_dir = EM->UTF8ToWide(request.target_dir);

    c2_log("Start RunExe [%s].\n", request.exe_filename.GetCString());

    reply->src_thread_id = GetCurrentThreadId();
    if (request.resource) {
        reply->resource = request.resource;

        create_directory_recursive(target_dir);

        exe_path = request.target_dir;
        exe_path.Append('\\');
        exe_path.Append(request.exe_filename);
        target_filename = EM->UTF8ToWide(exe_path);

    retry_create_file:
        hfile = CreateFileW(target_filename.c_str(),
                            GENERIC_WRITE,
                            0,
                            NULL,
                            CREATE_ALWAYS,
                            FILE_ATTRIBUTE_NORMAL,
                            NULL);
        if (hfile == NULL || hfile == INVALID_HANDLE_VALUE) {
            c2_log("RunExe: create file [%s] failed, GetLastError()=0x%08X.\n",
                   exe_path.GetCString(), GetLastError());
            InstallErrorAction action
                = ErrorUserConfirm(request.src_thread_id, request.src_hwnd, request.GetType(), request.exe_filename);
            if (action == INSTALL_ERR_ABORT) {
                goto error_out;
            } else if (action == INSTALL_ERR_RETRY) {
                goto retry_create_file;
            } else if (action == INSTALL_ERR_CONTINUE) {
                goto error_out;
            }
        }
		Resource resource = ResourceManager::Instance()->LoadResource(request.resource);
        success = WriteFile(hfile, resource.data, resource.size, &written, NULL);
        if (!success) {
            c2_log("RunExe: write file [%s] failed, GetLastError()=0x%08X.\n",
                   exe_path.GetCString(), GetLastError());
            goto error_out;
        }
        if (written != resource.size) {
            c2_log("RunExe: write file [%s] failed, written bytes=%u.\n",
                   exe_path.GetCString(), written);
            goto error_out;
        }
        if (!CloseHandle(hfile)) {
            c2_log("RunExe: close file handle [%s] failed, GetLastError()=0x%08X.\n",
                   exe_path.GetCString(), GetLastError());
            goto error_out;
        }
        cmdline = L"\"" + target_filename + L"\"";
    } else {
        cmdline = EM->UTF8ToWide(request.exe_filename);
        String dir = request.exe_filename;
        dir.RemoveLastSection('\\');
        if (dir.StartsWith("\""))
            dir = dir.Substr(1);
        target_dir = EM->UTF8ToWide(dir);
    }

    for (auto& a : request.arguments) {
        cmdline.push_back(L' ');
        cmdline += a;
    }

    success = CreateProcessW(NULL,
                             &cmdline[0],
                             NULL,
                             NULL,
                             FALSE,
                             0,
                             NULL,
                             target_dir.c_str(),
                             &si,
                             &pi);
    if (!success) {
        c2_log("RunExe: create process cmdline [%s] failed, GetLastError()=0x%08X.\n",
               EM->WideToUTF8(cmdline).GetCString(), GetLastError());
        goto error_out;
    }
    ret = WaitForSingleObject(pi.hProcess, INFINITE);
    if (ret != WAIT_OBJECT_0) {
        if (ret == WAIT_FAILED) {
            c2_log("RunExe: wait [%s] exit failed, ret 0x%08X, GetLastError()=0x%08X\n",
                   request.exe_filename.GetCString(), ret, GetLastError());
        } else {
            c2_log("RunExe: wait [%s] exit failed, ret 0x%08X\n",
                   request.exe_filename.GetCString(), ret);
        }
        CloseHandle(pi.hProcess);
        goto error_out;
    }
    success = GetExitCodeProcess(pi.hProcess, &reply->exit_code);
    if (!success) {
        c2_log("RunExe: GetExitCodeProcess [%s] failed, GetLastError()=0x%08X\n",
               request.exe_filename.GetCString(), GetLastError());
        CloseHandle(pi.hProcess);
        goto error_out;
    }
    c2_log("RunExe: [%s] exit code 0x%08X\n",
           request.exe_filename.GetCString(), reply->exit_code);
    CloseHandle(pi.hProcess);
    reply->status = 0;

error_out:
    success = post_thread_message(request.src_thread_id, request.src_hwnd, WM_APP, 0, reply);
    c2_log("Done RunExe [%s], time cost %.03lf s.\n",
           request.exe_filename.GetCString(),
           timer.GetElapsed());
}
DWORD create_directory(const wstring& name) {
    return CreateDirectoryW((LPCWSTR)name.c_str(), NULL) ? 0 : GetLastError();
}
bool directory_exists(const wstring& dir) {
	DWORD attribs = ::GetFileAttributesW(dir.c_str());
	if (attribs == INVALID_FILE_ATTRIBUTES) {
		return false;
	}
	return (attribs & FILE_ATTRIBUTE_DIRECTORY);
}
void create_directory_recursive(const wstring& dir_) {
    size_t off = 3;
    wstring dir = dir_;
    size_t idx;
    while ((idx = dir.find(L'\\', off)) != wstring::npos) {
        dir[idx] = L'\0';
        create_directory(dir);
        dir[idx] = L'\\';
        off = idx + 1;
    }
    create_directory(dir_);
}

InstallErrorAction ErrorUserConfirm(DWORD ui_thread_id, HWND hwnd,
                                    InstallMessageType orig_request_type,
                                    const String& data) {
    MSG msg;
    BOOL success;
    InstallErrorAction action;

    PeekMessageW(&msg, NULL, 0, 0, PM_NOREMOVE);

    auto request = new ErrorUserCallback(orig_request_type, data);
    request->src_thread_id = GetCurrentThreadId();
    success = post_thread_message(ui_thread_id, hwnd, WM_APP, 0, request);
    if (!success) {
        delete request;
        return INSTALL_ERR_ABORT;
    }

    success = GetMessageW(&msg, NULL, 0, 0);
    if (msg.message != WM_APP) {
        c2_log("Worker: ErrorUserConfirm() recv unexpect window msg 0x%04X\n", msg.message);
        return INSTALL_ERR_ABORT;
    }
    auto reply_base = (InstallMessageBase*)msg.lParam;
    if (reply_base->GetType() != INSTALL_MSG_ERROR_USER_ACTION) {
        c2_log("Worker: ErrorUserConfirm() recv unexpect InstallMessageType %d\n", reply_base->GetType());
        delete reply_base;
        return INSTALL_ERR_ABORT;
    }
    auto reply = (ErrorUserAction*)reply_base;
    reply_base = nullptr;
    if (reply->request_msg_type != orig_request_type) {
        c2_log("Worker: ErrorUserConfirm() recv unexpect original request InstallMessageType %d\n",
               reply->request_msg_type);
        delete reply;
        return INSTALL_ERR_ABORT;
    }
    action = reply->action;
    delete reply;
    if (action == INSTALL_ERR_RETRY || action == INSTALL_ERR_CONTINUE) {
        ::Sleep(50);
    }
    return action;
}
void LocalInstallService::DoUnpackArchive(UnpackArchiveRequest& request) {
    InstallTimer timer;
    InstallTimer notify_timer;
    bool success;
    auto EM = EncodingManager::Instance();
    wstring target_dir = EM->UTF8ToWide(request.target_dir);
    UnpackArchiveReply *reply = new UnpackArchiveReply;
    reply->resource = request.resource;
    reply->src_thread_id = GetCurrentThreadId();

    c2_log("Start UnpackArchive, target dir=[%s].\n", request.target_dir.GetCString());

    reply->status = 0;

    success = post_thread_message(request.src_thread_id, request.src_hwnd, WM_APP, 0, reply);
    if (!success)
        delete reply;
    c2_log("Done UnpackArchive, time cost %.03lf s.\n", timer.GetElapsed());
}
bool notify_shell_dir_updated(int csidl) {
	PIDLIST_ABSOLUTE pidl;  // Force start menu/desktop cache update
	if (SUCCEEDED(SHGetFolderLocation(0, csidl, 0, 0, &pidl))) {
		SHChangeNotify(SHCNE_UPDATEDIR, SHCNF_IDLIST, pidl, 0);
		CoTaskMemFree(pidl);
		return true;
	}
	return false;
}
bool create_link(const wstring& file_name, const wstring& link_name) {
    // CoInitialize cleanup object
    wstring working_dir = file_name;
    {
        size_t pos = working_dir.rfind(L'\\');
        if (pos != wstring::npos)
            working_dir.erase(pos);
    }

    ComPtr<IShellLink> psl;
    if (FAILED(CoCreateInstance(CLSID_ShellLink, NULL, CLSCTX_INPROC_SERVER,
                                IID_IShellLink, (LPVOID*)psl.GetAddressOf()))) {
        return false;
    }

    // TODO: implement this server side, since there's not Qt equivalent to set working dir and arguments
    psl->SetPath(file_name.c_str());
    psl->SetWorkingDirectory(working_dir.c_str());

    ComPtr<IPersistFile> ppf;
    if (SUCCEEDED(psl.As(&ppf))) {
        if (FAILED(ppf->Save(link_name.c_str(), true))) {
            return false;
        }
    }
    return true;
}
void LocalInstallService::DoCreateShortcut(CreateShortcutRequest& request) {
    bool success;
    auto EM = EncodingManager::Instance();
    wstring product_name = EM->UTF8ToWide(request.product_name);
    wstring display_name = EM->UTF8ToWide(request.display_name);
    wstring product_version = EM->UTF8ToWide(request.product_version);
    wstring target_dir = EM->UTF8ToWide(request.target_dir);
    wstring exe_filename = EM->UTF8ToWide(request.exe_filename);
    wstring uninstaller_filename = EM->UTF8ToWide(request.uninstaller_filename);
    wstring publisher = EM->UTF8ToWide(request.publisher);
    wstring shortcut_filename = display_name + L".lnk";
    wstring uninstaller_shortcut_filename = L"ж��" + shortcut_filename;
    CreateShortcutReply *reply = new CreateShortcutReply;
    reply->src_thread_id = GetCurrentThreadId();
	CoInitializeEx(NULL, COINIT_MULTITHREADED);
    try {
        wstring u16_filename;
        wstring u16_linkname;
        DWORD wres;

        winreg::RegKey shell_folders_key(HKEY_LOCAL_MACHINE, REG_SHELL_FOLDERS_KEY, KEY_READ);
        // StartMenu Shortcut
        wstring programs_dir = shell_folders_key.GetStringValue(L"Common Programs");
        programs_dir += L'\\';
        programs_dir += display_name;
        wres = create_directory(programs_dir);
        c2_log("CreateDirectory [%s] result 0x%08X\n",
               EM->WideToUTF8(programs_dir).GetCString(),
               wres);

        u16_filename = target_dir + L'\\' + exe_filename;
        u16_linkname = programs_dir + L'\\' + shortcut_filename;
        success = create_link(u16_filename, u16_linkname);
        if (success) {
            c2_log("CreateShortcut [%s]->[%s] success\n",
                   EM->WideToUTF8(u16_linkname).GetCString(),
                   EM->WideToUTF8(u16_filename).GetCString());
        } else {
            c2_log("CreateShortcut [%s]->[%s] failed, GetLastError()=0x%08X\n",
                   EM->WideToUTF8(u16_linkname).GetCString(),
                   EM->WideToUTF8(u16_filename).GetCString(),
                   GetLastError());
            //goto error_out;
        }

        u16_filename = target_dir + L'\\' + uninstaller_filename;
        u16_linkname = programs_dir + L'\\' + uninstaller_shortcut_filename;
        success = create_link(u16_filename, u16_linkname);
        if (success) {
            c2_log("CreateShortcut [%s]->[%s] success\n",
                   EM->WideToUTF8(u16_linkname).GetCString(),
                   EM->WideToUTF8(u16_filename).GetCString());
        } else {
            c2_log("CreateShortcut [%s]->[%s] failed, GetLastError()=0x%08X\n",
                   EM->WideToUTF8(u16_linkname).GetCString(),
                   EM->WideToUTF8(u16_filename).GetCString(),
                   GetLastError());
            //goto error_out;
        }

        notify_shell_dir_updated(CSIDL_STARTMENU);
        notify_shell_dir_updated(CSIDL_COMMON_STARTMENU);
		
		// Desktop Shortcut
        wstring desktop_dir = shell_folders_key.GetStringValue(L"Common Desktop");
        u16_filename = target_dir + L'\\' + exe_filename;
        u16_linkname = desktop_dir + L'\\' + shortcut_filename;
        success = create_link(target_dir + L'\\' + exe_filename,
                              desktop_dir + L'\\' + shortcut_filename);
        if (success) {
            c2_log("CreateShortcut: [%s]->[%s] success\n",
                   EM->WideToUTF8(u16_linkname).GetCString(),
                   EM->WideToUTF8(u16_filename).GetCString());
        } else {
            c2_log("CreateShortcut: [%s]->[%s] failed, GetLastError()=0x%08X\n",
                   EM->WideToUTF8(u16_linkname).GetCString(),
                   EM->WideToUTF8(u16_filename).GetCString(),
                   GetLastError());
            //goto error_out;
        }
        notify_shell_dir_updated(CSIDL_DESKTOPDIRECTORY);
        notify_shell_dir_updated(CSIDL_COMMON_DESKTOPDIRECTORY);
        /*
        PIDLIST_ABSOLUTE pidl;
        if (SUCCEEDED(SHGetFolderLocation(0, CSIDL_STARTMENU, 0, 0, &pidl))) {
            SHChangeNotify(SHCNE_UPDATEDIR, SHCNF_IDLIST, pidl, 0);
            CoTaskMemFree(pidl);
        }

        //PIDLIST_ABSOLUTE pidl;
        if (SUCCEEDED(SHGetFolderLocation(0, CSIDL_COMMON_STARTMENU, 0, 0, &pidl))) {
            SHChangeNotify(SHCNE_UPDATEDIR, SHCNF_IDLIST, pidl, 0);
            CoTaskMemFree(pidl);
        }
        */

        // Registry Uninstaller
        wstring path(REG_UNINSTALL_KEY);
        wstring value;
        path += L'\\';
        path += product_name;
        winreg::RegKey uninstall_key;

        c2_log("CreateShortcut: TryCreate RegKey [HKEY_LOCAL_MACHINE\\%s]\n", EM->WideToUTF8(path).GetCString());
        (void)uninstall_key.TryCreate(HKEY_LOCAL_MACHINE, path, KEY_READ | KEY_WRITE/* | KEY_EXECUTE*/);

        c2_log("CreateShortcut: Open RegKey [HKEY_LOCAL_MACHINE\\%s]\n", EM->WideToUTF8(path).GetCString());
        uninstall_key.Open(HKEY_LOCAL_MACHINE, path, KEY_READ | KEY_WRITE);

        value = L'"' + target_dir + L'\\' + exe_filename + L'"';
        c2_log("CreateShortcut: Set RegKey [HKEY_LOCAL_MACHINE\\%s] StringValue [DisplayIcon] = [%s]\n",
               EM->WideToUTF8(path).GetCString(),
               EM->WideToUTF8(value).GetCString());
        uninstall_key.SetStringValue(L"DisplayIcon", value);

        c2_log("CreateShortcut: Set RegKey [HKEY_LOCAL_MACHINE\\%s] StringValue [DisplayName] = [%s]\n",
               EM->WideToUTF8(path).GetCString(),
               EM->WideToUTF8(display_name).GetCString());
        uninstall_key.SetStringValue(L"DisplayName", display_name);

        c2_log("CreateShortcut: Set RegKey [HKEY_LOCAL_MACHINE\\%s] StringValue [DisplayVersion] = [%s]\n",
               EM->WideToUTF8(path).GetCString(),
               EM->WideToUTF8(product_version).GetCString());
        uninstall_key.SetStringValue(L"DisplayVersion", product_version);

        c2_log("CreateShortcut: Set RegKey [HKEY_LOCAL_MACHINE\\%s] StringValue [Publisher] = [%s]\n",
               EM->WideToUTF8(path).GetCString(),
               EM->WideToUTF8(publisher).GetCString());
        uninstall_key.SetStringValue(L"Publisher", publisher);

        value = L'"' + target_dir + L'\\' + uninstaller_filename + L'"';
        c2_log("CreateShortcut: Set RegKey [HKEY_LOCAL_MACHINE\\%s] StringValue [UninstallString] = [%s]\n",
               EM->WideToUTF8(path).GetCString(),
               EM->WideToUTF8(value).GetCString());
        uninstall_key.SetStringValue(L"UninstallString", L'"' + target_dir + L'\\' + uninstaller_filename + L'"');

        c2_log("CreateShortcut: Set RegKey [HKEY_LOCAL_MACHINE\\%s] DwordValue [NoModify] = [%u]\n",
               EM->WideToUTF8(path).GetCString(), 1);
        uninstall_key.SetDwordValue(L"NoModify", 1);

        c2_log("CreateShortcut: Set RegKey [HKEY_LOCAL_MACHINE\\%s] DwordValue [NoRepair] = [%u]\n",
               EM->WideToUTF8(path).GetCString(), 1);
        uninstall_key.SetDwordValue(L"NoRepair", 1);
        {
            RtcTime time = get_rtc_time();
            WCHAR install_date[32] = {};
            _snwprintf(install_date, sizeof(install_date) - 1, L"%04d%02d%02d",
                       time.year, time.month, time.day);
            c2_log("CreateShortcut: Set RegKey [HKEY_LOCAL_MACHINE\\%s] StringValue [InstallDate] = [%s]\n",
                   EM->WideToUTF8(path).GetCString(),
                   EM->WideToUTF8(install_date).GetCString());
            uninstall_key.SetStringValue(L"InstallDate", install_date);
        }
        if (request.estimated_size.has_value()) {
            c2_log("CreateShortcut: Set RegKey [HKEY_LOCAL_MACHINE\\%s] DwordValue [EstimatedSize] = [%u]\n",
                   EM->WideToUTF8(path).GetCString(),
                   (DWORD)request.estimated_size.value());
            uninstall_key.SetDwordValue(L"EstimatedSize", (DWORD)request.estimated_size.value());
        }

        uninstall_key.Close();
    } catch (...) {
        c2_log("CreateShortcut: Registry operation failed\n");
        goto error_out;
    }
    reply->status = 0;
error_out:
    CoUninitialize();
    success = post_thread_message(request.src_thread_id, request.src_hwnd, WM_APP, 0, reply);
	if (!success) {
		delete reply;
	}
}
void LocalInstallService::DoRemoveShortcut(RemoveShortcutRequest& req) {
    BOOL success;
    auto EM = EncodingManager::Instance();
    wstring product_name = EM->UTF8ToWide(req.product_name);
    wstring display_name = EM->UTF8ToWide(req.display_name);
    wstring shortcut_filename = display_name + L".lnk";
    auto reply = new RemoveShortcutReply;
    reply->src_thread_id = GetCurrentThreadId();
    wstring path(REG_UNINSTALL_KEY);
    try {
        PIDLIST_ABSOLUTE pidl;
        winreg::RegKey shell_folders_key(HKEY_LOCAL_MACHINE, REG_SHELL_FOLDERS_KEY, KEY_READ);
        // StartMenu Shortcut
        wstring programs_dir = shell_folders_key.GetStringValue(L"Common Programs");
        programs_dir += L'\\';
        programs_dir += display_name;
        delete_directory_recursive(programs_dir.c_str());
        if (SUCCEEDED(SHGetFolderLocation(0, CSIDL_COMMON_PROGRAMS, 0, 0, &pidl))) {
            SHChangeNotify(SHCNE_UPDATEDIR, SHCNF_IDLIST, pidl, 0);
            CoTaskMemFree(pidl);
        }

        // Desktop Shortcut
        wstring desktop_dir = shell_folders_key.GetStringValue(L"Common Desktop");
        wstring desktop_shortcut_path = desktop_dir + L'\\' + shortcut_filename;
        success = DeleteFileW(desktop_shortcut_path.c_str());

		if (success) {
			c2_log("RemoveShortcut: [%s] success\n",
				EM->WideToUTF8(desktop_shortcut_path).GetCString());
		} else {
			c2_log("RemoveShortcut: [%s] failed, GetLastError()=0x%08X\n",
				EM->WideToUTF8(desktop_shortcut_path).GetCString(),
				GetLastError());
		}

		if (SUCCEEDED(SHGetFolderLocation(0, CSIDL_COMMON_DESKTOPDIRECTORY, 0, 0, &pidl))) {
            SHChangeNotify(SHCNE_UPDATEDIR, SHCNF_IDLIST, pidl, 0);
            CoTaskMemFree(pidl);
        }


        // Remove Startup Shortcut
        try {
            winreg::RegKey curr_shell_folders_key(HKEY_CURRENT_USER, REG_SHELL_FOLDERS_KEY, KEY_READ);
            wstring startup_dir = curr_shell_folders_key.GetStringValue(L"Startup");
            wstring startup_shortcut = startup_dir + L"\\" + display_name + L".lnk";
            success = DeleteFileW(startup_shortcut.c_str());
            if (!success) {
                c2_log("remove file [%s] failed, GetLastError()=0x%08X\n",
                       EM->WideToUTF8(startup_shortcut).GetCString(),
                       GetLastError());
            }
        } catch (...) {
            c2_log("remove startup shortcut failed, GetLastError()=0x%08X\n",
                   GetLastError());
        }

        // Uninstaller
        winreg::RegKey uninstall_key(HKEY_LOCAL_MACHINE, path, KEY_READ | KEY_WRITE);
        uninstall_key.DeleteKey(product_name, DELETE);
    } catch (...) {
        goto error_out;
    }
    reply->status = 0;

error_out:
    success = post_thread_message(req.src_thread_id, req.src_hwnd, WM_APP, 0, reply);
	if (!success) {
		delete reply;
	}
}
static BOOL is_dots(const WCHAR* str) {
    if (wcscmp(str, L".") && wcscmp(str, L".."))
        return FALSE;
    return TRUE;
}
BOOL delete_directory_recursive(const WCHAR* sPath) {
    HANDLE hFind;    // file handle
    WIN32_FIND_DATAW find_file_data;
    WCHAR dir_path[MAX_PATH];
    WCHAR filename[MAX_PATH];

    wcscpy(dir_path, sPath);
    wcscat(dir_path, L"\\*");    // searching all files

    wcscpy(filename, sPath);
    wcscat(filename, L"\\");

    // find the first file
    hFind = FindFirstFileW(dir_path, &find_file_data);
    if (hFind == INVALID_HANDLE_VALUE)
        return FALSE;
    wcscpy(dir_path, filename);

    auto EM = EncodingManager::Instance();
    bool bSearch = true;
    while (bSearch) {    // until we find an entry
        if (FindNextFile(hFind, &find_file_data)) {
            if (is_dots(find_file_data.cFileName))
                continue;

            wcscat(filename, find_file_data.cFileName);
            if ((find_file_data.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)) {
                // we have found a directory, recurse
                if (!delete_directory_recursive(filename)) {
                    c2_log("Delete directory [%s] failed.\n", EM->WideToUTF8(filename).GetCString());
                    //FindClose(hFind);
                    //return FALSE;    // directory couldn��t be deleted
                }
                // remove the empty directory
                RemoveDirectoryW(filename);
                wcscpy(filename, dir_path);
            } else {
                if (find_file_data.dwFileAttributes & FILE_ATTRIBUTE_READONLY) {
                    // change read-only file mode
                    _wchmod(filename, _S_IWRITE);
                }
                if (!DeleteFileW(filename)) {    // delete the file
                    c2_log("Delete file [%s] failed.\n", EM->WideToUTF8(filename).GetCString());
                    //FindClose(hFind);
                    //return FALSE;
                }
                wcscpy(filename, dir_path);
            }
        } else {
            // no more files there
            if (GetLastError() == ERROR_NO_MORE_FILES) {
                bSearch = false;
            } else {
                // some error occurred; close the handle and return FALSE
                FindClose(hFind);
                return FALSE;
            }
        }
    }
    FindClose(hFind);                  // close the file handle
    return RemoveDirectoryW(sPath);     // remove the empty directory
}
void LocalInstallService::DoRemoveDir(RemoveDirRequest& req) {
    auto reply = new RemoveDirReply;
    reply->src_thread_id = GetCurrentThreadId();
    BOOL success;
    wstring path = EncodingManager::Instance()->UTF8ToWide(req.target_dir);
    delete_directory_recursive(path.c_str());
    success = post_thread_message(req.src_thread_id, req.src_hwnd, WM_APP, 0, reply);
	if (!success) {
		delete reply;
	}
}
void LocalInstallService::DoKillProcess(KillProcessRequest& req) {
    auto reply = new KillProcessReply;
    reply->src_thread_id = GetCurrentThreadId();
    HANDLE handle;
    for (auto process_id : req.process_ids) {
        handle = OpenProcess(PROCESS_TERMINATE, FALSE, process_id);
        if (handle) {
            if (TerminateProcess(handle, 0)) {
                WaitForSingleObject(handle, INFINITE);
                reply->status = 0;
            }
            CloseHandle(handle);
        }
    }
    
    /* �ȴ�С���˳� */
    ::Sleep(500);
    
    BOOL success = post_thread_message(req.src_thread_id, req.src_hwnd, WM_APP, 0, reply);
	if (!success) {
		delete reply;
	}
}
vector<DWORD> LocalInstallService::GetRunningProcess() const {
    auto EM = EncodingManager::Instance();
    wstring product_name = EM->UTF8ToWide(_product_name);
	vector<wstring> exe_filenames;
	exe_filenames.push_back(EM->UTF8ToWide(_exe_filename));
	exe_filenames.push_back(product_name + L"\\workbench.exe");
	exe_filenames.push_back(product_name + L"\\QtWebEngineProcess.exe");
	exe_filenames.push_back(product_name + L"\\dirmigrate.exe");

    DWORD aProcesses[1024], cbNeeded, cProcesses;
    unsigned int i;
    vector<DWORD> ret;

    if (!EnumProcesses(aProcesses, sizeof(aProcesses), &cbNeeded)) {
        return ret;
    }
    if (cbNeeded > sizeof(aProcesses))
        cbNeeded = sizeof(aProcesses);
    cProcesses = cbNeeded / sizeof(DWORD);
    for (i = 0; i < cProcesses; i++) {
        if (aProcesses[i] == NULL)
            continue;
        HANDLE process_handle = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, FALSE, aProcesses[i]);
        if (process_handle) {
            WCHAR path[MAX_PATH + 1] = {};
            DWORD path_len = MAX_PATH;
            if (QueryFullProcessImageNameW(process_handle, 0, path, &path_len) && path_len <= MAX_PATH) {
                path[path_len] = 0;
                wstring wpath(path, path + path_len);
				for (auto& exe_filename : exe_filenames) {
					wstring suffix = L"\\" + exe_filename;
					if (wpath.length() >= suffix.length()
						&& _wcsnicmp(&wpath[wpath.length() - suffix.length()], suffix.c_str(), suffix.length()) == 0) {

						ret.push_back(aProcesses[i]);
					}
				}
            }
            CloseHandle(process_handle);
        }
    }

    return ret;
}
void LocalInstallService::KillProcess(const vector<DWORD>& pid) {
    KillProcessRequest* req = new KillProcessRequest;
	req->src_hwnd = GetMsgHwnd();
    req->process_ids = pid;
    StartWorker(req);
}
void LocalInstallService::LaunchTargetExe() {
    String exe_path = "\"" + _target_dir + "\\" + _exe_filename + "\"";
    wstring utf16_exe_path = EncodingManager::Instance()
        ->UTF8ToWide(exe_path);
    bool success;
    PROCESS_INFORMATION pi = {};
    STARTUPINFOW si = {};
    si.cb = sizeof(si);
    success = CreateProcessW(NULL,
                             &utf16_exe_path[0],
                             NULL,
                             NULL,
                             FALSE,
                             DETACHED_PROCESS,
                             NULL,
                             NULL,
                             &si,
                             &pi);
    if (success) {
        CloseHandle(pi.hProcess);
    }
}

void LocalInstallService::DetectExistInstall() {
    auto req = new DetectExistInstallRequest;
	req->src_hwnd = GetMsgHwnd();
    req->program_files_dir_hint = _program_files_dir;
    req->product_name = _product_name;
    req->display_name = _display_name;
    req->current_vcredist_version = _vcredist_version;
    StartWorker(req);
}
void LocalInstallService::RemoveExistInstall(const ExistInstallData& data) {
    auto req = new RemoveExistInstallRequest;
	req->src_hwnd = GetMsgHwnd();
    req->data = data;
    StartWorker(req);
}

void LocalInstallService::DeleteUninstallerSelf() {
    InstallTimer timer;
    auto EM = EncodingManager::Instance();
    WCHAR temp_path[MAX_PATH + 1] = {};
    WCHAR filename[MAX_PATH + 1] = {};
    DWORD ret;
    ret = GetTempPathW(MAX_PATH, temp_path);
    ret = GetTempFileNameW(temp_path, L"chengxun_uninstall_", 1, filename);
    wstring script_filename = wstring(filename) + L".vbs";
    FILE* f = _wfopen(script_filename.c_str(), L"w");
    if (!f) {
        c2_log("Open [%s] failed.\n", EM->WideToUTF8(script_filename).GetCString());
        return;
    }
    fputs("Set fso = WScript.CreateObject(\"Scripting.FileSystemObject\")\n", f);
    fputs("file = WScript.Arguments.Item(0)\n", f);
    fputs("folderpath = WScript.Arguments.Item(1)\n", f);
    fputs("Set folder = fso.GetFolder(folderpath)\n", f);
    fputs("on error resume next\n", f);
	fputs("fso.DeleteFile(file)\n", f);
	fputs("for i = 1 to 5\n", f);
    fputs("  if NOT fso.FileExists(file) then\n", f);
	fputs("    exit for\n", f);
	fputs("  end if\n", f);
	fputs("  WScript.Sleep(1000)\n", f);
	fputs("  fso.DeleteFile(file)\n", f);
	fputs("next\n", f);
    //    fputs("if folder.SubFolders.Count = 0 and folder.Files.Count = 0 then\n", f);
    fputs("Set folder = Nothing\n", f);
    fputs("fso.DeleteFolder folderpath, true\n", f);
    //    fputs("end if\n", f);
    fputs("fso.DeleteFile(WScript.ScriptFullName)\n", f);
    fclose(f);

    BOOL success;
    PROCESS_INFORMATION pi = {};
    wstring cmdline;
    STARTUPINFOW si = {};
    si.cb = sizeof(si);

    cmdline = L"cscript \"" + script_filename + L"\"";
    //cmdline += L" //B";
    cmdline += L" //Nologo";
    wstring target_dir = EM->UTF8ToWide(_target_dir);
    wstring exe_filename = EM->UTF8ToWide(_uninstaller_filename);
    cmdline += L" \"" + target_dir + L"\\" + exe_filename + L"\"";
    cmdline += L" \"" + target_dir + L"\"";

    //c2_log("RemoveSelf: %.03lf create process cmdline [%s]...\n",
    //       timer.GetElapsed(),
    //       EM->WideToUTF8(cmdline).GetCString());
    success = CreateProcessW(NULL,
                             &cmdline[0],
                             NULL,
                             NULL,
                             FALSE,
                             DETACHED_PROCESS | CREATE_NO_WINDOW,
                             NULL,
                             temp_path,
                             &si,
                             &pi);
    if (!success) {
        c2_log("RunExe: create process cmdline [%s] failed, GetLastError()=0x%08X.\n",
               EM->WideToUTF8(cmdline).GetCString(), GetLastError());
        return;
    }
    CloseHandle(pi.hProcess);
    c2_log("RemoveSelf: %.03lf Done\n", timer.GetElapsed());
}

static BOOL Is64BitWindows()
{
#if defined(_WIN64)
    return TRUE;  // 64-bit programs run only on Win64
#elif defined(_WIN32)
    // 32-bit programs run on both 32-bit and 64-bit Windows
    // so must sniff
    BOOL f64 = FALSE;
    return IsWow64Process(GetCurrentProcess(), &f64) && f64;
#else
    return FALSE; // Win64 does not support Win16
#endif
}
LocalInstallService::LocalInstallService()
    : _product_name(DEFAULT_PRODUCT_NAME)
    , _display_name(DEFAULT_PRODUCT_NAME)
    , _product_version(DEFAULT_PRODUCT_VERSION) {

    WCHAR path[MAX_PATH + 1] = {};
    if (SHGetSpecialFolderPathW(NULL, path, CSIDL_PROGRAM_FILESX86, FALSE)) {
        _program_files_dir = EncodingManager::Instance()->WideToUTF8(path);
    } else {
        if (Is64BitWindows()) {
            _program_files_dir = "C:\\Program Files (x86)";
        } else {
            _program_files_dir = "C:\\Program Files";
        }
    }
}
void* memmem(const void* haystack, size_t haystackLen,
             const void* needle, size_t needleLen)
{
    /* The first occurrence of the empty string is deemed to occur at
    the beginning of the string.  */
    if (needleLen == 0 || haystack == needle)
    {
        return (void*)haystack;
    }

    if (haystack == NULL || needle == NULL)
    {
        return NULL;
    }

    const unsigned char* haystackStart = (const unsigned char*)haystack;
    const unsigned char* needleStart = (const unsigned char*)needle;
    const unsigned char needleEndChr = *(needleStart + needleLen - 1);

    ++haystackLen;
    for (; --haystackLen >= needleLen; ++haystackStart)
    {
        size_t x = needleLen;
        const unsigned char* n = needleStart;
        const unsigned char* h = haystackStart;

        /* Check for the first and the last character */
        if (*haystackStart != *needleStart ||
            *(haystackStart + needleLen - 1) != needleEndChr)
        {
            continue;
        }

        while (--x > 0)
        {
            if (*h++ != *n++)
            {
                break;
            }
        }

        if (x == 0)
        {
            return (void*)haystackStart;
        }
    }

    return NULL;
}
static optional<byte> convert_hex(byte c) {
    if (c >= '0' && c <= '9')
        return byte(c - '0');
    if (c >= 'a' && c <= 'f')
        return byte(c - 'a' + 10);
    if (c >= 'A' && c <= 'F')
        return byte(c - 'A' + 10);
    return nullopt;
}
static vector<byte> unescape_qt_data(const byte* data, size_t len) {
    vector<byte> buf;
    buf.reserve(len / 2);
    const byte* p = data;
    while (p < data + len) {
        switch (*p) {
        case '\\':
            if (p + 1 < data + len) {
                switch (p[1]) {
                case '0':
                    buf.push_back(0);
                    p += 2;
                    break;
                case 'x':
                    if (p + 3 < data + len) {
                        auto c0 = convert_hex(p[2]);
                        auto c1 = convert_hex(p[3]);
                        if (c0.has_value() && c1.has_value()) {
                            buf.push_back(*c0 * 16 + *c1);
                            p += 4;
                        } else if (c0.has_value()) {
                            buf.push_back(*c0);
                            p += 3;
                        } else {
                            c2_log("parse \\x failed.\n");
                            p += 4;
                        }
                    } else {
                        c2_log("parse \\x failed.\n");
                        p += 4;
                    }
                    break;
                case 'r':
                    buf.push_back('\r');
                    p += 2;
                    break;
                case 'n':
                    buf.push_back('\n');
                    p += 2;
                    break;
                case 'b':
                    buf.push_back('\b');
                    p += 2;
                    break;
                case '\\':
                    buf.push_back('\\');
                    p += 2;
                    break;
                case 't':
                    buf.push_back('\t');
                    p += 2;
                    break;
                case 'v':
                    buf.push_back('\v');
                    p += 2;
                    break;
                case 'f':
                    buf.push_back('\f');
                    p += 2;
                    break;
                case '\'':
                    buf.push_back('\'');
                    p += 2;
                    break;
                case '"':
                    buf.push_back('"');
                    p += 2;
                    break;
                default:
                    c2_log("parse \\ failed.\n");
                    p += 2;
                }
            } else {
                buf.push_back(*p++);
            }
            break;
        default:
            buf.push_back(*p++);
        }
    }
    return buf;
}

static const uint32 MAX_QSTRING_LEN = 64 * 1024;
static bool parse_qstring(const byte* data, const byte* end, wstring* out_str, size_t* consumed) {
    if (data + 4 > end)
        return false;
    uint32 len = unpack_be32(data); // byte len
    if (len == 0xffffffff) { // NULL marker
        out_str->clear();
        *consumed = 4;
        return true;
    }
    if (len % 2 != 0 || len > MAX_QSTRING_LEN || data + 4 + len > end)
        return false;
    len /= 2; // utf16 len
    out_str->clear();
    out_str->reserve(len);
    const byte* p = data + 4;
    for (uint32 i = 0; i < len; ++i) {
        wchar_t ch = ((wchar_t)p[0] << 8) | (wchar_t)p[1];
        out_str->push_back(ch);
        p += 2;
    }
    *consumed = 4 + len * 2;
    return true;
}
static bool parse_qvariant(const byte* data, const byte* end, wstring* out_str, size_t* consumed) {
    if (data + 4 > end)
        return false;
    uint32 meta_type = unpack_be32(data);
    if (meta_type != 10) // QMetaType::QString
        return false;
    if (parse_qstring(data + 4, end, out_str, consumed)) {
        *consumed += 4;
        return true;
    } else {
        return false;
    }
}
static unordered_map<String, String> parse_qvariant_hash(const byte* data, size_t len) {
    unordered_map<String, String> table;
    if (len < 8)
        return table;
    const byte* p = data;
    wstring key;
    wstring value;
    size_t n;
    uint32 i;
    uint32 metatype = unpack_be32(p);
    p += 4;
    if (metatype != 28) // QMetaType::QVariantHash
        return table;
    uint32 num_entries = unpack_be32(p);
    p += 4;
    c2_log("total %u entries.\n", (unsigned)num_entries);
    for (i = 0; i < num_entries; ++i) {
        if (!parse_qstring(p, data + len, &key, &n))
            break;
        p += n;
        if (!parse_qvariant(p, data + len, &value, &n))
            break;
        p += n;
        auto EM = EncodingManager::Instance();
        auto k = EM->WideToUTF8(key);
        auto v = EM->WideToUTF8(value);
        table[k] = v;
        c2_log("  #%u, key=[%s], value=[%s], offset=%04x\n", i, k.GetCString(), v.GetCString(), (int)(p - data));
    }
    c2_log("parsed %u entries\n", i);
    return table;
}
void LocalInstallService::DoDetectExistInstall(DetectExistInstallRequest& req) {
    InstallTimer timer;
    auto reply = new DetectExistInstallReply;
    reply->src_thread_id = GetCurrentThreadId();
    auto EM = EncodingManager::Instance();
    BOOL success;

    c2_log("Start DetectExistInstall.\n");

    // Detect VCRedist 2019 x86
    try {
        winreg::RegKey key(HKEY_LOCAL_MACHINE, VCREDIST_2019_X86_PROVIDER_KEY, KEY_READ | KEY_WOW64_64KEY);
        wstring product_key = key.GetStringValue(wstring());
        wstring product_version = key.GetStringValue(L"Version");
        INSTALLSTATE msi_state = MsiQueryProductStateW(product_key.c_str());
        c2_log("Found vcredist_2019_x86 installation, version=[%s] product=%s install_state=[%d].\n",
               EM->WideToUTF8(product_version).GetCString(),
               EM->WideToUTF8(product_key).GetCString(),
               msi_state);
        if (msi_state == INSTALLSTATE_DEFAULT) {
            String version = EM->WideToUTF8(product_version);
            optional<int> cmp = version.VersionCompare(req.current_vcredist_version);
            if (cmp.has_value() && *cmp != -1)
                reply->vcredist_installed = true;
        }
    } catch (...) {
        c2_log("vcredist_2019_x86 installation not detected.\n");
    }

    // detect new install
    try {
        wstring path(REG_UNINSTALL_KEY);
        path += L'\\';
        path += EM->UTF8ToWide(req.product_name);
        winreg::RegKey uninstall_key(HKEY_LOCAL_MACHINE, path, KEY_READ | KEY_WRITE);
        wstring display_name = uninstall_key.GetStringValue(L"DisplayName");
        wstring version = uninstall_key.GetStringValue(L"DisplayVersion");
        wstring uninstaller_path = uninstall_key.GetStringValue(L"UninstallString");

        // ȥ�����ܵ�˫����
        if (uninstaller_path.find(L'"') == 0)
            uninstaller_path.erase(0, 1);
        if (!uninstaller_path.empty()
            && uninstaller_path.rfind(L'"') == uninstaller_path.size() - 1)
            uninstaller_path.erase(uninstaller_path.size() - 1, 1);
        wstring::size_type pos = uninstaller_path.rfind(L'\\');
        if (pos != wstring::npos)
            uninstaller_path.erase(pos);

        ExistInstallData data;
        data.product_name = req.product_name;
        data.display_name = EM->WideToUTF8(display_name);
        data.target_dir = EM->WideToUTF8(uninstaller_path);
        data.version = EM->WideToUTF8(version);
        reply->chengxun_result.emplace(data);
    } catch (...) {}

    success = post_thread_message(req.src_thread_id, req.src_hwnd, WM_APP, 0, reply);
	if (!success) {
		delete reply;
	}
    c2_log("Done DetectExistInstall, time cost %.03lf s.\n", timer.GetElapsed());
}
void LocalInstallService::DoRemoveExistInstall(RemoveExistInstallRequest& req) {
    InstallTimer timer;
    auto reply = new RemoveExistInstallReply;
    reply->src_thread_id = GetCurrentThreadId();
    auto EM = EncodingManager::Instance();
    BOOL success;
    PIDLIST_ABSOLUTE pidl;
    c2_log("Start RemoveExistInstall\n");
    auto& my_data = req.data;
    wstring target_dir = EM->UTF8ToWide(my_data.target_dir);
    wstring product_name = EM->UTF8ToWide(my_data.product_name);
    wstring display_name = EM->UTF8ToWide(my_data.display_name);

    // Remove files
    success = delete_directory_recursive(target_dir.c_str());
    if (!success) {
        c2_log("remove dir [%s] failed.\n", my_data.target_dir.GetCString());
    }

    // Remove StartMenu Shortcut
    try {
        winreg::RegKey shell_folders_key(HKEY_LOCAL_MACHINE, REG_SHELL_FOLDERS_KEY, KEY_READ);
        wstring programs_dir = shell_folders_key.GetStringValue(L"Common Programs");
        programs_dir += L'\\';
        programs_dir += display_name;
        if (!delete_directory_recursive(programs_dir.c_str())) {
            auto p = EM->WideToUTF8(programs_dir);
            c2_log("remove dir [%s] failed.\n", p.GetCString());
        }
        if (SUCCEEDED(SHGetFolderLocation(0, CSIDL_COMMON_PROGRAMS, 0, 0, &pidl))) {
            SHChangeNotify(SHCNE_UPDATEDIR, SHCNF_IDLIST, pidl, 0);
            CoTaskMemFree(pidl);
        }
    } catch (...) {
        auto k = EM->WideToUTF8(REG_SHELL_FOLDERS_KEY);
        c2_log("read [HKEY_LOCAL_MACHINE\\%s] value [Common Programs] failed.\n",
                k.GetCString());
    }

    // Desktop Shortcut
    try {
        winreg::RegKey shell_folders_key(HKEY_LOCAL_MACHINE, REG_SHELL_FOLDERS_KEY, KEY_READ);
        wstring desktop_dir = shell_folders_key.GetStringValue(L"Common Desktop");
        wstring desktop_shortcut_path = desktop_dir + L'\\' + display_name + L".lnk";
        DeleteFileW(desktop_shortcut_path.c_str());
        if (SUCCEEDED(SHGetFolderLocation(0, CSIDL_COMMON_DESKTOPDIRECTORY, 0, 0, &pidl))) {
            SHChangeNotify(SHCNE_UPDATEDIR, SHCNF_IDLIST, pidl, 0);
            CoTaskMemFree(pidl);
        }
    } catch (...) {
        auto k = EM->WideToUTF8(REG_SHELL_FOLDERS_KEY);
        c2_log("read [HKEY_LOCAL_MACHINE\\%s] value [Common Desktop] failed.\n",
                k.GetCString());
    }

    // Remove Startup Shortcut
    try {
        winreg::RegKey curr_shell_folders_key(HKEY_CURRENT_USER, REG_SHELL_FOLDERS_KEY, KEY_READ);
        wstring startup_dir = curr_shell_folders_key.GetStringValue(L"Startup");
        wstring startup_shortcut = startup_dir + L"\\" + display_name + L".lnk";
        success = DeleteFileW(startup_shortcut.c_str());
        if (!success) {
            c2_log("remove file [%s] failed, GetLastError()=0x%08X\n",
                    EM->WideToUTF8(startup_shortcut).GetCString(),
                    GetLastError());
        }
    } catch (...) {
        c2_log("remove startup shortcut failed, GetLastError()=0x%08X\n",
                GetLastError());
    }

    // Uninstaller
    try {
        winreg::RegKey uninstall_key(HKEY_LOCAL_MACHINE, REG_UNINSTALL_KEY, KEY_READ | KEY_WRITE);
        uninstall_key.DeleteKey(product_name, DELETE);
    } catch (...) {
        auto k = EM->WideToUTF8(REG_UNINSTALL_KEY);
        c2_log("remove [HKEY_LOCAL_MACHINE\\%s\\%s] failed.\n",
                k.GetCString(),
                my_data.product_name.GetCString());
    }

    reply->status = 0;
    success = post_thread_message(req.src_thread_id, req.src_hwnd, WM_APP, 0, reply);
	if (!success) {
		delete reply;
	}
    c2_log("Done RemoveExistInstall, time cost %.3lf s.\n", timer.GetElapsed());
}
void LocalInstallService::DoUnpackResource(UnpackResourceRequest& request) {
    bool success;
    auto EM = EncodingManager::Instance();
    wstring target_dir = EM->UTF8ToWide(request.target_dir);
    wstring filename = EM->UTF8ToWide(request.filename);
    size_t n;
    auto reply = new UnpackResourceReply;
    reply->resource = request.resource;
    reply->src_thread_id = GetCurrentThreadId();

    create_directory(target_dir);

    wstring path = target_dir + L"\\" + filename;
    FILE* f;
	Resource resource;
retry_file_open:
    f = _wfopen(path.c_str(), L"wb");
    if (!f) {
        c2_log("UnpackResource: open file [%s] failed, GetLastError()=0x%08X.\n",
               EM->WideToUTF8(path).GetCString(), GetLastError());
        InstallErrorAction action
            = ErrorUserConfirm(request.src_thread_id, request.src_hwnd, request.GetType(), request.filename);
        if (action == INSTALL_ERR_ABORT) {
            goto error_out;
        } else if (action == INSTALL_ERR_RETRY) {
            goto retry_file_open;
        } else if (action == INSTALL_ERR_CONTINUE) {
            goto error_out;
        }

        goto error_out;
    }
	resource = ResourceManager::Instance()->LoadResource(request.resource);
    n = fwrite(resource.data, 1, resource.size, f);
    if (n != resource.size) {
        c2_log("UnpackResource: write file [%s] failed, ret_code %zd.\n",
               EM->WideToUTF8(path).GetCString(), n);
        fclose(f);
        goto error_out;
    }
    fclose(f);
    reply->status = 0;

error_out:
    success = post_thread_message(request.src_thread_id, request.src_hwnd, WM_APP, 0, reply);
	if (!success) {
		delete reply;
	}
}
bool post_thread_message(DWORD idThread, HWND hwnd, UINT Msg, WPARAM wParam, InstallMessageBase *lParam) {
	BOOL success;
	DWORD last_error;
	c2_log("post_thread_message idThread=%08X hwnd=%08X InstallMessage type %d\n",
		idThread, hwnd, lParam->GetType());
	if (idThread) {
	retry:
		success = PostThreadMessageW(idThread, Msg, wParam, (LPARAM)lParam);
		if (!success) {
			last_error = GetLastError();
			c2_log("notify ui thread failed, GetLastError()=0x%08X\n", last_error);
			if (last_error == ERROR_NOT_ENOUGH_QUOTA) {
				::Sleep(1000);
				goto retry;
			}
		}
	} else if (hwnd) {
	retry2:
		success = PostMessage(hwnd, Msg, wParam, (LPARAM)lParam);
		if (!success) {
			last_error = GetLastError();
			c2_log("notify ui hwnd failed, GetLastError()=0x%08X\n", last_error);
			if (last_error == ERROR_NOT_ENOUGH_QUOTA) {
				::Sleep(1000);
				goto retry2;
			}
		}
	} else {
		c2_log("notify ui failed, src thread and hwnd is invalid.\n");
		success = false;
	}
	return success;
}