#ifndef INSTALL_MESSAGE_H
#define INSTALL_MESSAGE_H
#include "string/String.h"
#include "memory/ResourceManager.h"

enum InstallMessageType {
	// Thread: worker -> ui
	INSTALL_MSG_CONNECT_NOTIFY,
	// Thread: ui -> worker
	INSTALL_MSG_RUN_EXE_REQUEST,
	// Thread: worker -> ui
	INSTALL_MSG_RUN_EXE_REPLY,
	// Thread: ui -> worker
	INSTALL_MSG_UNPACK_ARCHIVE_REQUEST,
	// Thread: worker -> ui
	INSTALL_MSG_UNPACK_ARCHIVE_REPLY,
	// Thread: worker -> ui
	INSTALL_MSG_UNPACK_ARCHIVE_PROGRESS,
	// Thread: ui -> worker
	INSTALL_MSG_CREATE_SHORTCUT_REQUEST,
	// Thread: worker -> ui
	INSTALL_MSG_CREATE_SHORTCUT_REPLY,
	// Thread: ui -> worker
	INSTALL_MSG_REMOVE_SHORTCUT_REQUEST,
	// Thread: worker -> ui
	INSTALL_MSG_REMOVE_SHORTCUT_REPLY,
	// Thread: ui -> worker
	INSTALL_MSG_REMOVE_DIR_REQUEST,
	// Thread: worker -> ui
	INSTALL_MSG_REMOVE_DIR_REPLY,
	// Thread: ui -> worker
	INSTALL_MSG_KILL_PROCESS_REQUEST,
	// Thread: worker -> ui
	INSTALL_MSG_KILL_PROCESS_REPLY,
	// Thread: ui -> worker
	INSTALL_MSG_DETECT_EXIST_INSTALL_REQUEST,
	// Thread: worker -> ui
	INSTALL_MSG_DETECT_EXIST_INSTALL_REPLY,
	// Thread: ui -> worker
	INSTALL_MSG_REMOVE_EXIST_INSTALL_REQUEST,
	// Thread: worker -> ui
	INSTALL_MSG_REMOVE_EXIST_INSTALL_REPLY,
	// Thread: ui -> worker
	INSTALL_MSG_UNPACK_RESOURCE_REQUEST,
	// Thread: worker -> ui
	INSTALL_MSG_UNPACK_RESOURCE_REPLY,
	// Thread: worker -> ui, worker blocked for CONFIRM
	INSTALL_MSG_ERROR_USER_CALLBACK,
	// Thread: ui -> worker, continue or abort
	INSTALL_MSG_ERROR_USER_ACTION,
	// Thread: ui -> worker
	INSTALL_MSG_GET_RUNNING_PROCESS_REQUEST,
	// Thread: worker -> ui
	INSTALL_MSG_GET_RUNNING_PROCESS_REPLY,
};
enum InstallErrorAction {
	INSTALL_ERR_RETRY,
	INSTALL_ERR_ABORT,
	INSTALL_ERR_CONTINUE,
};
struct InstallMessageBase {
	virtual ~InstallMessageBase() {}
	virtual InstallMessageType GetType() const = 0;
	UINT resource = 0;
	DWORD src_thread_id = 0;
	HWND src_hwnd = NULL;
};
struct ConnectNotify : InstallMessageBase {
	InstallMessageType GetType() const override { return INSTALL_MSG_CONNECT_NOTIFY; }
};
struct RunExeRequest : InstallMessageBase {
	String exe_filename;
	String target_dir;
	vector<wstring> arguments;
	InstallMessageType GetType() const override { return INSTALL_MSG_RUN_EXE_REQUEST; }
};
struct RunExeReply : InstallMessageBase {
	int status;
	DWORD exit_code;
	RunExeReply() : status(-1), exit_code(0) {}
	InstallMessageType GetType() const override { return INSTALL_MSG_RUN_EXE_REPLY; }
};
struct UnpackArchiveRequest : InstallMessageBase {
	String target_dir;
	InstallMessageType GetType() const override { return INSTALL_MSG_UNPACK_ARCHIVE_REQUEST; }
};
struct UnpackArchiveProgress : InstallMessageBase {
	double progress; // 0.0 ~ 1.0
	InstallMessageType GetType() const override { return INSTALL_MSG_UNPACK_ARCHIVE_PROGRESS; }
};
struct UnpackArchiveReply : InstallMessageBase {
	int status;
	UnpackArchiveReply() : status(-1) {}
	InstallMessageType GetType() const override { return INSTALL_MSG_UNPACK_ARCHIVE_REPLY; }
};
struct CreateShortcutRequest : InstallMessageBase {
	String target_dir;
	String product_name;
	String display_name;
	String product_version;
	String exe_filename;
	String uninstaller_filename;
	String publisher;
	optional<size_t> estimated_size;
	InstallMessageType GetType() const override { return INSTALL_MSG_CREATE_SHORTCUT_REQUEST; }
};
struct CreateShortcutReply : InstallMessageBase {
	int status;
	CreateShortcutReply() : status(-1) {}
	InstallMessageType GetType() const override { return INSTALL_MSG_CREATE_SHORTCUT_REPLY; }
};
struct RemoveDirRequest : InstallMessageBase {
	String target_dir;
	InstallMessageType GetType() const override { return INSTALL_MSG_REMOVE_DIR_REQUEST; }
};
struct RemoveDirReply : InstallMessageBase {
	int status;
	RemoveDirReply() : status(-1) {}
	InstallMessageType GetType() const override { return INSTALL_MSG_REMOVE_DIR_REPLY; }
};
struct RemoveShortcutRequest : InstallMessageBase {
	String product_name;
	String display_name;
	InstallMessageType GetType() const override { return INSTALL_MSG_REMOVE_SHORTCUT_REQUEST; }
};
struct RemoveShortcutReply : InstallMessageBase {
	int status;
	RemoveShortcutReply() : status(-1) {}
	InstallMessageType GetType() const override { return INSTALL_MSG_REMOVE_SHORTCUT_REPLY; }
};
struct KillProcessRequest : InstallMessageBase {
	vector<DWORD> process_ids;
	InstallMessageType GetType() const override { return INSTALL_MSG_KILL_PROCESS_REQUEST; }
};
struct KillProcessReply : InstallMessageBase {
	int status;
	KillProcessReply() : status(-1) {}
	InstallMessageType GetType() const override { return INSTALL_MSG_KILL_PROCESS_REPLY; }
};
struct GetRunningProcessRequest : InstallMessageBase {
	String product_name;
	vector<String> exe_filenames;
	InstallMessageType GetType() const override { return INSTALL_MSG_GET_RUNNING_PROCESS_REQUEST; }
};
struct GetRunningProcessReply : InstallMessageBase {
	vector<DWORD> process_ids;
	InstallMessageType GetType() const override { return INSTALL_MSG_GET_RUNNING_PROCESS_REPLY; }
};
struct DetectExistInstallRequest : InstallMessageBase {
	String program_files_dir_hint;
	String product_name;
    String display_name;
    String current_vcredist_version;
	InstallMessageType GetType() const override { return INSTALL_MSG_DETECT_EXIST_INSTALL_REQUEST; }
};
struct ExistInstallData {
	String product_name;
	String display_name;
	String target_dir;
	String version;
};
struct DetectExistInstallReply : InstallMessageBase {
    bool vcredist_installed;
	optional<ExistInstallData> chengxun_result;
    DetectExistInstallReply()
        : vcredist_installed(false) {}
	InstallMessageType GetType() const override { return INSTALL_MSG_DETECT_EXIST_INSTALL_REPLY; }
};

struct RemoveExistInstallRequest : InstallMessageBase {
	ExistInstallData data;
	InstallMessageType GetType() const override { return INSTALL_MSG_REMOVE_EXIST_INSTALL_REQUEST; }
};
struct RemoveExistInstallReply : InstallMessageBase {
	int status;
	RemoveExistInstallReply() : status(-1) {}
	InstallMessageType GetType() const override { return INSTALL_MSG_REMOVE_EXIST_INSTALL_REPLY; }
};
struct UnpackResourceRequest : InstallMessageBase {
	String filename;
	String target_dir;
	InstallMessageType GetType() const override { return INSTALL_MSG_UNPACK_RESOURCE_REQUEST; }
};
struct UnpackResourceReply : InstallMessageBase {
	int status;
	UnpackResourceReply() : status(-1) {}
	InstallMessageType GetType() const override { return INSTALL_MSG_UNPACK_RESOURCE_REPLY; }
};
struct ErrorUserCallback : InstallMessageBase {
	InstallMessageType request_msg_type;
	String detail;
	InstallMessageType GetType() const override { return INSTALL_MSG_ERROR_USER_CALLBACK; }
	ErrorUserCallback(InstallMessageType orig, const String& d)
		: request_msg_type(orig), detail(d) {}
};
struct ErrorUserAction : InstallMessageBase {
	InstallMessageType request_msg_type;
	InstallErrorAction action;
	InstallMessageType GetType() const override { return INSTALL_MSG_ERROR_USER_ACTION; }
	ErrorUserAction(InstallMessageType orig, InstallErrorAction a)
		: request_msg_type(orig), action(a) {}
};
#endif // INSTALL_MESSAGE_H
