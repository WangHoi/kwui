#ifndef SINGLE_INSTANCE_APPLICATION_H
#define SINGLE_INSTANCE_APPLICATION_H

#include "platform/platform_config.h"
#include "platform/windows/windows_header.h"
#include "string/String.h"

class SingleInstanceApplication {
public:
    SingleInstanceApplication(const String& unique_name);
    ~SingleInstanceApplication();

    inline bool IsLate() const { return _late_runner; }

private:
    HANDLE _mutex_handle;
    bool _late_runner;
};

#endif // SINGLE_INSTANCE_APPLICATION_H
