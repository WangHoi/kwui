#ifndef LOCAL_INSTALL_SERVICE_H
#define LOCAL_INSTALL_SERVICE_H
#include "pattern/singleton.h"
#include "data/data_helpers.h"
#include "string/String.h"
#include "memory/ResourceManager.h"
#include "InstallMessage.h"
#include "HiddenMsgWindow.h"

class LocalInstallService {
public:
	const String& GetTargetDir() const { return _target_dir; }
    void SetTargetDir(const String& dir);
	inline void SetProductName(const String& name) { SetProductName(name, name); }
	inline void SetProductName(const String& name, const String& display_name) {
		_product_name = name;
		_display_name = display_name;
	}
	inline void SetProductVersion(const String& version) { _product_version = version; }
    inline void SetVCRedistVersion(const String& version) { _vcredist_version = version; }
	// filename without directory
	inline void SetExeFilename(const String& filename) { _exe_filename = filename; }
	// filename without directory
	inline void SetUninstallerFilename(const String& filename) { _uninstaller_filename = filename; }
	inline void SetPublisher(const String& publisher) { _publisher = publisher; }
	inline void SetEstimatedSize(size_t size_kb) { _estimated_size_kb.emplace(size_kb); }
    
	void RunExe(const String& exe_filename,
				const Resource& exe,
				const vector<String>& args);
    void RunExe(const String& exe_filename,
                const vector<String>& args);
    void UnpackArchive(const Resource& data);
	// ����Դд�뵽��װĿ��Ŀ¼
	void UnpackResource(const String& filename, const Resource& data);
	void RemoveTargetDir();
	void CreateShortcut();
	void RemoveShortcut();
	bool CreateTargetDir();
	vector<DWORD> GetRunningProcess() const;
	void KillProcess(const vector<DWORD>& pid);
	void LaunchTargetExe();
	inline String GetProgramFilesDir() const { return _program_files_dir; }
	void DetectExistInstall();
	void RemoveExistInstall(const ExistInstallData& data);
    void DeleteUninstallerSelf();

	inline void SetListener(WindowMsgListener *listener) { _msg_window.SetListener(listener); }
	inline HWND GetMsgHwnd() const { return _msg_window.GetHwnd(); }
	
private:
	LocalInstallService();
    static DWORD WINAPI WorkerThreadFunc(LPVOID lpParam);
	static void StartWorker(InstallMessageBase* msg);
    static void DoRunExe(RunExeRequest& exe);
    static void DoUnpackArchive(UnpackArchiveRequest& req);
	static void DoCreateShortcut(CreateShortcutRequest& req);
	static void DoRemoveShortcut(RemoveShortcutRequest& req);
	static void DoRemoveDir(RemoveDirRequest& req);
	static void DoKillProcess(KillProcessRequest& req);
	static void DoDetectExistInstall(DetectExistInstallRequest& req);
	static void DoRemoveExistInstall(RemoveExistInstallRequest& req);
	static void DoUnpackResource(UnpackResourceRequest& req);
    String _target_dir;
	String _product_name;
	String _display_name;
	String _product_version;
    String _vcredist_version;
	String _exe_filename;
	String _uninstaller_filename;
	String _publisher;
	String _program_files_dir;
	optional<size_t> _estimated_size_kb;
	HiddenMsgWindow _msg_window;
    SUPPORT_SINGLETON(LocalInstallService)
};

#endif // LOCAL_INSTALL_SERVICE_H
