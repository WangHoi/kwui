#include "InstallTimer.h"
#include "platform/platform_config.h"
#include "platform/platform_helpers.h"

InstallTimer::InstallTimer() {
	_start_ts = get_timestamp();
}

double InstallTimer::Restart() {
	double new_ts = get_timestamp();
	double elapsed = new_ts - _start_ts;
	_start_ts = new_ts;
	return elapsed;
}

double InstallTimer::GetElapsed() const {
	return get_timestamp() - _start_ts;
}
