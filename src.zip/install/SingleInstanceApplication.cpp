#include "SingleInstanceApplication.h"
#include "platform/platform_helpers.h"

SingleInstanceApplication::SingleInstanceApplication(const String& unique_name)
    : _mutex_handle(NULL), _late_runner(false) {
    
    WCHAR mutex_name[MAX_PATH + 32] = {};
    swprintf(mutex_name, L"%S", unique_name.GetCString());
    _mutex_handle = CreateMutexW(NULL, TRUE, mutex_name);
    _late_runner = (GetLastError() == ERROR_ALREADY_EXISTS);
}
SingleInstanceApplication::~SingleInstanceApplication() {
    ReleaseMutex(_mutex_handle);
    CloseHandle(_mutex_handle);
}
