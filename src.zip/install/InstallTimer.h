#pragma once

class InstallTimer {
public:
	InstallTimer();
	double Restart();
	double GetElapsed() const;
private:
	double _start_ts;
};
